import { mysqlTable, varchar, timestamp, int, text, decimal } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

// Business settings
export const businessSettings = mysqlTable('business_settings', {
  id: int('id').primaryKey().autoincrement(),
  
  // Company info
  companyName: varchar('company_name', { length: 200 }),
  companyEmail: varchar('company_email', { length: 255 }),
  companyPhone: varchar('company_phone', { length: 20 }),
  companyAddress: text('company_address'),
  companyTaxId: varchar('company_tax_id', { length: 50 }),
  companyLogo: varchar('company_logo', { length: 500 }),
  
  // Currency and pricing
  currency: varchar('currency', { length: 3 }).default('PLN'),
  currencySymbol: varchar('currency_symbol', { length: 5 }).default('zł'),
  taxRate: decimal('tax_rate', { precision: 5, scale: 2 }).default('23'),
  
  // Default pricing
  defaultMarkupPercentage: decimal('default_markup_percentage', { precision: 5, scale: 2 }).default('50'),
  hourlyRate: decimal('hourly_rate', { precision: 10, scale: 2 }).default('50'),
  
  // Order settings
  orderPrefix: varchar('order_prefix', { length: 10 }).default('ORD'),
  nextOrderNumber: int('next_order_number').default(1000),
  
  // Print settings
  defaultInfill: int('default_infill').default(20),
  defaultLayerHeight: decimal('default_layer_height', { precision: 4, scale: 2 }).default('0.20'),
  defaultWallCount: int('default_wall_count').default(2),
  defaultTopBottomLayers: int('default_top_bottom_layers').default(4,
  ),
  
  // Notifications
  emailNotifications: int('email_notifications').default(1),
  smsNotifications: int('sms_notifications').default(0),
  
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// User preferences
export const userPreferences = mysqlTable('user_preferences', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('user_id').notNull().unique(),
  
  // UI preferences
  theme: varchar('theme', { length: 20 }).default('dark'),
  language: varchar('language', { length: 10 }).default('pl'),
  timezone: varchar('timezone', { length: 50 }).default('Europe/Warsaw'),
  dateFormat: varchar('date_format', { length: 20 }).default('DD.MM.YYYY'),
  timeFormat: varchar('time_format', { length: 10 }).default('24h'),
  
  // Dashboard
  dashboardLayout: text('dashboard_layout'),
  defaultPage: varchar('default_page', { length: 50 }).default('dashboard'),
  
  // Notifications
  emailNotificationsEnabled: int('email_notifications_enabled').default(1),
  orderStatusNotifications: int('order_status_notifications').default(1),
  lowStockNotifications: int('low_stock_notifications').default(1),
  maintenanceNotifications: int('maintenance_notifications').default(1),
  
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Zod schemas
export const insertBusinessSettingsSchema = createInsertSchema(businessSettings)
export const selectBusinessSettingsSchema = createSelectSchema(businessSettings)

export const insertUserPreferencesSchema = createInsertSchema(userPreferences)
export const selectUserPreferencesSchema = createSelectSchema(userPreferences)

// Types
export type BusinessSettings = typeof businessSettings.$inferSelect
export type NewBusinessSettings = typeof businessSettings.$inferInsert
export type UserPreferences = typeof userPreferences.$inferSelect
export type NewUserPreferences = typeof userPreferences.$inferInsert
