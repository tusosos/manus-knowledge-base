import { mysqlTable, varchar, timestamp, int, text, decimal } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { relations } from 'drizzle-orm'
import { orders } from './orders'

export const customers = mysqlTable('customers', {
  id: int('id').primaryKey().autoincrement(),
  companyName: varchar('company_name', { length: 200 }),
  firstName: varchar('first_name', { length: 100 }).notNull(),
  lastName: varchar('last_name', { length: 100 }).notNull(),
  email: varchar('email', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 20 }),
  address: text('address'),
  city: varchar('city', { length: 100 }),
  postalCode: varchar('postal_code', { length: 20 }),
  country: varchar('country', { length: 100 }),
  taxId: varchar('tax_id', { length: 50 }),
  notes: text('notes'),
  totalOrders: int('total_orders').default(0),
  totalRevenue: decimal('total_revenue', { precision: 12, scale: 2 }).default('0'),
  isActive: int('is_active').default(1).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Relations
export const customersRelations = relations(customers, ({ many }) => ({
  orders: many(orders),
}))

// Zod schemas
export const insertCustomerSchema = createInsertSchema(customers, {
  email: z.string().email(),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
})

export const selectCustomerSchema = createSelectSchema(customers)
export const updateCustomerSchema = insertCustomerSchema.partial()

// Types
export type Customer = typeof customers.$inferSelect
export type NewCustomer = typeof customers.$inferInsert
