import { mysqlTable, varchar, timestamp, int, text, decimal, mysqlEnum, date } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'
import { relations } from 'drizzle-orm'
import { customers } from './customers'

export const orders = mysqlTable('orders', {
  id: int('id').primaryKey().autoincrement(),
  orderNumber: varchar('order_number', { length: 50 }).notNull().unique(),
  customerId: int('customer_id').notNull(),
  status: mysqlEnum('status', [
    'pending',
    'confirmed',
    'in_production',
    'printing',
    'post_processing',
    'quality_check',
    'ready_for_pickup',
    'shipped',
    'delivered',
    'cancelled',
    'refunded'
  ]).default('pending').notNull(),
  priority: mysqlEnum('priority', ['low', 'normal', 'high', 'urgent']).default('normal').notNull(),
  
  // Financial fields
  subtotal: decimal('subtotal', { precision: 12, scale: 2 }).notNull(),
  taxRate: decimal('tax_rate', { precision: 5, scale: 2 }).default('0'),
  taxAmount: decimal('tax_amount', { precision: 12, scale: 2 }).default('0'),
  discountAmount: decimal('discount_amount', { precision: 12, scale: 2 }).default('0'),
  shippingCost: decimal('shipping_cost', { precision: 10, scale: 2 }).default('0'),
  totalAmount: decimal('total_amount', { precision: 12, scale: 2 }).notNull(),
  
  // Dates
  orderDate: timestamp('order_date').defaultNow().notNull(),
  dueDate: date('due_date'),
  completedAt: timestamp('completed_at'),
  shippedAt: timestamp('shipped_at'),
  deliveredAt: timestamp('delivered_at'),
  
  // Shipping
  shippingAddress: text('shipping_address'),
  shippingMethod: varchar('shipping_method', { length: 50 }),
  trackingNumber: varchar('tracking_number', { length: 100 }),
  
  // Notes
  customerNotes: text('customer_notes'),
  internalNotes: text('internal_notes'),
  
  // Metadata
  createdBy: int('created_by'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Relations
export const ordersRelations = relations(orders, ({ one }) => ({
  customer: one(customers, {
    fields: [orders.customerId],
    references: [customers.id],
  }),
}))

// Zod schemas
export const insertOrderSchema = createInsertSchema(orders)
export const selectOrderSchema = createSelectSchema(orders)
export const updateOrderSchema = insertOrderSchema.partial()

// Order status type
export const orderStatusSchema = z.enum([
  'pending',
  'confirmed',
  'in_production',
  'printing',
  'post_processing',
  'quality_check',
  'ready_for_pickup',
  'shipped',
  'delivered',
  'cancelled',
  'refunded'
])

export const orderPrioritySchema = z.enum(['low', 'normal', 'high', 'urgent'])

// Types
export type Order = typeof orders.$inferSelect
export type NewOrder = typeof orders.$inferInsert
export type OrderStatus = z.infer<typeof orderStatusSchema>
export type OrderPriority = z.infer<typeof orderPrioritySchema>
