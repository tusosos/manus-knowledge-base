import { mysqlTable, varchar, timestamp, int, text, decimal, mysqlEnum } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const products = mysqlTable('products', {
  id: int('id').primaryKey().autoincrement(),
  sku: varchar('sku', { length: 50 }).notNull().unique(),
  name: varchar('name', { length: 200 }).notNull(),
  description: text('description'),
  category: mysqlEnum('category', [
    'prototype',
    'functional_part',
    'artistic',
    'jewelry',
    'architectural',
    'mechanical',
    'custom',
    'other'
  ]).default('custom').notNull(),
  
  // Pricing
  basePrice: decimal('base_price', { precision: 10, scale: 2 }).notNull(),
  costPrice: decimal('cost_price', { precision: 10, scale: 2 }),
  
  // 3D Print specific
  estimatedPrintTime: int('estimated_print_time'), // in minutes
  estimatedMaterialWeight: decimal('estimated_material_weight', { precision: 10, scale: 2 }), // in grams
  defaultMaterialId: int('default_material_id'),
  defaultInfill: int('default_infill').default(20), // percentage
  defaultLayerHeight: decimal('default_layer_height', { precision: 4, scale: 2 }).default('0.20'), // mm
  
  // Files
  stlFileUrl: varchar('stl_file_url', { length: 500 }),
  previewImageUrl: varchar('preview_image_url', { length: 500 }),
  
  // Inventory
  isStockItem: int('is_stock_item').default(0),
  stockQuantity: int('stock_quantity').default(0),
  minStockLevel: int('min_stock_level').default(0),
  
  // Status
  isActive: int('is_active').default(1).notNull(),
  isCustomizable: int('is_customizable').default(0),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Zod schemas
export const insertProductSchema = createInsertSchema(products, {
  name: z.string().min(1),
  sku: z.string().min(1),
  basePrice: z.number().or(z.string()).transform((v) => Number(v)),
})

export const selectProductSchema = createSelectSchema(products)
export const updateProductSchema = insertProductSchema.partial()

// Product category type
export const productCategorySchema = z.enum([
  'prototype',
  'functional_part',
  'artistic',
  'jewelry',
  'architectural',
  'mechanical',
  'custom',
  'other'
])

// Types
export type Product = typeof products.$inferSelect
export type NewProduct = typeof products.$inferInsert
export type ProductCategory = z.infer<typeof productCategorySchema>
