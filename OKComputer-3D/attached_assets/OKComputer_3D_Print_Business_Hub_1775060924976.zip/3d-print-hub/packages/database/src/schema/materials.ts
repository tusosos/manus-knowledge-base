import { mysqlTable, varchar, timestamp, int, text, decimal, mysqlEnum } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const materials = mysqlTable('materials', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 100 }).notNull(),
  sku: varchar('sku', { length: 50 }).notNull().unique(),
  
  // Material properties
  type: mysqlEnum('type', [
    'pla',
    'abs',
    'petg',
    'tpu',
    'nylon',
    'pc',
    'asa',
    'hips',
    'pva',
    'resin_standard',
    'resin_tough',
    'resin_flexible',
    'resin_castable',
    'composite',
    'metal',
    'ceramic',
    'other'
  ]).notNull(),
  
  brand: varchar('brand', { length: 100 }),
  color: varchar('color', { length: 50 }),
  colorHex: varchar('color_hex', { length: 7 }),
  
  // Specifications
  diameter: decimal('diameter', { precision: 4, scale: 2 }).default('1.75'), // for FDM (mm)
  weight: decimal('weight', { precision: 8, scale: 2 }).default('1000'), // grams per spool/cartridge
  
  // Print settings defaults
  defaultNozzleTemp: int('default_nozzle_temp').default(200), // °C
  defaultBedTemp: int('default_bed_temp').default(60), // °C
  defaultPrintSpeed: int('default_print_speed').default(50), // mm/s
  
  // Pricing
  costPerKg: decimal('cost_per_kg', { precision: 10, scale: 2 }),
  sellingPricePerGram: decimal('selling_price_per_gram', { precision: 8, scale: 4 }),
  
  // Inventory
  stockQuantity: decimal('stock_quantity', { precision: 10, scale: 2 }).default('0'),
  minStockLevel: decimal('min_stock_level', { precision: 10, scale: 2 }).default('0'),
  
  // Status
  isActive: int('is_active').default(1).notNull(),
  isFavorite: int('is_favorite').default(0),
  
  description: text('description'),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Material presets for different printers/material combinations
export const materialPresets = mysqlTable('material_presets', {
  id: int('id').primaryKey().autoincrement(),
  materialId: int('material_id').notNull(),
  printerId: int('printer_id'),
  
  name: varchar('name', { length: 100 }).notNull(),
  
  // Temperatures
  nozzleTemp: int('nozzle_temp').notNull(),
  bedTemp: int('bed_temp'),
  chamberTemp: int('chamber_temp'),
  
  // Speeds
  printSpeed: int('print_speed').default(50),
  firstLayerSpeed: int('first_layer_speed').default(20),
  travelSpeed: int('travel_speed').default(150),
  
  // Retraction
  retractionDistance: decimal('retraction_distance', { precision: 5, scale: 2 }).default('6'),
  retractionSpeed: int('retraction_speed').default(25),
  
  // Cooling
  fanSpeed: int('fan_speed').default(100),
  firstLayerFanSpeed: int('first_layer_fan_speed').default(0),
  
  // Advanced
  flowRate: int('flow_rate').default(100), // percentage
  pressureAdvance: decimal('pressure_advance', { precision: 5, scale: 3 }),
  
  notes: text('notes'),
  isDefault: int('is_default').default(0),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Zod schemas
export const insertMaterialSchema = createInsertSchema(materials)
export const selectMaterialSchema = createSelectSchema(materials)
export const updateMaterialSchema = insertMaterialSchema.partial()

export const insertMaterialPresetSchema = createInsertSchema(materialPresets)
export const selectMaterialPresetSchema = createSelectSchema(materialPresets)

// Material type enum
export const materialTypeSchema = z.enum([
  'pla',
  'abs',
  'petg',
  'tpu',
  'nylon',
  'pc',
  'asa',
  'hips',
  'pva',
  'resin_standard',
  'resin_tough',
  'resin_flexible',
  'resin_castable',
  'composite',
  'metal',
  'ceramic',
  'other'
])

// Types
export type Material = typeof materials.$inferSelect
export type NewMaterial = typeof materials.$inferInsert
export type MaterialPreset = typeof materialPresets.$inferSelect
export type NewMaterialPreset = typeof materialPresets.$inferInsert
export type MaterialType = z.infer<typeof materialTypeSchema>
