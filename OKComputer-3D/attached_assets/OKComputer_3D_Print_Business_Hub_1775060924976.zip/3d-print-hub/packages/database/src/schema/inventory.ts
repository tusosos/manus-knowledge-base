import { mysqlTable, varchar, timestamp, int, text, decimal, mysqlEnum } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const inventoryItems = mysqlTable('inventory_items', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 200 }).notNull(),
  sku: varchar('sku', { length: 50 }).notNull().unique(),
  description: text('description'),
  category: mysqlEnum('category', [
    'filament',
    'resin',
    'nozzle',
    'build_plate',
    'tool',
    'spare_part',
    'packaging',
    'consumable',
    'other'
  ]).notNull(),
  
  // Stock
  quantity: decimal('quantity', { precision: 12, scale: 3 }).default('0').notNull(),
  unit: varchar('unit', { length: 20 }).notNull(), // kg, g, pcs, m, etc.
  minStockLevel: decimal('min_stock_level', { precision: 12, scale: 3 }).default('0'),
  maxStockLevel: decimal('max_stock_level', { precision: 12, scale: 3 }),
  reorderPoint: decimal('reorder_point', { precision: 12, scale: 3 }),
  
  // Location
  location: varchar('location', { length: 100 }),
  binNumber: varchar('bin_number', { length: 50 }),
  
  // Pricing
  unitCost: decimal('unit_cost', { precision: 10, scale: 2 }),
  supplierId: int('supplier_id'),
  
  // For filaments/materials
  color: varchar('color', { length: 50 }),
  materialType: varchar('material_type', { length: 50 }), // PLA, ABS, PETG, etc.
  diameter: decimal('diameter', { precision: 4, scale: 2 }), // for filament
  
  // Tracking
  isActive: int('is_active').default(1).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Inventory transactions
export const inventoryTransactions = mysqlTable('inventory_transactions', {
  id: int('id').primaryKey().autoincrement(),
  itemId: int('item_id').notNull(),
  type: mysqlEnum('type', [
    'purchase',
    'consumption',
    'adjustment',
    'return',
    'transfer_in',
    'transfer_out',
    'waste'
  ]).notNull(),
  quantity: decimal('quantity', { precision: 12, scale: 3 }).notNull(),
  unitCost: decimal('unit_cost', { precision: 10, scale: 2 }),
  totalCost: decimal('total_cost', { precision: 12, scale: 2 }),
  
  // Reference
  referenceType: varchar('reference_type', { length: 50 }), // order, purchase_order, adjustment
  referenceId: int('reference_id'),
  
  // Notes
  notes: text('notes'),
  performedBy: int('performed_by'),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// Zod schemas
export const insertInventoryItemSchema = createInsertSchema(inventoryItems)
export const selectInventoryItemSchema = createSelectSchema(inventoryItems)
export const updateInventoryItemSchema = insertInventoryItemSchema.partial()

export const insertInventoryTransactionSchema = createInsertSchema(inventoryTransactions)
export const selectInventoryTransactionSchema = createSelectSchema(inventoryTransactions)

// Types
export type InventoryItem = typeof inventoryItems.$inferSelect
export type NewInventoryItem = typeof inventoryItems.$inferInsert
export type InventoryTransaction = typeof inventoryTransactions.$inferSelect
export type NewInventoryTransaction = typeof inventoryTransactions.$inferInsert
