import { mysqlTable, varchar, timestamp, int, text, decimal, mysqlEnum } from 'drizzle-orm/mysql-core'
import { createInsertSchema, createSelectSchema } from 'drizzle-zod'
import { z } from 'zod'

export const printers = mysqlTable('printers', {
  id: int('id').primaryKey().autoincrement(),
  name: varchar('name', { length: 100 }).notNull(),
  model: varchar('model', { length: 100 }).notNull(),
  manufacturer: varchar('manufacturer', { length: 100 }),
  serialNumber: varchar('serial_number', { length: 100 }),
  
  // Specifications
  technology: mysqlEnum('technology', [
    'fdm',
    'sla',
    'dlp',
    'lcd',
    'sls',
    'mjf',
    'polyjet',
    'other'
  ]).notNull(),
  buildVolumeX: decimal('build_volume_x', { precision: 8, scale: 2 }), // mm
  buildVolumeY: decimal('build_volume_y', { precision: 8, scale: 2 }), // mm
  buildVolumeZ: decimal('build_volume_z', { precision: 8, scale: 2 }), // mm
  maxNozzleTemp: int('max_nozzle_temp'), // °C
  maxBedTemp: int('max_bed_temp'), // °C
  
  // Status
  status: mysqlEnum('status', [
    'idle',
    'printing',
    'paused',
    'finished',
    'error',
    'maintenance',
    'offline'
  ]).default('idle').notNull(),
  
  // Current job
  currentJobId: int('current_job_id'),
  currentProgress: decimal('current_progress', { precision: 5, scale: 2 }).default('0'),
  estimatedTimeRemaining: int('estimated_time_remaining'), // minutes
  
  // Maintenance
  totalPrintTime: int('total_print_time').default(0), // hours
  lastMaintenanceAt: timestamp('last_maintenance_at'),
  nextMaintenanceAt: timestamp('next_maintenance_at'),
  maintenanceNotes: text('maintenance_notes'),
  
  // Location
  location: varchar('location', { length: 100 }),
  
  // Configuration
  ipAddress: varchar('ip_address', { length: 50 }),
  apiKey: varchar('api_key', { length: 255 }),
  
  isActive: int('is_active').default(1).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Print jobs
export const printJobs = mysqlTable('print_jobs', {
  id: int('id').primaryKey().autoincrement(),
  jobNumber: varchar('job_number', { length: 50 }).notNull().unique(),
  printerId: int('printer_id').notNull(),
  orderId: int('order_id'),
  orderItemId: int('order_item_id'),
  
  // Job details
  name: varchar('name', { length: 200 }).notNull(),
  status: mysqlEnum('status', [
    'queued',
    'preparing',
    'printing',
    'paused',
    'completed',
    'failed',
    'cancelled'
  ]).default('queued').notNull(),
  
  // Progress
  progress: decimal('progress', { precision: 5, scale: 2 }).default('0'),
  totalLayers: int('total_layers'),
  currentLayer: int('current_layer'),
  
  // Time tracking
  estimatedDuration: int('estimated_duration'), // minutes
  actualDuration: int('actual_duration'), // minutes
  startedAt: timestamp('started_at'),
  completedAt: timestamp('completed_at'),
  
  // Material usage
  materialId: int('material_id'),
  materialUsed: decimal('material_used', { precision: 10, scale: 2 }), // grams
  
  // Files
  gcodeFileUrl: varchar('gcode_file_url', { length: 500 }),
  
  // Results
  printQuality: mysqlEnum('print_quality', ['excellent', 'good', 'acceptable', 'poor', 'failed']),
  notes: text('notes'),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().onUpdateNow().notNull(),
})

// Zod schemas
export const insertPrinterSchema = createInsertSchema(printers)
export const selectPrinterSchema = createSelectSchema(printers)
export const updatePrinterSchema = insertPrinterSchema.partial()

export const insertPrintJobSchema = createInsertSchema(printJobs)
export const selectPrintJobSchema = createSelectSchema(printJobs)

// Types
export type Printer = typeof printers.$inferSelect
export type NewPrinter = typeof printers.$inferInsert
export type PrintJob = typeof printJobs.$inferSelect
export type NewPrintJob = typeof printJobs.$inferInsert

export type PrinterTechnology = 'fdm' | 'sla' | 'dlp' | 'lcd' | 'sls' | 'mjf' | 'polyjet' | 'other'
export type PrinterStatus = 'idle' | 'printing' | 'paused' | 'finished' | 'error' | 'maintenance' | 'offline'
export type PrintJobStatus = 'queued' | 'preparing' | 'printing' | 'paused' | 'completed' | 'failed' | 'cancelled'
