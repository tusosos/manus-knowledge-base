import { drizzle } from 'drizzle-orm/mysql2'
import mysql from 'mysql2/promise'
import * as schema from './schema'

// Create database connection pool
const createPool = () => {
  return mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306'),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || '3d_print_hub',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
  })
}

// Initialize Drizzle ORM
const pool = createPool()
export const db = drizzle(pool, { schema, mode: 'default' })

// Export schema
export * from './schema'

// Export types
export type Database = typeof db

// Helper function to check database connection
export async function checkConnection(): Promise<boolean> {
  try {
    const connection = await pool.getConnection()
    connection.release()
    return true
  } catch (error) {
    console.error('Database connection failed:', error)
    return false
  }
}

// Helper function to close pool
export async function closePool(): Promise<void> {
  await pool.end()
}
