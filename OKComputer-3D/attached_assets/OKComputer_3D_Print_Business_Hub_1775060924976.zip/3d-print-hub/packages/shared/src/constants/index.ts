// Order statuses
export const ORDER_STATUSES = [
  'pending',
  'confirmed',
  'in_production',
  'printing',
  'post_processing',
  'quality_check',
  'ready_for_pickup',
  'shipped',
  'delivered',
  'cancelled',
  'refunded',
] as const

export type OrderStatus = (typeof ORDER_STATUSES)[number]

// Order priorities
export const ORDER_PRIORITIES = ['low', 'normal', 'high', 'urgent'] as const
export type OrderPriority = (typeof ORDER_PRIORITIES)[number]

// Printer statuses
export const PRINTER_STATUSES = [
  'idle',
  'printing',
  'paused',
  'finished',
  'error',
  'maintenance',
  'offline',
] as const

export type PrinterStatus = (typeof PRINTER_STATUSES)[number]

// Print job statuses
export const PRINT_JOB_STATUSES = [
  'queued',
  'preparing',
  'printing',
  'paused',
  'completed',
  'failed',
  'cancelled',
] as const

export type PrintJobStatus = (typeof PRINT_JOB_STATUSES)[number]

// Material types
export const MATERIAL_TYPES = [
  'pla',
  'abs',
  'petg',
  'tpu',
  'nylon',
  'pc',
  'asa',
  'hips',
  'pva',
  'resin_standard',
  'resin_tough',
  'resin_flexible',
  'resin_castable',
  'composite',
  'metal',
  'ceramic',
  'other',
] as const

export type MaterialType = (typeof MATERIAL_TYPES)[number]

// Printer technologies
export const PRINTER_TECHNOLOGIES = [
  'fdm',
  'sla',
  'dlp',
  'lcd',
  'sls',
  'mjf',
  'polyjet',
  'other',
] as const

export type PrinterTechnology = (typeof PRINTER_TECHNOLOGIES)[number]

// Product categories
export const PRODUCT_CATEGORIES = [
  'prototype',
  'functional_part',
  'artistic',
  'jewelry',
  'architectural',
  'mechanical',
  'custom',
  'other',
] as const

export type ProductCategory = (typeof PRODUCT_CATEGORIES)[number]

// Inventory categories
export const INVENTORY_CATEGORIES = [
  'filament',
  'resin',
  'nozzle',
  'build_plate',
  'tool',
  'spare_part',
  'packaging',
  'consumable',
  'other',
] as const

export type InventoryCategory = (typeof INVENTORY_CATEGORIES)[number]

// User roles
export const USER_ROLES = ['admin', 'manager', 'operator', 'viewer'] as const
export type UserRole = (typeof USER_ROLES)[number]

// Transaction types
export const TRANSACTION_TYPES = [
  'purchase',
  'consumption',
  'adjustment',
  'return',
  'transfer_in',
  'transfer_out',
  'waste',
] as const

export type TransactionType = (typeof TRANSACTION_TYPES)[number]

// Default print settings
export const DEFAULT_PRINT_SETTINGS = {
  infill: 20,
  layerHeight: 0.2,
  wallCount: 2,
  topBottomLayers: 4,
  printSpeed: 50,
  nozzleTemp: 200,
  bedTemp: 60,
  fanSpeed: 100,
} as const

// Material temperature ranges
export const MATERIAL_TEMP_RANGES: Record<
  string,
  { nozzle: [number, number]; bed: [number, number] }
> = {
  pla: { nozzle: [190, 220], bed: [50, 70] },
  abs: { nozzle: [230, 250], bed: [90, 110] },
  petg: { nozzle: [230, 250], bed: [70, 90] },
  tpu: { nozzle: [210, 230], bed: [40, 60] },
  nylon: { nozzle: [240, 260], bed: [70, 90] },
  pc: { nozzle: [260, 290], bed: [100, 120] },
  asa: { nozzle: [240, 260], bed: [90, 110] },
  hips: { nozzle: [230, 250], bed: [90, 110] },
  pva: { nozzle: [190, 210], bed: [50, 70] },
}

// Pagination defaults
export const PAGINATION_DEFAULTS = {
  page: 1,
  limit: 20,
  maxLimit: 100,
} as const

// Date formats
export const DATE_FORMATS = {
  display: 'DD.MM.YYYY',
  displayWithTime: 'DD.MM.YYYY HH:mm',
  iso: 'YYYY-MM-DD',
  isoWithTime: 'YYYY-MM-DDTHH:mm:ss',
} as const

// Currency defaults
export const CURRENCY_DEFAULTS = {
  code: 'PLN',
  symbol: 'zł',
  locale: 'pl-PL',
} as const

// Tax defaults
export const TAX_DEFAULTS = {
  rate: 23, // Polish VAT
} as const

// File upload limits
export const UPLOAD_LIMITS = {
  maxFileSize: 50 * 1024 * 1024, // 50MB
  allowedStlExtensions: ['.stl', '.obj', '.3mf', '.ply'],
  allowedGcodeExtensions: ['.gcode', '.g', '.gc'],
  allowedImageExtensions: ['.jpg', '.jpeg', '.png', '.webp'],
} as const

// Print quality ratings
export const PRINT_QUALITY_RATINGS = [
  'excellent',
  'good',
  'acceptable',
  'poor',
  'failed',
] as const

export type PrintQualityRating = (typeof PRINT_QUALITY_RATINGS)[number]

// Notification types
export const NOTIFICATION_TYPES = ['info', 'success', 'warning', 'error'] as const
export type NotificationType = (typeof NOTIFICATION_TYPES)[number]

// Theme options
export const THEME_OPTIONS = ['light', 'dark', 'system'] as const
export type ThemeOption = (typeof THEME_OPTIONS)[number]

// Language options
export const LANGUAGE_OPTIONS = [
  { code: 'pl', name: 'Polski', flag: '🇵🇱' },
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
] as const

export type LanguageCode = (typeof LANGUAGE_OPTIONS)[number]['code']

// Status colors for UI
export const STATUS_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  pending: { bg: 'bg-amber-500/20', text: 'text-amber-400', border: 'border-amber-500/30' },
  confirmed: { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/30' },
  in_production: { bg: 'bg-purple-500/20', text: 'text-purple-400', border: 'border-purple-500/30' },
  printing: { bg: 'bg-cyan-500/20', text: 'text-cyan-400', border: 'border-cyan-500/30' },
  post_processing: { bg: 'bg-indigo-500/20', text: 'text-indigo-400', border: 'border-indigo-500/30' },
  quality_check: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', border: 'border-yellow-500/30' },
  ready_for_pickup: { bg: 'bg-teal-500/20', text: 'text-teal-400', border: 'border-teal-500/30' },
  shipped: { bg: 'bg-sky-500/20', text: 'text-sky-400', border: 'border-sky-500/30' },
  delivered: { bg: 'bg-green-500/20', text: 'text-green-400', border: 'border-green-500/30' },
  cancelled: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/30' },
  refunded: { bg: 'bg-gray-500/20', text: 'text-gray-400', border: 'border-gray-500/30' },
  idle: { bg: 'bg-green-500/20', text: 'text-green-400', border: 'border-green-500/30' },
  finished: { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/30' },
  error: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/30' },
  maintenance: { bg: 'bg-orange-500/20', text: 'text-orange-400', border: 'border-orange-500/30' },
  offline: { bg: 'bg-gray-500/20', text: 'text-gray-400', border: 'border-gray-500/30' },
}

// Priority colors
export const PRIORITY_COLORS: Record<string, { bg: string; text: string }> = {
  low: { bg: 'bg-gray-500/20', text: 'text-gray-400' },
  normal: { bg: 'bg-blue-500/20', text: 'text-blue-400' },
  high: { bg: 'bg-orange-500/20', text: 'text-orange-400' },
  urgent: { bg: 'bg-red-500/20', text: 'text-red-400' },
}

// API routes
export const API_ROUTES = {
  auth: {
    login: '/auth/login',
    logout: '/auth/logout',
    refresh: '/auth/refresh',
    me: '/auth/me',
  },
  users: {
    base: '/users',
    byId: (id: number) => `/users/${id}`,
  },
  customers: {
    base: '/customers',
    byId: (id: number) => `/customers/${id}`,
  },
  orders: {
    base: '/orders',
    byId: (id: number) => `/orders/${id}`,
    items: (id: number) => `/orders/${id}/items`,
  },
  products: {
    base: '/products',
    byId: (id: number) => `/products/${id}`,
  },
  inventory: {
    base: '/inventory',
    byId: (id: number) => `/inventory/${id}`,
    transactions: '/inventory/transactions',
  },
  printers: {
    base: '/printers',
    byId: (id: number) => `/printers/${id}`,
    jobs: (id: number) => `/printers/${id}/jobs`,
  },
  materials: {
    base: '/materials',
    byId: (id: number) => `/materials/${id}`,
  },
  settings: {
    base: '/settings',
    business: '/settings/business',
    preferences: '/settings/preferences',
  },
  dashboard: {
    stats: '/dashboard/stats',
    chart: '/dashboard/chart',
  },
} as const

// Local storage keys
export const STORAGE_KEYS = {
  authToken: '3dph_auth_token',
  refreshToken: '3dph_refresh_token',
  user: '3dph_user',
  theme: '3dph_theme',
  language: '3dph_language',
  sidebarCollapsed: '3dph_sidebar_collapsed',
  dashboardLayout: '3dph_dashboard_layout',
} as const
