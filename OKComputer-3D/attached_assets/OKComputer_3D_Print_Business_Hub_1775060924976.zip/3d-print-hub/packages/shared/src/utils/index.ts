import { type ClassValue, clsx } from 'clsx'

// Format currency
export function formatCurrency(
  amount: number,
  currency: string = 'PLN',
  locale: string = 'pl-PL'
): string {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

// Format number
export function formatNumber(
  value: number,
  decimals: number = 0,
  locale: string = 'pl-PL'
): string {
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
}

// Format date
export function formatDate(
  date: Date | string | number,
  options: Intl.DateTimeFormatOptions = {},
  locale: string = 'pl-PL'
): string {
  const defaultOptions: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    ...options,
  }
  return new Intl.DateTimeFormat(locale, defaultOptions).format(new Date(date))
}

// Format date and time
export function formatDateTime(
  date: Date | string | number,
  locale: string = 'pl-PL'
): string {
  return formatDate(date, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }, locale)
}

// Format duration (minutes to hours and minutes)
export function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  
  if (hours === 0) {
    return `${mins}m`
  }
  if (mins === 0) {
    return `${hours}h`
  }
  return `${hours}h ${mins}m`
}

// Format weight (grams to kg if needed)
export function formatWeight(grams: number): string {
  if (grams >= 1000) {
    return `${(grams / 1000).toFixed(2)} kg`
  }
  return `${grams.toFixed(1)} g`
}

// Truncate text
export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength) + '...'
}

// Generate order number
export function generateOrderNumber(prefix: string = 'ORD', nextNumber: number = 1000): string {
  const timestamp = Date.now().toString(36).toUpperCase()
  return `${prefix}-${nextNumber}-${timestamp.slice(-4)}`
}

// Generate SKU
export function generateSKU(
  category: string,
  material: string,
  color: string,
  sequence: number
): string {
  const cat = category.slice(0, 3).toUpperCase()
  const mat = material.slice(0, 3).toUpperCase()
  const col = color.slice(0, 3).toUpperCase()
  const seq = sequence.toString().padStart(4, '0')
  return `${cat}-${mat}-${col}-${seq}`
}

// Calculate print cost
export function calculatePrintCost(
  materialWeight: number, // grams
  materialCostPerGram: number,
  printTimeMinutes: number,
  hourlyRate: number,
  markupPercentage: number = 50
): { subtotal: number; total: number } {
  const materialCost = materialWeight * materialCostPerGram
  const laborCost = (printTimeMinutes / 60) * hourlyRate
  const subtotal = materialCost + laborCost
  const markup = subtotal * (markupPercentage / 100)
  const total = subtotal + markup
  
  return {
    subtotal: Math.round(subtotal * 100) / 100,
    total: Math.round(total * 100) / 100,
  }
}

// Debounce function
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null
  
  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

// Throttle function
export function throttle<T extends (...args: unknown[]) => unknown>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle = false
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

// Deep clone
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj))
}

// Group array by key
export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce((result, item) => {
    const groupKey = String(item[key])
    if (!result[groupKey]) {
      result[groupKey] = []
    }
    result[groupKey].push(item)
    return result
  }, {} as Record<string, T[]>)
}

// Sort array by key
export function sortBy<T>(
  array: T[],
  key: keyof T,
  order: 'asc' | 'desc' = 'asc'
): T[] {
  return [...array].sort((a, b) => {
    const aVal = a[key]
    const bVal = b[key]
    
    if (aVal < bVal) return order === 'asc' ? -1 : 1
    if (aVal > bVal) return order === 'asc' ? 1 : -1
    return 0
  })
}

// Calculate percentage
export function calculatePercentage(value: number, total: number): number {
  if (total === 0) return 0
  return Math.round((value / total) * 100 * 100) / 100
}

// Validate email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Validate phone number (Polish format)
export function isValidPhone(phone: string): boolean {
  const phoneRegex = /^(?:(?:\+|00)48)?\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{3}$/
  return phoneRegex.test(phone.replace(/\s/g, ''))
}

// Sleep utility
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// Generate random ID
export function generateId(length: number = 8): string {
  return Math.random()
    .toString(36)
    .substring(2, 2 + length)
    .toUpperCase()
}

// Parse query params
export function parseQueryParams(
  params: Record<string, string | string[] | undefined>
): Record<string, unknown> {
  const result: Record<string, unknown> = {}
  
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined) continue
    
    if (Array.isArray(value)) {
      result[key] = value
    } else if (value === 'true') {
      result[key] = true
    } else if (value === 'false') {
      result[key] = false
    } else if (!isNaN(Number(value)) && value !== '') {
      result[key] = Number(value)
    } else {
      result[key] = value
    }
  }
  
  return result
}
