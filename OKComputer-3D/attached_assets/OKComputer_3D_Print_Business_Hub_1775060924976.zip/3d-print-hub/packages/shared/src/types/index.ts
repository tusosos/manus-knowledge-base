import { z } from 'zod'

// Common pagination types
export const paginationSchema = z.object({
  page: z.number().min(1).default(1),
  limit: z.number().min(1).max(100).default(20),
})

export const paginationMetaSchema = z.object({
  page: z.number(),
  limit: z.number(),
  total: z.number(),
  totalPages: z.number(),
  hasNext: z.boolean(),
  hasPrev: z.boolean(),
})

export type Pagination = z.infer<typeof paginationSchema>
export type PaginationMeta = z.infer<typeof paginationMetaSchema>

// API Response types
export const apiResponseSchema = <T extends z.ZodType>(dataSchema: T) =>
  z.object({
    success: z.boolean(),
    data: dataSchema.optional(),
    error: z.string().optional(),
    message: z.string().optional(),
    meta: paginationMetaSchema.optional(),
  })

export type ApiResponse<T> = {
  success: boolean
  data?: T
  error?: string
  message?: string
  meta?: PaginationMeta
}

// Sorting types
export const sortOrderSchema = z.enum(['asc', 'desc'])
export type SortOrder = z.infer<typeof sortOrderSchema>

export interface SortConfig {
  field: string
  order: SortOrder
}

// Filter types
export const filterOperatorSchema = z.enum([
  'eq',
  'neq',
  'gt',
  'gte',
  'lt',
  'lte',
  'contains',
  'startsWith',
  'endsWith',
  'in',
  'between',
])

export type FilterOperator = z.infer<typeof filterOperatorSchema>

export interface FilterConfig {
  field: string
  operator: FilterOperator
  value: unknown
}

// Date range type
export const dateRangeSchema = z.object({
  from: z.date().optional(),
  to: z.date().optional(),
})

export type DateRange = z.infer<typeof dateRangeSchema>

// Common status types
export const entityStatusSchema = z.enum(['active', 'inactive', 'archived'])
export type EntityStatus = z.infer<typeof entityStatusSchema>

// User role type
export const userRoleSchema = z.enum(['admin', 'manager', 'operator', 'viewer'])
export type UserRole = z.infer<typeof userRoleSchema>

// Notification type
export interface Notification {
  id: string
  type: 'info' | 'success' | 'warning' | 'error'
  title: string
  message: string
  read: boolean
  createdAt: Date
}

// Dashboard stats type
export interface DashboardStats {
  totalOrders: number
  pendingOrders: number
  printingOrders: number
  completedOrdersToday: number
  revenueToday: number
  revenueThisMonth: number
  activePrinters: number
  lowStockItems: number
}

// Chart data type
export interface ChartDataPoint {
  label: string
  value: number
  date?: Date
}

export interface ChartSeries {
  name: string
  data: ChartDataPoint[]
  color?: string
}
