# 🖨️ 3D Print Business Hub

<p align="center">
  <img src="https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white&style=for-the-badge" alt="React 19">
  <img src="https://img.shields.io/badge/TypeScript-5.0-3178C6?logo=typescript&logoColor=white&style=for-the-badge" alt="TypeScript">
  <img src="https://img.shields.io/badge/Tailwind%20CSS-4-06B6D4?logo=tailwindcss&logoColor=white&style=for-the-badge" alt="Tailwind CSS">
  <img src="https://img.shields.io/badge/tRPC-10-2596BE?logo=trpc&logoColor=white&style=for-the-badge" alt="tRPC">
  <img src="https://img.shields.io/badge/Drizzle-ORM-C5F74F?logo=drizzle&logoColor=black&style=for-the-badge" alt="Drizzle ORM">
</p>

<p align="center">
  <strong>Profesjonalna aplikacja do zarządzania biznesem druku 3D</strong>
</p>

<p align="center">
  <a href="#-funkcjonalności">Funkcjonalności</a> •
  <a href="#-technologie">Technologie</a> •
  <a href="#-instalacja">Instalacja</a> •
  <a href="#-struktura-projektu">Struktura</a> •
  <a href="#-licencja">Licencja</a>
</p>

---

## ✨ Funkcjonalności

3D Print Business Hub to kompleksowe rozwiązanie do zarządzania firmą oferującą usługi druku 3D. Aplikacja zawiera **18 zaawansowanych modułów**:

### 📊 Zarządzanie & Dashboard

| Moduł | Opis |
|-------|------|
| **📈 Dashboard z KPI** | Interaktywny panel z kluczowymi wskaźnikami wydajności, statystykami sprzedaży i produkcji w czasie rzeczywistym |
| **📋 Kanban Taski** | System zarządzania zadaniami w stylu Kanban z przeciąganiem kart, etykietami i priorytetami |
| **🎯 Projekty 3D** | Kompletne zarządzanie projektami druku 3D z historią, wersjami i załącznikami |

### 💰 Finanse & Wyceny

| Moduł | Opis |
|-------|------|
| **🧮 Kalkulator kosztów** | Precyzyjny kalkulator kosztów druku uwzględniający filament, czas, energię i amortyzację |
| **📄 Generator wycen PDF** | Automatyczne generowanie profesjonalnych ofert i faktur w formacie PDF |
| **📊 Analityka sprzedaży** | Szczegółowe raporty sprzedaży z wykresami, trendami i prognozami |
| **🏆 Bestsellery** | Analiza najpopularniejszych produktów i usług z rekomendacjami |
| **📈 Biznesplan** | Narzędzie do tworzenia i śledzenia celów biznesowych z prognozami finansowymi |
| **📦 Kalkulator wysyłki** | Obliczanie kosztów wysyłki dla różnych przewoźników i lokalizacji |
| **💼 Generator ofert** | Szybkie tworzenie spersonalizowanych ofert handlowych dla klientów |

### 🏭 Produkcja & Magazyn

| Moduł | Opis |
|-------|------|
| **🧵 Magazyn filamentów** | Zarządzanie zapasami filamentów z alertami o niskim stanie i datami ważności |
| **🖨️ Kolejka druku** | Inteligentna kolejka druku z optymalizacją czasu i priorytetowaniem zadań |
| **🎨 Planner multicolor** | Planowanie wydruków wielokolorowych z zarządzaniem zmianami filamentu |
| **🔧 Profil H2D** | Konfiguracja i zarządzanie profilami drukarek Bambu Lab H2D |

### 👥 Klienci & Marketing

| Moduł | Opis |
|-------|------|
| **👤 Baza klientów** | CRM z historią zamówień, notatkami i segmentacją klientów |
| **🔍 Analiza konkurencji** | Narzędzie do monitorowania cen i ofert konkurencji |
| **💡 Centrum wiedzy** | Baza wiedzy z poradnikami, FAQ i dokumentacją techniczną |
| **🏷️ Okazje filamenty** | Śledzenie promocji i okazji cenowych na filamenty z różnych sklepów |

---

## 🛠️ Technologie

### Frontend

| Technologia | Wersja | Opis |
|-------------|--------|------|
| **React** | 19 | Biblioteka UI z najnowszymi funkcjami |
| **TypeScript** | 5.0 | Typowanie statyczne dla bezpieczeństwa kodu |
| **Tailwind CSS** | 4 | Utility-first framework CSS |
| **shadcn/ui** | latest | Komponenty UI współdzielone i dostosowywalne |
| **Wouter** | latest | Lekki router dla React |
| **Framer Motion** | latest | Animacje i gesty |

### Backend

| Technologia | Wersja | Opis |
|-------------|--------|------|
| **Express** | 4.x | Framework webowy Node.js |
| **tRPC** | 10 | Type-safe API endpoints |
| **Drizzle ORM** | latest | Type-safe ORM dla SQL |
| **MySQL/TiDB** | 8.0 | Relacyjna baza danych |

### Biblioteki dodatkowe

| Biblioteka | Zastosowanie |
|------------|--------------|
| **Recharts** | Wykresy i wizualizacje danych |
| **jsPDF** | Generowanie dokumentów PDF |
| **Lucide React** | Ikony SVG |
| **date-fns** | Manipulacja datami |
| **Zod** | Walidacja schematów |

---

## 🚀 Instalacja

### Wymagania wstępne

- Node.js 20+
- MySQL 8.0+ lub TiDB
- npm lub yarn

### Krok po kroku

```bash
# 1. Klonowanie repozytorium
git clone https://github.com/yourusername/3d-print-business-hub.git
cd 3d-print-business-hub

# 2. Instalacja zależności
npm install

# 3. Konfiguracja zmiennych środowiskowych
cp .env.example .env
# Edytuj .env i ustaw swoje dane:
# - DATABASE_URL
# - JWT_SECRET
# - SMTP_* (opcjonalnie dla maili)

# 4. Migracja bazy danych
npm run db:migrate

# 5. Seedowanie danych (opcjonalnie)
npm run db:seed

# 6. Uruchomienie w trybie deweloperskim
npm run dev
```

Aplikacja będzie dostępna pod adresem: `http://localhost:5173`

### Skrypty dostępne

```bash
npm run dev          # Tryb deweloperski
npm run build        # Budowanie produkcyjne
npm run preview      # Podgląd wersji produkcyjnej
npm run lint         # Sprawdzanie ESLint
npm run typecheck    # Sprawdzanie TypeScript
npm run db:migrate   # Migracje bazy danych
npm run db:generate  # Generowanie schematu Drizzle
npm run db:studio    # Przeglądarka bazy danych
```

---

## 📁 Struktura Projektu

```
3d-print-business-hub/
├── 📂 client/                    # Frontend React
│   ├── 📂 src/
│   │   ├── 📂 components/        # Komponenty React
│   │   │   ├── 📂 ui/            # Komponenty shadcn/ui
│   │   │   ├── 📂 dashboard/     # Komponenty dashboardu
│   │   │   ├── 📂 kanban/        # Komponenty Kanban
│   │   │   ├── 📂 projects/      # Komponenty projektów
│   │   │   ├── 📂 calculator/    # Komponenty kalkulatora
│   │   │   ├── 📂 inventory/     # Komponenty magazynu
│   │   │   ├── 📂 customers/     # Komponenty klientów
│   │   │   ├── 📂 print-queue/   # Komponenty kolejki druku
│   │   │   ├── 📂 analytics/     # Komponenty analityki
│   │   │   ├── 📂 pdf/           # Komponenty PDF
│   │   │   └── 📂 layout/        # Layouty i nawigacja
│   │   ├── 📂 hooks/             # Custom hooks
│   │   ├── 📂 lib/               # Funkcje pomocnicze
│   │   ├── 📂 pages/             # Strony aplikacji
│   │   ├── 📂 styles/            # Style CSS
│   │   ├── 📂 types/             # Definicje TypeScript
│   │   └── 📂 context/           # Konteksty React
│   ├── 📄 index.html
│   └── 📄 vite.config.ts
│
├── 📂 server/                    # Backend Express
│   ├── 📂 src/
│   │   ├── 📂 routes/            # Trasy API
│   │   ├── 📂 trpc/              # Routery tRPC
│   │   ├── 📂 db/                # Konfiguracja Drizzle
│   │   ├── 📂 schema/            # Schematy bazy danych
│   │   ├── 📂 middleware/        # Middleware Express
│   │   ├── 📂 services/          # Logika biznesowa
│   │   └── 📂 utils/             # Funkcje pomocnicze
│   └── 📄 index.ts
│
├── 📂 shared/                    # Kod współdzielony
│   └── 📂 types/                 # Wspólne typy
│
├── 📂 migrations/                # Migracje bazy danych
├── 📂 docs/                      # Dokumentacja
├── 📄 .env.example               # Przykładowy plik .env
├── 📄 package.json
├── 📄 tailwind.config.ts
├── 📄 tsconfig.json
└── 📄 README.md
```

---

## 📸 Screenshots

### Dashboard z KPI
> Interaktywny panel z kluczowymi wskaźnikami wydajności, wykresami sprzedaży i statystykami produkcji w czasie rzeczywistym.

```
┌─────────────────────────────────────────────────────────────┐
│  📊 DASHBOARD - 3D Print Business Hub                       │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │  💰 Zysk │ │  📦 Zlecenia│ │  ⏱️ Czas │ │  🎯 Cel  │       │
│  │  12,450zł│ │    47    │ │  320h   │ │   85%   │       │
│  │  +15%   │ │   +8     │ │  -5%    │ │   +12%  │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
│                                                             │
│  ┌─────────────────────────┐ ┌─────────────────────────┐   │
│  │  📈 Sprzedaż (wykres)   │ │  🖨️ Aktywne drukarki    │   │
│  │                         │ │  • Bambu Lab X1C - Druk │   │
│  │    ╱╲    ╱╲    ╱╲      │ │  • Prusa MK4 - Gotowa   │   │
│  │   ╱  ╲  ╱  ╲  ╱  ╲     │ │  • Ender 3 S1 - Druk    │   │
│  │  ╱    ╲╱    ╲╱    ╲    │ │  • H2D - Konserwacja    │   │
│  └─────────────────────────┘ └─────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Kanban Taski
> System zarządzania zadaniami z przeciąganiem kart, etykietami kolorów i priorytetami.

```
┌─────────────────────────────────────────────────────────────┐
│  📋 KANBAN - Zarządzanie Zadaniami                          │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐        │
│  │ 📝 DO ZROBIENIA │ 🔄 W TRAKCIE │ ✅ ZAKOŃCZONE │        │
│  │     (5)      │     (3)      │     (12)     │        │
│  ├──────────────┤ ├──────────────┤ ├──────────────┤        │
│  │ ┌──────────┐ │ │ ┌──────────┐ │ │ ┌──────────┐ │        │
│  │ │ 🔴 Pilne │ │ │ │ 🟡 Druk  │ │ │ │ 🟢 Dost. │ │        │
│  │ │ Wycena   │ │ │ │ Figurka  │ │ │ │ Zamówienie│ │        │
│  │ │ #1234    │ │ │ │ #1235    │ │ │ │ #1230    │ │        │
│  │ └──────────┘ │ │ └──────────┘ │ │ └──────────┘ │        │
│  │ ┌──────────┐ │ │ ┌──────────┐ │ │ ┌──────────┐ │        │
│  │ │ 🟢 Nowe  │ │ │ │ 🔴 Kalibr│ │ │ │ 🟢 Dost. │ │        │
│  │ │ Zamówienie│ │ │ │ H2D      │ │ │ │ Zamówienie│ │        │
│  │ │ #1236    │ │ │ │ #1233    │ │ │ │ #1228    │ │        │
│  │ └──────────┘ │ │ └──────────┘ │ │ └──────────┘ │        │
│  └──────────────┘ └──────────────┘ └──────────────┘        │
└─────────────────────────────────────────────────────────────┘
```

### Kalkulator Kosztów
> Precyzyjny kalkulator uwzględniający wszystkie składowe kosztu druku 3D.

```
┌─────────────────────────────────────────────────────────────┐
│  🧮 KALKULATOR KOSZTÓW DRUKU 3D                             │
├─────────────────────────────────────────────────────────────┤
│  Model: dragon_v2.stl                                       │
│  Waga: 125g | Czas: 4h 30min | Wypełnienie: 15%            │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ KOSZTY:                                             │   │
│  │ ├─ Filament (PLA):          125g × 0.12zł = 15.00zł│   │
│  │ ├─ Energia (4.5h × 0.3kW):  1.35kWh × 0.80zł = 1.08zł│   │
│  │ ├─ Amortyzacja drukarki:    4.5h × 0.50zł = 2.25zł │   │
│  │ ├─ Czas pracy operatora:    0.5h × 50zł = 25.00zł  │   │
│  │ ├─ Pakowanie:                                   3.00zł│   │
│  │ └─ Marża (30%):                                13.60zł│   │
│  │                                                     │   │
│  │ 💰 CAŁKOWITY KOSZT:                          59.93zł │   │
│  │ 💵 CENA SPRZEDAŻY (z marżą):                 77.91zł │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  [📄 Generuj wycenę PDF]  [💾 Zapisz szablon]              │
└─────────────────────────────────────────────────────────────┘
```

### Magazyn Filamentów
> Zarządzanie zapasami z alertami o niskim stanie i datami ważności.

```
┌─────────────────────────────────────────────────────────────┐
│  🧵 MAGAZYN FILAMENTÓW                                      │
├─────────────────────────────────────────────────────────────┤
│  [🔍 Szukaj...] [Filtruj ▼] [+ Dodaj filament]             │
│                                                             │
│  ┌──────────┬──────────┬─────────┬──────────┬────────────┐ │
│  │ Producent│ Materiał │ Kolor   │ Stan     │ Status     │ │
│  ├──────────┼──────────┼─────────┼──────────┼────────────┤ │
│  │ Bambu Lab│ PLA      │ Czerwony│ 2.1/5kg  │ 🟡 Niski   │ │
│  │ Prusament│ PETG     │ Czarny  │ 4.5/5kg  │ 🟢 OK      │ │
│  │ eSun     │ ABS      │ Biały   │ 0.8/5kg  │ 🔴 Krytyczny│ │
│  │ Fiberlogy│ TPU      │ Żółty   │ 3.2/5kg  │ 🟢 OK      │ │
│  │ Polymaker│ PLA Silk │ Złoty   │ 1.5/5kg  │ 🟡 Niski   │ │
│  └──────────┴──────────┴─────────┴──────────┴────────────┘ │
│                                                             │
│  ⚠️ ALERTY: 2 filamenty wymagają uzupełnienia!             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Konfiguracja

### Zmienne środowiskowe

Utwórz plik `.env` w głównym katalogu:

```env
# Baza danych
DATABASE_URL=mysql://user:password@localhost:3306/3d_print_hub

# JWT
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRES_IN=7d

# Email (opcjonalnie)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# API Keys (opcjonalnie)
OPENAI_API_KEY=your-openai-key
STRIPE_SECRET_KEY=your-stripe-key
```

---

## 🤝 Współpraca

Chcesz przyczynić się do rozwoju projektu? Świetnie!

1. Fork repozytorium
2. Stwórz branch (`git checkout -b feature/amazing-feature`)
3. Commit zmiany (`git commit -m 'Add amazing feature'`)
4. Push do brancha (`git push origin feature/amazing-feature`)
5. Otwórz Pull Request

### Zasady współpracy

- Pisz czysty, typowany kod TypeScript
- Stosuj się do konwencji ESLint i Prettier
- Pisz testy dla nowych funkcjonalności
- Aktualizuj dokumentację

---

## 🗺️ Roadmap

- [x] Dashboard z KPI
- [x] Kanban Taski
- [x] Kalkulator kosztów
- [x] Magazyn filamentów
- [ ] Integracja z drukarkami (API Bambu Lab)
- [ ] Automatyczne powiadomienia SMS/Email
- [ ] Aplikacja mobilna (React Native)
- [ ] Integracja z marketplace'ami (Allegro, Etsy)
- [ ] System subskrypcji dla klientów
- [ ] AI-powered optymalizacja ustawień druku

---

## 📄 Licencja

Ten projekt jest udostępniony na licencji **MIT**.

```
MIT License

Copyright (c) 2024 3D Print Business Hub

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## 📞 Kontakt

Masz pytania lub sugestie?

- 🌐 Strona: [3dprinthub.pl](https://3dprinthub.pl)
- 📧 Email: kontakt@3dprinthub.pl
- 💬 Discord: [discord.gg/3dprinthub](https://discord.gg/3dprinthub)
- 🐦 Twitter: [@3DPrintHubPL](https://twitter.com/3DPrintHubPL)

---

<p align="center">
  Stworzone z ❤️ dla społeczności druku 3D
</p>

<p align="center">
  <a href="https://github.com/yourusername/3d-print-business-hub/stargazers">
    <img src="https://img.shields.io/github/stars/yourusername/3d-print-business-hub?style=social" alt="GitHub stars">
  </a>
</p>
