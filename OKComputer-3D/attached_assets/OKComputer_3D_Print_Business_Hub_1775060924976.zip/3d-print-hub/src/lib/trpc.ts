import { createTRPCReact } from '@trpc/react-query';
import { httpBatchLink } from '@trpc/client';
import { QueryClient } from '@tanstack/react-query';
import superjson from 'superjson';

// Import types from your tRPC router (will be defined in server)
// For now, we'll use a placeholder type that will be replaced
// when the server router is implemented
import type { AppRouter } from '../../../server/src/routers/_app';

// Create tRPC React hooks
export const trpc = createTRPCReact<AppRouter>();

// Create QueryClient with industrial-optimized settings
export const createQueryClient = () =>
  new QueryClient({
    defaultOptions: {
      queries: {
        // Stale time for 3D print business data
        staleTime: 1000 * 60 * 5, // 5 minutes
        // Retry configuration for industrial reliability
        retry: 3,
        retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
        // Refetch on window focus for real-time updates
        refetchOnWindowFocus: true,
        // Keep previous data while fetching
        placeholderData: (previousData: unknown) => previousData,
      },
      mutations: {
        // Retry failed mutations
        retry: 1,
        // Show error notifications
        onError: (error: Error) => {
          console.error('Mutation error:', error);
          // You can integrate with your toast notification system here
        },
      },
    },
  });

// tRPC client configuration
export const createTRPCClient = () =>
  trpc.createClient({
    transformer: superjson,
    links: [
      httpBatchLink({
        url: '/api/trpc',
        // Optional: Add headers for authentication
        headers: () => {
          const token = localStorage.getItem('auth_token');
          return token ? { Authorization: `Bearer ${token}` } : {};
        },
        // Max batch size for optimal performance
        maxBatchSize: 10,
        // Batch interval for grouping requests
        batchInterval: 16, // ~1 frame at 60fps
      }),
    ],
  });

// Utility type for inferring tRPC outputs
export type RouterOutputs = ReturnType<typeof trpc.useUtils>;

// Utility hook for handling tRPC errors
export const handleTRPCError = (error: Error): string => {
  if (error.message.includes('UNAUTHORIZED')) {
    return 'Session expired. Please log in again.';
  }
  if (error.message.includes('FORBIDDEN')) {
    return 'You do not have permission to perform this action.';
  }
  if (error.message.includes('NOT_FOUND')) {
    return 'The requested resource was not found.';
  }
  if (error.message.includes('BAD_REQUEST')) {
    return 'Invalid request. Please check your input.';
  }
  if (error.message.includes('RATE_LIMIT')) {
    return 'Too many requests. Please try again later.';
  }
  if (error.message.includes('TIMEOUT')) {
    return 'Request timed out. Please try again.';
  }
  return 'An unexpected error occurred. Please try again.';
};

// Query keys for cache management
export const queryKeys = {
  dashboard: ['dashboard'],
  tasks: {
    all: ['tasks'] as const,
    byId: (id: string) => ['tasks', id] as const,
    byStatus: (status: string) => ['tasks', 'status', status] as const,
  },
  projects: {
    all: ['projects'] as const,
    byId: (id: string) => ['projects', id] as const,
    active: ['projects', 'active'] as const,
  },
  inventory: {
    all: ['inventory'] as const,
    filaments: ['inventory', 'filaments'] as const,
    lowStock: ['inventory', 'lowStock'] as const,
  },
  clients: {
    all: ['clients'] as const,
    byId: (id: string) => ['clients', id] as const,
  },
  printQueue: {
    all: ['printQueue'] as const,
    active: ['printQueue', 'active'] as const,
    completed: ['printQueue', 'completed'] as const,
  },
  quotes: {
    all: ['quotes'] as const,
    byId: (id: string) => ['quotes', id] as const,
    pending: ['quotes', 'pending'] as const,
  },
  analytics: {
    overview: ['analytics', 'overview'] as const,
    revenue: ['analytics', 'revenue'] as const,
    prints: ['analytics', 'prints'] as const,
  },
} as const;

// Prefetch strategies for common data patterns
export const prefetchStrategies = {
  // Prefetch dashboard data on app load
  dashboard: (utils: ReturnType<typeof trpc.useUtils>) => {
    utils.dashboard.getOverview.prefetch();
  },
  // Prefetch active tasks when viewing task list
  tasks: (utils: ReturnType<typeof trpc.useUtils>) => {
    utils.task.getAll.prefetch({ status: 'active' });
  },
  // Prefetch inventory data for quick access
  inventory: (utils: ReturnType<typeof trpc.useUtils>) => {
    utils.inventory.getAll.prefetch();
    utils.inventory.getLowStock.prefetch();
  },
};
