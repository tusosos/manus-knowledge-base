import { CreateFastifyContextOptions } from '@trpc/server/adapters/fastify';
import { DrizzleD1Database } from 'drizzle-orm/d1';
import * as schema from '../db/schema';

/**
 * User session type
 */
export interface UserSession {
  id: string;
  email: string;
  name: string | null;
  role: 'ADMIN' | 'MANAGER' | 'OPERATOR' | 'VIEWER';
}

/**
 * Session type
 */
export interface Session {
  user: UserSession;
  expires: Date;
}

/**
 * Context options for creating context
 */
export interface ContextOptions {
  db: DrizzleD1Database<typeof schema>;
  session: Session | null;
}

/**
 * Creates context for tRPC procedures
 * Used in Fastify adapter
 */
export async function createContext({ req, res }: CreateFastifyContextOptions): Promise<ContextOptions> {
  // Session will be attached by auth middleware
  const session = (req as any).session as Session | null;
  const db = (req as any).db as DrizzleD1Database<typeof schema>;

  return {
    db,
    session,
  };
}

/**
 * Context type for tRPC
 */
export type Context = Awaited<ReturnType<typeof createContext>>;
