import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, like, gte, lte } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Project status enum
 */
const ProjectStatus = z.enum(['DRAFT', 'PLANNING', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED']);

/**
 * Project priority enum
 */
const ProjectPriority = z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']);

/**
 * Project filter input schema
 */
const projectFilterSchema = z.object({
  status: ProjectStatus.optional(),
  priority: ProjectPriority.optional(),
  clientId: z.string().optional(),
  search: z.string().optional(),
  startDateFrom: z.date().optional(),
  startDateTo: z.date().optional(),
  deadlineFrom: z.date().optional(),
  deadlineTo: z.date().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'startDate', 'deadline', 'name']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create project input schema
 */
const createProjectSchema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  description: z.string().optional(),
  status: ProjectStatus.default('DRAFT'),
  priority: ProjectPriority.default('MEDIUM'),
  startDate: z.date().optional(),
  deadline: z.date().optional(),
  clientId: z.string().optional(),
  budget: z.number().min(0).optional(),
  tags: z.array(z.string()).default([]),
});

/**
 * Update project input schema
 */
const updateProjectSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(200).optional(),
  description: z.string().optional(),
  status: ProjectStatus.optional(),
  priority: ProjectPriority.optional(),
  startDate: z.date().optional().nullable(),
  deadline: z.date().optional().nullable(),
  clientId: z.string().optional().nullable(),
  budget: z.number().min(0).optional().nullable(),
  tags: z.array(z.string()).optional(),
});

/**
 * Update project status input schema
 */
const updateStatusSchema = z.object({
  id: z.string(),
  status: ProjectStatus,
});

/**
 * Project response schema
 */
const projectResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string().nullable(),
  status: ProjectStatus,
  priority: ProjectPriority,
  startDate: z.date().nullable(),
  deadline: z.date().nullable(),
  clientId: z.string().nullable(),
  client: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string(),
  }).nullable(),
  budget: z.number().nullable(),
  tags: z.array(z.string()),
  progress: z.number(),
  createdById: z.string(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Projects list response schema
 */
const projectsListResponseSchema = z.object({
  projects: z.array(projectResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Projects router
 */
export const projectsRouter = router({
  /**
   * Get all projects with filters
   */
  getAll: protectedProcedure
    .input(projectFilterSchema)
    .output(projectsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { status, priority, clientId, search, startDateFrom, startDateTo, deadlineFrom, deadlineTo, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (status) {
        whereConditions.push(eq(schema.projects.status, status));
      }
      if (priority) {
        whereConditions.push(eq(schema.projects.priority, priority));
      }
      if (clientId) {
        whereConditions.push(eq(schema.projects.clientId, clientId));
      }
      if (search) {
        whereConditions.push(like(schema.projects.name, `%${search}%`));
      }
      if (startDateFrom) {
        whereConditions.push(gte(schema.projects.startDate, startDateFrom));
      }
      if (startDateTo) {
        whereConditions.push(lte(schema.projects.startDate, startDateTo));
      }
      if (deadlineFrom) {
        whereConditions.push(gte(schema.projects.deadline, deadlineFrom));
      }
      if (deadlineTo) {
        whereConditions.push(lte(schema.projects.deadline, deadlineTo));
      }

      // Get total count
      const allProjects = await ctx.db.query.projects.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allProjects.length;

      // Get paginated projects
      const projects = await ctx.db.query.projects.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.projects[sortBy]) : asc(schema.projects[sortBy]),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      return {
        projects: projects.map(project => ({
          ...project,
          description: project.description ?? null,
          startDate: project.startDate ?? null,
          deadline: project.deadline ?? null,
          clientId: project.clientId ?? null,
          budget: project.budget ?? null,
          tags: project.tags ?? [],
          progress: project.progress ?? 0,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get project by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(projectResponseSchema)
    .query(async ({ ctx, input }) => {
      const project = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, input.id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      if (!project) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found',
        });
      }

      return {
        ...project,
        description: project.description ?? null,
        startDate: project.startDate ?? null,
        deadline: project.deadline ?? null,
        clientId: project.clientId ?? null,
        budget: project.budget ?? null,
        tags: project.tags ?? [],
        progress: project.progress ?? 0,
      };
    }),

  /**
   * Create new project
   */
  create: protectedProcedure
    .input(createProjectSchema)
    .output(projectResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      const [project] = await ctx.db.insert(schema.projects).values({
        name: input.name,
        description: input.description,
        status: input.status,
        priority: input.priority,
        startDate: input.startDate,
        deadline: input.deadline,
        clientId: input.clientId,
        budget: input.budget,
        tags: input.tags,
        progress: 0,
        createdById: ctx.session.user.id,
      }).returning();

      if (!project) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create project',
        });
      }

      // Fetch the created project with relations
      const projectWithRelations = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, project.id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      if (!projectWithRelations) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found after creation',
        });
      }

      return {
        ...projectWithRelations,
        description: projectWithRelations.description ?? null,
        startDate: projectWithRelations.startDate ?? null,
        deadline: projectWithRelations.deadline ?? null,
        clientId: projectWithRelations.clientId ?? null,
        budget: projectWithRelations.budget ?? null,
        tags: projectWithRelations.tags ?? [],
        progress: projectWithRelations.progress ?? 0,
      };
    }),

  /**
   * Update project
   */
  update: protectedProcedure
    .input(updateProjectSchema)
    .output(projectResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, ...updateData } = input;

      // Check if project exists
      const existingProject = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, id),
      });

      if (!existingProject) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found',
        });
      }

      // Update project
      await ctx.db.update(schema.projects)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(schema.projects.id, id));

      // Fetch updated project
      const project = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      if (!project) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found after update',
        });
      }

      return {
        ...project,
        description: project.description ?? null,
        startDate: project.startDate ?? null,
        deadline: project.deadline ?? null,
        clientId: project.clientId ?? null,
        budget: project.budget ?? null,
        tags: project.tags ?? [],
        progress: project.progress ?? 0,
      };
    }),

  /**
   * Delete project
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if project exists
      const existingProject = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, input.id),
      });

      if (!existingProject) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found',
        });
      }

      await ctx.db.delete(schema.projects).where(eq(schema.projects.id, input.id));

      return { success: true };
    }),

  /**
   * Update project status
   */
  updateStatus: protectedProcedure
    .input(updateStatusSchema)
    .output(projectResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, status } = input;

      // Check if project exists
      const existingProject = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, id),
      });

      if (!existingProject) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found',
        });
      }

      // Update status
      await ctx.db.update(schema.projects)
        .set({
          status,
          updatedAt: new Date(),
        })
        .where(eq(schema.projects.id, id));

      // Fetch updated project
      const project = await ctx.db.query.projects.findFirst({
        where: eq(schema.projects.id, id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
      });

      if (!project) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Project not found after update',
        });
      }

      return {
        ...project,
        description: project.description ?? null,
        startDate: project.startDate ?? null,
        deadline: project.deadline ?? null,
        clientId: project.clientId ?? null,
        budget: project.budget ?? null,
        tags: project.tags ?? [],
        progress: project.progress ?? 0,
      };
    }),
});

export type ProjectsRouter = typeof projectsRouter;
