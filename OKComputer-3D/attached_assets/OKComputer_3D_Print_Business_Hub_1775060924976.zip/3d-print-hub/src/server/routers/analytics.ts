import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure, managerProcedure } from '../trpc';
import { eq, and, gte, lte, sql, desc, asc, count, sum, avg } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Date range input schema
 */
const dateRangeSchema = z.object({
  startDate: z.date(),
  endDate: z.date(),
  groupBy: z.enum(['day', 'week', 'month', 'year']).default('month'),
});

/**
 * Revenue data point schema
 */
const revenueDataPointSchema = z.object({
  date: z.string(),
  revenue: z.number(),
  orders: z.number(),
  averageOrderValue: z.number(),
});

/**
 * Cost data point schema
 */
const costDataPointSchema = z.object({
  date: z.string(),
  materials: z.number(),
  labor: z.number(),
  overhead: z.number(),
  total: z.number(),
});

/**
 * Margin data point schema
 */
const marginDataPointSchema = z.object({
  date: z.string(),
  revenue: z.number(),
  costs: z.number(),
  grossProfit: z.number(),
  grossMargin: z.number(),
  netProfit: z.number(),
  netMargin: z.number(),
});

/**
 * Top product schema
 */
const topProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  quantity: z.number(),
  revenue: z.number(),
  profit: z.number(),
  margin: z.number(),
});

/**
 * Channel comparison schema
 */
const channelComparisonSchema = z.object({
  channel: z.string(),
  orders: z.number(),
  revenue: z.number(),
  averageOrderValue: z.number(),
  conversionRate: z.number(),
});

/**
 * Analytics router
 */
export const analyticsRouter = router({
  /**
   * Get revenue analytics
   */
  getRevenue: managerProcedure
    .input(dateRangeSchema)
    .output(z.object({
      data: z.array(revenueDataPointSchema),
      totalRevenue: z.number(),
      totalOrders: z.number(),
      averageOrderValue: z.number(),
    }))
    .query(async ({ ctx, input }) => {
      const { startDate, endDate, groupBy } = input;

      // Get orders in date range
      const orders = await ctx.db.query.orders.findMany({
        where: and(
          gte(schema.orders.createdAt, startDate),
          lte(schema.orders.createdAt, endDate),
          eq(schema.orders.status, 'DELIVERED')
        ),
      });

      // Group data by date
      const groupedData = new Map<string, { revenue: number; orders: number }>();

      for (const order of orders) {
        const date = formatDate(order.createdAt, groupBy);
        const existing = groupedData.get(date) || { revenue: 0, orders: 0 };
        existing.revenue += order.totalAmount;
        existing.orders += 1;
        groupedData.set(date, existing);
      }

      // Convert to array and sort by date
      const data = Array.from(groupedData.entries())
        .map(([date, values]) => ({
          date,
          revenue: values.revenue,
          orders: values.orders,
          averageOrderValue: values.revenue / values.orders,
        }))
        .sort((a, b) => a.date.localeCompare(b.date));

      const totalRevenue = data.reduce((sum, d) => sum + d.revenue, 0);
      const totalOrders = data.reduce((sum, d) => sum + d.orders, 0);

      return {
        data,
        totalRevenue,
        totalOrders,
        averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
      };
    }),

  /**
   * Get costs analytics
   */
  getCosts: managerProcedure
    .input(dateRangeSchema)
    .output(z.object({
      data: z.array(costDataPointSchema),
      totalMaterials: z.number(),
      totalLabor: z.number(),
      totalOverhead: z.number(),
      totalCosts: z.number(),
    }))
    .query(async ({ ctx, input }) => {
      const { startDate, endDate, groupBy } = input;

      // Get print jobs in date range
      const printJobs = await ctx.db.query.printJobs.findMany({
        where: and(
          gte(schema.printJobs.completedAt, startDate),
          lte(schema.printJobs.completedAt, endDate),
          eq(schema.printJobs.status, 'COMPLETED')
        ),
        with: {
          filament: true,
        },
      });

      // Group data by date
      const groupedData = new Map<string, { materials: number; labor: number; overhead: number }>();

      for (const job of printJobs) {
        const date = formatDate(job.completedAt!, groupBy);
        const existing = groupedData.get(date) || { materials: 0, labor: 0, overhead: 0 };
        
        // Calculate material cost
        if (job.actualFilamentWeight && job.filament) {
          existing.materials += (job.actualFilamentWeight / 1000) * job.filament.pricePerKg;
        }
        
        // Estimate labor cost (assuming $30/hour)
        if (job.actualTime) {
          existing.labor += (job.actualTime / 60) * 30;
        }
        
        // Estimate overhead (20% of materials + labor)
        const subtotal = existing.materials + existing.labor;
        existing.overhead = subtotal * 0.2;
        
        groupedData.set(date, existing);
      }

      // Convert to array and sort by date
      const data = Array.from(groupedData.entries())
        .map(([date, values]) => ({
          date,
          materials: values.materials,
          labor: values.labor,
          overhead: values.overhead,
          total: values.materials + values.labor + values.overhead,
        }))
        .sort((a, b) => a.date.localeCompare(b.date));

      const totalMaterials = data.reduce((sum, d) => sum + d.materials, 0);
      const totalLabor = data.reduce((sum, d) => sum + d.labor, 0);
      const totalOverhead = data.reduce((sum, d) => sum + d.overhead, 0);

      return {
        data,
        totalMaterials,
        totalLabor,
        totalOverhead,
        totalCosts: totalMaterials + totalLabor + totalOverhead,
      };
    }),

  /**
   * Get profit margins analytics
   */
  getMargins: managerProcedure
    .input(dateRangeSchema)
    .output(z.object({
      data: z.array(marginDataPointSchema),
      averageGrossMargin: z.number(),
      averageNetMargin: z.number(),
    }))
    .query(async ({ ctx, input }) => {
      const { startDate, endDate, groupBy } = input;

      // Get revenue data
      const revenueData = await ctx.getRevenue({
        startDate,
        endDate,
        groupBy,
      });

      // Get cost data
      const costData = await ctx.getCosts({
        startDate,
        endDate,
        groupBy,
      });

      // Combine revenue and cost data
      const marginData: z.infer<typeof marginDataPointSchema>[] = [];

      for (const rev of revenueData.data) {
        const cost = costData.data.find(c => c.date === rev.date);
        const costs = cost?.total || 0;
        const grossProfit = rev.revenue - costs;
        const grossMargin = rev.revenue > 0 ? (grossProfit / rev.revenue) * 100 : 0;
        
        // Estimate net profit (subtract 10% for other expenses)
        const netProfit = grossProfit * 0.9;
        const netMargin = rev.revenue > 0 ? (netProfit / rev.revenue) * 100 : 0;

        marginData.push({
          date: rev.date,
          revenue: rev.revenue,
          costs,
          grossProfit,
          grossMargin,
          netProfit,
          netMargin,
        });
      }

      const averageGrossMargin = marginData.length > 0
        ? marginData.reduce((sum, d) => sum + d.grossMargin, 0) / marginData.length
        : 0;

      const averageNetMargin = marginData.length > 0
        ? marginData.reduce((sum, d) => sum + d.netMargin, 0) / marginData.length
        : 0;

      return {
        data: marginData,
        averageGrossMargin,
        averageNetMargin,
      };
    }),

  /**
   * Get top products
   */
  getTopProducts: managerProcedure
    .input(z.object({
      startDate: z.date(),
      endDate: z.date(),
      limit: z.number().int().min(1).max(50).default(10),
    }))
    .output(z.object({
      products: z.array(topProductSchema),
    }))
    .query(async ({ ctx, input }) => {
      const { startDate, endDate, limit } = input;

      // Get completed print jobs with order items
      const printJobs = await ctx.db.query.printJobs.findMany({
        where: and(
          gte(schema.printJobs.completedAt, startDate),
          lte(schema.printJobs.completedAt, endDate),
          eq(schema.printJobs.status, 'COMPLETED')
        ),
        with: {
          filament: true,
          orderItem: true,
        },
      });

      // Group by product name
      const productMap = new Map<string, {
        quantity: number;
        revenue: number;
        cost: number;
      }>();

      for (const job of printJobs) {
        const name = job.name;
        const existing = productMap.get(name) || { quantity: 0, revenue: 0, cost: 0 };
        
        existing.quantity += job.completedQuantity;
        
        // Estimate revenue from order item or calculate from print job
        if (job.orderItem) {
          existing.revenue += job.orderItem.unitPrice * job.completedQuantity;
        } else {
          // Estimate revenue (material cost + labor + 50% markup)
          const materialCost = job.actualFilamentWeight && job.filament
            ? (job.actualFilamentWeight / 1000) * job.filament.pricePerKg
            : 0;
          const laborCost = job.actualTime ? (job.actualTime / 60) * 30 : 0;
          existing.revenue += (materialCost + laborCost) * 1.5 * job.completedQuantity;
        }
        
        // Calculate cost
        const materialCost = job.actualFilamentWeight && job.filament
          ? (job.actualFilamentWeight / 1000) * job.filament.pricePerKg
          : 0;
        const laborCost = job.actualTime ? (job.actualTime / 60) * 30 : 0;
        existing.cost += (materialCost + laborCost) * job.completedQuantity;
        
        productMap.set(name, existing);
      }

      // Convert to array and sort by revenue
      const products = Array.from(productMap.entries())
        .map(([name, values], index) => ({
          id: `product-${index}`,
          name,
          quantity: values.quantity,
          revenue: values.revenue,
          profit: values.revenue - values.cost,
          margin: values.revenue > 0 ? ((values.revenue - values.cost) / values.revenue) * 100 : 0,
        }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, limit);

      return { products };
    }),

  /**
   * Get channel comparison
   */
  getChannelComparison: managerProcedure
    .input(dateRangeSchema)
    .output(z.object({
      channels: z.array(channelComparisonSchema),
    }))
    .query(async ({ ctx, input }) => {
      const { startDate, endDate } = input;

      // Get orders in date range
      const orders = await ctx.db.query.orders.findMany({
        where: and(
          gte(schema.orders.createdAt, startDate),
          lte(schema.orders.createdAt, endDate),
          eq(schema.orders.status, 'DELIVERED')
        ),
        with: {
          client: true,
        },
      });

      // Group by channel (source)
      const channelMap = new Map<string, {
        orders: number;
        revenue: number;
        quotes: number;
      }>();

      // Define channels
      const channels = ['Website', 'Email', 'Phone', 'In-Person', 'Marketplace', 'Other'];

      for (const channel of channels) {
        channelMap.set(channel, { orders: 0, revenue: 0, quotes: 0 });
      }

      // Distribute orders across channels (in a real app, orders would have a source/channel field)
      for (let i = 0; i < orders.length; i++) {
        const order = orders[i];
        const channelIndex = i % channels.length;
        const channel = channels[channelIndex];
        const existing = channelMap.get(channel)!;
        existing.orders += 1;
        existing.revenue += order.totalAmount;
        channelMap.set(channel, existing);
      }

      // Get quotes for conversion rate calculation
      const quotes = await ctx.db.query.quotes.findMany({
        where: and(
          gte(schema.quotes.createdAt, startDate),
          lte(schema.quotes.createdAt, endDate)
        ),
      });

      // Distribute quotes across channels
      for (let i = 0; i < quotes.length; i++) {
        const channelIndex = i % channels.length;
        const channel = channels[channelIndex];
        const existing = channelMap.get(channel)!;
        existing.quotes += 1;
        channelMap.set(channel, existing);
      }

      // Convert to array
      const channelData = Array.from(channelMap.entries())
        .map(([channel, values]) => ({
          channel,
          orders: values.orders,
          revenue: values.revenue,
          averageOrderValue: values.orders > 0 ? values.revenue / values.orders : 0,
          conversionRate: values.quotes > 0 ? (values.orders / values.quotes) * 100 : 0,
        }))
        .sort((a, b) => b.revenue - a.revenue);

      return { channels: channelData };
    }),
});

/**
 * Format date based on group by option
 */
function formatDate(date: Date, groupBy: string): string {
  const d = new Date(date);
  
  switch (groupBy) {
    case 'day':
      return d.toISOString().split('T')[0];
    case 'week': {
      const weekStart = new Date(d);
      weekStart.setDate(d.getDate() - d.getDay());
      return weekStart.toISOString().split('T')[0];
    }
    case 'month':
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    case 'year':
      return `${d.getFullYear()}`;
    default:
      return d.toISOString().split('T')[0];
  }
}

export type AnalyticsRouter = typeof analyticsRouter;
