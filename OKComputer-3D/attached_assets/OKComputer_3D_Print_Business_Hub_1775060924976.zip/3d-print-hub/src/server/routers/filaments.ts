import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, like, lte } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Filament type enum
 */
const FilamentType = z.enum(['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'NYLON', 'PC', 'PVA', 'HIPS', 'OTHER']);

/**
 * Filament filter input schema
 */
const filamentFilterSchema = z.object({
  type: FilamentType.optional(),
  brand: z.string().optional(),
  color: z.string().optional(),
  search: z.string().optional(),
  inStock: z.boolean().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'name', 'stockWeight']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create filament input schema
 */
const createFilamentSchema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  type: FilamentType,
  brand: z.string().min(1, 'Brand is required').max(100),
  color: z.string().min(1, 'Color is required').max(100),
  colorHex: z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'Invalid hex color').optional(),
  diameter: z.number().min(1).max(3).default(1.75),
  weightTotal: z.number().min(0, 'Weight must be positive'),
  stockWeight: z.number().min(0, 'Stock weight must be positive'),
  pricePerKg: z.number().min(0, 'Price must be positive'),
  nozzleTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).optional(),
  bedTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).optional(),
  location: z.string().max(100).optional(),
  notes: z.string().optional(),
  lowStockThreshold: z.number().min(0).default(200),
});

/**
 * Update filament input schema
 */
const updateFilamentSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(200).optional(),
  type: FilamentType.optional(),
  brand: z.string().min(1).max(100).optional(),
  color: z.string().min(1).max(100).optional(),
  colorHex: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional().nullable(),
  diameter: z.number().min(1).max(3).optional(),
  weightTotal: z.number().min(0).optional(),
  stockWeight: z.number().min(0).optional(),
  pricePerKg: z.number().min(0).optional(),
  nozzleTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).optional().nullable(),
  bedTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).optional().nullable(),
  location: z.string().max(100).optional().nullable(),
  notes: z.string().optional().nullable(),
  lowStockThreshold: z.number().min(0).optional(),
});

/**
 * Update stock input schema
 */
const updateStockSchema = z.object({
  id: z.string(),
  stockWeight: z.number().min(0, 'Stock weight must be positive'),
  reason: z.string().optional(),
});

/**
 * Filament response schema
 */
const filamentResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: FilamentType,
  brand: z.string(),
  color: z.string(),
  colorHex: z.string().nullable(),
  diameter: z.number(),
  weightTotal: z.number(),
  stockWeight: z.number(),
  pricePerKg: z.number(),
  nozzleTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).nullable(),
  bedTemp: z.object({
    min: z.number(),
    max: z.number(),
  }).nullable(),
  location: z.string().nullable(),
  notes: z.string().nullable(),
  lowStockThreshold: z.number(),
  isLowStock: z.boolean(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Filaments list response schema
 */
const filamentsListResponseSchema = z.object({
  filaments: z.array(filamentResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Filaments router
 */
export const filamentsRouter = router({
  /**
   * Get all filaments with filters
   */
  getAll: protectedProcedure
    .input(filamentFilterSchema)
    .output(filamentsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { type, brand, color, search, inStock, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (type) {
        whereConditions.push(eq(schema.filaments.type, type));
      }
      if (brand) {
        whereConditions.push(eq(schema.filaments.brand, brand));
      }
      if (color) {
        whereConditions.push(eq(schema.filaments.color, color));
      }
      if (search) {
        whereConditions.push(like(schema.filaments.name, `%${search}%`));
      }
      if (inStock) {
        whereConditions.push(lte(schema.filaments.stockWeight, 0));
      }

      // Get total count
      const allFilaments = await ctx.db.query.filaments.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allFilaments.length;

      // Get paginated filaments
      const filaments = await ctx.db.query.filaments.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.filaments[sortBy]) : asc(schema.filaments[sortBy]),
      });

      return {
        filaments: filaments.map(filament => ({
          ...filament,
          colorHex: filament.colorHex ?? null,
          nozzleTemp: filament.nozzleTemp ?? null,
          bedTemp: filament.bedTemp ?? null,
          location: filament.location ?? null,
          notes: filament.notes ?? null,
          isLowStock: filament.stockWeight <= filament.lowStockThreshold,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get low stock filaments
   */
  getLowStock: protectedProcedure
    .input(z.object({
      page: z.number().int().min(1).default(1),
      limit: z.number().int().min(1).max(100).default(20),
    }))
    .output(filamentsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { page, limit } = input;

      // Get all filaments and filter low stock in memory
      // (since we need to compare stockWeight with lowStockThreshold)
      const allFilaments = await ctx.db.query.filaments.findMany({
        orderBy: asc(schema.filaments.stockWeight),
      });

      const lowStockFilaments = allFilaments.filter(
        f => f.stockWeight <= f.lowStockThreshold
      );

      const total = lowStockFilaments.length;
      const paginatedFilaments = lowStockFilaments.slice((page - 1) * limit, page * limit);

      return {
        filaments: paginatedFilaments.map(filament => ({
          ...filament,
          colorHex: filament.colorHex ?? null,
          nozzleTemp: filament.nozzleTemp ?? null,
          bedTemp: filament.bedTemp ?? null,
          location: filament.location ?? null,
          notes: filament.notes ?? null,
          isLowStock: true,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Create new filament
   */
  create: protectedProcedure
    .input(createFilamentSchema)
    .output(filamentResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      const [filament] = await ctx.db.insert(schema.filaments).values({
        name: input.name,
        type: input.type,
        brand: input.brand,
        color: input.color,
        colorHex: input.colorHex,
        diameter: input.diameter,
        weightTotal: input.weightTotal,
        stockWeight: input.stockWeight,
        pricePerKg: input.pricePerKg,
        nozzleTemp: input.nozzleTemp,
        bedTemp: input.bedTemp,
        location: input.location,
        notes: input.notes,
        lowStockThreshold: input.lowStockThreshold,
      }).returning();

      if (!filament) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create filament',
        });
      }

      return {
        ...filament,
        colorHex: filament.colorHex ?? null,
        nozzleTemp: filament.nozzleTemp ?? null,
        bedTemp: filament.bedTemp ?? null,
        location: filament.location ?? null,
        notes: filament.notes ?? null,
        isLowStock: filament.stockWeight <= filament.lowStockThreshold,
      };
    }),

  /**
   * Update filament
   */
  update: protectedProcedure
    .input(updateFilamentSchema)
    .output(filamentResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, ...updateData } = input;

      // Check if filament exists
      const existingFilament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, id),
      });

      if (!existingFilament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found',
        });
      }

      // Update filament
      await ctx.db.update(schema.filaments)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(schema.filaments.id, id));

      // Fetch updated filament
      const filament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, id),
      });

      if (!filament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found after update',
        });
      }

      return {
        ...filament,
        colorHex: filament.colorHex ?? null,
        nozzleTemp: filament.nozzleTemp ?? null,
        bedTemp: filament.bedTemp ?? null,
        location: filament.location ?? null,
        notes: filament.notes ?? null,
        isLowStock: filament.stockWeight <= filament.lowStockThreshold,
      };
    }),

  /**
   * Delete filament
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if filament exists
      const existingFilament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, input.id),
      });

      if (!existingFilament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found',
        });
      }

      // Check if filament is used in print jobs
      const printJobs = await ctx.db.query.printJobs.findMany({
        where: eq(schema.printJobs.filamentId, input.id),
      });

      if (printJobs.length > 0) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Cannot delete filament used in print jobs',
        });
      }

      await ctx.db.delete(schema.filaments).where(eq(schema.filaments.id, input.id));

      return { success: true };
    }),

  /**
   * Update filament stock
   */
  updateStock: protectedProcedure
    .input(updateStockSchema)
    .output(filamentResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, stockWeight, reason } = input;

      // Check if filament exists
      const existingFilament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, id),
      });

      if (!existingFilament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found',
        });
      }

      // Update stock
      await ctx.db.update(schema.filaments)
        .set({
          stockWeight,
          updatedAt: new Date(),
        })
        .where(eq(schema.filaments.id, id));

      // Log stock change (optional - could add to a stock history table)
      // await ctx.db.insert(schema.stockHistory).values({...})

      // Fetch updated filament
      const filament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, id),
      });

      if (!filament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found after update',
        });
      }

      return {
        ...filament,
        colorHex: filament.colorHex ?? null,
        nozzleTemp: filament.nozzleTemp ?? null,
        bedTemp: filament.bedTemp ?? null,
        location: filament.location ?? null,
        notes: filament.notes ?? null,
        isLowStock: filament.stockWeight <= filament.lowStockThreshold,
      };
    }),
});

export type FilamentsRouter = typeof filamentsRouter;
