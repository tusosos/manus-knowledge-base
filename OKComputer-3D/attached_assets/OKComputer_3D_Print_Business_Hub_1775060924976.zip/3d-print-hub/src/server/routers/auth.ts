import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, publicProcedure, protectedProcedure } from '../trpc';
import { eq } from 'drizzle-orm';
import * as schema from '../../db/schema';
import bcrypt from 'bcryptjs';

/**
 * Login input schema
 */
const loginInputSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

/**
 * User response schema
 */
const userResponseSchema = z.object({
  id: z.string(),
  email: z.string(),
  name: z.string().nullable(),
  role: z.enum(['ADMIN', 'MANAGER', 'OPERATOR', 'VIEWER']),
  avatar: z.string().nullable(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Session response schema
 */
const sessionResponseSchema = z.object({
  user: userResponseSchema,
  expires: z.date(),
});

/**
 * Auth router
 */
export const authRouter = router({
  /**
   * Login user
   */
  login: publicProcedure
    .input(loginInputSchema)
    .output(sessionResponseSchema)
    .mutation(async ({ ctx, input }) => {
      // Find user by email
      const user = await ctx.db.query.users.findFirst({
        where: eq(schema.users.email, input.email),
      });

      if (!user) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid email or password',
        });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(input.password, user.passwordHash);

      if (!isValidPassword) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Invalid email or password',
        });
      }

      // Check if user is active
      if (!user.isActive) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'Account is deactivated',
        });
      }

      // Create session (expires in 7 days)
      const expires = new Date();
      expires.setDate(expires.getDate() + 7);

      const session = {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          avatar: user.avatar,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
        },
        expires,
      };

      // Store session (implementation depends on session store)
      // This would typically set a cookie or JWT token

      return session;
    }),

  /**
   * Logout user
   */
  logout: protectedProcedure
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx }) => {
      // Clear session (implementation depends on session store)
      return { success: true };
    }),

  /**
   * Get current session
   */
  getSession: publicProcedure
    .output(sessionResponseSchema.nullable())
    .query(async ({ ctx }) => {
      return ctx.session;
    }),

  /**
   * Get current user details
   */
  getUser: protectedProcedure
    .output(userResponseSchema)
    .query(async ({ ctx }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({
          code: 'UNAUTHORIZED',
          message: 'Not authenticated',
        });
      }

      const user = await ctx.db.query.users.findFirst({
        where: eq(schema.users.id, ctx.session.user.id),
      });

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      return {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        avatar: user.avatar,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      };
    }),
});

export type AuthRouter = typeof authRouter;
