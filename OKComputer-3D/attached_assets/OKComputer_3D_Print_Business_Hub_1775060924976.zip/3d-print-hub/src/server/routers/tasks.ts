import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, like, gte, lte, inArray } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Task status enum
 */
const TaskStatus = z.enum(['TODO', 'IN_PROGRESS', 'REVIEW', 'DONE', 'CANCELLED']);

/**
 * Task priority enum
 */
const TaskPriority = z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']);

/**
 * Task filter input schema
 */
const taskFilterSchema = z.object({
  status: TaskStatus.optional(),
  priority: TaskPriority.optional(),
  assigneeId: z.string().optional(),
  projectId: z.string().optional(),
  search: z.string().optional(),
  dueDateFrom: z.date().optional(),
  dueDateTo: z.date().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'dueDate', 'priority', 'title']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create task input schema
 */
const createTaskSchema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().optional(),
  status: TaskStatus.default('TODO'),
  priority: TaskPriority.default('MEDIUM'),
  dueDate: z.date().optional(),
  assigneeId: z.string().optional(),
  projectId: z.string().optional(),
  tags: z.array(z.string()).default([]),
});

/**
 * Update task input schema
 */
const updateTaskSchema = z.object({
  id: z.string(),
  title: z.string().min(1).max(200).optional(),
  description: z.string().optional(),
  status: TaskStatus.optional(),
  priority: TaskPriority.optional(),
  dueDate: z.date().optional().nullable(),
  assigneeId: z.string().optional().nullable(),
  projectId: z.string().optional().nullable(),
  tags: z.array(z.string()).optional(),
});

/**
 * Update task status input schema
 */
const updateStatusSchema = z.object({
  id: z.string(),
  status: TaskStatus,
});

/**
 * Task response schema
 */
const taskResponseSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  status: TaskStatus,
  priority: TaskPriority,
  dueDate: z.date().nullable(),
  assigneeId: z.string().nullable(),
  assignee: z.object({
    id: z.string(),
    name: z.string().nullable(),
    email: z.string(),
    avatar: z.string().nullable(),
  }).nullable(),
  projectId: z.string().nullable(),
  project: z.object({
    id: z.string(),
    name: z.string(),
  }).nullable(),
  tags: z.array(z.string()),
  createdById: z.string(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Tasks list response schema
 */
const tasksListResponseSchema = z.object({
  tasks: z.array(taskResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Tasks router
 */
export const tasksRouter = router({
  /**
   * Get all tasks with filters
   */
  getAll: protectedProcedure
    .input(taskFilterSchema)
    .output(tasksListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { status, priority, assigneeId, projectId, search, dueDateFrom, dueDateTo, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (status) {
        whereConditions.push(eq(schema.tasks.status, status));
      }
      if (priority) {
        whereConditions.push(eq(schema.tasks.priority, priority));
      }
      if (assigneeId) {
        whereConditions.push(eq(schema.tasks.assigneeId, assigneeId));
      }
      if (projectId) {
        whereConditions.push(eq(schema.tasks.projectId, projectId));
      }
      if (search) {
        whereConditions.push(like(schema.tasks.title, `%${search}%`));
      }
      if (dueDateFrom) {
        whereConditions.push(gte(schema.tasks.dueDate, dueDateFrom));
      }
      if (dueDateTo) {
        whereConditions.push(lte(schema.tasks.dueDate, dueDateTo));
      }

      // Get total count
      const allTasks = await ctx.db.query.tasks.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allTasks.length;

      // Get paginated tasks
      const tasks = await ctx.db.query.tasks.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.tasks[sortBy]) : asc(schema.tasks[sortBy]),
        with: {
          assignee: {
            columns: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      return {
        tasks: tasks.map(task => ({
          ...task,
          description: task.description ?? null,
          dueDate: task.dueDate ?? null,
          assigneeId: task.assigneeId ?? null,
          projectId: task.projectId ?? null,
          tags: task.tags ?? [],
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get task by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(taskResponseSchema)
    .query(async ({ ctx, input }) => {
      const task = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, input.id),
        with: {
          assignee: {
            columns: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!task) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found',
        });
      }

      return {
        ...task,
        description: task.description ?? null,
        dueDate: task.dueDate ?? null,
        assigneeId: task.assigneeId ?? null,
        projectId: task.projectId ?? null,
        tags: task.tags ?? [],
      };
    }),

  /**
   * Create new task
   */
  create: protectedProcedure
    .input(createTaskSchema)
    .output(taskResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      const [task] = await ctx.db.insert(schema.tasks).values({
        title: input.title,
        description: input.description,
        status: input.status,
        priority: input.priority,
        dueDate: input.dueDate,
        assigneeId: input.assigneeId,
        projectId: input.projectId,
        tags: input.tags,
        createdById: ctx.session.user.id,
      }).returning();

      if (!task) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create task',
        });
      }

      // Fetch the created task with relations
      const taskWithRelations = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, task.id),
        with: {
          assignee: {
            columns: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!taskWithRelations) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found after creation',
        });
      }

      return {
        ...taskWithRelations,
        description: taskWithRelations.description ?? null,
        dueDate: taskWithRelations.dueDate ?? null,
        assigneeId: taskWithRelations.assigneeId ?? null,
        projectId: taskWithRelations.projectId ?? null,
        tags: taskWithRelations.tags ?? [],
      };
    }),

  /**
   * Update task
   */
  update: protectedProcedure
    .input(updateTaskSchema)
    .output(taskResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, ...updateData } = input;

      // Check if task exists
      const existingTask = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, id),
      });

      if (!existingTask) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found',
        });
      }

      // Update task
      await ctx.db.update(schema.tasks)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(schema.tasks.id, id));

      // Fetch updated task
      const task = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, id),
        with: {
          assignee: {
            columns: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!task) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found after update',
        });
      }

      return {
        ...task,
        description: task.description ?? null,
        dueDate: task.dueDate ?? null,
        assigneeId: task.assigneeId ?? null,
        projectId: task.projectId ?? null,
        tags: task.tags ?? [],
      };
    }),

  /**
   * Delete task
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if task exists
      const existingTask = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, input.id),
      });

      if (!existingTask) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found',
        });
      }

      await ctx.db.delete(schema.tasks).where(eq(schema.tasks.id, input.id));

      return { success: true };
    }),

  /**
   * Update task status
   */
  updateStatus: protectedProcedure
    .input(updateStatusSchema)
    .output(taskResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, status } = input;

      // Check if task exists
      const existingTask = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, id),
      });

      if (!existingTask) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found',
        });
      }

      // Update status
      await ctx.db.update(schema.tasks)
        .set({
          status,
          updatedAt: new Date(),
        })
        .where(eq(schema.tasks.id, id));

      // Fetch updated task
      const task = await ctx.db.query.tasks.findFirst({
        where: eq(schema.tasks.id, id),
        with: {
          assignee: {
            columns: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      if (!task) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Task not found after update',
        });
      }

      return {
        ...task,
        description: task.description ?? null,
        dueDate: task.dueDate ?? null,
        assigneeId: task.assigneeId ?? null,
        projectId: task.projectId ?? null,
        tags: task.tags ?? [],
      };
    }),
});

export type TasksRouter = typeof tasksRouter;
