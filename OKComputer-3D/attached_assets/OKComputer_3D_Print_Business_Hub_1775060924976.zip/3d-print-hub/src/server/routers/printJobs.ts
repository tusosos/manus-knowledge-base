import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, gte, lte } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Print job status enum
 */
const PrintJobStatus = z.enum(['QUEUED', 'PREPARING', 'PRINTING', 'PAUSED', 'COMPLETED', 'FAILED', 'CANCELLED']);

/**
 * Print job filter input schema
 */
const printJobFilterSchema = z.object({
  status: PrintJobStatus.optional(),
  printerId: z.string().optional(),
  filamentId: z.string().optional(),
  orderId: z.string().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'startedAt', 'completedAt']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create print job input schema
 */
const createPrintJobSchema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  description: z.string().optional(),
  orderId: z.string().optional(),
  orderItemId: z.string().optional(),
  printerId: z.string().optional(),
  filamentId: z.string().min(1, 'Filament is required'),
  quantity: z.number().int().min(1).default(1),
  estimatedTime: z.number().int().min(0).optional(), // in minutes
  estimatedFilamentWeight: z.number().min(0).optional(), // in grams
  gcodeFile: z.string().optional(),
  settings: z.object({
    layerHeight: z.number().optional(),
    infill: z.number().optional(),
    supports: z.boolean().optional(),
    printSpeed: z.number().optional(),
    nozzleTemp: z.number().optional(),
    bedTemp: z.number().optional(),
  }).optional(),
  priority: z.number().int().min(0).max(10).default(5),
  scheduledFor: z.date().optional(),
  notes: z.string().optional(),
});

/**
 * Update print job status input schema
 */
const updateStatusSchema = z.object({
  id: z.string(),
  status: PrintJobStatus,
  notes: z.string().optional(),
});

/**
 * Print job response schema
 */
const printJobResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string().nullable(),
  status: PrintJobStatus,
  orderId: z.string().nullable(),
  orderItemId: z.string().nullable(),
  printerId: z.string().nullable(),
  printer: z.object({
    id: z.string(),
    name: z.string(),
  }).nullable(),
  filamentId: z.string(),
  filament: z.object({
    id: z.string(),
    name: z.string(),
    type: z.string(),
    color: z.string(),
    colorHex: z.string().nullable(),
  }),
  quantity: z.number(),
  completedQuantity: z.number(),
  estimatedTime: z.number().nullable(),
  actualTime: z.number().nullable(),
  estimatedFilamentWeight: z.number().nullable(),
  actualFilamentWeight: z.number().nullable(),
  gcodeFile: z.string().nullable(),
  settings: z.record(z.any()).nullable(),
  priority: z.number(),
  scheduledFor: z.date().nullable(),
  startedAt: z.date().nullable(),
  completedAt: z.date().nullable(),
  notes: z.string().nullable(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Print jobs list response schema
 */
const printJobsListResponseSchema = z.object({
  printJobs: z.array(printJobResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Print jobs router
 */
export const printJobsRouter = router({
  /**
   * Get all print jobs with filters
   */
  getAll: protectedProcedure
    .input(printJobFilterSchema)
    .output(printJobsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { status, printerId, filamentId, orderId, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (status) {
        whereConditions.push(eq(schema.printJobs.status, status));
      }
      if (printerId) {
        whereConditions.push(eq(schema.printJobs.printerId, printerId));
      }
      if (filamentId) {
        whereConditions.push(eq(schema.printJobs.filamentId, filamentId));
      }
      if (orderId) {
        whereConditions.push(eq(schema.printJobs.orderId, orderId));
      }

      // Get total count
      const allPrintJobs = await ctx.db.query.printJobs.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allPrintJobs.length;

      // Get paginated print jobs
      const printJobs = await ctx.db.query.printJobs.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.printJobs[sortBy]) : asc(schema.printJobs[sortBy]),
        with: {
          printer: {
            columns: {
              id: true,
              name: true,
            },
          },
          filament: {
            columns: {
              id: true,
              name: true,
              type: true,
              color: true,
              colorHex: true,
            },
          },
        },
      });

      return {
        printJobs: printJobs.map(job => ({
          ...job,
          description: job.description ?? null,
          orderId: job.orderId ?? null,
          orderItemId: job.orderItemId ?? null,
          printerId: job.printerId ?? null,
          printer: job.printer ?? null,
          estimatedTime: job.estimatedTime ?? null,
          actualTime: job.actualTime ?? null,
          estimatedFilamentWeight: job.estimatedFilamentWeight ?? null,
          actualFilamentWeight: job.actualFilamentWeight ?? null,
          gcodeFile: job.gcodeFile ?? null,
          settings: job.settings ?? null,
          scheduledFor: job.scheduledFor ?? null,
          startedAt: job.startedAt ?? null,
          completedAt: job.completedAt ?? null,
          notes: job.notes ?? null,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get print queue (queued and preparing jobs sorted by priority)
   */
  getQueue: protectedProcedure
    .input(z.object({
      page: z.number().int().min(1).default(1),
      limit: z.number().int().min(1).max(100).default(20),
    }))
    .output(printJobsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { page, limit } = input;

      // Get queued and preparing jobs
      const whereConditions = [
        eq(schema.printJobs.status, 'QUEUED'),
      ];

      const allPrintJobs = await ctx.db.query.printJobs.findMany({
        where: and(...whereConditions),
      });
      const total = allPrintJobs.length;

      // Get paginated print jobs sorted by priority (desc) and scheduledFor (asc)
      const printJobs = await ctx.db.query.printJobs.findMany({
        where: and(...whereConditions),
        limit,
        offset: (page - 1) * limit,
        orderBy: [desc(schema.printJobs.priority), asc(schema.printJobs.scheduledFor)],
        with: {
          printer: {
            columns: {
              id: true,
              name: true,
            },
          },
          filament: {
            columns: {
              id: true,
              name: true,
              type: true,
              color: true,
              colorHex: true,
            },
          },
        },
      });

      return {
        printJobs: printJobs.map(job => ({
          ...job,
          description: job.description ?? null,
          orderId: job.orderId ?? null,
          orderItemId: job.orderItemId ?? null,
          printerId: job.printerId ?? null,
          printer: job.printer ?? null,
          estimatedTime: job.estimatedTime ?? null,
          actualTime: job.actualTime ?? null,
          estimatedFilamentWeight: job.estimatedFilamentWeight ?? null,
          actualFilamentWeight: job.actualFilamentWeight ?? null,
          gcodeFile: job.gcodeFile ?? null,
          settings: job.settings ?? null,
          scheduledFor: job.scheduledFor ?? null,
          startedAt: job.startedAt ?? null,
          completedAt: job.completedAt ?? null,
          notes: job.notes ?? null,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Create new print job
   */
  create: protectedProcedure
    .input(createPrintJobSchema)
    .output(printJobResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      // Verify filament exists
      const filament = await ctx.db.query.filaments.findFirst({
        where: eq(schema.filaments.id, input.filamentId),
      });

      if (!filament) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Filament not found',
        });
      }

      // Check if enough filament in stock
      if (input.estimatedFilamentWeight && filament.stockWeight < input.estimatedFilamentWeight) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Not enough filament in stock',
        });
      }

      // Verify printer exists if provided
      if (input.printerId) {
        const printer = await ctx.db.query.printers.findFirst({
          where: eq(schema.printers.id, input.printerId),
        });

        if (!printer) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Printer not found',
          });
        }
      }

      const [printJob] = await ctx.db.insert(schema.printJobs).values({
        name: input.name,
        description: input.description,
        status: 'QUEUED',
        orderId: input.orderId,
        orderItemId: input.orderItemId,
        printerId: input.printerId,
        filamentId: input.filamentId,
        quantity: input.quantity,
        completedQuantity: 0,
        estimatedTime: input.estimatedTime,
        estimatedFilamentWeight: input.estimatedFilamentWeight,
        gcodeFile: input.gcodeFile,
        settings: input.settings,
        priority: input.priority,
        scheduledFor: input.scheduledFor,
        notes: input.notes,
      }).returning();

      if (!printJob) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create print job',
        });
      }

      // Fetch the created print job with relations
      const jobWithRelations = await ctx.db.query.printJobs.findFirst({
        where: eq(schema.printJobs.id, printJob.id),
        with: {
          printer: {
            columns: {
              id: true,
              name: true,
            },
          },
          filament: {
            columns: {
              id: true,
              name: true,
              type: true,
              color: true,
              colorHex: true,
            },
          },
        },
      });

      if (!jobWithRelations) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Print job not found after creation',
        });
      }

      return {
        ...jobWithRelations,
        description: jobWithRelations.description ?? null,
        orderId: jobWithRelations.orderId ?? null,
        orderItemId: jobWithRelations.orderItemId ?? null,
        printerId: jobWithRelations.printerId ?? null,
        printer: jobWithRelations.printer ?? null,
        estimatedTime: jobWithRelations.estimatedTime ?? null,
        actualTime: jobWithRelations.actualTime ?? null,
        estimatedFilamentWeight: jobWithRelations.estimatedFilamentWeight ?? null,
        actualFilamentWeight: jobWithRelations.actualFilamentWeight ?? null,
        gcodeFile: jobWithRelations.gcodeFile ?? null,
        settings: jobWithRelations.settings ?? null,
        scheduledFor: jobWithRelations.scheduledFor ?? null,
        startedAt: jobWithRelations.startedAt ?? null,
        completedAt: jobWithRelations.completedAt ?? null,
        notes: jobWithRelations.notes ?? null,
      };
    }),

  /**
   * Update print job status
   */
  updateStatus: protectedProcedure
    .input(updateStatusSchema)
    .output(printJobResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, status, notes } = input;

      // Check if print job exists
      const existingJob = await ctx.db.query.printJobs.findFirst({
        where: eq(schema.printJobs.id, id),
      });

      if (!existingJob) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Print job not found',
        });
      }

      const updateData: any = {
        status,
        updatedAt: new Date(),
      };

      // Set timestamps based on status
      if (status === 'PRINTING' && !existingJob.startedAt) {
        updateData.startedAt = new Date();
      }
      if (['COMPLETED', 'FAILED', 'CANCELLED'].includes(status) && !existingJob.completedAt) {
        updateData.completedAt = new Date();
      }
      if (notes) {
        updateData.notes = existingJob.notes 
          ? `${existingJob.notes}\n${new Date().toISOString()}: ${notes}`
          : `${new Date().toISOString()}: ${notes}`;
      }

      // Update print job
      await ctx.db.update(schema.printJobs)
        .set(updateData)
        .where(eq(schema.printJobs.id, id));

      // If completed, update filament stock
      if (status === 'COMPLETED' && existingJob.actualFilamentWeight) {
        const filament = await ctx.db.query.filaments.findFirst({
          where: eq(schema.filaments.id, existingJob.filamentId),
        });
        if (filament) {
          await ctx.db.update(schema.filaments)
            .set({
              stockWeight: Math.max(0, filament.stockWeight - existingJob.actualFilamentWeight),
              updatedAt: new Date(),
            })
            .where(eq(schema.filaments.id, existingJob.filamentId));
        }
      }

      // Fetch updated print job
      const printJob = await ctx.db.query.printJobs.findFirst({
        where: eq(schema.printJobs.id, id),
        with: {
          printer: {
            columns: {
              id: true,
              name: true,
            },
          },
          filament: {
            columns: {
              id: true,
              name: true,
              type: true,
              color: true,
              colorHex: true,
            },
          },
        },
      });

      if (!printJob) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Print job not found after update',
        });
      }

      return {
        ...printJob,
        description: printJob.description ?? null,
        orderId: printJob.orderId ?? null,
        orderItemId: printJob.orderItemId ?? null,
        printerId: printJob.printerId ?? null,
        printer: printJob.printer ?? null,
        estimatedTime: printJob.estimatedTime ?? null,
        actualTime: printJob.actualTime ?? null,
        estimatedFilamentWeight: printJob.estimatedFilamentWeight ?? null,
        actualFilamentWeight: printJob.actualFilamentWeight ?? null,
        gcodeFile: printJob.gcodeFile ?? null,
        settings: printJob.settings ?? null,
        scheduledFor: printJob.scheduledFor ?? null,
        startedAt: printJob.startedAt ?? null,
        completedAt: printJob.completedAt ?? null,
        notes: printJob.notes ?? null,
      };
    }),

  /**
   * Delete print job
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if print job exists
      const existingJob = await ctx.db.query.printJobs.findFirst({
        where: eq(schema.printJobs.id, input.id),
      });

      if (!existingJob) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Print job not found',
        });
      }

      // Only allow deletion of queued, failed, or cancelled jobs
      if (!['QUEUED', 'FAILED', 'CANCELLED'].includes(existingJob.status)) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'Can only delete queued, failed, or cancelled print jobs',
        });
      }

      await ctx.db.delete(schema.printJobs).where(eq(schema.printJobs.id, input.id));

      return { success: true };
    }),
});

export type PrintJobsRouter = typeof printJobsRouter;
