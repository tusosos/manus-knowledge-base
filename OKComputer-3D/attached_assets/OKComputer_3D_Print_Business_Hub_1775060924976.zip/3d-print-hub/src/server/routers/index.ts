import { router } from '../trpc';
import { authRouter } from './auth';
import { tasksRouter } from './tasks';
import { projectsRouter } from './projects';
import { clientsRouter } from './clients';
import { filamentsRouter } from './filaments';
import { printJobsRouter } from './printJobs';
import { quotesRouter } from './quotes';
import { analyticsRouter } from './analytics';

/**
 * Main app router
 * Combines all sub-routers
 */
export const appRouter = router({
  auth: authRouter,
  tasks: tasksRouter,
  projects: projectsRouter,
  clients: clientsRouter,
  filaments: filamentsRouter,
  printJobs: printJobsRouter,
  quotes: quotesRouter,
  analytics: analyticsRouter,
});

/**
 * Export type definition of API
 * Used for client type inference
 */
export type AppRouter = typeof appRouter;
