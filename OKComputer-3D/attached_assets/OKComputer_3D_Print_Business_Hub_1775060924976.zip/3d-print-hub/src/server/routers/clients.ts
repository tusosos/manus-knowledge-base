import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, like } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Client type enum
 */
const ClientType = z.enum(['INDIVIDUAL', 'COMPANY']);

/**
 * Client filter input schema
 */
const clientFilterSchema = z.object({
  type: ClientType.optional(),
  search: z.string().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'name']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create client input schema
 */
const createClientSchema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  email: z.string().email('Invalid email address'),
  phone: z.string().max(50).optional(),
  type: ClientType.default('INDIVIDUAL'),
  companyName: z.string().max(200).optional(),
  taxId: z.string().max(50).optional(),
  address: z.object({
    street: z.string().optional(),
    city: z.string().optional(),
    postalCode: z.string().optional(),
    country: z.string().optional(),
  }).optional(),
  notes: z.string().optional(),
});

/**
 * Update client input schema
 */
const updateClientSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(200).optional(),
  email: z.string().email().optional(),
  phone: z.string().max(50).optional(),
  type: ClientType.optional(),
  companyName: z.string().max(200).optional().nullable(),
  taxId: z.string().max(50).optional().nullable(),
  address: z.object({
    street: z.string().optional(),
    city: z.string().optional(),
    postalCode: z.string().optional(),
    country: z.string().optional(),
  }).optional().nullable(),
  notes: z.string().optional().nullable(),
});

/**
 * Client response schema
 */
const clientResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string(),
  phone: z.string().nullable(),
  type: ClientType,
  companyName: z.string().nullable(),
  taxId: z.string().nullable(),
  address: z.object({
    street: z.string().nullable(),
    city: z.string().nullable(),
    postalCode: z.string().nullable(),
    country: z.string().nullable(),
  }).nullable(),
  notes: z.string().nullable(),
  totalOrders: z.number(),
  totalRevenue: z.number(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Clients list response schema
 */
const clientsListResponseSchema = z.object({
  clients: z.array(clientResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Order response schema for getOrders
 */
const clientOrderSchema = z.object({
  id: z.string(),
  orderNumber: z.string(),
  status: z.enum(['DRAFT', 'PENDING', 'CONFIRMED', 'IN_PRODUCTION', 'READY', 'SHIPPED', 'DELIVERED', 'CANCELLED']),
  totalAmount: z.number(),
  createdAt: z.date(),
  project: z.object({
    id: z.string(),
    name: z.string(),
  }).nullable(),
});

/**
 * Clients router
 */
export const clientsRouter = router({
  /**
   * Get all clients with filters
   */
  getAll: protectedProcedure
    .input(clientFilterSchema)
    .output(clientsListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { type, search, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (type) {
        whereConditions.push(eq(schema.clients.type, type));
      }
      if (search) {
        whereConditions.push(
          like(schema.clients.name, `%${search}%`)
        );
      }

      // Get total count
      const allClients = await ctx.db.query.clients.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allClients.length;

      // Get paginated clients
      const clients = await ctx.db.query.clients.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.clients[sortBy]) : asc(schema.clients[sortBy]),
      });

      return {
        clients: clients.map(client => ({
          ...client,
          phone: client.phone ?? null,
          companyName: client.companyName ?? null,
          taxId: client.taxId ?? null,
          address: client.address ?? null,
          notes: client.notes ?? null,
          totalOrders: client.totalOrders ?? 0,
          totalRevenue: client.totalRevenue ?? 0,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get client by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(clientResponseSchema)
    .query(async ({ ctx, input }) => {
      const client = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, input.id),
      });

      if (!client) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found',
        });
      }

      return {
        ...client,
        phone: client.phone ?? null,
        companyName: client.companyName ?? null,
        taxId: client.taxId ?? null,
        address: client.address ?? null,
        notes: client.notes ?? null,
        totalOrders: client.totalOrders ?? 0,
        totalRevenue: client.totalRevenue ?? 0,
      };
    }),

  /**
   * Create new client
   */
  create: protectedProcedure
    .input(createClientSchema)
    .output(clientResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      // Check if email already exists
      const existingClient = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.email, input.email),
      });

      if (existingClient) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Client with this email already exists',
        });
      }

      const [client] = await ctx.db.insert(schema.clients).values({
        name: input.name,
        email: input.email,
        phone: input.phone,
        type: input.type,
        companyName: input.companyName,
        taxId: input.taxId,
        address: input.address,
        notes: input.notes,
        totalOrders: 0,
        totalRevenue: 0,
      }).returning();

      if (!client) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create client',
        });
      }

      return {
        ...client,
        phone: client.phone ?? null,
        companyName: client.companyName ?? null,
        taxId: client.taxId ?? null,
        address: client.address ?? null,
        notes: client.notes ?? null,
        totalOrders: client.totalOrders ?? 0,
        totalRevenue: client.totalRevenue ?? 0,
      };
    }),

  /**
   * Update client
   */
  update: protectedProcedure
    .input(updateClientSchema)
    .output(clientResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, ...updateData } = input;

      // Check if client exists
      const existingClient = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, id),
      });

      if (!existingClient) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found',
        });
      }

      // Check email uniqueness if updating email
      if (updateData.email && updateData.email !== existingClient.email) {
        const emailExists = await ctx.db.query.clients.findFirst({
          where: eq(schema.clients.email, updateData.email),
        });
        if (emailExists) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Client with this email already exists',
          });
        }
      }

      // Update client
      await ctx.db.update(schema.clients)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(schema.clients.id, id));

      // Fetch updated client
      const client = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, id),
      });

      if (!client) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found after update',
        });
      }

      return {
        ...client,
        phone: client.phone ?? null,
        companyName: client.companyName ?? null,
        taxId: client.taxId ?? null,
        address: client.address ?? null,
        notes: client.notes ?? null,
        totalOrders: client.totalOrders ?? 0,
        totalRevenue: client.totalRevenue ?? 0,
      };
    }),

  /**
   * Delete client
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if client exists
      const existingClient = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, input.id),
      });

      if (!existingClient) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found',
        });
      }

      // Check if client has orders
      const orders = await ctx.db.query.orders.findMany({
        where: eq(schema.orders.clientId, input.id),
      });

      if (orders.length > 0) {
        throw new TRPCError({
          code: 'CONFLICT',
          message: 'Cannot delete client with existing orders',
        });
      }

      await ctx.db.delete(schema.clients).where(eq(schema.clients.id, input.id));

      return { success: true };
    }),

  /**
   * Get client orders
   */
  getOrders: protectedProcedure
    .input(z.object({ 
      id: z.string(),
      page: z.number().int().min(1).default(1),
      limit: z.number().int().min(1).max(100).default(20),
    }))
    .output(z.object({
      orders: z.array(clientOrderSchema),
      total: z.number(),
      page: z.number(),
      limit: z.number(),
      totalPages: z.number(),
    }))
    .query(async ({ ctx, input }) => {
      const { id, page, limit } = input;

      // Check if client exists
      const existingClient = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, id),
      });

      if (!existingClient) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found',
        });
      }

      // Get total count
      const allOrders = await ctx.db.query.orders.findMany({
        where: eq(schema.orders.clientId, id),
      });
      const total = allOrders.length;

      // Get paginated orders
      const orders = await ctx.db.query.orders.findMany({
        where: eq(schema.orders.clientId, id),
        limit,
        offset: (page - 1) * limit,
        orderBy: desc(schema.orders.createdAt),
        with: {
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
        },
      });

      return {
        orders: orders.map(order => ({
          ...order,
          project: order.project ?? null,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),
});

export type ClientsRouter = typeof clientsRouter;
