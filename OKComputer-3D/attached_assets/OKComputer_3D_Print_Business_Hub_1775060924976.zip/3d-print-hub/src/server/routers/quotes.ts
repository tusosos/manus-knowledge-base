import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import { router, protectedProcedure } from '../trpc';
import { eq, and, desc, asc, like, gte, lte } from 'drizzle-orm';
import * as schema from '../../db/schema';

/**
 * Quote status enum
 */
const QuoteStatus = z.enum(['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED', 'CONVERTED']);

/**
 * Quote item input schema
 */
const quoteItemInputSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  description: z.string().optional(),
  quantity: z.number().int().min(1).default(1),
  unitPrice: z.number().min(0),
  material: z.string().optional(),
  estimatedTime: z.number().int().min(0).optional(), // in minutes
  estimatedWeight: z.number().min(0).optional(), // in grams
  fileUrl: z.string().optional(),
});

/**
 * Quote filter input schema
 */
const quoteFilterSchema = z.object({
  status: QuoteStatus.optional(),
  clientId: z.string().optional(),
  search: z.string().optional(),
  dateFrom: z.date().optional(),
  dateTo: z.date().optional(),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
  sortBy: z.enum(['createdAt', 'validUntil', 'totalAmount']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

/**
 * Create quote input schema
 */
const createQuoteSchema = z.object({
  clientId: z.string().min(1, 'Client is required'),
  projectId: z.string().optional(),
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().optional(),
  items: z.array(quoteItemInputSchema).min(1, 'At least one item is required'),
  validUntil: z.date(),
  notes: z.string().optional(),
  terms: z.string().optional(),
  discount: z.number().min(0).default(0),
  taxRate: z.number().min(0).max(100).default(23),
});

/**
 * Update quote input schema
 */
const updateQuoteSchema = z.object({
  id: z.string(),
  title: z.string().min(1).max(200).optional(),
  description: z.string().optional(),
  items: z.array(quoteItemInputSchema).optional(),
  validUntil: z.date().optional(),
  notes: z.string().optional().nullable(),
  terms: z.string().optional().nullable(),
  discount: z.number().min(0).optional(),
  taxRate: z.number().min(0).max(100).optional(),
  status: QuoteStatus.optional(),
});

/**
 * Quote item response schema
 */
const quoteItemResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string().nullable(),
  quantity: z.number(),
  unitPrice: z.number(),
  totalPrice: z.number(),
  material: z.string().nullable(),
  estimatedTime: z.number().nullable(),
  estimatedWeight: z.number().nullable(),
  fileUrl: z.string().nullable(),
});

/**
 * Quote response schema
 */
const quoteResponseSchema = z.object({
  id: z.string(),
  quoteNumber: z.string(),
  title: z.string(),
  description: z.string().nullable(),
  status: QuoteStatus,
  clientId: z.string(),
  client: z.object({
    id: z.string(),
    name: z.string(),
    email: z.string(),
    companyName: z.string().nullable(),
  }),
  projectId: z.string().nullable(),
  project: z.object({
    id: z.string(),
    name: z.string(),
  }).nullable(),
  items: z.array(quoteItemResponseSchema),
  subtotal: z.number(),
  discount: z.number(),
  taxRate: z.number(),
  taxAmount: z.number(),
  totalAmount: z.number(),
  validUntil: z.date(),
  notes: z.string().nullable(),
  terms: z.string().nullable(),
  sentAt: z.date().nullable(),
  acceptedAt: z.date().nullable(),
  createdById: z.string(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

/**
 * Quotes list response schema
 */
const quotesListResponseSchema = z.object({
  quotes: z.array(quoteResponseSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

/**
 * Generate quote number
 */
function generateQuoteNumber(): string {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `Q-${year}${month}-${random}`;
}

/**
 * Quotes router
 */
export const quotesRouter = router({
  /**
   * Get all quotes with filters
   */
  getAll: protectedProcedure
    .input(quoteFilterSchema)
    .output(quotesListResponseSchema)
    .query(async ({ ctx, input }) => {
      const { status, clientId, search, dateFrom, dateTo, page, limit, sortBy, sortOrder } = input;

      // Build where conditions
      const whereConditions: any[] = [];

      if (status) {
        whereConditions.push(eq(schema.quotes.status, status));
      }
      if (clientId) {
        whereConditions.push(eq(schema.quotes.clientId, clientId));
      }
      if (search) {
        whereConditions.push(
          like(schema.quotes.title, `%${search}%`)
        );
      }
      if (dateFrom) {
        whereConditions.push(gte(schema.quotes.createdAt, dateFrom));
      }
      if (dateTo) {
        whereConditions.push(lte(schema.quotes.createdAt, dateTo));
      }

      // Get total count
      const allQuotes = await ctx.db.query.quotes.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
      });
      const total = allQuotes.length;

      // Get paginated quotes
      const quotes = await ctx.db.query.quotes.findMany({
        where: whereConditions.length > 0 ? and(...whereConditions) : undefined,
        limit,
        offset: (page - 1) * limit,
        orderBy: sortOrder === 'desc' ? desc(schema.quotes[sortBy]) : asc(schema.quotes[sortBy]),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
              companyName: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
          items: true,
        },
      });

      return {
        quotes: quotes.map(quote => ({
          ...quote,
          description: quote.description ?? null,
          projectId: quote.projectId ?? null,
          project: quote.project ?? null,
          notes: quote.notes ?? null,
          terms: quote.terms ?? null,
          sentAt: quote.sentAt ?? null,
          acceptedAt: quote.acceptedAt ?? null,
        })),
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  /**
   * Get quote by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(quoteResponseSchema)
    .query(async ({ ctx, input }) => {
      const quote = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, input.id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
              companyName: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
          items: true,
        },
      });

      if (!quote) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found',
        });
      }

      return {
        ...quote,
        description: quote.description ?? null,
        projectId: quote.projectId ?? null,
        project: quote.project ?? null,
        notes: quote.notes ?? null,
        terms: quote.terms ?? null,
        sentAt: quote.sentAt ?? null,
        acceptedAt: quote.acceptedAt ?? null,
      };
    }),

  /**
   * Create new quote
   */
  create: protectedProcedure
    .input(createQuoteSchema)
    .output(quoteResponseSchema)
    .mutation(async ({ ctx, input }) => {
      if (!ctx.session?.user) {
        throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not authenticated' });
      }

      // Verify client exists
      const client = await ctx.db.query.clients.findFirst({
        where: eq(schema.clients.id, input.clientId),
      });

      if (!client) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Client not found',
        });
      }

      // Calculate totals
      const subtotal = input.items.reduce((sum, item) => 
        sum + (item.unitPrice * item.quantity), 0
      );
      const discountAmount = subtotal * (input.discount / 100);
      const taxableAmount = subtotal - discountAmount;
      const taxAmount = taxableAmount * (input.taxRate / 100);
      const totalAmount = taxableAmount + taxAmount;

      // Create quote
      const [quote] = await ctx.db.insert(schema.quotes).values({
        quoteNumber: generateQuoteNumber(),
        title: input.title,
        description: input.description,
        status: 'DRAFT',
        clientId: input.clientId,
        projectId: input.projectId,
        subtotal,
        discount: input.discount,
        taxRate: input.taxRate,
        taxAmount,
        totalAmount,
        validUntil: input.validUntil,
        notes: input.notes,
        terms: input.terms,
        createdById: ctx.session.user.id,
      }).returning();

      if (!quote) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to create quote',
        });
      }

      // Create quote items
      for (const item of input.items) {
        await ctx.db.insert(schema.quoteItems).values({
          quoteId: quote.id,
          name: item.name,
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.unitPrice * item.quantity,
          material: item.material,
          estimatedTime: item.estimatedTime,
          estimatedWeight: item.estimatedWeight,
          fileUrl: item.fileUrl,
        });
      }

      // Fetch the created quote with relations
      const quoteWithRelations = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, quote.id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
              companyName: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
          items: true,
        },
      });

      if (!quoteWithRelations) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found after creation',
        });
      }

      return {
        ...quoteWithRelations,
        description: quoteWithRelations.description ?? null,
        projectId: quoteWithRelations.projectId ?? null,
        project: quoteWithRelations.project ?? null,
        notes: quoteWithRelations.notes ?? null,
        terms: quoteWithRelations.terms ?? null,
        sentAt: quoteWithRelations.sentAt ?? null,
        acceptedAt: quoteWithRelations.acceptedAt ?? null,
      };
    }),

  /**
   * Update quote
   */
  update: protectedProcedure
    .input(updateQuoteSchema)
    .output(quoteResponseSchema)
    .mutation(async ({ ctx, input }) => {
      const { id, items, ...updateData } = input;

      // Check if quote exists
      const existingQuote = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, id),
      });

      if (!existingQuote) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found',
        });
      }

      // Only allow updates to draft quotes
      if (existingQuote.status !== 'DRAFT' && !updateData.status) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'Can only update draft quotes',
        });
      }

      // Recalculate totals if items are updated
      let subtotal = existingQuote.subtotal;
      let taxAmount = existingQuote.taxAmount;
      let totalAmount = existingQuote.totalAmount;

      if (items && items.length > 0) {
        subtotal = items.reduce((sum, item) => 
          sum + (item.unitPrice * item.quantity), 0
        );
        const discountAmount = subtotal * ((updateData.discount ?? existingQuote.discount) / 100);
        const taxableAmount = subtotal - discountAmount;
        taxAmount = taxableAmount * ((updateData.taxRate ?? existingQuote.taxRate) / 100);
        totalAmount = taxableAmount + taxAmount;

        // Delete existing items and create new ones
        await ctx.db.delete(schema.quoteItems).where(eq(schema.quoteItems.quoteId, id));
        
        for (const item of items) {
          await ctx.db.insert(schema.quoteItems).values({
            quoteId: id,
            name: item.name,
            description: item.description,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.unitPrice * item.quantity,
            material: item.material,
            estimatedTime: item.estimatedTime,
            estimatedWeight: item.estimatedWeight,
            fileUrl: item.fileUrl,
          });
        }
      }

      // Update quote
      await ctx.db.update(schema.quotes)
        .set({
          ...updateData,
          subtotal,
          taxAmount,
          totalAmount,
          updatedAt: new Date(),
        })
        .where(eq(schema.quotes.id, id));

      // Fetch updated quote
      const quote = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
              companyName: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
          items: true,
        },
      });

      if (!quote) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found after update',
        });
      }

      return {
        ...quote,
        description: quote.description ?? null,
        projectId: quote.projectId ?? null,
        project: quote.project ?? null,
        notes: quote.notes ?? null,
        terms: quote.terms ?? null,
        sentAt: quote.sentAt ?? null,
        acceptedAt: quote.acceptedAt ?? null,
      };
    }),

  /**
   * Delete quote
   */
  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ success: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // Check if quote exists
      const existingQuote = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, input.id),
      });

      if (!existingQuote) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found',
        });
      }

      // Only allow deletion of draft or rejected quotes
      if (!['DRAFT', 'REJECTED'].includes(existingQuote.status)) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'Can only delete draft or rejected quotes',
        });
      }

      // Delete quote items first
      await ctx.db.delete(schema.quoteItems).where(eq(schema.quoteItems.quoteId, input.id));

      // Delete quote
      await ctx.db.delete(schema.quotes).where(eq(schema.quotes.id, input.id));

      return { success: true };
    }),

  /**
   * Generate PDF for quote
   */
  generatePDF: protectedProcedure
    .input(z.object({ id: z.string() }))
    .output(z.object({ 
      success: z.boolean(),
      url: z.string().optional(),
      pdfData: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      // Check if quote exists
      const quote = await ctx.db.query.quotes.findFirst({
        where: eq(schema.quotes.id, input.id),
        with: {
          client: {
            columns: {
              id: true,
              name: true,
              email: true,
              companyName: true,
              address: true,
              taxId: true,
            },
          },
          project: {
            columns: {
              id: true,
              name: true,
            },
          },
          items: true,
        },
      });

      if (!quote) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Quote not found',
        });
      }

      // In a real implementation, this would generate a PDF
      // For now, we return a placeholder response
      // You would use a library like PDFKit, jsPDF, or puppeteer here

      // Example PDF generation placeholder:
      // const pdfBuffer = await generateQuotePDF(quote);
      // const pdfBase64 = pdfBuffer.toString('base64');

      return {
        success: true,
        url: `/api/quotes/${quote.id}/download`,
        // pdfData: pdfBase64, // Uncomment when PDF generation is implemented
      };
    }),
});

export type QuotesRouter = typeof quotesRouter;
