import { useState, useEffect, useCallback, createContext, useContext } from 'react';

// User types for 3D Print Business Hub
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'operator' | 'viewer';
  avatar?: string;
  permissions: Permission[];
  preferences: UserPreferences;
  createdAt: Date;
  lastLoginAt: Date;
}

export interface UserPreferences {
  theme: 'dark' | 'light' | 'system';
  language: string;
  timezone: string;
  currency: string;
  notifications: NotificationPreferences;
  dashboardLayout: DashboardLayout;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  printCompleted: boolean;
  lowFilament: boolean;
  newOrder: boolean;
  taskAssigned: boolean;
}

export interface DashboardLayout {
  widgets: string[];
  sidebarCollapsed: boolean;
}

export type Permission = 
  | 'dashboard:view'
  | 'tasks:view' | 'tasks:create' | 'tasks:edit' | 'tasks:delete'
  | 'projects:view' | 'projects:create' | 'projects:edit' | 'projects:delete'
  | 'inventory:view' | 'inventory:create' | 'inventory:edit' | 'inventory:delete'
  | 'clients:view' | 'clients:create' | 'clients:edit' | 'clients:delete'
  | 'printQueue:view' | 'printQueue:manage'
  | 'quotes:view' | 'quotes:create' | 'quotes:edit' | 'quotes:delete'
  | 'analytics:view'
  | 'settings:view' | 'settings:edit'
  | 'users:view' | 'users:manage';

// Role-based permissions
const rolePermissions: Record<User['role'], Permission[]> = {
  admin: [
    'dashboard:view',
    'tasks:view', 'tasks:create', 'tasks:edit', 'tasks:delete',
    'projects:view', 'projects:create', 'projects:edit', 'projects:delete',
    'inventory:view', 'inventory:create', 'inventory:edit', 'inventory:delete',
    'clients:view', 'clients:create', 'clients:edit', 'clients:delete',
    'printQueue:view', 'printQueue:manage',
    'quotes:view', 'quotes:create', 'quotes:edit', 'quotes:delete',
    'analytics:view',
    'settings:view', 'settings:edit',
    'users:view', 'users:manage',
  ],
  manager: [
    'dashboard:view',
    'tasks:view', 'tasks:create', 'tasks:edit', 'tasks:delete',
    'projects:view', 'projects:create', 'projects:edit', 'projects:delete',
    'inventory:view', 'inventory:create', 'inventory:edit', 'inventory:delete',
    'clients:view', 'clients:create', 'clients:edit', 'clients:delete',
    'printQueue:view', 'printQueue:manage',
    'quotes:view', 'quotes:create', 'quotes:edit', 'quotes:delete',
    'analytics:view',
    'settings:view',
    'users:view',
  ],
  operator: [
    'dashboard:view',
    'tasks:view', 'tasks:create', 'tasks:edit',
    'projects:view',
    'inventory:view', 'inventory:edit',
    'clients:view',
    'printQueue:view', 'printQueue:manage',
    'quotes:view', 'quotes:create',
  ],
  viewer: [
    'dashboard:view',
    'tasks:view',
    'projects:view',
    'inventory:view',
    'clients:view',
    'printQueue:view',
    'quotes:view',
    'analytics:view',
  ],
};

// Auth context interface
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  updatePreferences: (preferences: Partial<UserPreferences>) => Promise<void>;
  hasPermission: (permission: Permission) => boolean;
  hasAnyPermission: (permissions: Permission[]) => boolean;
  refreshToken: () => Promise<void>;
}

// Create auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user for development (replace with actual API calls)
const mockUser: User = {
  id: '1',
  email: 'admin@3dprinthub.com',
  name: 'Admin User',
  role: 'admin',
  avatar: undefined,
  permissions: rolePermissions.admin,
  preferences: {
    theme: 'dark',
    language: 'pl',
    timezone: 'Europe/Warsaw',
    currency: 'PLN',
    notifications: {
      email: true,
      push: true,
      printCompleted: true,
      lowFilament: true,
      newOrder: true,
      taskAssigned: true,
    },
    dashboardLayout: {
      widgets: ['stats', 'queue', 'tasks', 'inventory'],
      sidebarCollapsed: false,
    },
  },
  createdAt: new Date(),
  lastLoginAt: new Date(),
};

// Auth provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('auth_token');
        if (token) {
          // In production, validate token with server
          // For now, use mock user
          setUser(mockUser);
        }
      } catch (error) {
        console.error('Auth check failed:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Login function
  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // In production, make API call to authenticate
      // const response = await api.auth.login({ email, password });
      
      // Mock login
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (email === 'admin@3dprinthub.com' && password === 'admin') {
        const token = 'mock_jwt_token';
        localStorage.setItem('auth_token', token);
        setUser(mockUser);
      } else {
        throw new Error('Invalid credentials');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Logout function
  const logout = useCallback(async () => {
    setIsLoading(true);
    try {
      // In production, make API call to invalidate session
      // await api.auth.logout();
      
      localStorage.removeItem('auth_token');
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Register function
  const register = useCallback(async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      // In production, make API call to register
      // const response = await api.auth.register({ email, password, name });
      
      // Mock registration
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log('Registered:', { email, name });
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Update profile function
  const updateProfile = useCallback(async (updates: Partial<User>) => {
    if (!user) return;
    
    try {
      // In production, make API call to update profile
      // const response = await api.users.updateProfile(user.id, updates);
      
      setUser(prev => prev ? { ...prev, ...updates } : null);
    } catch (error) {
      console.error('Profile update failed:', error);
      throw error;
    }
  }, [user]);

  // Update preferences function
  const updatePreferences = useCallback(async (preferences: Partial<UserPreferences>) => {
    if (!user) return;
    
    try {
      // In production, make API call to update preferences
      // const response = await api.users.updatePreferences(user.id, preferences);
      
      setUser(prev => 
        prev ? { 
          ...prev, 
          preferences: { ...prev.preferences, ...preferences } 
        } : null
      );
    } catch (error) {
      console.error('Preferences update failed:', error);
      throw error;
    }
  }, [user]);

  // Check if user has specific permission
  const hasPermission = useCallback((permission: Permission): boolean => {
    if (!user) return false;
    return user.permissions.includes(permission);
  }, [user]);

  // Check if user has any of the specified permissions
  const hasAnyPermission = useCallback((permissions: Permission[]): boolean => {
    if (!user) return false;
    return permissions.some(p => user.permissions.includes(p));
  }, [user]);

  // Refresh token function
  const refreshToken = useCallback(async () => {
    try {
      // In production, make API call to refresh token
      // const response = await api.auth.refreshToken();
      
      const newToken = 'refreshed_mock_token';
      localStorage.setItem('auth_token', newToken);
    } catch (error) {
      console.error('Token refresh failed:', error);
      // If refresh fails, logout user
      await logout();
    }
  }, [logout]);

  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    register,
    updateProfile,
    updatePreferences,
    hasPermission,
    hasAnyPermission,
    refreshToken,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Hook for protected routes
export const useRequireAuth = (requiredPermissions?: Permission[]) => {
  const { isAuthenticated, isLoading, hasAnyPermission } = useAuth();
  const [location, setLocation] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation('/login');
    }
    
    if (requiredPermissions && !hasAnyPermission(requiredPermissions)) {
      setLocation('/unauthorized');
    }
  }, [isAuthenticated, isLoading, requiredPermissions, hasAnyPermission]);

  return { isLoading, redirectTo: location };
};

// Hook for permission-based rendering
export const usePermission = (permission: Permission): boolean => {
  const { hasPermission } = useAuth();
  return hasPermission(permission);
};

// Permission guard component
export const PermissionGuard: React.FC<{
  permission: Permission;
  children: React.ReactNode;
  fallback?: React.ReactNode;
}> = ({ permission, children, fallback = null }) => {
  const hasPerm = usePermission(permission);
  return hasPerm ? <>{children}</> : <>{fallback}</>;
};

export default useAuth;
