import { PrintCostCalculator } from "@/components/calculator";

export default function CalculatorPage() {
  return <PrintCostCalculator />;
}
