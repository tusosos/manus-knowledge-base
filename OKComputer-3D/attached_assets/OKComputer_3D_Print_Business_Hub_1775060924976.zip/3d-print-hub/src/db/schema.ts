import { 
  sqliteTable, 
  text, 
  integer, 
  real, 
  blob,
  primaryKey 
} from 'drizzle-orm/sqlite-core';
import { relations } from 'drizzle-orm';

// ============================================
// Users Table
// ============================================
export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  name: text('name'),
  role: text('role', { enum: ['ADMIN', 'MANAGER', 'OPERATOR', 'VIEWER'] }).notNull().default('VIEWER'),
  avatar: text('avatar'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const usersRelations = relations(users, ({ many }) => ({
  tasks: many(tasks),
  projects: many(projects),
  quotes: many(quotes),
}));

// ============================================
// Clients Table
// ============================================
export const clients = sqliteTable('clients', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  phone: text('phone'),
  type: text('type', { enum: ['INDIVIDUAL', 'COMPANY'] }).notNull().default('INDIVIDUAL'),
  companyName: text('company_name'),
  taxId: text('tax_id'),
  address: blob('address', { mode: 'json' }).$type<{
    street?: string;
    city?: string;
    postalCode?: string;
    country?: string;
  } | null>(),
  notes: text('notes'),
  totalOrders: integer('total_orders').notNull().default(0),
  totalRevenue: real('total_revenue').notNull().default(0),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const clientsRelations = relations(clients, ({ many }) => ({
  projects: many(projects),
  orders: many(orders),
  quotes: many(quotes),
}));

// ============================================
// Projects Table
// ============================================
export const projects = sqliteTable('projects', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  status: text('status', { enum: ['DRAFT', 'PLANNING', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED'] }).notNull().default('DRAFT'),
  priority: text('priority', { enum: ['LOW', 'MEDIUM', 'HIGH', 'URGENT'] }).notNull().default('MEDIUM'),
  startDate: integer('start_date', { mode: 'timestamp' }),
  deadline: integer('deadline', { mode: 'timestamp' }),
  clientId: text('client_id').references(() => clients.id),
  budget: real('budget'),
  tags: blob('tags', { mode: 'json' }).$type<string[]>().notNull().default([]),
  progress: integer('progress').notNull().default(0),
  createdById: text('created_by_id').notNull().references(() => users.id),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const projectsRelations = relations(projects, ({ one, many }) => ({
  client: one(clients, {
    fields: [projects.clientId],
    references: [clients.id],
  }),
  tasks: many(tasks),
  orders: many(orders),
  quotes: many(quotes),
  creator: one(users, {
    fields: [projects.createdById],
    references: [users.id],
  }),
}));

// ============================================
// Tasks Table
// ============================================
export const tasks = sqliteTable('tasks', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  description: text('description'),
  status: text('status', { enum: ['TODO', 'IN_PROGRESS', 'REVIEW', 'DONE', 'CANCELLED'] }).notNull().default('TODO'),
  priority: text('priority', { enum: ['LOW', 'MEDIUM', 'HIGH', 'URGENT'] }).notNull().default('MEDIUM'),
  dueDate: integer('due_date', { mode: 'timestamp' }),
  assigneeId: text('assignee_id').references(() => users.id),
  projectId: text('project_id').references(() => projects.id),
  tags: blob('tags', { mode: 'json' }).$type<string[]>().notNull().default([]),
  createdById: text('created_by_id').notNull().references(() => users.id),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const tasksRelations = relations(tasks, ({ one }) => ({
  assignee: one(users, {
    fields: [tasks.assigneeId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
  creator: one(users, {
    fields: [tasks.createdById],
    references: [users.id],
  }),
}));

// ============================================
// Filaments Table
// ============================================
export const filaments = sqliteTable('filaments', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  type: text('type', { enum: ['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'NYLON', 'PC', 'PVA', 'HIPS', 'OTHER'] }).notNull(),
  brand: text('brand').notNull(),
  color: text('color').notNull(),
  colorHex: text('color_hex'),
  diameter: real('diameter').notNull().default(1.75),
  weightTotal: real('weight_total').notNull(),
  stockWeight: real('stock_weight').notNull(),
  pricePerKg: real('price_per_kg').notNull(),
  nozzleTemp: blob('nozzle_temp', { mode: 'json' }).$type<{ min: number; max: number } | null>(),
  bedTemp: blob('bed_temp', { mode: 'json' }).$type<{ min: number; max: number } | null>(),
  location: text('location'),
  notes: text('notes'),
  lowStockThreshold: real('low_stock_threshold').notNull().default(200),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const filamentsRelations = relations(filaments, ({ many }) => ({
  printJobs: many(printJobs),
}));

// ============================================
// Printers Table
// ============================================
export const printers = sqliteTable('printers', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  model: text('model').notNull(),
  manufacturer: text('manufacturer').notNull(),
  status: text('status', { enum: ['IDLE', 'PRINTING', 'PAUSED', 'MAINTENANCE', 'OFFLINE', 'ERROR'] }).notNull().default('IDLE'),
  buildVolume: blob('build_volume', { mode: 'json' }).$type<{ x: number; y: number; z: number }>(),
  nozzleDiameter: real('nozzle_diameter').notNull().default(0.4),
  currentFilamentId: text('current_filament_id').references(() => filaments.id),
  totalPrintTime: integer('total_print_time').notNull().default(0), // in minutes
  totalPrints: integer('total_prints').notNull().default(0),
  lastMaintenance: integer('last_maintenance', { mode: 'timestamp' }),
  notes: text('notes'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const printersRelations = relations(printers, ({ one, many }) => ({
  currentFilament: one(filaments, {
    fields: [printers.currentFilamentId],
    references: [filaments.id],
  }),
  printJobs: many(printJobs),
}));

// ============================================
// Print Jobs Table
// ============================================
export const printJobs = sqliteTable('print_jobs', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  status: text('status', { enum: ['QUEUED', 'PREPARING', 'PRINTING', 'PAUSED', 'COMPLETED', 'FAILED', 'CANCELLED'] }).notNull().default('QUEUED'),
  orderId: text('order_id').references(() => orders.id),
  orderItemId: text('order_item_id').references(() => orderItems.id),
  printerId: text('printer_id').references(() => printers.id),
  filamentId: text('filament_id').notNull().references(() => filaments.id),
  quantity: integer('quantity').notNull().default(1),
  completedQuantity: integer('completed_quantity').notNull().default(0),
  estimatedTime: integer('estimated_time'), // in minutes
  actualTime: integer('actual_time'), // in minutes
  estimatedFilamentWeight: real('estimated_filament_weight'), // in grams
  actualFilamentWeight: real('actual_filament_weight'), // in grams
  gcodeFile: text('gcode_file'),
  settings: blob('settings', { mode: 'json' }).$type<{
    layerHeight?: number;
    infill?: number;
    supports?: boolean;
    printSpeed?: number;
    nozzleTemp?: number;
    bedTemp?: number;
  }>(),
  priority: integer('priority').notNull().default(5),
  scheduledFor: integer('scheduled_for', { mode: 'timestamp' }),
  startedAt: integer('started_at', { mode: 'timestamp' }),
  completedAt: integer('completed_at', { mode: 'timestamp' }),
  notes: text('notes'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const printJobsRelations = relations(printJobs, ({ one }) => ({
  order: one(orders, {
    fields: [printJobs.orderId],
    references: [orders.id],
  }),
  orderItem: one(orderItems, {
    fields: [printJobs.orderItemId],
    references: [orderItems.id],
  }),
  printer: one(printers, {
    fields: [printJobs.printerId],
    references: [printers.id],
  }),
  filament: one(filaments, {
    fields: [printJobs.filamentId],
    references: [filaments.id],
  }),
}));

// ============================================
// Orders Table
// ============================================
export const orders = sqliteTable('orders', {
  id: text('id').primaryKey(),
  orderNumber: text('order_number').notNull().unique(),
  clientId: text('client_id').notNull().references(() => clients.id),
  projectId: text('project_id').references(() => projects.id),
  status: text('status', { enum: ['DRAFT', 'PENDING', 'CONFIRMED', 'IN_PRODUCTION', 'READY', 'SHIPPED', 'DELIVERED', 'CANCELLED'] }).notNull().default('DRAFT'),
  subtotal: real('subtotal').notNull().default(0),
  discount: real('discount').notNull().default(0),
  taxRate: real('tax_rate').notNull().default(23),
  taxAmount: real('tax_amount').notNull().default(0),
  totalAmount: real('total_amount').notNull().default(0),
  shippingCost: real('shipping_cost').notNull().default(0),
  shippingAddress: blob('shipping_address', { mode: 'json' }).$type<{
    street?: string;
    city?: string;
    postalCode?: string;
    country?: string;
  }>(),
  notes: text('notes'),
  internalNotes: text('internal_notes'),
  dueDate: integer('due_date', { mode: 'timestamp' }),
  completedAt: integer('completed_at', { mode: 'timestamp' }),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const ordersRelations = relations(orders, ({ one, many }) => ({
  client: one(clients, {
    fields: [orders.clientId],
    references: [clients.id],
  }),
  project: one(projects, {
    fields: [orders.projectId],
    references: [projects.id],
  }),
  items: many(orderItems),
  printJobs: many(printJobs),
}));

// ============================================
// Order Items Table
// ============================================
export const orderItems = sqliteTable('order_items', {
  id: text('id').primaryKey(),
  orderId: text('order_id').notNull().references(() => orders.id),
  name: text('name').notNull(),
  description: text('description'),
  quantity: integer('quantity').notNull().default(1),
  unitPrice: real('unit_price').notNull(),
  totalPrice: real('total_price').notNull(),
  material: text('material'),
  estimatedTime: integer('estimated_time'), // in minutes
  estimatedWeight: real('estimated_weight'), // in grams
  fileUrl: text('file_url'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const orderItemsRelations = relations(orderItems, ({ one, many }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  printJobs: many(printJobs),
}));

// ============================================
// Quotes Table
// ============================================
export const quotes = sqliteTable('quotes', {
  id: text('id').primaryKey(),
  quoteNumber: text('quote_number').notNull().unique(),
  title: text('title').notNull(),
  description: text('description'),
  status: text('status', { enum: ['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED', 'CONVERTED'] }).notNull().default('DRAFT'),
  clientId: text('client_id').notNull().references(() => clients.id),
  projectId: text('project_id').references(() => projects.id),
  subtotal: real('subtotal').notNull().default(0),
  discount: real('discount').notNull().default(0),
  taxRate: real('tax_rate').notNull().default(23),
  taxAmount: real('tax_amount').notNull().default(0),
  totalAmount: real('total_amount').notNull().default(0),
  validUntil: integer('valid_until', { mode: 'timestamp' }).notNull(),
  notes: text('notes'),
  terms: text('terms'),
  sentAt: integer('sent_at', { mode: 'timestamp' }),
  acceptedAt: integer('accepted_at', { mode: 'timestamp' }),
  createdById: text('created_by_id').notNull().references(() => users.id),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const quotesRelations = relations(quotes, ({ one, many }) => ({
  client: one(clients, {
    fields: [quotes.clientId],
    references: [clients.id],
  }),
  project: one(projects, {
    fields: [quotes.projectId],
    references: [projects.id],
  }),
  creator: one(users, {
    fields: [quotes.createdById],
    references: [users.id],
  }),
  items: many(quoteItems),
}));

// ============================================
// Quote Items Table
// ============================================
export const quoteItems = sqliteTable('quote_items', {
  id: text('id').primaryKey(),
  quoteId: text('quote_id').notNull().references(() => quotes.id),
  name: text('name').notNull(),
  description: text('description'),
  quantity: integer('quantity').notNull().default(1),
  unitPrice: real('unit_price').notNull(),
  totalPrice: real('total_price').notNull(),
  material: text('material'),
  estimatedTime: integer('estimated_time'), // in minutes
  estimatedWeight: real('estimated_weight'), // in grams
  fileUrl: text('file_url'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const quoteItemsRelations = relations(quoteItems, ({ one }) => ({
  quote: one(quotes, {
    fields: [quoteItems.quoteId],
    references: [quotes.id],
  }),
}));

// ============================================
// Activity Log Table
// ============================================
export const activityLog = sqliteTable('activity_log', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id),
  action: text('action').notNull(),
  entityType: text('entity_type').notNull(), // 'order', 'project', 'task', etc.
  entityId: text('entity_id').notNull(),
  details: blob('details', { mode: 'json' }),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const activityLogRelations = relations(activityLog, ({ one }) => ({
  user: one(users, {
    fields: [activityLog.userId],
    references: [users.id],
  }),
}));
