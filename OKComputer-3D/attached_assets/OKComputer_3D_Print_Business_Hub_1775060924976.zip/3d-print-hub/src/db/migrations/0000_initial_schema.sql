-- 3D Print Business Hub - Initial Database Schema
-- Generated for MySQL/TiDB
-- ============================================

-- ============================================
-- 1. USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `role` enum('admin','manager','operator','viewer') DEFAULT 'operator',
  `avatar_url` varchar(500),
  `phone` varchar(20),
  `is_active` boolean DEFAULT true,
  `last_login_at` timestamp,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Users indexes
CREATE UNIQUE INDEX `users_email_idx` ON `users` (`email`);
CREATE INDEX `users_role_idx` ON `users` (`role`);
CREATE INDEX `users_active_idx` ON `users` (`is_active`);

-- ============================================
-- 2. CLIENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `clients` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20),
  `company_name` varchar(200),
  `tax_id` varchar(50),
  `address` text,
  `city` varchar(100),
  `postal_code` varchar(20),
  `country` varchar(100) DEFAULT 'Poland',
  `notes` text,
  `status` enum('active','inactive','blocked','vip') DEFAULT 'active',
  `assigned_to` int,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
);

-- Clients indexes
CREATE UNIQUE INDEX `clients_email_idx` ON `clients` (`email`);
CREATE INDEX `clients_status_idx` ON `clients` (`status`);
CREATE INDEX `clients_assigned_idx` ON `clients` (`assigned_to`);
CREATE INDEX `clients_name_idx` ON `clients` (`last_name`, `first_name`);
CREATE INDEX `clients_company_idx` ON `clients` (`company_name`);

-- ============================================
-- 3. PROJECTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(200) NOT NULL,
  `description` text,
  `client_id` int,
  `status` enum('draft','pending','approved','in_progress','completed','cancelled') DEFAULT 'draft',
  `model_url` varchar(500),
  `model_file_name` varchar(255),
  `model_file_size` int,
  `preview_image_url` varchar(500),
  `estimated_print_time` int,
  `actual_print_time` int,
  `material_weight` decimal(10,2),
  `material_cost` decimal(10,2),
  `labor_cost` decimal(10,2),
  `overhead_cost` decimal(10,2),
  `total_cost` decimal(10,2),
  `price` decimal(10,2),
  `profit_margin` decimal(5,2),
  `quantity` int DEFAULT 1,
  `completed_quantity` int DEFAULT 0,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `deadline` date,
  `started_at` timestamp,
  `completed_at` timestamp,
  `created_by` int,
  `assigned_to` int,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
);

-- Projects indexes
CREATE INDEX `projects_client_idx` ON `projects` (`client_id`);
CREATE INDEX `projects_status_idx` ON `projects` (`status`);
CREATE INDEX `projects_deadline_idx` ON `projects` (`deadline`);
CREATE INDEX `projects_priority_idx` ON `projects` (`priority`);
CREATE INDEX `projects_assigned_idx` ON `projects` (`assigned_to`);
CREATE INDEX `projects_created_by_idx` ON `projects` (`created_by`);
CREATE INDEX `projects_name_idx` ON `projects` (`name`);

-- ============================================
-- 4. FILAMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `filaments` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(200) NOT NULL,
  `brand` varchar(100),
  `material` enum('PLA','ABS','PETG','TPU','ASA','nylon','PC','wood','metal_filled','carbon_fiber') NOT NULL,
  `color` varchar(100) NOT NULL,
  `color_hex` varchar(7),
  `diameter` decimal(3,2) DEFAULT 1.75,
  `weight_total` decimal(10,2) NOT NULL,
  `weight_remaining` decimal(10,2) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `cost_per_gram` decimal(10,4),
  `nozzle_temp_min` int,
  `nozzle_temp_max` int,
  `bed_temp_min` int,
  `bed_temp_max` int,
  `spool_weight` decimal(10,2) DEFAULT 250,
  `sku` varchar(100),
  `supplier` varchar(200),
  `purchase_date` date,
  `alert_threshold` decimal(10,2) DEFAULT 100,
  `is_active` boolean DEFAULT true,
  `notes` text,
  `location` varchar(100),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Filaments indexes
CREATE INDEX `filaments_material_idx` ON `filaments` (`material`);
CREATE INDEX `filaments_color_idx` ON `filaments` (`color`);
CREATE INDEX `filaments_brand_idx` ON `filaments` (`brand`);
CREATE INDEX `filaments_active_idx` ON `filaments` (`is_active`);
CREATE UNIQUE INDEX `filaments_sku_idx` ON `filaments` (`sku`);
CREATE INDEX `filaments_remaining_idx` ON `filaments` (`weight_remaining`);

-- ============================================
-- 5. PRINT JOBS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `print_jobs` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `project_id` int,
  `filament_id` int,
  `status` enum('queued','printing','paused','completed','failed','cancelled') DEFAULT 'queued',
  `printer_name` varchar(100),
  `nozzle_size` enum('0.25','0.4','0.6','0.8','1.0') DEFAULT '0.4',
  `layer_height` decimal(3,2) DEFAULT 0.2,
  `infill_percentage` int DEFAULT 20,
  `print_speed` int DEFAULT 50,
  `estimated_duration` int,
  `actual_duration` int,
  `material_used` decimal(10,2),
  `started_at` timestamp,
  `completed_at` timestamp,
  `failed_at` timestamp,
  `failure_reason` text,
  `gcode_file_name` varchar(255),
  `gcode_file_url` varchar(500),
  `sliced_by` int,
  `started_by` int,
  `quality_settings` text,
  `notes` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`filament_id`) REFERENCES `filaments` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`sliced_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`started_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
);

-- Print jobs indexes
CREATE INDEX `print_jobs_project_idx` ON `print_jobs` (`project_id`);
CREATE INDEX `print_jobs_filament_idx` ON `print_jobs` (`filament_id`);
CREATE INDEX `print_jobs_status_idx` ON `print_jobs` (`status`);
CREATE INDEX `print_jobs_printer_idx` ON `print_jobs` (`printer_name`);
CREATE INDEX `print_jobs_started_idx` ON `print_jobs` (`started_at`);
CREATE INDEX `print_jobs_completed_idx` ON `print_jobs` (`completed_at`);

-- ============================================
-- 6. TASKS TABLE (Kanban)
-- ============================================
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `title` varchar(200) NOT NULL,
  `description` text,
  `status` enum('backlog','todo','in_progress','review','done') DEFAULT 'backlog',
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `category` enum('design','printing','post_processing','delivery','maintenance','admin') DEFAULT 'printing',
  `deadline` date,
  `estimated_hours` decimal(5,2),
  `actual_hours` decimal(5,2),
  `project_id` int,
  `client_id` int,
  `assigned_to` int,
  `created_by` int,
  `parent_task_id` int,
  `position` int DEFAULT 0,
  `tags` text,
  `attachments` text,
  `completed_at` timestamp,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
);

-- Tasks indexes
CREATE INDEX `tasks_status_idx` ON `tasks` (`status`);
CREATE INDEX `tasks_priority_idx` ON `tasks` (`priority`);
CREATE INDEX `tasks_category_idx` ON `tasks` (`category`);
CREATE INDEX `tasks_deadline_idx` ON `tasks` (`deadline`);
CREATE INDEX `tasks_project_idx` ON `tasks` (`project_id`);
CREATE INDEX `tasks_client_idx` ON `tasks` (`client_id`);
CREATE INDEX `tasks_assigned_idx` ON `tasks` (`assigned_to`);
CREATE INDEX `tasks_created_by_idx` ON `tasks` (`created_by`);
CREATE INDEX `tasks_parent_idx` ON `tasks` (`parent_task_id`);
CREATE INDEX `tasks_position_idx` ON `tasks` (`status`, `position`);

-- ============================================
-- 7. QUOTES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `quote_number` varchar(50) NOT NULL,
  `client_id` int NOT NULL,
  `project_id` int,
  `title` varchar(200) NOT NULL,
  `description` text,
  `items` text NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) DEFAULT 0,
  `discount_percent` decimal(5,2) DEFAULT 0,
  `tax_rate` decimal(5,2) DEFAULT 23,
  `tax_amount` decimal(10,2),
  `total_amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'PLN',
  `status` enum('draft','sent','accepted','rejected','expired') DEFAULT 'draft',
  `valid_until` date,
  `sent_at` timestamp,
  `accepted_at` timestamp,
  `rejected_at` timestamp,
  `rejection_reason` text,
  `notes` text,
  `terms_and_conditions` text,
  `created_by` int,
  `sent_by` int,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`sent_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
);

-- Quotes indexes
CREATE UNIQUE INDEX `quotes_number_idx` ON `quotes` (`quote_number`);
CREATE INDEX `quotes_client_idx` ON `quotes` (`client_id`);
CREATE INDEX `quotes_project_idx` ON `quotes` (`project_id`);
CREATE INDEX `quotes_status_idx` ON `quotes` (`status`);
CREATE INDEX `quotes_valid_until_idx` ON `quotes` (`valid_until`);
CREATE INDEX `quotes_created_by_idx` ON `quotes` (`created_by`);
CREATE INDEX `quotes_sent_at_idx` ON `quotes` (`sent_at`);
