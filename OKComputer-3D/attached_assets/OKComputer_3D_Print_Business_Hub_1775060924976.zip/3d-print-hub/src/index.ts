import Fastify from 'fastify';
import cors from '@fastify/cors';
import cookie from '@fastify/cookie';
import { fastifyTRPCPlugin } from '@trpc/server/adapters/fastify';
import { appRouter } from './server/routers';
import { createContext } from './server/context';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as schema from './db/schema';

// Initialize database
const sqlite = new Database(process.env.DATABASE_URL || './sqlite.db');
const db = drizzle(sqlite, { schema });

// Create Fastify instance
const app = Fastify({
  logger: true,
});

// Register plugins
async function start() {
  // CORS
  await app.register(cors, {
    origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
    credentials: true,
  });

  // Cookies
  await app.register(cookie, {
    secret: process.env.COOKIE_SECRET || 'your-secret-key',
    parseOptions: {},
  });

  // Attach db to request
  app.addHook('onRequest', async (request) => {
    (request as any).db = db;
  });

  // Session middleware (simplified - use proper session management in production)
  app.addHook('onRequest', async (request, reply) => {
    const sessionToken = request.cookies.session;
    if (sessionToken) {
      // Verify and decode session token
      // In production, use a proper session store (Redis, database, etc.)
      try {
        // Placeholder for session verification
        // const session = await verifySession(sessionToken);
        // (request as any).session = session;
      } catch {
        // Invalid session
      }
    }
  });

  // tRPC
  await app.register(fastifyTRPCPlugin, {
    prefix: '/api/trpc',
    trpcOptions: {
      router: appRouter,
      createContext,
    },
  });

  // Health check
  app.get('/health', async () => {
    return { status: 'ok', timestamp: new Date().toISOString() };
  });

  // Start server
  const port = parseInt(process.env.PORT || '4000');
  const host = process.env.HOST || '0.0.0.0';

  try {
    await app.listen({ port, host });
    console.log(`🚀 Server running at http://${host}:${port}`);
    console.log(`📡 tRPC endpoint: http://${host}:${port}/api/trpc`);
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
}

start();

// Export for testing
export { app, db };
