import { useState } from 'react';
import { 
  Target, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package,
  ExternalLink,
  AlertCircle,
  BarChart3,
  Eye,
  Bookmark,
  Filter
} from 'lucide-react';

interface Competitor {
  id: string;
  name: string;
  platform: 'allegro' | 'etsy' | 'ebay' | 'olx';
  products: number;
  avgPrice: number;
  rating: number;
  sales: number;
  trend: number;
  lastUpdated: string;
}

interface CompetitorProduct {
  id: string;
  name: string;
  competitor: string;
  price: number;
  ourPrice?: number;
  rating: number;
  sales: number;
  trend: number;
}

const mockCompetitors: Competitor[] = [
  { id: '1', name: '3DPrintStudio', platform: 'allegro', products: 156, avgPrice: 45, rating: 4.8, sales: 2340, trend: 15, lastUpdated: '2024-01-15' },
  { id: '2', name: 'PrintMasterPL', platform: 'allegro', products: 89, avgPrice: 52, rating: 4.6, sales: 1890, trend: -5, lastUpdated: '2024-01-14' },
  { id: '3', name: 'MakerSpace3D', platform: 'etsy', products: 234, avgPrice: 38, rating: 4.9, sales: 4560, trend: 28, lastUpdated: '2024-01-15' },
  { id: '4', name: 'Druk3DPro', platform: 'olx', products: 45, avgPrice: 35, rating: 4.4, sales: 670, trend: 8, lastUpdated: '2024-01-13' },
  { id: '5', name: 'CreativePrints', platform: 'ebay', products: 123, avgPrice: 48, rating: 4.7, sales: 2150, trend: 12, lastUpdated: '2024-01-14' },
];

const mockProducts: CompetitorProduct[] = [
  { id: '1', name: 'Wsporniki półek uniwersalne', competitor: '3DPrintStudio', price: 18, ourPrice: 15, rating: 4.7, sales: 234, trend: 15 },
  { id: '2', name: 'Obudowa Raspberry Pi 4', competitor: 'PrintMasterPL', price: 95, ourPrice: 85, rating: 4.8, sales: 156, trend: 8 },
  { id: '3', name: 'Uchwyt na telefon', competitor: 'MakerSpace3D', price: 29, ourPrice: 35, rating: 4.5, sales: 445, trend: -3 },
  { id: '4', name: 'Zawiasy meblowe', competitor: 'Druk3DPro', price: 15, ourPrice: 12, rating: 4.3, sales: 89, trend: 22 },
  { id: '5', name: 'Stojak na słuchawki', competitor: 'CreativePrints', price: 49, ourPrice: 55, rating: 4.6, sales: 178, trend: 5 },
];

const platformColors: Record<string, string> = {
  'allegro': 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  'etsy': 'bg-orange-600/10 text-orange-500 border-orange-600/20',
  'ebay': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'olx': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
};

export const CompetitionPage: React.FC = () => {
  const [competitors] = useState<Competitor[]>(mockCompetitors);
  const [products] = useState<CompetitorProduct[]>(mockProducts);
  const [activeTab, setActiveTab] = useState<'competitors' | 'products' | 'pricing'>('competitors');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCompetitors = competitors.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const avgMarketPrice = products.reduce((sum, p) => sum + p.price, 0) / products.length;
  const ourAvgPrice = products.filter(p => p.ourPrice).reduce((sum, p) => sum + (p.ourPrice || 0), 0) / products.filter(p => p.ourPrice).length;
  const priceDifference = ((ourAvgPrice - avgMarketPrice) / avgMarketPrice * 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Konkurencja</h1>
          <p className="text-slate-400">Monitoruj konkurencję i analizuj ceny rynkowe</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Search size={18} />
          Dodaj konkurenta
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Target size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{competitors.length}</p>
              <p className="text-sm text-slate-500">Monitorowanych</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <DollarSign size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{avgMarketPrice.toFixed(0)} zł</p>
              <p className="text-sm text-slate-500">Śr. cena rynkowa</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <BarChart3 size={20} className="text-amber-400" />
            </div>
            <div>
              <p className={`text-2xl font-bold ${priceDifference >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {priceDifference > 0 ? '+' : ''}{priceDifference.toFixed(0)}%
              </p>
              <p className="text-sm text-slate-500">Nasza pozycja</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/10 rounded-lg">
              <Package size={20} className="text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{products.length}</p>
              <p className="text-sm text-slate-500">Produktów śledzonych</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2a2a2a]">
        {[
          { id: 'competitors', label: 'Konkurenci', icon: Target },
          { id: 'products', label: 'Produkty', icon: Package },
          { id: 'pricing', label: 'Analiza cen', icon: DollarSign },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`
              flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2
              ${activeTab === tab.id 
                ? 'text-amber-400 border-amber-400' 
                : 'text-slate-400 border-transparent hover:text-white'
              }
            `}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          placeholder={activeTab === 'competitors' ? "Szukaj konkurentów..." : "Szukaj produktów..."}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full max-w-md pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
        />
      </div>

      {/* Competitors Tab */}
      {activeTab === 'competitors' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCompetitors.map((competitor) => (
            <div key={competitor.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="font-semibold text-white">{competitor.name}</h3>
                  <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded-full border mt-1 ${platformColors[competitor.platform]}`}>
                    {competitor.platform}
                  </span>
                </div>
                <div className={`flex items-center gap-1 text-sm ${competitor.trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {competitor.trend >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {Math.abs(competitor.trend)}%
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-2 bg-[#1a1a1a] rounded-lg text-center">
                  <p className="text-lg font-bold text-white">{competitor.products}</p>
                  <p className="text-xs text-slate-500">Produktów</p>
                </div>
                <div className="p-2 bg-[#1a1a1a] rounded-lg text-center">
                  <p className="text-lg font-bold text-amber-400">{competitor.avgPrice} zł</p>
                  <p className="text-xs text-slate-500">Śr. cena</p>
                </div>
                <div className="p-2 bg-[#1a1a1a] rounded-lg text-center">
                  <p className="text-lg font-bold text-white">{competitor.sales}</p>
                  <p className="text-xs text-slate-500">Sprzedaż</p>
                </div>
                <div className="p-2 bg-[#1a1a1a] rounded-lg text-center">
                  <p className="text-lg font-bold text-purple-400">{competitor.rating}</p>
                  <p className="text-xs text-slate-500">Ocena</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Aktualizacja: {competitor.lastUpdated}</span>
                <button className="text-amber-400 hover:text-amber-300 flex items-center gap-1">
                  <ExternalLink size={14} />
                  Odwiedź
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Products Tab */}
      {activeTab === 'products' && (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Produkt</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Konkurent</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Ich cena</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Nasza cena</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Różnica</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Sprzedaż</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Trend</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((product) => {
                const difference = product.ourPrice ? ((product.ourPrice - product.price) / product.price * 100) : null;
                return (
                  <tr key={product.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                    <td className="py-3 px-4">
                      <span className="text-sm font-medium text-white">{product.name}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-slate-400">{product.competitor}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-white">{product.price} zł</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-amber-400">{product.ourPrice ? `${product.ourPrice} zł` : '-'}</span>
                    </td>
                    <td className="py-3 px-4">
                      {difference !== null ? (
                        <span className={`text-sm ${difference > 0 ? 'text-red-400' : 'text-green-400'}`}>
                          {difference > 0 ? '+' : ''}{difference.toFixed(0)}%
                        </span>
                      ) : (
                        <span className="text-sm text-slate-500">-</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-white">{product.sales}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className={`flex items-center gap-1 text-sm ${product.trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {product.trend >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                        {Math.abs(product.trend)}%
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pricing Tab */}
      {activeTab === 'pricing' && (
        <div className="industrial-card p-8 text-center">
          <BarChart3 size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">Analiza cenowa</h3>
          <p className="text-slate-500">Szczegółowa analiza cenowa w przygotowaniu</p>
        </div>
      )}
    </div>
  );
};

export default CompetitionPage;
