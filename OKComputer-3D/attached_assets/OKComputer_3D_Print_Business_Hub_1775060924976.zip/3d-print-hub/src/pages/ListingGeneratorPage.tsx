import { useState } from 'react';
import { 
  FileCode, 
  Copy, 
  RefreshCw, 
  Download, 
  Sparkles,
  Check,
  Image as ImageIcon,
  Tag,
  DollarSign,
  Package,
  Truck,
  Star,
  Wand2,
  Settings,
  Languages
} from 'lucide-react';

interface ListingData {
  productName: string;
  category: string;
  material: string;
  dimensions: string;
  weight: number;
  price: number;
  description: string;
  features: string[];
  shippingTime: string;
  customization: boolean;
  language: 'pl' | 'en' | 'de';
}

const categories = [
  'Meble i wyposażenie',
  'Elektronika i gadżety',
  'Dekoracje',
  'Biuro i organizacja',
  'Sport i rekreacja',
  'Zabawki i hobby',
  'Narzędzia i części',
  'Inne',
];

const materials = ['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'Nylon', 'PC', 'Wood', 'Metal-filled'];

export const ListingGeneratorPage: React.FC = () => {
  const [formData, setFormData] = useState<ListingData>({
    productName: '',
    category: '',
    material: 'PLA',
    dimensions: '',
    weight: 50,
    price: 0,
    description: '',
    features: [],
    shippingTime: '3-5 dni',
    customization: false,
    language: 'pl',
  });

  const [generatedListing, setGeneratedListing] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [newFeature, setNewFeature] = useState('');

  const addFeature = () => {
    if (newFeature.trim()) {
      setFormData({ ...formData, features: [...formData.features, newFeature.trim()] });
      setNewFeature('');
    }
  };

  const removeFeature = (index: number) => {
    setFormData({ ...formData, features: formData.features.filter((_, i) => i !== index) });
  };

  const generateListing = async () => {
    setIsGenerating(true);
    
    // Simulate AI generation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const titles: Record<string, string[]> = {
      pl: [
        `✨ ${formData.productName} - Wydruk 3D z ${formData.material}`,
        `🎨 ${formData.productName} - Handmade 3D Print ${formData.material}`,
        `⭐ ${formData.productName} - Profesjonalny wydruk 3D`,
      ],
      en: [
        `✨ ${formData.productName} - 3D Printed ${formData.material}`,
        `🎨 ${formData.productName} - Professional 3D Print`,
        `⭐ ${formData.productName} - Premium Quality 3D Print`,
      ],
      de: [
        `✨ ${formData.productName} - 3D-Druck aus ${formData.material}`,
        `🎨 ${formData.productName} - Professioneller 3D-Druck`,
      ],
    };

    const descriptions: Record<string, string> = {
      pl: `🎯 ${formData.productName}

✅ WYKONANE Z NAJWYŻSZĄ STARANNOŚCIĄ
Nasze produkty są drukowane na profesjonalnych drukarkach 3D z najwyższą precyzją. Każdy element jest dokładnie sprawdzany przed wysyłką.

📦 SPECJYKACJA:
• Materiał: ${formData.material} (wysoka jakość)
• Wymiary: ${formData.dimensions || 'według specyfikacji'}
• Waga: ~${formData.weight}g
• Kolor: Dostępne różne kolory (wybierz przy zamówieniu)

⭐ DLACZEGO WARTO NAS WYBRAĆ?
${formData.features.map(f => `✓ ${f}`).join('\n')}
✓ Szybka realizacja (${formData.shippingTime})
✓ Bezpieczne pakowanie
✓ Gwarancja satysfakcji
${formData.customization ? '✓ Możliwość personalizacji' : ''}

🚚 WYSYŁKA:
• Czas realizacji: ${formData.shippingTime}
• Bezpieczne pakowanie w ekologiczne materiały
• Śledzenie przesyłki

💬 MASZ PYTANIA?
Skontaktuj się z nami! Chętnie pomożemy i doradzimy.

#3dprint #${formData.material.toLowerCase()} #handmade #${formData.category.toLowerCase().replace(/\s+/g, '')}`,

      en: `🎯 ${formData.productName}

✅ CRAFTED WITH PRECISION
Our products are printed on professional 3D printers with the highest precision. Each item is carefully inspected before shipping.

📦 SPECIFICATIONS:
• Material: ${formData.material} (premium quality)
• Dimensions: ${formData.dimensions || 'as specified'}
• Weight: ~${formData.weight}g
• Color: Multiple colors available (choose when ordering)

⭐ WHY CHOOSE US?
${formData.features.map(f => `✓ ${f}`).join('\n')}
✓ Fast processing (${formData.shippingTime})
✓ Secure packaging
✓ Satisfaction guarantee
${formData.customization ? '✓ Customization available' : ''}

🚚 SHIPPING:
• Processing time: ${formData.shippingTime}
• Secure eco-friendly packaging
• Tracking included

💬 QUESTIONS?
Contact us! We're happy to help and advise.

#3dprint #${formData.material.toLowerCase()} #handmade #${formData.category.toLowerCase().replace(/\s+/g, '')}`,

      de: `🎯 ${formData.productName}

✅ MIT HÖCHSTER SORGFALT GEFERTIGT
Unsere Produkte werden auf professionellen 3D-Druckern mit höchster Präzision gedruckt. Jedes Element wird vor dem Versand sorgfältig geprüft.

📦 SPEZIFIKATIONEN:
• Material: ${formData.material} (Premium-Qualität)
• Abmessungen: ${formData.dimensions || 'wie angegeben'}
• Gewicht: ~${formData.weight}g
• Farbe: Mehrere Farben verfügbar

⭐ WARUM UNS WÄHLEN?
${formData.features.map(f => `✓ ${f}`).join('\n')}
✓ Schnelle Bearbeitung (${formData.shippingTime})
✓ Sichere Verpackung
✓ Zufriedenheitsgarantie
${formData.customization ? '✓ Individualisierung möglich' : ''}

🚚 VERSAND:
• Bearbeitungszeit: ${formData.shippingTime}
• Sichere umweltfreundliche Verpackung
• Tracking inklusive

💬 FRAGEN?
Kontaktieren Sie uns! Wir helfen gerne weiter.

#3ddruck #${formData.material.toLowerCase()} #handmade`,
    };

    const randomTitle = titles[formData.language][Math.floor(Math.random() * titles[formData.language].length)];
    setGeneratedListing(`${randomTitle}\n\n${descriptions[formData.language]}`);
    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedListing);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadListing = () => {
    const blob = new Blob([generatedListing], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `listing-${formData.productName.toLowerCase().replace(/\s+/g, '-')}.txt`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Generator Listingów</h1>
          <p className="text-slate-400">Twórz profesjonalne opisy produktów z AI</p>
        </div>
        <div className="flex items-center gap-2">
          <Sparkles size={20} className="text-amber-400" />
          <span className="text-amber-400 font-medium">AI Powered</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="industrial-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Settings size={20} className="text-amber-400" />
            Dane produktu
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-1">Nazwa produktu</label>
              <input
                type="text"
                value={formData.productName}
                onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                placeholder="np. Wsporniki półek uniwersalne"
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Kategoria</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                >
                  <option value="">Wybierz kategorię</option>
                  {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Materiał</label>
                <select
                  value={formData.material}
                  onChange={(e) => setFormData({ ...formData, material: e.target.value })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                >
                  {materials.map(mat => <option key={mat} value={mat}>{mat}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Wymiary</label>
                <input
                  type="text"
                  value={formData.dimensions}
                  onChange={(e) => setFormData({ ...formData, dimensions: e.target.value })}
                  placeholder="np. 50x30x20 mm"
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Waga (g)</label>
                <input
                  type="number"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Czas wysyłki</label>
              <select
                value={formData.shippingTime}
                onChange={(e) => setFormData({ ...formData, shippingTime: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              >
                <option value="24h">24 godziny</option>
                <option value="2-3 dni">2-3 dni</option>
                <option value="3-5 dni">3-5 dni</option>
                <option value="5-7 dni">5-7 dni</option>
                <option value="7-14 dni">7-14 dni</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Język</label>
              <div className="flex items-center gap-2">
                {[
                  { id: 'pl', label: 'Polski' },
                  { id: 'en', label: 'English' },
                  { id: 'de', label: 'Deutsch' },
                ].map((lang) => (
                  <button
                    key={lang.id}
                    onClick={() => setFormData({ ...formData, language: lang.id as 'pl' | 'en' | 'de' })}
                    className={`
                      px-4 py-2 rounded-lg text-sm font-medium transition-colors
                      ${formData.language === lang.id 
                        ? 'bg-amber-500 text-black' 
                        : 'bg-[#1a1a1a] text-slate-400 border border-[#2a2a2a] hover:text-white'
                      }
                    `}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Cechy produktu</label>
              <div className="flex items-center gap-2 mb-2">
                <input
                  type="text"
                  value={newFeature}
                  onChange={(e) => setNewFeature(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addFeature()}
                  placeholder="np. Wysoka wytrzymałość"
                  className="flex-1 px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
                />
                <button
                  onClick={addFeature}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-medium rounded-lg transition-colors"
                >
                  Dodaj
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.features.map((feature, index) => (
                  <span 
                    key={index}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-[#2a2a2a] text-slate-300 text-sm rounded-full"
                  >
                    {feature}
                    <button 
                      onClick={() => removeFeature(index)}
                      className="text-slate-500 hover:text-red-400"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="customization"
                checked={formData.customization}
                onChange={(e) => setFormData({ ...formData, customization: e.target.checked })}
                className="w-4 h-4 rounded border-[#2a2a2a] bg-[#1a1a1a] text-amber-500 focus:ring-amber-500"
              />
              <label htmlFor="customization" className="text-sm text-slate-400">
                Możliwość personalizacji
              </label>
            </div>

            <button
              onClick={generateListing}
              disabled={!formData.productName || isGenerating}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-black font-semibold rounded-lg transition-colors"
            >
              {isGenerating ? (
                <>
                  <RefreshCw size={18} className="animate-spin" />
                  Generowanie...
                </>
              ) : (
                <>
                  <Wand2 size={18} />
                  Generuj listing
                </>
              )}
            </button>
          </div>
        </div>

        {/* Result */}
        <div className="industrial-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <FileCode size={20} className="text-amber-400" />
              Wygenerowany listing
            </h3>
            {generatedListing && (
              <div className="flex items-center gap-2">
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'Skopiowano' : 'Kopiuj'}
                </button>
                <button
                  onClick={downloadListing}
                  className="flex items-center gap-1 px-3 py-1.5 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors"
                >
                  <Download size={14} />
                  Pobierz
                </button>
              </div>
            )}
          </div>

          {generatedListing ? (
            <textarea
              value={generatedListing}
              readOnly
              className="w-full h-[500px] px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-slate-300 text-sm font-mono resize-none focus:outline-none"
            />
          ) : (
            <div className="h-[500px] flex flex-col items-center justify-center text-center p-8">
              <Sparkles size={64} className="text-slate-600 mb-4" />
              <h4 className="text-lg font-semibold text-white mb-2">Gotowy do generowania?</h4>
              <p className="text-slate-500">Wypełnij formularz i kliknij "Generuj listing"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ListingGeneratorPage;
