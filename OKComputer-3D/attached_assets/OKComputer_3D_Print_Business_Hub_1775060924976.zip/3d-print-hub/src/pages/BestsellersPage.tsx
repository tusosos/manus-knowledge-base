import { useState } from 'react';
import { 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  Star, 
  Package, 
  DollarSign,
  Eye,
  Download,
  Filter,
  ArrowUpRight,
  Heart,
  Share2
} from 'lucide-react';

interface Bestseller {
  id: string;
  name: string;
  category: string;
  image?: string;
  price: number;
  cost: number;
  orders: number;
  revenue: number;
  rating: number;
  reviews: number;
  trend: number;
  views: number;
  conversion: number;
}

const mockBestsellers: Bestseller[] = [
  { id: '1', name: 'Wsporniki półek uniwersalne', category: 'Meble', price: 15, cost: 4, orders: 156, revenue: 2340, rating: 4.8, reviews: 42, trend: 23, views: 1200, conversion: 13 },
  { id: '2', name: 'Obudowa Raspberry Pi 4', category: 'Elektronika', price: 85, cost: 25, orders: 89, revenue: 7565, rating: 4.9, reviews: 67, trend: 15, views: 890, conversion: 10 },
  { id: '3', name: 'Uchwyt na telefon do samochodu', category: 'Akcesoria', price: 35, cost: 8, orders: 134, revenue: 4690, rating: 4.6, reviews: 28, trend: -5, views: 1500, conversion: 8.9 },
  { id: '4', name: 'Zawiasy meblowe zestaw', category: 'Meble', price: 12, cost: 3, orders: 234, revenue: 2808, rating: 4.7, reviews: 56, trend: 45, views: 2100, conversion: 11.1 },
  { id: '5', name: 'Wieszak na klucze magnetyczny', category: 'Dekoracje', price: 45, cost: 12, orders: 78, revenue: 3510, rating: 4.5, reviews: 23, trend: 12, views: 650, conversion: 12 },
  { id: '6', name: 'Stojak na słuchawki', category: 'Akcesoria', price: 55, cost: 15, orders: 67, revenue: 3685, rating: 4.8, reviews: 34, trend: 8, views: 780, conversion: 8.6 },
  { id: '7', name: 'Organizer na biurko', category: 'Biuro', price: 75, cost: 22, orders: 45, revenue: 3375, rating: 4.4, reviews: 18, trend: -12, views: 920, conversion: 4.9 },
  { id: '8', name: 'Wieszak na rower', category: 'Sport', price: 95, cost: 28, orders: 38, revenue: 3610, rating: 4.9, reviews: 29, trend: 34, views: 450, conversion: 8.4 },
];

const categories = ['Wszystkie', 'Meble', 'Elektronika', 'Akcesoria', 'Dekoracje', 'Biuro', 'Sport'];

export const BestsellersPage: React.FC = () => {
  const [bestsellers] = useState<Bestseller[]>(mockBestsellers);
  const [selectedCategory, setSelectedCategory] = useState('Wszystkie');
  const [sortBy, setSortBy] = useState<'revenue' | 'orders' | 'rating'>('revenue');

  const filteredBestsellers = bestsellers
    .filter(item => selectedCategory === 'Wszystkie' || item.category === selectedCategory)
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const totalRevenue = bestsellers.reduce((sum, item) => sum + item.revenue, 0);
  const totalOrders = bestsellers.reduce((sum, item) => sum + item.orders, 0);
  const avgRating = bestsellers.reduce((sum, item) => sum + item.rating, 0) / bestsellers.length;
  const avgMargin = bestsellers.reduce((sum, item) => sum + ((item.price - item.cost) / item.price * 100), 0) / bestsellers.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Bestsellery</h1>
          <p className="text-slate-400">Analiza najlepiej sprzedających się produktów</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors">
          <Download size={18} />
          Eksportuj raport
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Trophy size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{bestsellers.length}</p>
              <p className="text-sm text-slate-500">Bestsellerów</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <DollarSign size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalRevenue.toLocaleString()} zł</p>
              <p className="text-sm text-slate-500">Przychód</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Package size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalOrders}</p>
              <p className="text-sm text-slate-500">Sprzedanych sztuk</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/10 rounded-lg">
              <Star size={20} className="text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{avgRating.toFixed(1)}</p>
              <p className="text-sm text-slate-500">Średnia ocena</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`
                px-3 py-1.5 text-sm font-medium rounded-md transition-colors
                ${selectedCategory === category 
                  ? 'bg-amber-500 text-black' 
                  : 'text-slate-400 hover:text-white'
                }
              `}
            >
              {category}
            </button>
          ))}
        </div>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="revenue">Sortuj: Przychód</option>
          <option value="orders">Sortuj: Zamówienia</option>
          <option value="rating">Sortuj: Ocena</option>
        </select>
      </div>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {filteredBestsellers.slice(0, 3).map((item, index) => (
          <div 
            key={item.id} 
            className={`
              industrial-card p-5 text-center relative overflow-hidden
              ${index === 0 ? 'border-amber-500/50' : ''}
            `}
          >
            {index === 0 && (
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500" />
            )}
            <div className={`
              w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center
              ${index === 0 ? 'bg-amber-500 text-black' : 'bg-[#2a2a2a] text-slate-400'}
            `}>
              <Trophy size={24} />
            </div>
            <h3 className="font-semibold text-white mb-1 line-clamp-1">{item.name}</h3>
            <p className="text-sm text-slate-500 mb-3">{item.category}</p>
            <div className="flex items-center justify-center gap-4">
              <div>
                <p className="text-lg font-bold text-amber-400">{item.revenue.toLocaleString()} zł</p>
                <p className="text-xs text-slate-500">Przychód</p>
              </div>
              <div>
                <p className="text-lg font-bold text-white">{item.orders}</p>
                <p className="text-xs text-slate-500">Sprzedaż</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Full List */}
      <div className="industrial-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2a2a2a]">
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">#</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Produkt</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Kategoria</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Cena</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Sprzedaż</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Przychód</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Marża</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Trend</th>
              <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Ocena</th>
            </tr>
          </thead>
          <tbody>
            {filteredBestsellers.map((item, index) => {
              const margin = ((item.price - item.cost) / item.price * 100).toFixed(0);
              return (
                <tr key={item.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                  <td className="py-3 px-4">
                    <span className="text-slate-600 font-mono font-bold">{index + 1}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-slate-700 to-slate-800 rounded-lg flex items-center justify-center">
                        <Package size={18} className="text-slate-500" />
                      </div>
                      <span className="text-sm font-medium text-white">{item.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">{item.category}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-white">{item.price} zł</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-white">{item.orders} szt</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm font-medium text-amber-400">{item.revenue.toLocaleString()} zł</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-green-400">{margin}%</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className={`flex items-center gap-1 text-sm ${item.trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {item.trend >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                      {Math.abs(item.trend)}%
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-amber-400 fill-amber-400" />
                      <span className="text-sm text-white">{item.rating}</span>
                      <span className="text-xs text-slate-500">({item.reviews})</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BestsellersPage;
