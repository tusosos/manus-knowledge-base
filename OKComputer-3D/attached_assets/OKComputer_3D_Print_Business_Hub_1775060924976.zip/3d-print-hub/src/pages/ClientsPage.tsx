import { useState } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Mail, 
  Phone, 
  MapPin, 
  MoreHorizontal,
  Edit,
  Trash2,
  FileText,
  DollarSign,
  Package,
  Star,
  ArrowUpRight
} from 'lucide-react';

interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  type: 'individual' | 'company';
  ordersCount: number;
  totalSpent: number;
  rating: number;
  notes: string;
  createdAt: string;
  lastOrder?: string;
}

const mockClients: Client[] = [
  { id: '1', name: 'Jan Kowalski', email: 'jan.kowalski@email.pl', phone: '+48 123 456 789', address: 'ul. Drukarska 1', city: 'Warszawa', type: 'individual', ordersCount: 5, totalSpent: 1250, rating: 5, notes: 'Stały klient, płaci terminowo', createdAt: '2023-06-15', lastOrder: '2024-01-10' },
  { id: '2', name: 'Firma XYZ Sp. z o.o.', email: 'kontakt@firma-xyz.pl', phone: '+48 987 654 321', address: 'ul. Przemysłowa 10', city: 'Kraków', type: 'company', ordersCount: 12, totalSpent: 8500, rating: 4, notes: 'Duże zamówienia, negocjuje ceny', createdAt: '2023-03-20', lastOrder: '2024-01-14' },
  { id: '3', name: 'Anna Nowak', email: 'anna.nowak@email.pl', phone: '+48 555 666 777', address: 'ul. 3D Printing 5', city: 'Poznań', type: 'individual', ordersCount: 2, totalSpent: 350, rating: 5, notes: 'Nowy klient', createdAt: '2024-01-05', lastOrder: '2024-01-12' },
  { id: '4', name: 'Meble Design', email: 'biuro@mebledesign.pl', phone: '+48 111 222 333', address: 'ul. Meblowa 25', city: 'Wrocław', type: 'company', ordersCount: 8, totalSpent: 4200, rating: 4, notes: 'Specjalizuje się w prototypach mebli', createdAt: '2023-08-10', lastOrder: '2024-01-08' },
  { id: '5', name: 'Piotr Wiśniewski', email: 'piotr.w@email.pl', phone: '+48 444 555 666', address: 'ul. Modelarska 3', city: 'Gdańsk', type: 'individual', ordersCount: 15, totalSpent: 2100, rating: 5, notes: 'Hobbysta, częste zamówienia małych elementów', createdAt: '2023-01-10', lastOrder: '2024-01-15' },
];

export const ClientsPage: React.FC = () => {
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filteredClients = clients.filter(client => {
    const matchesSearch = client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         client.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         client.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || client.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const stats = {
    total: clients.length,
    individuals: clients.filter(c => c.type === 'individual').length,
    companies: clients.filter(c => c.type === 'company').length,
    totalRevenue: clients.reduce((sum, c) => sum + c.totalSpent, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Klienci</h1>
          <p className="text-slate-400">Zarządzaj bazą klientów i ich zamówieniami</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Nowy klient
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Users size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.total}</p>
              <p className="text-sm text-slate-500">Wszystkich klientów</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <Users size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.individuals}</p>
              <p className="text-sm text-slate-500">Osoby prywatne</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/10 rounded-lg">
              <Users size={20} className="text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.companies}</p>
              <p className="text-sm text-slate-500">Firmy</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <DollarSign size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{stats.totalRevenue.toLocaleString()} zł</p>
              <p className="text-sm text-slate-500">Całkowity przychód</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj klientów..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszyscy klienci</option>
          <option value="individual">Osoby prywatne</option>
          <option value="company">Firmy</option>
        </select>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredClients.map((client) => (
          <div key={client.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all group">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center">
                  <span className="text-lg font-bold text-black">{client.name.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-white">{client.name}</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    client.type === 'company' ? 'bg-purple-500/10 text-purple-400' : 'bg-green-500/10 text-green-400'
                  }`}>
                    {client.type === 'company' ? 'Firma' : 'Osoba prywatna'}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                  <Edit size={16} />
                </button>
                <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Mail size={14} />
                <span>{client.email}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Phone size={14} />
                <span>{client.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <MapPin size={14} />
                <span>{client.city}</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <p className="text-lg font-bold text-white">{client.ordersCount}</p>
                <p className="text-xs text-slate-500">Zamówień</p>
              </div>
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <p className="text-lg font-bold text-amber-400">{client.totalSpent} zł</p>
                <p className="text-xs text-slate-500">Wartość</p>
              </div>
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <div className="flex items-center justify-center gap-0.5">
                  <Star size={14} className="text-amber-400 fill-amber-400" />
                  <span className="text-lg font-bold text-white">{client.rating}</span>
                </div>
                <p className="text-xs text-slate-500">Ocena</p>
              </div>
            </div>

            {client.notes && (
              <p className="text-xs text-slate-500 mb-3 line-clamp-2">{client.notes}</p>
            )}

            <button className="w-full py-2 bg-[#1a1a1a] hover:bg-[#252525] text-amber-400 text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-1">
              Szczegóły
              <ArrowUpRight size={14} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ClientsPage;
