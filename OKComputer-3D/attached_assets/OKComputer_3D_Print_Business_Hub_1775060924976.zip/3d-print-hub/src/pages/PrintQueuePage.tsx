import { useState } from 'react';
import { 
  Printer, 
  Plus, 
  Play, 
  Pause, 
  Square, 
  RotateCcw,
  Clock,
  Thermometer,
  Layers,
  MoreHorizontal,
  AlertTriangle,
  CheckCircle2,
  Hourglass,
  Trash2,
  Edit,
  Eye
} from 'lucide-react';

interface PrintJob {
  id: string;
  name: string;
  printer: string;
  status: 'queued' | 'printing' | 'paused' | 'completed' | 'failed';
  progress: number;
  timeElapsed: string;
  timeRemaining: string;
  filamentUsed: number;
  filamentTotal: number;
  layer: number;
  totalLayers: number;
  nozzleTemp: number;
  bedTemp: number;
  thumbnail?: string;
}

interface PrinterStatus {
  id: string;
  name: string;
  status: 'idle' | 'printing' | 'paused' | 'error' | 'offline';
  currentJob?: PrintJob;
  nozzleTemp: number;
  bedTemp: number;
  progress: number;
}

const mockPrinters: PrinterStatus[] = [
  { 
    id: '1', 
    name: 'Prusa i3 MK3S+', 
    status: 'printing', 
    currentJob: {
      id: 'j1',
      name: 'Wsporniki półek x12',
      printer: 'Prusa i3 MK3S+',
      status: 'printing',
      progress: 67,
      timeElapsed: '2h 15m',
      timeRemaining: '1h 23m',
      filamentUsed: 85,
      filamentTotal: 127,
      layer: 134,
      totalLayers: 200,
      nozzleTemp: 215,
      bedTemp: 60,
    },
    nozzleTemp: 215,
    bedTemp: 60,
    progress: 67,
  },
  { 
    id: '2', 
    name: 'Bambu Lab X1 Carbon', 
    status: 'printing', 
    currentJob: {
      id: 'j2',
      name: 'Obudowa elektroniki',
      printer: 'Bambu Lab X1 Carbon',
      status: 'printing',
      progress: 34,
      timeElapsed: '45m',
      timeRemaining: '2h 45m',
      filamentUsed: 42,
      filamentTotal: 123,
      layer: 68,
      totalLayers: 200,
      nozzleTemp: 220,
      bedTemp: 65,
    },
    nozzleTemp: 220,
    bedTemp: 65,
    progress: 34,
  },
  { id: '3', name: 'Ender 3 V2', status: 'idle', nozzleTemp: 24, bedTemp: 22, progress: 0 },
  { id: '4', name: 'Voron 2.4', status: 'offline', nozzleTemp: 0, bedTemp: 0, progress: 0 },
];

const mockQueue: PrintJob[] = [
  { id: 'q1', name: 'Uchwyt na telefon', printer: 'Ender 3 V2', status: 'queued', progress: 0, timeElapsed: '-', timeRemaining: '45m', filamentUsed: 0, filamentTotal: 25, layer: 0, totalLayers: 80, nozzleTemp: 0, bedTemp: 0 },
  { id: 'q2', name: 'Model architektoniczny', printer: 'Prusa i3 MK3S+', status: 'queued', progress: 0, timeElapsed: '-', timeRemaining: '6h 30m', filamentUsed: 0, filamentTotal: 350, layer: 0, totalLayers: 450, nozzleTemp: 0, bedTemp: 0 },
  { id: 'q3', name: 'Zawiasy x20', printer: 'Bambu Lab X1 Carbon', status: 'queued', progress: 0, timeElapsed: '-', timeRemaining: '3h 15m', filamentUsed: 0, filamentTotal: 180, layer: 0, totalLayers: 120, nozzleTemp: 0, bedTemp: 0 },
];

const statusConfig = {
  'queued': { label: 'W kolejce', color: 'text-slate-400 bg-slate-500/10', icon: Hourglass },
  'printing': { label: 'Drukowanie', color: 'text-green-400 bg-green-500/10', icon: Printer },
  'paused': { label: 'Wstrzymane', color: 'text-amber-400 bg-amber-500/10', icon: Pause },
  'completed': { label: 'Zakończone', color: 'text-blue-400 bg-blue-500/10', icon: CheckCircle2 },
  'failed': { label: 'Błąd', color: 'text-red-400 bg-red-500/10', icon: AlertTriangle },
};

const printerStatusConfig = {
  'idle': { label: 'Gotowa', color: 'text-green-400' },
  'printing': { label: 'Drukuje', color: 'text-blue-400' },
  'paused': { label: 'Wstrzymana', color: 'text-amber-400' },
  'error': { label: 'Błąd', color: 'text-red-400' },
  'offline': { label: 'Offline', color: 'text-slate-500' },
};

export const PrintQueuePage: React.FC = () => {
  const [printers, setPrinters] = useState<PrinterStatus[]>(mockPrinters);
  const [queue, setQueue] = useState<PrintJob[]>(mockQueue);
  const [activeTab, setActiveTab] = useState<'printers' | 'queue' | 'history'>('printers');

  const activePrints = printers.filter(p => p.status === 'printing').length;
  const queuedJobs = queue.length;
  const completedToday = 5; // Mock value

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Kolejka Druku</h1>
          <p className="text-slate-400">Zarządzaj drukarkami i kolejką wydruków</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Dodaj do kolejki
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <Printer size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{activePrints}</p>
              <p className="text-sm text-slate-500">Aktywnych wydruków</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Hourglass size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{queuedJobs}</p>
              <p className="text-sm text-slate-500">W kolejce</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <CheckCircle2 size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{completedToday}</p>
              <p className="text-sm text-slate-500">Ukończonych dzisiaj</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2a2a2a]">
        {[
          { id: 'printers', label: 'Drukarki', icon: Printer },
          { id: 'queue', label: 'Kolejka', icon: Hourglass },
          { id: 'history', label: 'Historia', icon: Clock },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`
              flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2
              ${activeTab === tab.id 
                ? 'text-amber-400 border-amber-400' 
                : 'text-slate-400 border-transparent hover:text-white'
              }
            `}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === 'printers' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {printers.map((printer) => (
            <div key={printer.id} className="industrial-card p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${printer.status === 'offline' ? 'bg-slate-700' : 'bg-amber-500/10'}`}>
                    <Printer size={20} className={printer.status === 'offline' ? 'text-slate-500' : 'text-amber-400'} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{printer.name}</h3>
                    <span className={`text-sm ${printerStatusConfig[printer.status].color}`}>
                      {printerStatusConfig[printer.status].label}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {printer.status === 'printing' && (
                    <>
                      <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                        <Pause size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                        <Square size={16} />
                      </button>
                    </>
                  )}
                  {printer.status === 'paused' && (
                    <button className="p-1.5 text-slate-400 hover:text-green-400 hover:bg-green-500/10 rounded-lg transition-colors">
                      <Play size={16} />
                    </button>
                  )}
                </div>
              </div>

              {/* Temperature */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Thermometer size={14} className="text-red-400" />
                  <span className="text-slate-400">Dysza:</span>
                  <span className="text-white font-medium">{printer.nozzleTemp}°C</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Layers size={14} className="text-blue-400" />
                  <span className="text-slate-400">Stół:</span>
                  <span className="text-white font-medium">{printer.bedTemp}°C</span>
                </div>
              </div>

              {/* Current Job */}
              {printer.currentJob && (
                <div className="bg-[#1a1a1a] rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-white">{printer.currentJob.name}</span>
                    <span className="text-sm text-green-400">{printer.currentJob.progress}%</span>
                  </div>
                  <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden mb-3">
                    <div 
                      className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full transition-all"
                      style={{ width: `${printer.currentJob.progress}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {printer.currentJob.timeElapsed}
                      </span>
                      <span className="flex items-center gap-1">
                        <Hourglass size={12} />
                        {printer.currentJob.timeRemaining}
                      </span>
                    </div>
                    <span>Warstwa {printer.currentJob.layer}/{printer.currentJob.totalLayers}</span>
                  </div>
                </div>
              )}

              {printer.status === 'idle' && (
                <div className="bg-[#1a1a1a] rounded-lg p-4 text-center">
                  <p className="text-slate-500">Drukarka gotowa do pracy</p>
                  <button className="mt-2 px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-black text-sm font-medium rounded-lg transition-colors">
                    Rozpocznij druk
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'queue' && (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Zadanie</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Drukarka</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Czas</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Filament</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {queue.map((job, index) => (
                <tr key={job.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-600 font-mono">#{index + 1}</span>
                      <span className="text-sm font-medium text-white">{job.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">{job.printer}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">{job.timeRemaining}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">{job.filamentTotal}g</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-green-400 hover:bg-green-500/10 rounded-lg transition-colors">
                        <Play size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                        <Edit size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="industrial-card p-8 text-center">
          <Clock size={48} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-lg font-semibold text-white mb-2">Historia wydruków</h3>
          <p className="text-slate-500">Funkcja w przygotowaniu</p>
        </div>
      )}
    </div>
  );
};

export default PrintQueuePage;
