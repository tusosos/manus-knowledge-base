import { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Printer, 
  Package, 
  Users,
  Calendar,
  Download,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Target
} from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  changeLabel: string;
  icon: React.ElementType;
  color: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, changeLabel, icon: Icon, color }) => (
  <div className="industrial-card p-5">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-slate-400 text-sm mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-white">{value}</h3>
        <div className="flex items-center gap-1 mt-2">
          {change >= 0 ? (
            <ArrowUpRight size={14} className="text-green-400" />
          ) : (
            <ArrowDownRight size={14} className="text-red-400" />
          )}
          <span className={`text-sm font-medium ${change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {change > 0 ? '+' : ''}{change}%
          </span>
          <span className="text-slate-500 text-sm">{changeLabel}</span>
        </div>
      </div>
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon size={24} />
      </div>
    </div>
  </div>
);

interface ChartBarProps {
  label: string;
  value: number;
  maxValue: number;
  color?: string;
}

const ChartBar: React.FC<ChartBarProps> = ({ label, value, maxValue, color = 'bg-amber-500' }) => (
  <div className="flex items-center gap-3">
    <span className="text-sm text-slate-400 w-16">{label}</span>
    <div className="flex-1 h-8 bg-[#1a1a1a] rounded-lg overflow-hidden">
      <div 
        className={`h-full ${color} rounded-lg transition-all duration-500`}
        style={{ width: `${(value / maxValue) * 100}%` }}
      />
    </div>
    <span className="text-sm text-white font-medium w-16 text-right">{value}</span>
  </div>
);

export const AnalyticsPage: React.FC = () => {
  const [dateRange, setDateRange] = useState('7d');
  const [activeTab, setActiveTab] = useState<'overview' | 'revenue' | 'prints' | 'products'>('overview');

  const metrics = [
    { title: 'Przychód', value: '45,230 zł', change: 15.3, changeLabel: 'vs poprzedni miesiąc', icon: DollarSign, color: 'bg-green-500/10 text-green-400' },
    { title: 'Wydrukowane modele', value: '1,247', change: 8.7, changeLabel: 'vs poprzedni miesiąc', icon: Printer, color: 'bg-blue-500/10 text-blue-400' },
    { title: 'Zużyty filament', value: '45.2 kg', change: 12.1, changeLabel: 'vs poprzedni miesiąc', icon: Package, color: 'bg-amber-500/10 text-amber-400' },
    { title: 'Nowi klienci', value: '28', change: -3.2, changeLabel: 'vs poprzedni miesiąc', icon: Users, color: 'bg-purple-500/10 text-purple-400' },
  ];

  const revenueData = [
    { label: 'Pon', value: 1200 },
    { label: 'Wt', value: 1900 },
    { label: 'Śr', value: 1500 },
    { label: 'Czw', value: 2200 },
    { label: 'Pt', value: 2800 },
    { label: 'Sob', value: 1600 },
    { label: 'Ndz', value: 900 },
  ];

  const filamentUsage = [
    { label: 'PLA', value: 25.4, color: 'bg-green-500' },
    { label: 'PETG', value: 12.8, color: 'bg-blue-500' },
    { label: 'ABS', value: 4.2, color: 'bg-red-500' },
    { label: 'TPU', value: 2.1, color: 'bg-amber-500' },
    { label: 'ASA', value: 0.7, color: 'bg-purple-500' },
  ];

  const topProducts = [
    { name: 'Wsporniki półek', orders: 45, revenue: 2250 },
    { name: 'Obudowy Raspberry Pi', orders: 32, revenue: 2720 },
    { name: 'Uchwyty na telefon', orders: 28, revenue: 840 },
    { name: 'Zawiasy meblowe', orders: 24, revenue: 720 },
    { name: 'Elementy dekoracyjne', orders: 18, revenue: 540 },
  ];

  const printerEfficiency = [
    { name: 'Prusa i3 MK3S+', uptime: 92, prints: 523, success: 98 },
    { name: 'Bambu Lab X1', uptime: 88, prints: 412, success: 96 },
    { name: 'Ender 3 V2', uptime: 76, prints: 215, success: 94 },
    { name: 'Voron 2.4', uptime: 45, prints: 97, success: 99 },
  ];

  const maxRevenue = Math.max(...revenueData.map(d => d.value));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Analizy</h1>
          <p className="text-slate-400">Szczegółowe statystyki i analizy biznesowe</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
            {['7d', '30d', '90d', '1y'].map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`
                  px-3 py-1.5 text-sm font-medium rounded-md transition-colors
                  ${dateRange === range 
                    ? 'bg-amber-500 text-black' 
                    : 'text-slate-400 hover:text-white'
                  }
                `}
              >
                {range === '7d' ? '7 dni' : range === '30d' ? '30 dni' : range === '90d' ? '90 dni' : 'Rok'}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors">
            <Download size={18} />
            Eksport
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2a2a2a]">
        {[
          { id: 'overview', label: 'Przegląd', icon: BarChart3 },
          { id: 'revenue', label: 'Przychody', icon: DollarSign },
          { id: 'prints', label: 'Druki', icon: Printer },
          { id: 'products', label: 'Produkty', icon: Package },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`
              flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2
              ${activeTab === tab.id 
                ? 'text-amber-400 border-amber-400' 
                : 'text-slate-400 border-transparent hover:text-white'
              }
            `}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <>
          {/* Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.map((metric, index) => (
              <MetricCard key={index} {...metric} />
            ))}
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue Chart */}
            <div className="industrial-card p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <DollarSign size={20} className="text-amber-400" />
                  Przychód (ostatni tydzień)
                </h3>
                <span className="text-2xl font-bold text-amber-400">12,100 zł</span>
              </div>
              <div className="space-y-3">
                {revenueData.map((data, index) => (
                  <ChartBar key={index} label={data.label} value={data.value} maxValue={maxRevenue} />
                ))}
              </div>
            </div>

            {/* Filament Usage */}
            <div className="industrial-card p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Package size={20} className="text-amber-400" />
                  Zużycie filamentu
                </h3>
                <span className="text-2xl font-bold text-amber-400">45.2 kg</span>
              </div>
              <div className="space-y-3">
                {filamentUsage.map((data, index) => (
                  <ChartBar 
                    key={index} 
                    label={data.label} 
                    value={data.value} 
                    maxValue={30} 
                    color={data.color}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Top Products & Printer Efficiency */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Products */}
            <div className="industrial-card p-5">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Target size={20} className="text-amber-400" />
                Najpopularniejsze produkty
              </h3>
              <div className="space-y-3">
                {topProducts.map((product, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded-lg">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-600 font-mono">#{index + 1}</span>
                      <span className="text-white">{product.name}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-slate-500">{product.orders} zamówień</span>
                      <span className="text-amber-400 font-medium">{product.revenue} zł</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Printer Efficiency */}
            <div className="industrial-card p-5">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Printer size={20} className="text-amber-400" />
                Efektywność drukarek
              </h3>
              <div className="space-y-3">
                {printerEfficiency.map((printer, index) => (
                  <div key={index} className="p-3 bg-[#1a1a1a] rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">{printer.name}</span>
                      <span className="text-green-400 text-sm">{printer.success}% sukcesu</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <span>Czas pracy: {printer.uptime}%</span>
                      <span>Wydruki: {printer.prints}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {/* Other tabs placeholder */}
      {activeTab !== 'overview' && (
        <div className="industrial-card p-12 text-center">
          <BarChart3 size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">
            {activeTab === 'revenue' && 'Szczegółowa analiza przychodów'}
            {activeTab === 'prints' && 'Szczegółowa analiza wydruków'}
            {activeTab === 'products' && 'Analiza produktów'}
          </h3>
          <p className="text-slate-500">Funkcja w przygotowaniu</p>
        </div>
      )}
    </div>
  );
};

export default AnalyticsPage;
