import { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package, 
  Printer, 
  Users, 
  Clock,
  CheckCircle,
  AlertTriangle,
  MoreHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  Calendar
} from 'lucide-react';

// Stat Card Component
interface StatCardProps {
  title: string;
  value: string;
  change: number;
  changeLabel: string;
  icon: React.ElementType;
  color: 'amber' | 'green' | 'blue' | 'purple';
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, changeLabel, icon: Icon, color }) => {
  const colorClasses = {
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  };

  return (
    <div className="industrial-card p-5 hover:border-amber-500/30 transition-all">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-slate-400 text-sm mb-1">{title}</p>
          <h3 className="text-2xl font-bold text-white">{value}</h3>
          <div className="flex items-center gap-1 mt-2">
            {change >= 0 ? (
              <ArrowUpRight size={14} className="text-green-400" />
            ) : (
              <ArrowDownRight size={14} className="text-red-400" />
            )}
            <span className={`text-sm font-medium ${change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {change > 0 ? '+' : ''}{change}%
            </span>
            <span className="text-slate-500 text-sm">{changeLabel}</span>
          </div>
        </div>
        <div className={`p-3 rounded-xl border ${colorClasses[color]}`}>
          <Icon size={24} />
        </div>
      </div>
    </div>
  );
};

// Activity Item Component
interface ActivityItemProps {
  type: 'print' | 'order' | 'alert' | 'task';
  title: string;
  description: string;
  time: string;
}

const ActivityItem: React.FC<ActivityItemProps> = ({ type, title, description, time }) => {
  const typeConfig = {
    print: { icon: Printer, color: 'text-green-400 bg-green-500/10' },
    order: { icon: DollarSign, color: 'text-amber-400 bg-amber-500/10' },
    alert: { icon: AlertTriangle, color: 'text-red-400 bg-red-500/10' },
    task: { icon: CheckCircle, color: 'text-blue-400 bg-blue-500/10' },
  };

  const { icon: Icon, color } = typeConfig[type];

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-[#252525] transition-colors">
      <div className={`p-2 rounded-lg ${color}`}>
        <Icon size={16} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">{title}</p>
        <p className="text-xs text-slate-400 truncate">{description}</p>
      </div>
      <span className="text-xs text-slate-500 whitespace-nowrap">{time}</span>
    </div>
  );
};

// Print Queue Item Component
interface PrintQueueItemProps {
  name: string;
  printer: string;
  progress: number;
  timeLeft: string;
  status: 'printing' | 'queued' | 'paused';
}

const PrintQueueItem: React.FC<PrintQueueItemProps> = ({ name, printer, progress, timeLeft, status }) => {
  const statusConfig = {
    printing: { label: 'Drukowanie', color: 'text-green-400' },
    queued: { label: 'W kolejce', color: 'text-slate-400' },
    paused: { label: 'Wstrzymane', color: 'text-amber-400' },
  };

  return (
    <div className="p-4 border-b border-[#2a2a2a] last:border-0">
      <div className="flex items-center justify-between mb-2">
        <div>
          <p className="text-sm font-medium text-white">{name}</p>
          <p className="text-xs text-slate-500">{printer}</p>
        </div>
        <span className={`text-xs font-medium ${statusConfig[status].color}`}>
          {statusConfig[status].label}
        </span>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex-1">
          <div className="h-1.5 bg-[#2a2a2a] rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        <span className="text-xs text-slate-500 whitespace-nowrap">{timeLeft}</span>
      </div>
    </div>
  );
};

export const DashboardPage: React.FC = () => {
  const [dateRange, setDateRange] = useState('7d');

  const stats = [
    { title: 'Przychód', value: '12,450 zł', change: 12.5, changeLabel: 'vs ostatni tydzień', icon: DollarSign, color: 'green' as const },
    { title: 'Aktywne Druki', value: '8', change: 33.3, changeLabel: 'vs wczoraj', icon: Printer, color: 'amber' as const },
    { title: 'Zamówienia', value: '24', change: -5.2, changeLabel: 'vs ostatni tydzień', icon: Package, color: 'blue' as const },
    { title: 'Nowi Klienci', value: '7', change: 16.7, changeLabel: 'vs ostatni miesiąc', icon: Users, color: 'purple' as const },
  ];

  const activities = [
    { type: 'print' as const, title: 'Drukowanie zakończone', description: 'Obudowa Raspberry Pi 4', time: '2 min temu' },
    { type: 'order' as const, title: 'Nowe zamówienie', description: 'Zamówienie #1234 - 150 zł', time: '15 min temu' },
    { type: 'alert' as const, title: 'Niski poziom filamentu', description: 'Czarny PLA - 15% pozostało', time: '1h temu' },
    { type: 'task' as const, title: 'Zadanie ukończone', description: 'Kalibracja drukarki Ender 3', time: '2h temu' },
    { type: 'print' as const, title: 'Drukowanie rozpoczęte', description: 'Wsporniki półek - 4h 30m', time: '3h temu' },
  ];

  const printQueue = [
    { name: 'Wsporniki półek x12', printer: 'Prusa i3 MK3S+', progress: 67, timeLeft: '1h 23m', status: 'printing' as const },
    { name: 'Obudowa elektroniki', printer: 'Bambu Lab X1', progress: 34, timeLeft: '2h 45m', status: 'printing' as const },
    { name: 'Uchwyt na telefon', printer: 'Ender 3 V2', progress: 0, timeLeft: '45m', status: 'queued' as const },
    { name: 'Model architektoniczny', printer: 'Prusa i3 MK3S+', progress: 89, timeLeft: '15m', status: 'printing' as const },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400">Witaj z powrotem! Oto podsumowanie Twojego biznesu.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
            {['24h', '7d', '30d', '90d'].map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`
                  px-3 py-1.5 text-sm font-medium rounded-md transition-colors
                  ${dateRange === range 
                    ? 'bg-amber-500 text-black' 
                    : 'text-slate-400 hover:text-white'
                  }
                `}
              >
                {range === '24h' ? 'Dzień' : range === '7d' ? 'Tydzień' : range === '30d' ? 'Miesiąc' : 'Kwartał'}
              </button>
            ))}
          </div>
          <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
            <Calendar size={20} />
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Print Queue */}
        <div className="lg:col-span-2 industrial-card">
          <div className="flex items-center justify-between p-5 border-b border-[#2a2a2a]">
            <div className="flex items-center gap-3">
              <Printer size={20} className="text-amber-400" />
              <h2 className="text-lg font-semibold text-white">Kolejka Druku</h2>
            </div>
            <button className="text-sm text-amber-400 hover:text-amber-300 flex items-center gap-1">
              Zobacz wszystkie
              <ArrowUpRight size={16} />
            </button>
          </div>
          <div>
            {printQueue.map((item, index) => (
              <PrintQueueItem key={index} {...item} />
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="industrial-card">
          <div className="flex items-center justify-between p-5 border-b border-[#2a2a2a]">
            <div className="flex items-center gap-3">
              <Clock size={20} className="text-amber-400" />
              <h2 className="text-lg font-semibold text-white">Ostatnia Aktywność</h2>
            </div>
            <button className="p-1.5 text-slate-400 hover:text-white hover:bg-[#252525] rounded-lg transition-colors">
              <MoreHorizontal size={18} />
            </button>
          </div>
          <div className="p-2">
            {activities.map((activity, index) => (
              <ActivityItem key={index} {...activity} />
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <div className="industrial-card p-5">
          <h2 className="text-lg font-semibold text-white mb-4">Szybkie Akcje</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Nowe zadanie', icon: TrendingUp, color: 'bg-blue-500/10 text-blue-400' },
              { label: 'Dodaj do kolejki', icon: Printer, color: 'bg-amber-500/10 text-amber-400' },
              { label: 'Utwórz wycenę', icon: DollarSign, color: 'bg-green-500/10 text-green-400' },
              { label: 'Dodaj klienta', icon: Users, color: 'bg-purple-500/10 text-purple-400' },
            ].map((action, index) => (
              <button
                key={index}
                className="flex items-center gap-3 p-4 bg-[#1a1a1a] hover:bg-[#252525] border border-[#2a2a2a] hover:border-amber-500/30 rounded-lg transition-all group"
              >
                <div className={`p-2 rounded-lg ${action.color}`}>
                  <action.icon size={18} />
                </div>
                <span className="text-sm font-medium text-slate-300 group-hover:text-white">{action.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Alerts */}
        <div className="industrial-card p-5">
          <h2 className="text-lg font-semibold text-white mb-4">Alerty</h2>
          <div className="space-y-3">
            {[
              { type: 'warning', message: 'Niski poziom filamentu - Czarny PLA (15%)', icon: AlertTriangle },
              { type: 'info', message: 'Konserwacja drukarki Prusa za 3 dni', icon: Clock },
              { type: 'success', message: '5 zamówień oczekuje na wysyłkę', icon: Package },
            ].map((alert, index) => (
              <div 
                key={index} 
                className={`
                  flex items-center gap-3 p-3 rounded-lg border
                  ${alert.type === 'warning' ? 'bg-amber-500/5 border-amber-500/20' : ''}
                  ${alert.type === 'info' ? 'bg-blue-500/5 border-blue-500/20' : ''}
                  ${alert.type === 'success' ? 'bg-green-500/5 border-green-500/20' : ''}
                `}
              >
                <alert.icon size={18} className={
                  alert.type === 'warning' ? 'text-amber-400' :
                  alert.type === 'info' ? 'text-blue-400' : 'text-green-400'
                } />
                <span className="text-sm text-slate-300">{alert.message}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
