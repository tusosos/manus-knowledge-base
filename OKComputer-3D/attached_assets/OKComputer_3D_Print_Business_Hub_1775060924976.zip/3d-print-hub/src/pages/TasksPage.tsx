import { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Calendar, 
  Clock, 
  User, 
  Tag,
  CheckCircle2,
  Circle,
  AlertCircle,
  ArrowUpDown,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in-progress' | 'review' | 'done';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignee: string;
  dueDate: string;
  tags: string[];
  project?: string;
}

const mockTasks: Task[] = [
  { id: '1', title: 'Kalibracja drukarki Ender 3', description: 'Wykonać kalibrację osi Z i poziomowanie stołu', status: 'in-progress', priority: 'high', assignee: 'Jan K.', dueDate: '2024-01-15', tags: ['konserwacja', 'ender3'], project: 'Utrzymanie' },
  { id: '2', title: 'Przygotować zamówienie #1234', description: 'Wydrukować i spakować 10 sztuk wsporników', status: 'todo', priority: 'urgent', assignee: 'Anna M.', dueDate: '2024-01-14', tags: ['zamówienie', 'priorytet'], project: 'Zamówienia' },
  { id: '3', title: 'Zamówić filament PETG', description: 'Zamówić 5 szpul białego PETG', status: 'todo', priority: 'medium', assignee: 'Jan K.', dueDate: '2024-01-20', tags: ['zakupy', 'filament'], project: 'Magazyn' },
  { id: '4', title: 'Aktualizacja firmware Prusa', description: 'Zaktualizować firmware do najnowszej wersji', status: 'done', priority: 'low', assignee: 'Piotr W.', dueDate: '2024-01-10', tags: ['update', 'prusa'], project: 'Utrzymanie' },
  { id: '5', title: 'Wycena projektu lampy', description: 'Przygotować wycenę dla klienta XYZ', status: 'review', priority: 'high', assignee: 'Anna M.', dueDate: '2024-01-16', tags: ['wycena', 'lampa'], project: 'Wyceny' },
];

const statusConfig = {
  'todo': { label: 'Do zrobienia', color: 'bg-slate-500/10 text-slate-400 border-slate-500/20', icon: Circle },
  'in-progress': { label: 'W trakcie', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20', icon: Clock },
  'review': { label: 'Do przeglądu', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20', icon: Eye },
  'done': { label: 'Zakończone', color: 'bg-green-500/10 text-green-400 border-green-500/20', icon: CheckCircle2 },
};

const priorityConfig = {
  'low': { label: 'Niski', color: 'text-slate-400 bg-slate-500/10' },
  'medium': { label: 'Średni', color: 'text-blue-400 bg-blue-500/10' },
  'high': { label: 'Wysoki', color: 'text-amber-400 bg-amber-500/10' },
  'urgent': { label: 'Pilny', color: 'text-red-400 bg-red-500/10' },
};

export const TasksPage: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'list' | 'board'>('list');

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const tasksByStatus = {
    'todo': filteredTasks.filter(t => t.status === 'todo'),
    'in-progress': filteredTasks.filter(t => t.status === 'in-progress'),
    'review': filteredTasks.filter(t => t.status === 'review'),
    'done': filteredTasks.filter(t => t.status === 'done'),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Zadania</h1>
          <p className="text-slate-400">Zarządzaj zadaniami i śledź postępy prac</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Nowe zadanie
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj zadań..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie statusy</option>
          <option value="todo">Do zrobienia</option>
          <option value="in-progress">W trakcie</option>
          <option value="review">Do przeglądu</option>
          <option value="done">Zakończone</option>
        </select>

        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie priorytety</option>
          <option value="low">Niski</option>
          <option value="medium">Średni</option>
          <option value="high">Wysoki</option>
          <option value="urgent">Pilny</option>
        </select>

        <div className="flex items-center gap-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'list' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Lista
          </button>
          <button
            onClick={() => setViewMode('board')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'board' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Tablica
          </button>
        </div>
      </div>

      {/* Content */}
      {viewMode === 'list' ? (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Zadanie</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Priorytet</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Przypisane</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Termin</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks.map((task) => (
                <tr key={task.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                  <td className="py-3 px-4">
                    <div>
                      <p className="text-sm font-medium text-white">{task.title}</p>
                      <p className="text-xs text-slate-500">{task.description}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full border ${statusConfig[task.status].color}`}>
                      <statusConfig[task.status].icon size={12} />
                      {statusConfig[task.status].label}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded ${priorityConfig[task.priority].color}`}>
                      <AlertCircle size={12} />
                      {priorityConfig[task.priority].label}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center">
                        <span className="text-xs font-medium text-white">{task.assignee.charAt(0)}</span>
                      </div>
                      <span className="text-sm text-slate-400">{task.assignee}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1.5 text-sm text-slate-400">
                      <Calendar size={14} />
                      {task.dueDate}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                        <Edit size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(tasksByStatus).map(([status, statusTasks]) => (
            <div key={status} className="industrial-card">
              <div className={`flex items-center gap-2 p-3 border-b border-[#2a2a2a] ${statusConfig[status as keyof typeof statusConfig].color}`}>
                {(() => {
                  const Icon = statusConfig[status as keyof typeof statusConfig].icon;
                  return <Icon size={16} />;
                })()}
                <span className="font-medium">{statusConfig[status as keyof typeof statusConfig].label}</span>
                <span className="ml-auto bg-[#2a2a2a] text-slate-400 text-xs px-2 py-0.5 rounded-full">
                  {statusTasks.length}
                </span>
              </div>
              <div className="p-2 space-y-2">
                {statusTasks.map((task) => (
                  <div key={task.id} className="p-3 bg-[#1a1a1a] rounded-lg border border-[#2a2a2a] hover:border-amber-500/30 transition-colors cursor-pointer">
                    <div className="flex items-start justify-between mb-2">
                      <p className="text-sm font-medium text-white">{task.title}</p>
                      <span className={`text-xs px-1.5 py-0.5 rounded ${priorityConfig[task.priority].color}`}>
                        {priorityConfig[task.priority].label}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mb-3">{task.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center">
                          <span className="text-[10px] font-medium text-white">{task.assignee.charAt(0)}</span>
                        </div>
                      </div>
                      <span className="text-xs text-slate-500">{task.dueDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TasksPage;
