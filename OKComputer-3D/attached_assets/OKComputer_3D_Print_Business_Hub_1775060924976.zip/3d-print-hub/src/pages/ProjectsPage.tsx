import { useState } from 'react';
import { 
  Plus, 
  Search, 
  FolderKanban, 
  Calendar, 
  Users, 
  MoreHorizontal,
  Edit,
  Trash2,
  Clock,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  FileText
} from 'lucide-react';

interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'on-hold' | 'cancelled';
  progress: number;
  startDate: string;
  endDate?: string;
  team: string[];
  tasks: { total: number; completed: number };
  budget?: number;
  client?: string;
}

const mockProjects: Project[] = [
  { 
    id: '1', 
    name: 'Seria wsporników półek', 
    description: 'Projekt produkcji wsporników półek w różnych rozmiarach', 
    status: 'active', 
    progress: 65, 
    startDate: '2024-01-01', 
    endDate: '2024-02-15',
    team: ['Jan K.', 'Anna M.'],
    tasks: { total: 12, completed: 8 },
    budget: 5000,
    client: 'Meble XYZ'
  },
  { 
    id: '2', 
    name: 'Obudowy elektroniki', 
    description: 'Customowe obudowy dla projektów IoT', 
    status: 'active', 
    progress: 30, 
    startDate: '2024-01-10',
    team: ['Piotr W.'],
    tasks: { total: 8, completed: 2 },
    budget: 3000
  },
  { 
    id: '3', 
    name: 'Modele architektoniczne', 
    description: 'Modele 3D dla biura architektonicznego', 
    status: 'completed', 
    progress: 100, 
    startDate: '2023-12-01', 
    endDate: '2024-01-05',
    team: ['Anna M.', 'Jan K.'],
    tasks: { total: 15, completed: 15 },
    budget: 8000,
    client: 'Architektura Nowoczesna'
  },
  { 
    id: '4', 
    name: 'Prototypy zabawek', 
    description: 'Prototypy elementów zabawek edukacyjnych', 
    status: 'on-hold', 
    progress: 45, 
    startDate: '2023-12-15',
    team: ['Piotr W.'],
    tasks: { total: 10, completed: 4 },
    budget: 2500
  },
];

const statusConfig = {
  'active': { label: 'Aktywny', color: 'bg-green-500/10 text-green-400 border-green-500/20', icon: Clock },
  'completed': { label: 'Zakończony', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20', icon: CheckCircle2 },
  'on-hold': { label: 'Wstrzymany', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20', icon: AlertCircle },
  'cancelled': { label: 'Anulowany', color: 'bg-red-500/10 text-red-400 border-red-500/20', icon: Trash2 },
};

export const ProjectsPage: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || project.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: projects.length,
    active: projects.filter(p => p.status === 'active').length,
    completed: projects.filter(p => p.status === 'completed').length,
    onHold: projects.filter(p => p.status === 'on-hold').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Projekty</h1>
          <p className="text-slate-400">Zarządzaj projektami i śledź ich postęp</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Nowy projekt
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Wszystkie', value: stats.total, color: 'text-white' },
          { label: 'Aktywne', value: stats.active, color: 'text-green-400' },
          { label: 'Zakończone', value: stats.completed, color: 'text-blue-400' },
          { label: 'Wstrzymane', value: stats.onHold, color: 'text-amber-400' },
        ].map((stat, index) => (
          <div key={index} className="industrial-card p-4 text-center">
            <p className="text-2xl font-bold {stat.color}">{stat.value}</p>
            <p className="text-sm text-slate-500">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj projektów..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie statusy</option>
          <option value="active">Aktywne</option>
          <option value="completed">Zakończone</option>
          <option value="on-hold">Wstrzymane</option>
          <option value="cancelled">Anulowane</option>
        </select>

        <div className="flex items-center gap-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'grid' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Siatka
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'list' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Lista
          </button>
        </div>
      </div>

      {/* Projects */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProjects.map((project) => (
            <div key={project.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all group">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-2 rounded-lg ${statusConfig[project.status].color}`}>
                  <FolderKanban size={20} />
                </div>
                <div className="flex items-center gap-1">
                  <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                    <Edit size={16} />
                  </button>
                  <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              <h3 className="text-lg font-semibold text-white mb-1">{project.name}</h3>
              <p className="text-sm text-slate-500 mb-4">{project.description}</p>

              <div className="flex items-center gap-2 mb-4">
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full border ${statusConfig[project.status].color}`}>
                  <statusConfig[project.status].icon size={12} />
                  {statusConfig[project.status].label}
                </span>
                {project.client && (
                  <span className="text-xs text-slate-500 bg-[#2a2a2a] px-2 py-1 rounded-full">
                    {project.client}
                  </span>
                )}
              </div>

              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-slate-400">Postęp</span>
                  <span className="text-white font-medium">{project.progress}%</span>
                </div>
                <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all"
                    style={{ width: `${project.progress}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-slate-500">
                    <Calendar size={14} />
                    <span>{project.startDate}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-500">
                    <CheckCircle2 size={14} />
                    <span>{project.tasks.completed}/{project.tasks.total}</span>
                  </div>
                </div>
                <div className="flex -space-x-2">
                  {project.team.map((member, i) => (
                    <div key={i} className="w-7 h-7 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center border-2 border-[#1a1a1a]">
                      <span className="text-xs font-medium text-white">{member.charAt(0)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Projekt</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Postęp</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Termin</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Zespół</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {filteredProjects.map((project) => (
                <tr key={project.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                  <td className="py-3 px-4">
                    <div>
                      <p className="text-sm font-medium text-white">{project.name}</p>
                      <p className="text-xs text-slate-500">{project.description}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full border ${statusConfig[project.status].color}`}>
                      <statusConfig[project.status].icon size={12} />
                      {statusConfig[project.status].label}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-1.5 bg-[#2a2a2a] rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full"
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-400">{project.progress}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-sm text-slate-400">
                      {project.endDate || 'Brak'}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex -space-x-2">
                      {project.team.map((member, i) => (
                        <div key={i} className="w-7 h-7 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center border-2 border-[#1a1a1a]">
                          <span className="text-xs font-medium text-white">{member.charAt(0)}</span>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                        <Edit size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ProjectsPage;
