import { useState } from 'react';
import { 
  FileSpreadsheet, 
  TrendingUp, 
  DollarSign, 
  Target, 
  Calendar,
  Download,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  PieChart,
  ArrowUpRight
} from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  unit: string;
  deadline: string;
  category: 'revenue' | 'sales' | 'production' | 'marketing';
  status: 'active' | 'completed' | 'at-risk';
}

interface Expense {
  id: string;
  name: string;
  category: string;
  amount: number;
  frequency: 'monthly' | 'yearly' | 'one-time';
}

const mockGoals: Goal[] = [
  { id: '1', title: 'Miesięczny przychód', description: 'Osiągnąć 20,000 zł miesięcznego przychodu', target: 20000, current: 15230, unit: 'zł', deadline: '2024-03-31', category: 'revenue', status: 'active' },
  { id: '2', title: 'Liczba zamówień', description: '100 zamówień w miesiącu', target: 100, current: 78, unit: 'szt', deadline: '2024-02-28', category: 'sales', status: 'active' },
  { id: '3', title: 'Nowi klienci', description: 'Zdobyć 50 nowych klientów', target: 50, current: 42, unit: 'osób', deadline: '2024-06-30', category: 'marketing', status: 'active' },
  { id: '4', title: 'Godziny druku', description: '500h druku miesięcznie', target: 500, current: 423, unit: 'h', deadline: '2024-02-28', category: 'production', status: 'at-risk' },
];

const mockExpenses: Expense[] = [
  { id: '1', name: 'Filament PLA', category: 'Materiały', amount: 800, frequency: 'monthly' },
  { id: '2', name: 'Filament PETG', category: 'Materiały', amount: 400, frequency: 'monthly' },
  { id: '3', name: 'Prąd', category: 'Media', amount: 350, frequency: 'monthly' },
  { id: '4', name: 'Ubezpieczenie', category: 'Ubezpieczenia', amount: 150, frequency: 'monthly' },
  { id: '5', name: 'Oprogramowanie', category: 'Narzędzia', amount: 200, frequency: 'monthly' },
  { id: '6', name: 'Marketing', category: 'Marketing', amount: 500, frequency: 'monthly' },
];

const categoryColors: Record<string, string> = {
  'revenue': 'bg-green-500/10 text-green-400 border-green-500/20',
  'sales': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'production': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  'marketing': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
};

const statusColors: Record<string, string> = {
  'active': 'text-blue-400',
  'completed': 'text-green-400',
  'at-risk': 'text-red-400',
};

export const BusinessPlanPage: React.FC = () => {
  const [goals] = useState<Goal[]>(mockGoals);
  const [expenses] = useState<Expense[]>(mockExpenses);
  const [activeTab, setActiveTab] = useState<'overview' | 'goals' | 'expenses' | 'projections'>('overview');

  const totalMonthlyExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalRevenue = goals.find(g => g.category === 'revenue')?.current || 0;
  const profit = totalRevenue - totalMonthlyExpenses;
  const profitMargin = (profit / totalRevenue * 100).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Biznes Plan</h1>
          <p className="text-slate-400">Planuj cele i śledź postępy biznesowe</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors">
            <Download size={18} />
            Eksportuj
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
            <Plus size={18} />
            Nowy cel
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2a2a2a]">
        {[
          { id: 'overview', label: 'Przegląd', icon: BarChart3 },
          { id: 'goals', label: 'Cele', icon: Target },
          { id: 'expenses', label: 'Koszty', icon: DollarSign },
          { id: 'projections', label: 'Projekcje', icon: TrendingUp },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`
              flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2
              ${activeTab === tab.id 
                ? 'text-amber-400 border-amber-400' 
                : 'text-slate-400 border-transparent hover:text-white'
              }
            `}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <>
          {/* Financial Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="industrial-card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/10 rounded-lg">
                  <DollarSign size={20} className="text-green-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{totalRevenue.toLocaleString()} zł</p>
                  <p className="text-sm text-slate-500">Przychód (mies.)</p>
                </div>
              </div>
            </div>
            <div className="industrial-card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-500/10 rounded-lg">
                  <DollarSign size={20} className="text-red-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{totalMonthlyExpenses.toLocaleString()} zł</p>
                  <p className="text-sm text-slate-500">Koszty (mies.)</p>
                </div>
              </div>
            </div>
            <div className="industrial-card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/10 rounded-lg">
                  <TrendingUp size={20} className="text-amber-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-amber-400">{profit.toLocaleString()} zł</p>
                  <p className="text-sm text-slate-500">Zysk (mies.)</p>
                </div>
              </div>
            </div>
            <div className="industrial-card p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/10 rounded-lg">
                  <PieChart size={20} className="text-blue-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-blue-400">{profitMargin}%</p>
                  <p className="text-sm text-slate-500">Marża</p>
                </div>
              </div>
            </div>
          </div>

          {/* Goals Progress */}
          <div className="industrial-card p-5">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Target size={20} className="text-amber-400" />
              Postęp Celów
            </h3>
            <div className="space-y-4">
              {goals.map((goal) => {
                const progress = (goal.current / goal.target) * 100;
                return (
                  <div key={goal.id} className="p-4 bg-[#1a1a1a] rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full border ${categoryColors[goal.category]}`}>
                          {goal.category}
                        </span>
                        <span className="text-white font-medium">{goal.title}</span>
                      </div>
                      <span className={`text-sm ${statusColors[goal.status]}`}>
                        {goal.status === 'active' ? 'Aktywny' : goal.status === 'completed' ? 'Ukończony' : 'Ryzyko'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm text-slate-500 mb-2">
                      <span>{goal.current} / {goal.target} {goal.unit}</span>
                      <span>Termin: {goal.deadline}</span>
                    </div>
                    <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          progress >= 100 ? 'bg-green-500' : progress >= 75 ? 'bg-blue-500' : progress >= 50 ? 'bg-amber-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Expense Breakdown */}
          <div className="industrial-card p-5">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <DollarSign size={20} className="text-amber-400" />
              Struktura Kosztów
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {expenses.map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded-lg">
                  <div>
                    <p className="text-sm text-white">{expense.name}</p>
                    <p className="text-xs text-slate-500">{expense.category}</p>
                  </div>
                  <span className="text-sm font-medium text-red-400">{expense.amount} zł</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Goals Tab */}
      {activeTab === 'goals' && (
        <div className="space-y-4">
          {goals.map((goal) => {
            const progress = (goal.current / goal.target) * 100;
            return (
              <div key={goal.id} className="industrial-card p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-2 py-0.5 text-xs font-medium rounded-full border ${categoryColors[goal.category]}`}>
                        {goal.category}
                      </span>
                      <span className={`text-sm ${statusColors[goal.status]}`}>
                        {goal.status === 'active' ? 'Aktywny' : goal.status === 'completed' ? 'Ukończony' : 'Ryzyko'}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-white">{goal.title}</h3>
                    <p className="text-sm text-slate-500">{goal.description}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                      <Edit size={18} />
                    </button>
                    <button className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-slate-400">Postęp</span>
                  <span className="text-white font-medium">{progress.toFixed(0)}%</span>
                </div>
                <div className="h-3 bg-[#2a2a2a] rounded-full overflow-hidden mb-4">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      progress >= 100 ? 'bg-green-500' : progress >= 75 ? 'bg-blue-500' : progress >= 50 ? 'bg-amber-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4">
                    <span className="text-slate-500">Aktualnie: <span className="text-white">{goal.current} {goal.unit}</span></span>
                    <span className="text-slate-500">Cel: <span className="text-white">{goal.target} {goal.unit}</span></span>
                  </div>
                  <span className="text-slate-500">Termin: {goal.deadline}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Expenses Tab */}
      {activeTab === 'expenses' && (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Nazwa</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Kategoria</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Kwota</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Częstotliwość</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((expense) => (
                <tr key={expense.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                  <td className="py-3 px-4">
                    <span className="text-sm font-medium text-white">{expense.name}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">{expense.category}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-red-400">{expense.amount} zł</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-sm text-slate-400">
                      {expense.frequency === 'monthly' ? 'Miesięcznie' : expense.frequency === 'yearly' ? 'Rocznie' : 'Jednorazowo'}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1">
                      <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                        <Edit size={16} />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Projections Tab */}
      {activeTab === 'projections' && (
        <div className="industrial-card p-8 text-center">
          <TrendingUp size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">Projekcje finansowe</h3>
          <p className="text-slate-500">Szczegółowe projekcje w przygotowaniu</p>
        </div>
      )}
    </div>
  );
};

export default BusinessPlanPage;
