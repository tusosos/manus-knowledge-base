import { useState } from 'react';
import { 
  Settings, 
  Printer, 
  Plus, 
  Edit, 
  Trash2, 
  Thermometer,
  Ruler,
  Zap,
  Calendar,
  Wrench,
  AlertTriangle,
  CheckCircle2,
  Clock,
  MoreHorizontal,
  Save,
  RotateCcw
} from 'lucide-react';

interface PrinterConfig {
  id: string;
  name: string;
  model: string;
  buildVolume: { x: number; y: number; z: number };
  nozzleSize: number;
  maxTemp: { nozzle: number; bed: number };
  power: number;
  purchaseDate: string;
  price: number;
  maintenanceInterval: number;
  lastMaintenance: string;
  notes: string;
  status: 'active' | 'maintenance' | 'offline';
}

const mockPrinters: PrinterConfig[] = [
  {
    id: '1',
    name: 'Prusa i3 MK3S+ #1',
    model: 'Prusa i3 MK3S+',
    buildVolume: { x: 250, y: 210, z: 200 },
    nozzleSize: 0.4,
    maxTemp: { nozzle: 300, bed: 120 },
    power: 120,
    purchaseDate: '2023-03-15',
    price: 3500,
    maintenanceInterval: 500,
    lastMaintenance: '2024-01-01',
    notes: 'Główna drukarka, niezawodna',
    status: 'active',
  },
  {
    id: '2',
    name: 'Bambu Lab X1 Carbon',
    model: 'Bambu Lab X1 Carbon',
    buildVolume: { x: 256, y: 256, z: 256 },
    nozzleSize: 0.4,
    maxTemp: { nozzle: 300, bed: 110 },
    power: 200,
    purchaseDate: '2023-08-20',
    price: 1800,
    maintenanceInterval: 1000,
    lastMaintenance: '2024-01-10',
    notes: 'Szybka drukarka, świetna jakość',
    status: 'active',
  },
  {
    id: '3',
    name: 'Ender 3 V2',
    model: 'Creality Ender 3 V2',
    buildVolume: { x: 220, y: 220, z: 250 },
    nozzleSize: 0.4,
    maxTemp: { nozzle: 260, bed: 100 },
    power: 150,
    purchaseDate: '2022-11-05',
    price: 800,
    maintenanceInterval: 300,
    lastMaintenance: '2023-12-15',
    notes: 'Wymaga kalibracji',
    status: 'maintenance',
  },
];

const printerModels = [
  'Prusa i3 MK3S+',
  'Prusa i3 MK4',
  'Prusa XL',
  'Bambu Lab X1 Carbon',
  'Bambu Lab P1P',
  'Creality Ender 3 V2',
  'Creality Ender 3 S1',
  'Creality K1',
  'Voron 2.4',
  'Voron Trident',
  'Rat Rig V-Core 3',
  'Inne',
];

export const PrinterPage: React.FC = () => {
  const [printers, setPrinters] = useState<PrinterConfig[]>(mockPrinters);
  const [editingPrinter, setEditingPrinter] = useState<PrinterConfig | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  const [formData, setFormData] = useState<Partial<PrinterConfig>>({
    name: '',
    model: '',
    buildVolume: { x: 220, y: 220, z: 250 },
    nozzleSize: 0.4,
    maxTemp: { nozzle: 260, bed: 100 },
    power: 150,
    purchaseDate: new Date().toISOString().split('T')[0],
    price: 0,
    maintenanceInterval: 500,
    lastMaintenance: new Date().toISOString().split('T')[0],
    notes: '',
    status: 'active',
  });

  const handleSave = () => {
    if (editingPrinter) {
      setPrinters(printers.map(p => p.id === editingPrinter.id ? { ...p, ...formData } as PrinterConfig : p));
      setEditingPrinter(null);
    } else {
      const newPrinter: PrinterConfig = {
        ...formData as PrinterConfig,
        id: Date.now().toString(),
      };
      setPrinters([...printers, newPrinter]);
      setIsAdding(false);
    }
  };

  const handleDelete = (id: string) => {
    setPrinters(printers.filter(p => p.id !== id));
  };

  const startEdit = (printer: PrinterConfig) => {
    setEditingPrinter(printer);
    setFormData(printer);
    setIsAdding(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      model: '',
      buildVolume: { x: 220, y: 220, z: 250 },
      nozzleSize: 0.4,
      maxTemp: { nozzle: 260, bed: 100 },
      power: 150,
      purchaseDate: new Date().toISOString().split('T')[0],
      price: 0,
      maintenanceInterval: 500,
      lastMaintenance: new Date().toISOString().split('T')[0],
      notes: '',
      status: 'active',
    });
  };

  const statusConfig = {
    'active': { label: 'Aktywna', color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: CheckCircle2 },
    'maintenance': { label: 'Konserwacja', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20', icon: Wrench },
    'offline': { label: 'Offline', color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: AlertTriangle },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Drukarki</h1>
          <p className="text-slate-400">Zarządzaj flotą drukarek 3D</p>
        </div>
        <button 
          onClick={() => {
            setIsAdding(true);
            setEditingPrinter(null);
            resetForm();
          }}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
        >
          <Plus size={18} />
          Dodaj drukarkę
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Printer size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{printers.length}</p>
              <p className="text-sm text-slate-500">Drukarek</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <CheckCircle2 size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{printers.filter(p => p.status === 'active').length}</p>
              <p className="text-sm text-slate-500">Aktywnych</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Wrench size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{printers.filter(p => p.status === 'maintenance').length}</p>
              <p className="text-sm text-slate-500">W konserwacji</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/10 rounded-lg">
              <DollarSign size={20} className="text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{printers.reduce((sum, p) => sum + p.price, 0).toLocaleString()} zł</p>
              <p className="text-sm text-slate-500">Wartość sprzętu</p>
            </div>
          </div>
        </div>
      </div>

      {/* Add/Edit Form */}
      {(isAdding || editingPrinter) && (
        <div className="industrial-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">
            {editingPrinter ? 'Edytuj drukarkę' : 'Nowa drukarka'}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm text-slate-400 mb-1">Nazwa</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="np. Prusa i3 MK3S+ #1"
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Model</label>
              <select
                value={formData.model}
                onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              >
                <option value="">Wybierz model</option>
                {printerModels.map((model) => (
                  <option key={model} value={model}>{model}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as PrinterConfig['status'] })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              >
                <option value="active">Aktywna</option>
                <option value="maintenance">Konserwacja</option>
                <option value="offline">Offline</option>
              </select>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Rozmiar dyszy (mm)</label>
              <input
                type="number"
                step="0.1"
                value={formData.nozzleSize}
                onChange={(e) => setFormData({ ...formData, nozzleSize: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Moc (W)</label>
              <input
                type="number"
                value={formData.power}
                onChange={(e) => setFormData({ ...formData, power: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Cena zakupu (zł)</label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Data zakupu</label>
              <input
                type="date"
                value={formData.purchaseDate}
                onChange={(e) => setFormData({ ...formData, purchaseDate: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Interwał konserwacji (h)</label>
              <input
                type="number"
                value={formData.maintenanceInterval}
                onChange={(e) => setFormData({ ...formData, maintenanceInterval: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Ostatnia konserwacja</label>
              <input
                type="date"
                value={formData.lastMaintenance}
                onChange={(e) => setFormData({ ...formData, lastMaintenance: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm text-slate-400 mb-1">Notatki</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
            />
          </div>

          <div className="flex items-center gap-2 mt-4">
            <button 
              onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
            >
              <Save size={18} />
              Zapisz
            </button>
            <button 
              onClick={() => {
                setIsAdding(false);
                setEditingPrinter(null);
              }}
              className="px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors"
            >
              Anuluj
            </button>
          </div>
        </div>
      )}

      {/* Printers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {printers.map((printer) => (
          <div key={printer.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-semibold text-white">{printer.name}</h3>
                <p className="text-sm text-slate-500">{printer.model}</p>
              </div>
              <span className={`inline-flex items-center gap-1.5 px-2 py-1 text-xs font-medium rounded-full border ${statusConfig[printer.status].color}`}>
                <statusConfig[printer.status].icon size={12} />
                {statusConfig[printer.status].label}
              </span>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Ruler size={14} />
                  Pole robocze
                </span>
                <span className="text-white">{printer.buildVolume.x}×{printer.buildVolume.y}×{printer.buildVolume.z} mm</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Settings size={14} />
                  Dysza
                </span>
                <span className="text-white">{printer.nozzleSize} mm</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Thermometer size={14} />
                  Max temp
                </span>
                <span className="text-white">{printer.maxTemp.nozzle}°C / {printer.maxTemp.bed}°C</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Zap size={14} />
                  Moc
                </span>
                <span className="text-white">{printer.power} W</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Wrench size={14} />
                  Konserwacja
                </span>
                <span className="text-white">co {printer.maintenanceInterval}h</span>
              </div>
            </div>

            {printer.notes && (
              <p className="text-xs text-slate-500 mb-4">{printer.notes}</p>
            )}

            <div className="flex items-center gap-2">
              <button 
                onClick={() => startEdit(printer)}
                className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-amber-400 border border-[#2a2a2a] rounded-lg transition-colors"
              >
                <Edit size={16} />
                Edytuj
              </button>
              <button 
                onClick={() => handleDelete(printer.id)}
                className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 border border-[#2a2a2a] rounded-lg transition-colors"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PrinterPage;
