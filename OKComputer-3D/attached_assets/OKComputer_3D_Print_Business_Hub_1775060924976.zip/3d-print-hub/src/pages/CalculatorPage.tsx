import { useState, useCallback } from 'react';
import { 
  Calculator, 
  DollarSign, 
  Clock, 
  Scale, 
  RotateCcw,
  Save,
  FileText,
  ChevronDown,
  Info
} from 'lucide-react';

interface CalculationResult {
  filamentCost: number;
  electricityCost: number;
  depreciationCost: number;
  laborCost: number;
  packagingCost: number;
  marginAmount: number;
  totalCost: number;
  suggestedPrice: number;
  printTime: number;
  weight: number;
}

const filamentTypes = [
  { name: 'PLA', density: 1.24, pricePerKg: 60 },
  { name: 'PETG', density: 1.27, pricePerKg: 70 },
  { name: 'ABS', density: 1.04, pricePerKg: 65 },
  { name: 'TPU', density: 1.21, pricePerKg: 90 },
  { name: 'ASA', density: 1.07, pricePerKg: 85 },
  { name: 'Nylon', density: 1.14, pricePerKg: 120 },
  { name: 'PC', density: 1.20, pricePerKg: 150 },
];

const printers = [
  { name: 'Prusa i3 MK3S+', power: 120, price: 3500, lifespan: 5 },
  { name: 'Bambu Lab X1 Carbon', power: 200, price: 1800, lifespan: 5 },
  { name: 'Ender 3 V2', power: 150, price: 800, lifespan: 4 },
  { name: 'Voron 2.4', power: 300, price: 4000, lifespan: 6 },
];

export const CalculatorPage: React.FC = () => {
  const [formData, setFormData] = useState({
    modelWeight: 50,
    printTime: 4,
    filamentType: 'PLA',
    printer: 'Prusa i3 MK3S+',
    electricityPrice: 0.80,
    hourlyRate: 50,
    packagingCost: 5,
    margin: 30,
    failureRate: 5,
  });

  const [result, setResult] = useState<CalculationResult | null>(null);
  const [savedCalculations, setSavedCalculations] = useState<Array<{ name: string; result: CalculationResult; date: string }>>([]);

  const calculate = useCallback(() => {
    const filament = filamentTypes.find(f => f.name === formData.filamentType);
    const printer = printers.find(p => p.name === formData.printer);
    
    if (!filament || !printer) return;

    const weightKg = formData.modelWeight / 1000;
    const filamentCost = weightKg * filament.pricePerKg;
    const electricityCost = (printer.power / 1000) * formData.printTime * formData.electricityPrice;
    const depreciationCost = (printer.price / (printer.lifespan * 365 * 24)) * formData.printTime;
    const laborCost = formData.hourlyRate * (formData.printTime + 0.5);
    const packagingCost = formData.packagingCost;
    
    const subtotal = filamentCost + electricityCost + depreciationCost + laborCost + packagingCost;
    const failureMultiplier = 1 + (formData.failureRate / 100);
    const totalCost = subtotal * failureMultiplier;
    const marginAmount = totalCost * (formData.margin / 100);
    const suggestedPrice = totalCost + marginAmount;

    setResult({
      filamentCost,
      electricityCost,
      depreciationCost,
      laborCost,
      packagingCost,
      marginAmount,
      totalCost,
      suggestedPrice,
      printTime: formData.printTime,
      weight: formData.modelWeight,
    });
  }, [formData]);

  const saveCalculation = () => {
    if (!result) return;
    const newCalc = {
      name: `Wycena ${savedCalculations.length + 1}`,
      result,
      date: new Date().toLocaleDateString('pl-PL'),
    };
    setSavedCalculations([...savedCalculations, newCalc]);
  };

  const resetForm = () => {
    setFormData({
      modelWeight: 50,
      printTime: 4,
      filamentType: 'PLA',
      printer: 'Prusa i3 MK3S+',
      electricityPrice: 0.80,
      hourlyRate: 50,
      packagingCost: 5,
      margin: 30,
      failureRate: 5,
    });
    setResult(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Kalkulator Wycen</h1>
          <p className="text-slate-400">Oblicz koszty druku i wyceniaj projekty</p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={resetForm}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors"
          >
            <RotateCcw size={18} />
            Resetuj
          </button>
          <button 
            onClick={calculate}
            className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
          >
            <Calculator size={18} />
            Oblicz
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="industrial-card p-6">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Scale size={20} className="text-amber-400" />
            Parametry Druku
          </h2>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Waga modelu (g)</label>
                <input
                  type="number"
                  value={formData.modelWeight}
                  onChange={(e) => setFormData({ ...formData, modelWeight: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Czas druku (h)</label>
                <input
                  type="number"
                  step="0.5"
                  value={formData.printTime}
                  onChange={(e) => setFormData({ ...formData, printTime: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Typ filamentu</label>
              <select
                value={formData.filamentType}
                onChange={(e) => setFormData({ ...formData, filamentType: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              >
                {filamentTypes.map((f) => (
                  <option key={f.name} value={f.name}>{f.name} - {f.pricePerKg} zł/kg</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Drukarka</label>
              <select
                value={formData.printer}
                onChange={(e) => setFormData({ ...formData, printer: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              >
                {printers.map((p) => (
                  <option key={p.name} value={p.name}>{p.name} - {p.power}W</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Cena prądu (zł/kWh)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.electricityPrice}
                  onChange={(e) => setFormData({ ...formData, electricityPrice: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Stawka godzinowa (zł/h)</label>
                <input
                  type="number"
                  value={formData.hourlyRate}
                  onChange={(e) => setFormData({ ...formData, hourlyRate: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1">Koszt opakowania (zł)</label>
                <input
                  type="number"
                  value={formData.packagingCost}
                  onChange={(e) => setFormData({ ...formData, packagingCost: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1">Marża (%)</label>
                <input
                  type="number"
                  value={formData.margin}
                  onChange={(e) => setFormData({ ...formData, margin: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Współczynnik nieudanych wydruków (%)</label>
              <input
                type="number"
                value={formData.failureRate}
                onChange={(e) => setFormData({ ...formData, failureRate: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {result && (
            <>
              <div className="industrial-card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                    <DollarSign size={20} className="text-amber-400" />
                    Wynik Kalkulacji
                  </h2>
                  <button 
                    onClick={saveCalculation}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors"
                  >
                    <Save size={16} />
                    Zapisz
                  </button>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Filament</span>
                    <span className="text-white font-medium">{result.filamentCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Prąd</span>
                    <span className="text-white font-medium">{result.electricityCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Amortyzacja</span>
                    <span className="text-white font-medium">{result.depreciationCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Robocizna</span>
                    <span className="text-white font-medium">{result.laborCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Opakowanie</span>
                    <span className="text-white font-medium">{result.packagingCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Koszt całkowity</span>
                    <span className="text-white font-medium">{result.totalCost.toFixed(2)} zł</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-[#2a2a2a]">
                    <span className="text-slate-400">Marża</span>
                    <span className="text-amber-400 font-medium">{result.marginAmount.toFixed(2)} zł</span>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/30 rounded-lg">
                  <p className="text-sm text-slate-400 mb-1">Sugerowana cena sprzedaży</p>
                  <p className="text-3xl font-bold text-amber-400">{result.suggestedPrice.toFixed(2)} zł</p>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="industrial-card p-4 text-center">
                  <Clock size={20} className="mx-auto mb-2 text-blue-400" />
                  <p className="text-2xl font-bold text-white">{result.printTime}h</p>
                  <p className="text-sm text-slate-500">Czas druku</p>
                </div>
                <div className="industrial-card p-4 text-center">
                  <Scale size={20} className="mx-auto mb-2 text-green-400" />
                  <p className="text-2xl font-bold text-white">{result.weight}g</p>
                  <p className="text-sm text-slate-500">Waga modelu</p>
                </div>
              </div>
            </>
          )}

          {/* Saved Calculations */}
          {savedCalculations.length > 0 && (
            <div className="industrial-card p-6">
              <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <FileText size={20} className="text-amber-400" />
                Zapisane Wyceny
              </h2>
              <div className="space-y-2">
                {savedCalculations.map((calc, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-white">{calc.name}</p>
                      <p className="text-xs text-slate-500">{calc.date}</p>
                    </div>
                    <span className="text-lg font-bold text-amber-400">{calc.result.suggestedPrice.toFixed(2)} zł</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CalculatorPage;
