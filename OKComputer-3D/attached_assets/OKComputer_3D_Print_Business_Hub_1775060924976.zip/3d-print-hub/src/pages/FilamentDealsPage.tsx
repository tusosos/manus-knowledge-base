import { useState } from 'react';
import { 
  Tag, 
  Search, 
  ExternalLink, 
  TrendingDown, 
  Bell,
  Filter,
  Star,
  Clock,
  ShoppingCart,
  Percent,
  Package,
  AlertCircle,
  Bookmark,
  Share2
} from 'lucide-react';

interface FilamentDeal {
  id: string;
  name: string;
  type: string;
  color: string;
  brand: string;
  originalPrice: number;
  salePrice: number;
  discount: number;
  shop: string;
  shopUrl: string;
  expiresAt?: string;
  isHot: boolean;
  rating: number;
  reviews: number;
  addedAt: string;
}

const mockDeals: FilamentDeal[] = [
  { id: '1', name: 'Prusament PLA Galaxy Black', type: 'PLA', color: '#1a1a2e', brand: 'Prusament', originalPrice: 99, salePrice: 79, discount: 20, shop: 'Prusa Research', shopUrl: 'https://www.prusa3d.com', expiresAt: '2024-01-20', isHot: true, rating: 4.9, reviews: 234, addedAt: '2024-01-15' },
  { id: '2', name: 'Hatchbox PETG White', type: 'PETG', color: '#FFFFFF', brand: 'Hatchbox', originalPrice: 89, salePrice: 59, discount: 34, shop: 'Amazon', shopUrl: 'https://amazon.pl', expiresAt: '2024-01-18', isHot: true, rating: 4.6, reviews: 156, addedAt: '2024-01-14' },
  { id: '3', name: 'eSun ABS+ Red', type: 'ABS', color: '#DC2626', brand: 'eSun', originalPrice: 75, salePrice: 55, discount: 27, shop: 'AliExpress', shopUrl: 'https://aliexpress.com', expiresAt: '2024-01-25', isHot: false, rating: 4.4, reviews: 89, addedAt: '2024-01-13' },
  { id: '4', name: 'SainSmart TPU Flexible', type: 'TPU', color: '#F59E0B', brand: 'SainSmart', originalPrice: 140, salePrice: 99, discount: 29, shop: 'Botland', shopUrl: 'https://botland.com.pl', expiresAt: '2024-01-22', isHot: false, rating: 4.5, reviews: 67, addedAt: '2024-01-12' },
  { id: '5', name: 'Prusament PLA Jet Black', type: 'PLA', color: '#000000', brand: 'Prusament', originalPrice: 89, salePrice: 69, discount: 22, shop: 'Prusa Research', shopUrl: 'https://www.prusa3d.com', expiresAt: '2024-01-19', isHot: true, rating: 4.8, reviews: 312, addedAt: '2024-01-15' },
  { id: '6', name: 'Fiberlogy Easy PLA Blue', type: 'PLA', color: '#2563EB', brand: 'Fiberlogy', originalPrice: 79, salePrice: 55, discount: 30, shop: 'Sklep 3D', shopUrl: 'https://sklep3d.pl', expiresAt: '2024-01-21', isHot: false, rating: 4.7, reviews: 123, addedAt: '2024-01-11' },
];

const shops = ['Wszystkie', 'Prusa Research', 'Amazon', 'AliExpress', 'Botland', 'Sklep 3D'];
const types = ['Wszystkie', 'PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'Nylon', 'PC'];

export const FilamentDealsPage: React.FC = () => {
  const [deals] = useState<FilamentDeal[]>(mockDeals);
  const [searchQuery, setSearchQuery] = useState('');
  const [shopFilter, setShopFilter] = useState('Wszystkie');
  const [typeFilter, setTypeFilter] = useState('Wszystkie');
  const [sortBy, setSortBy] = useState<'discount' | 'price' | 'newest'>('discount');
  const [savedDeals, setSavedDeals] = useState<string[]>([]);

  const filteredDeals = deals
    .filter(deal => {
      const matchesSearch = deal.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           deal.brand.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesShop = shopFilter === 'Wszystkie' || deal.shop === shopFilter;
      const matchesType = typeFilter === 'Wszystkie' || deal.type === typeFilter;
      return matchesSearch && matchesShop && matchesType;
    })
    .sort((a, b) => {
      if (sortBy === 'discount') return b.discount - a.discount;
      if (sortBy === 'price') return a.salePrice - b.salePrice;
      return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
    });

  const toggleSaveDeal = (id: string) => {
    setSavedDeals(prev => 
      prev.includes(id) ? prev.filter(d => d !== id) : [...prev, id]
    );
  };

  const avgDiscount = Math.round(deals.reduce((sum, d) => sum + d.discount, 0) / deals.length);
  const hotDeals = deals.filter(d => d.isHot).length;
  const totalSavings = deals.reduce((sum, d) => sum + (d.originalPrice - d.salePrice), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Okazje Filamentów</h1>
          <p className="text-slate-400">Znajdź najlepsze promocje na filamenty</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Bell size={18} />
          Powiadomienia
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <Tag size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{deals.length}</p>
              <p className="text-sm text-slate-500">Aktualnych okazji</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <Percent size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{avgDiscount}%</p>
              <p className="text-sm text-slate-500">Średnia zniżka</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-500/10 rounded-lg">
              <TrendingDown size={20} className="text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{hotDeals}</p>
              <p className="text-sm text-slate-500">Gorących okazji</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <ShoppingCart size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalSavings} zł</p>
              <p className="text-sm text-slate-500">Oszczędności</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[250px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj filamentów..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={shopFilter}
          onChange={(e) => setShopFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          {shops.map(shop => <option key={shop} value={shop}>{shop}</option>)}
        </select>

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          {types.map(type => <option key={type} value={type}>{type}</option>)}
        </select>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="discount">Sortuj: Zniżka</option>
          <option value="price">Sortuj: Cena</option>
          <option value="newest">Sortuj: Najnowsze</option>
        </select>
      </div>

      {/* Deals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDeals.map((deal) => (
          <div key={deal.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all group relative overflow-hidden">
            {/* Hot Badge */}
            {deal.isHot && (
              <div className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                HOT
              </div>
            )}

            <div className="flex items-start gap-4 mb-4">
              <div 
                className="w-16 h-16 rounded-lg border-2 border-[#2a2a2a] flex-shrink-0"
                style={{ backgroundColor: deal.color }}
              />
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-white line-clamp-2">{deal.name}</h3>
                <p className="text-sm text-slate-500">{deal.brand}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-0.5 bg-[#2a2a2a] text-slate-400 text-xs rounded-full">{deal.type}</span>
                  <div className="flex items-center gap-1">
                    <Star size={12} className="text-amber-400 fill-amber-400" />
                    <span className="text-xs text-slate-400">{deal.rating}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-end gap-2 mb-4">
              <span className="text-2xl font-bold text-amber-400">{deal.salePrice} zł</span>
              <span className="text-lg text-slate-500 line-through">{deal.originalPrice} zł</span>
              <span className="px-2 py-0.5 bg-green-500/10 text-green-400 text-sm font-bold rounded">
                -{deal.discount}%
              </span>
            </div>

            {/* Shop & Expiry */}
            <div className="flex items-center justify-between text-sm mb-4">
              <span className="text-slate-400">{deal.shop}</span>
              {deal.expiresAt && (
                <span className="text-slate-500 flex items-center gap-1">
                  <Clock size={12} />
                  do {deal.expiresAt}
                </span>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <a
                href={deal.shopUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
              >
                <ShoppingCart size={16} />
                Kup teraz
              </a>
              <button 
                onClick={() => toggleSaveDeal(deal.id)}
                className={`p-2 border border-[#2a2a2a] rounded-lg transition-colors ${
                  savedDeals.includes(deal.id) 
                    ? 'text-amber-400 bg-amber-500/10' 
                    : 'text-slate-400 hover:text-amber-400 hover:bg-amber-500/10'
                }`}
              >
                <Bookmark size={18} className={savedDeals.includes(deal.id) ? 'fill-amber-400' : ''} />
              </button>
              <button className="p-2 text-slate-400 hover:text-blue-400 hover:bg-blue-500/10 border border-[#2a2a2a] rounded-lg transition-colors">
                <Share2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredDeals.length === 0 && (
        <div className="industrial-card p-12 text-center">
          <Tag size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">Brak okazji</h3>
          <p className="text-slate-500">Spróbuj zmienić kryteria wyszukiwania</p>
        </div>
      )}
    </div>
  );
};

export default FilamentDealsPage;
