import { useState } from 'react';
import { 
  Truck, 
  Plus, 
  Search, 
  Package, 
  MapPin, 
  Clock,
  CheckCircle2,
  AlertCircle,
  MoreHorizontal,
  Edit,
  Trash2,
  ExternalLink,
  Printer,
  Download,
  Filter,
  Calendar,
  DollarSign,
  Weight,
  Box
} from 'lucide-react';

interface Shipment {
  id: string;
  orderNumber: string;
  customerName: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  items: { name: string; quantity: number }[];
  weight: number;
  dimensions: string;
  carrier: string;
  trackingNumber?: string;
  status: 'pending' | 'ready' | 'shipped' | 'delivered' | 'returned';
  shippingCost: number;
  createdAt: string;
  shippedAt?: string;
  estimatedDelivery?: string;
}

const mockShipments: Shipment[] = [
  {
    id: '1',
    orderNumber: 'ZAM-2024-001',
    customerName: 'Jan Kowalski',
    address: 'ul. Drukarska 15',
    city: 'Warszawa',
    postalCode: '00-001',
    country: 'Polska',
    items: [{ name: 'Wsporniki półek x12', quantity: 1 }, { name: 'Obudowa Raspberry Pi', quantity: 1 }],
    weight: 250,
    dimensions: '20x15x10',
    carrier: 'InPost',
    trackingNumber: '6200001234567',
    status: 'shipped',
    shippingCost: 14.99,
    createdAt: '2024-01-15',
    shippedAt: '2024-01-16',
    estimatedDelivery: '2024-01-18',
  },
  {
    id: '2',
    orderNumber: 'ZAM-2024-002',
    customerName: 'Anna Nowak',
    address: 'ul. 3D Printing 5',
    city: 'Kraków',
    postalCode: '30-001',
    country: 'Polska',
    items: [{ name: 'Uchwyt na telefon', quantity: 2 }],
    weight: 80,
    dimensions: '15x10x5',
    carrier: 'DPD',
    status: 'ready',
    shippingCost: 16.50,
    createdAt: '2024-01-16',
  },
  {
    id: '3',
    orderNumber: 'ZAM-2024-003',
    customerName: 'Firma XYZ Sp. z o.o.',
    address: 'ul. Przemysłowa 10',
    city: 'Poznań',
    postalCode: '60-001',
    country: 'Polska',
    items: [{ name: 'Zawiasy meblowe x50', quantity: 1 }],
    weight: 500,
    dimensions: '25x20x15',
    carrier: 'DHL',
    trackingNumber: '1234567890',
    status: 'delivered',
    shippingCost: 25.00,
    createdAt: '2024-01-10',
    shippedAt: '2024-01-11',
    estimatedDelivery: '2024-01-13',
  },
  {
    id: '4',
    orderNumber: 'ZAM-2024-004',
    customerName: 'Piotr Wiśniewski',
    address: 'ul. Modelarska 3',
    city: 'Gdańsk',
    postalCode: '80-001',
    country: 'Polska',
    items: [{ name: 'Stojak na słuchawki', quantity: 1 }],
    weight: 120,
    dimensions: '18x12x8',
    carrier: 'InPost',
    status: 'pending',
    shippingCost: 14.99,
    createdAt: '2024-01-17',
  },
];

const carriers = ['InPost', 'DPD', 'DHL', 'FedEx', 'Poczta Polska', 'Orlen Paczka'];

const statusConfig = {
  'pending': { label: 'Oczekuje', color: 'text-slate-400 bg-slate-500/10 border-slate-500/20', icon: Clock },
  'ready': { label: 'Gotowa do wysyłki', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: Package },
  'shipped': { label: 'Wysłana', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20', icon: Truck },
  'delivered': { label: 'Dostarczona', color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: CheckCircle2 },
  'returned': { label: 'Zwrócona', color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: AlertCircle },
};

export const ShippingPage: React.FC = () => {
  const [shipments, setShipments] = useState<Shipment[]>(mockShipments);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredShipments = shipments.filter(shipment => {
    const matchesSearch = shipment.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         shipment.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (shipment.trackingNumber && shipment.trackingNumber.includes(searchQuery));
    const matchesStatus = statusFilter === 'all' || shipment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: shipments.length,
    pending: shipments.filter(s => s.status === 'pending').length,
    ready: shipments.filter(s => s.status === 'ready').length,
    shipped: shipments.filter(s => s.status === 'shipped').length,
    delivered: shipments.filter(s => s.status === 'delivered').length,
    totalShippingCost: shipments.reduce((sum, s) => sum + s.shippingCost, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Wysyłka</h1>
          <p className="text-slate-400">Zarządzaj wysyłkami i śledzeniem przesyłek</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Nowa wysyłka
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-white">{stats.total}</p>
          <p className="text-sm text-slate-500">Wszystkich</p>
        </div>
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-slate-400">{stats.pending}</p>
          <p className="text-sm text-slate-500">Oczekujących</p>
        </div>
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-blue-400">{stats.ready}</p>
          <p className="text-sm text-slate-500">Gotowych</p>
        </div>
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-amber-400">{stats.shipped}</p>
          <p className="text-sm text-slate-500">W drodze</p>
        </div>
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-green-400">{stats.delivered}</p>
          <p className="text-sm text-slate-500">Dostarczonych</p>
        </div>
        <div className="industrial-card p-4">
          <p className="text-2xl font-bold text-purple-400">{stats.totalShippingCost.toFixed(2)} zł</p>
          <p className="text-sm text-slate-500">Koszty wysyłki</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj wysyłek..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie statusy</option>
          <option value="pending">Oczekujące</option>
          <option value="ready">Gotowe do wysyłki</option>
          <option value="shipped">Wysłane</option>
          <option value="delivered">Dostarczone</option>
          <option value="returned">Zwrócone</option>
        </select>
      </div>

      {/* Shipments List */}
      <div className="space-y-4">
        {filteredShipments.map((shipment) => (
          <div key={shipment.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="font-semibold text-white">{shipment.orderNumber}</h3>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full border ${statusConfig[shipment.status].color}`}>
                    <statusConfig[shipment.status].icon size={12} />
                    {statusConfig[shipment.status].label}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Klient</p>
                    <p className="text-white font-medium">{shipment.customerName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Adres</p>
                    <p className="text-white">{shipment.address}</p>
                    <p className="text-slate-400 text-sm">{shipment.postalCode} {shipment.city}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Przewoźnik</p>
                    <p className="text-white font-medium">{shipment.carrier}</p>
                    {shipment.trackingNumber && (
                      <p className="text-amber-400 text-sm">{shipment.trackingNumber}</p>
                    )}
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 mb-1">Koszt</p>
                    <p className="text-amber-400 font-medium">{shipment.shippingCost.toFixed(2)} zł</p>
                    <p className="text-slate-400 text-sm">{shipment.weight}g • {shipment.dimensions} cm</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <span className="text-slate-500">Produkty:</span>
                  <div className="flex items-center gap-2">
                    {shipment.items.map((item, i) => (
                      <span key={i} className="px-2 py-1 bg-[#2a2a2a] text-slate-300 rounded text-xs">
                        {item.name} x{item.quantity}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2">
                {shipment.trackingNumber && (
                  <a
                    href={`#track-${shipment.trackingNumber}`}
                    className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors"
                    title="Śledź przesyłkę"
                  >
                    <ExternalLink size={18} />
                  </a>
                )}
                <button className="p-2 text-slate-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors" title="Drukuj etykietę">
                  <Printer size={18} />
                </button>
                <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors" title="Edytuj">
                  <Edit size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredShipments.length === 0 && (
        <div className="industrial-card p-12 text-center">
          <Truck size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">Brak wysyłek</h3>
          <p className="text-slate-500">Nie znaleziono wysyłek spełniających kryteria</p>
        </div>
      )}
    </div>
  );
};

export default ShippingPage;
