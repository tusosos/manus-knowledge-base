import { useState } from 'react';
import { 
  Palette, 
  Plus, 
  Save, 
  Download, 
  Upload,
  Layers,
  Droplets,
  RefreshCw,
  Check,
  Copy,
  Trash2,
  Play,
  Settings,
  Info
} from 'lucide-react';

interface ColorChange {
  id: string;
  layer: number;
  color: string;
  filament: string;
}

interface MulticolorProject {
  id: string;
  name: string;
  description: string;
  colors: string[];
  changes: ColorChange[];
  totalLayers: number;
  createdAt: string;
}

const availableFilaments = [
  { name: 'PLA White', color: '#FFFFFF' },
  { name: 'PLA Black', color: '#000000' },
  { name: 'PLA Red', color: '#DC2626' },
  { name: 'PLA Blue', color: '#2563EB' },
  { name: 'PLA Green', color: '#16A34A' },
  { name: 'PLA Yellow', color: '#EAB308' },
  { name: 'PLA Orange', color: '#F97316' },
  { name: 'PLA Purple', color: '#9333EA' },
  { name: 'PLA Pink', color: '#EC4899' },
  { name: 'PLA Silver', color: '#C0C0C0' },
  { name: 'PLA Gold', color: '#FFD700' },
];

const mockProjects: MulticolorProject[] = [
  {
    id: '1',
    name: 'Logo firmy 3-kolorowe',
    description: 'Logo z białym, niebieskim i zielonym',
    colors: ['#FFFFFF', '#2563EB', '#16A34A'],
    changes: [
      { id: '1', layer: 1, color: '#FFFFFF', filament: 'PLA White' },
      { id: '2', layer: 15, color: '#2563EB', filament: 'PLA Blue' },
      { id: '3', layer: 30, color: '#16A34A', filament: 'PLA Green' },
    ],
    totalLayers: 45,
    createdAt: '2024-01-10',
  },
  {
    id: '2',
    name: 'Flaga Polski',
    description: 'Biało-czerwona flaga',
    colors: ['#FFFFFF', '#DC2626'],
    changes: [
      { id: '1', layer: 1, color: '#FFFFFF', filament: 'PLA White' },
      { id: '2', layer: 25, color: '#DC2626', filament: 'PLA Red' },
    ],
    totalLayers: 50,
    createdAt: '2024-01-12',
  },
];

export const MulticolorPage: React.FC = () => {
  const [projects, setProjects] = useState<MulticolorProject[]>(mockProjects);
  const [activeProject, setActiveProject] = useState<MulticolorProject | null>(null);
  const [newProjectName, setNewProjectName] = useState('');
  const [totalLayers, setTotalLayers] = useState(50);
  const [colorChanges, setColorChanges] = useState<ColorChange[]>([]);
  const [showNewProject, setShowNewProject] = useState(false);

  const addColorChange = () => {
    const newChange: ColorChange = {
      id: Date.now().toString(),
      layer: 1,
      color: availableFilaments[0].color,
      filament: availableFilaments[0].name,
    };
    setColorChanges([...colorChanges, newChange]);
  };

  const updateColorChange = (id: string, updates: Partial<ColorChange>) => {
    setColorChanges(colorChanges.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const removeColorChange = (id: string) => {
    setColorChanges(colorChanges.filter(c => c.id !== id));
  };

  const saveProject = () => {
    if (!newProjectName) return;
    
    const newProject: MulticolorProject = {
      id: Date.now().toString(),
      name: newProjectName,
      description: '',
      colors: [...new Set(colorChanges.map(c => c.color))],
      changes: colorChanges,
      totalLayers,
      createdAt: new Date().toISOString().split('T')[0],
    };
    
    setProjects([...projects, newProject]);
    setShowNewProject(false);
    setNewProjectName('');
    setColorChanges([]);
  };

  const generateGCode = () => {
    // Mock G-code generation
    const gcode = colorChanges
      .sort((a, b) => a.layer - b.layer)
      .map((change, index) => `; Color Change ${index + 1} at Layer ${change.layer}\nM600 ; Filament Change`)
      .join('\n');
    
    const blob = new Blob([gcode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'color_changes.gcode';
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Multicolor / MMU</h1>
          <p className="text-slate-400">Zarządzaj projektami wielokolorowymi</p>
        </div>
        <button 
          onClick={() => setShowNewProject(true)}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
        >
          <Plus size={18} />
          Nowy projekt
        </button>
      </div>

      {/* Info Card */}
      <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Info size={20} className="text-blue-400 mt-0.5" />
          <div>
            <h3 className="font-semibold text-blue-400 mb-1">Wskazówka</h3>
            <p className="text-sm text-slate-400">
              Użyj tego narzędzia do planowania zmian kolorów w druku wielokolorowym. 
              Możesz użyć M600 (filament change) lub drukarki z MMU (Multi Material Unit).
            </p>
          </div>
        </div>
      </div>

      {/* New Project Form */}
      {showNewProject && (
        <div className="industrial-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Palette size={20} className="text-amber-400" />
            Nowy Projekt Multicolor
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-1">Nazwa projektu</label>
              <input
                type="text"
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                placeholder="np. Logo firmy 3-kolorowe"
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white placeholder-slate-600 focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Liczba warstw</label>
              <input
                type="number"
                value={totalLayers}
                onChange={(e) => setTotalLayers(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm text-slate-400">Zmiany kolorów</label>
                <button 
                  onClick={addColorChange}
                  className="flex items-center gap-1 px-3 py-1 bg-amber-500/10 text-amber-400 text-sm rounded-lg hover:bg-amber-500/20 transition-colors"
                >
                  <Plus size={14} />
                  Dodaj zmianę
                </button>
              </div>
              
              <div className="space-y-2">
                {colorChanges.map((change, index) => (
                  <div key={change.id} className="flex items-center gap-3 p-3 bg-[#1a1a1a] rounded-lg">
                    <span className="text-slate-500 font-mono">#{index + 1}</span>
                    
                    <div className="flex-1">
                      <label className="text-xs text-slate-500">Warstwa</label>
                      <input
                        type="number"
                        value={change.layer}
                        onChange={(e) => updateColorChange(change.id, { layer: Number(e.target.value) })}
                        className="w-20 px-2 py-1 bg-[#252525] border border-[#2a2a2a] rounded text-white text-sm"
                      />
                    </div>

                    <div className="flex-1">
                      <label className="text-xs text-slate-500">Filament</label>
                      <select
                        value={change.filament}
                        onChange={(e) => {
                          const filament = availableFilaments.find(f => f.name === e.target.value);
                          updateColorChange(change.id, { 
                            filament: e.target.value,
                            color: filament?.color || change.color
                          });
                        }}
                        className="w-full px-2 py-1 bg-[#252525] border border-[#2a2a2a] rounded text-white text-sm"
                      >
                        {availableFilaments.map((f) => (
                          <option key={f.name} value={f.name}>{f.name}</option>
                        ))}
                      </select>
                    </div>

                    <div 
                      className="w-8 h-8 rounded border-2 border-[#2a2a2a]"
                      style={{ backgroundColor: change.color }}
                    />

                    <button 
                      onClick={() => removeColorChange(change.id)}
                      className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Preview */}
            {colorChanges.length > 0 && (
              <div className="p-4 bg-[#1a1a1a] rounded-lg">
                <label className="block text-sm text-slate-400 mb-2">Podgląd warstw</label>
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(totalLayers, 50) }, (_, i) => {
                    const layerNum = i + 1;
                    const change = [...colorChanges]
                      .sort((a, b) => a.layer - b.layer)
                      .findLast(c => c.layer <= layerNum);
                    return (
                      <div
                        key={i}
                        className="w-2 h-8 rounded-sm"
                        style={{ backgroundColor: change?.color || '#FFFFFF' }}
                        title={`Warstwa ${layerNum}: ${change?.filament || 'Biały'}`}
                      />
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2">
              <button 
                onClick={saveProject}
                disabled={!newProjectName || colorChanges.length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed text-black font-semibold rounded-lg transition-colors"
              >
                <Save size={18} />
                Zapisz projekt
              </button>
              <button 
                onClick={() => {
                  setShowNewProject(false);
                  setNewProjectName('');
                  setColorChanges([]);
                }}
                className="px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 border border-[#2a2a2a] rounded-lg transition-colors"
              >
                Anuluj
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Projects List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((project) => (
          <div key={project.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="font-semibold text-white">{project.name}</h3>
                <p className="text-sm text-slate-500">{project.description || 'Brak opisu'}</p>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setActiveProject(project)}
                  className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors"
                >
                  <Settings size={16} />
                </button>
                <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 mb-4">
              {project.colors.map((color, i) => (
                <div 
                  key={i}
                  className="w-6 h-6 rounded border-2 border-[#2a2a2a]"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Warstw:</span>
                <span className="text-white">{project.totalLayers}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">Zmian kolorów:</span>
                <span className="text-white">{project.changes.length}</span>
              </div>
            </div>

            <button 
              onClick={generateGCode}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-amber-400 border border-[#2a2a2a] rounded-lg transition-colors"
            >
              <Download size={16} />
              Pobierz G-code
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MulticolorPage;
