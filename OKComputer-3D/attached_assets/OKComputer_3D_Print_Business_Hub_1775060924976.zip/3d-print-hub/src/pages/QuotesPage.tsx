import { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal,
  Edit,
  Trash2,
  Send,
  Download,
  CheckCircle2,
  Clock,
  XCircle,
  DollarSign,
  Calendar,
  User,
  ArrowUpRight,
  Copy
} from 'lucide-react';

interface Quote {
  id: string;
  number: string;
  clientName: string;
  clientEmail: string;
  projectName: string;
  items: QuoteItem[];
  subtotal: number;
  tax: number;
  total: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';
  createdAt: string;
  validUntil: string;
  notes?: string;
}

interface QuoteItem {
  name: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

const mockQuotes: Quote[] = [
  {
    id: '1',
    number: 'W-2024-001',
    clientName: 'Firma XYZ Sp. z o.o.',
    clientEmail: 'kontakt@firma-xyz.pl',
    projectName: 'Seria wsporników półek',
    items: [
      { name: 'Wspornik mały', description: 'PLA Black, 20 szt', quantity: 20, unitPrice: 15, total: 300 },
      { name: 'Wspornik średni', description: 'PLA Black, 15 szt', quantity: 15, unitPrice: 20, total: 300 },
    ],
    subtotal: 600,
    tax: 138,
    total: 738,
    status: 'sent',
    createdAt: '2024-01-10',
    validUntil: '2024-01-24',
    notes: 'Darmowa dostawa przy zamówieniu powyżej 500 zł',
  },
  {
    id: '2',
    number: 'W-2024-002',
    clientName: 'Jan Kowalski',
    clientEmail: 'jan.kowalski@email.pl',
    projectName: 'Obudowa Raspberry Pi',
    items: [
      { name: 'Obudowa Raspberry Pi 4', description: 'PETG Transparent', quantity: 1, unitPrice: 85, total: 85 },
    ],
    subtotal: 85,
    tax: 19.55,
    total: 104.55,
    status: 'accepted',
    createdAt: '2024-01-12',
    validUntil: '2024-01-26',
  },
  {
    id: '3',
    number: 'W-2024-003',
    clientName: 'Meble Design',
    clientEmail: 'biuro@mebledesign.pl',
    projectName: 'Prototyp uchwytu',
    items: [
      { name: 'Prototyp uchwytu v1', description: 'PLA White', quantity: 3, unitPrice: 120, total: 360 },
    ],
    subtotal: 360,
    tax: 82.80,
    total: 442.80,
    status: 'draft',
    createdAt: '2024-01-14',
    validUntil: '2024-01-28',
  },
];

const statusConfig = {
  'draft': { label: 'Wersja robocza', color: 'text-slate-400 bg-slate-500/10 border-slate-500/20', icon: FileText },
  'sent': { label: 'Wysłana', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: Send },
  'accepted': { label: 'Zaakceptowana', color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: CheckCircle2 },
  'rejected': { label: 'Odrzucona', color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: XCircle },
  'expired': { label: 'Wygasła', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20', icon: Clock },
};

export const QuotesPage: React.FC = () => {
  const [quotes, setQuotes] = useState<Quote[]>(mockQuotes);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredQuotes = quotes.filter(quote => {
    const matchesSearch = quote.number.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         quote.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         quote.projectName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || quote.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: quotes.length,
    draft: quotes.filter(q => q.status === 'draft').length,
    sent: quotes.filter(q => q.status === 'sent').length,
    accepted: quotes.filter(q => q.status === 'accepted').length,
    totalValue: quotes.filter(q => q.status === 'accepted').reduce((sum, q) => sum + q.total, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Wyceny</h1>
          <p className="text-slate-400">Twórz i zarządzaj wycenami dla klientów</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Nowa wycena
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="industrial-card p-4 text-center">
          <p className="text-2xl font-bold text-white">{stats.total}</p>
          <p className="text-sm text-slate-500">Wszystkich</p>
        </div>
        <div className="industrial-card p-4 text-center">
          <p className="text-2xl font-bold text-slate-400">{stats.draft}</p>
          <p className="text-sm text-slate-500">Wersje robocze</p>
        </div>
        <div className="industrial-card p-4 text-center">
          <p className="text-2xl font-bold text-blue-400">{stats.sent}</p>
          <p className="text-sm text-slate-500">Wysłane</p>
        </div>
        <div className="industrial-card p-4 text-center">
          <p className="text-2xl font-bold text-green-400">{stats.accepted}</p>
          <p className="text-sm text-slate-500">Zaakceptowane</p>
        </div>
        <div className="industrial-card p-4 text-center">
          <p className="text-2xl font-bold text-amber-400">{stats.totalValue.toLocaleString()} zł</p>
          <p className="text-sm text-slate-500">Wartość</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj wycen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie statusy</option>
          <option value="draft">Wersja robocza</option>
          <option value="sent">Wysłana</option>
          <option value="accepted">Zaakceptowana</option>
          <option value="rejected">Odrzucona</option>
          <option value="expired">Wygasła</option>
        </select>
      </div>

      {/* Quotes List */}
      <div className="space-y-4">
        {filteredQuotes.map((quote) => (
          <div key={quote.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-semibold text-white">{quote.number}</h3>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full border ${statusConfig[quote.status].color}`}>
                    <statusConfig[quote.status].icon size={12} />
                    {statusConfig[quote.status].label}
                  </span>
                </div>
                <p className="text-white font-medium mb-1">{quote.projectName}</p>
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <span className="flex items-center gap-1.5">
                    <User size={14} />
                    {quote.clientName}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar size={14} />
                    {quote.createdAt}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock size={14} />
                    Ważna do: {quote.validUntil}
                  </span>
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-2xl font-bold text-amber-400">{quote.total.toFixed(2)} zł</p>
                <p className="text-sm text-slate-500">{quote.items.length} pozycji</p>
              </div>
            </div>

            {/* Items Preview */}
            <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
              <div className="space-y-2">
                {quote.items.map((item, index) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <span className="text-slate-400">{item.name} x{item.quantity}</span>
                    <span className="text-white">{item.total} zł</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 pt-4 border-t border-[#2a2a2a] flex items-center justify-end gap-2">
              <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors" title="Pobierz PDF">
                <Download size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-colors" title="Duplikuj">
                <Copy size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors" title="Edytuj">
                <Edit size={18} />
              </button>
              <button className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Usuń">
                <Trash2 size={18} />
              </button>
              {quote.status === 'draft' && (
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-400 text-white text-sm font-medium rounded-lg transition-colors">
                  <Send size={16} />
                  Wyślij
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuotesPage;
