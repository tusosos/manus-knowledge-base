import { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Plus, 
  Folder,
  FileText,
  Video,
  Link as LinkIcon,
  MoreHorizontal,
  Edit,
  Trash2,
  ExternalLink,
  Tag,
  Star,
  Clock,
  ChevronRight,
  ChevronDown
} from 'lucide-react';

interface KnowledgeItem {
  id: string;
  title: string;
  description: string;
  type: 'article' | 'video' | 'link' | 'file';
  category: string;
  tags: string[];
  url?: string;
  createdAt: string;
  updatedAt: string;
  isFavorite: boolean;
}

interface Category {
  id: string;
  name: string;
  icon: React.ElementType;
  count: number;
}

const categories: Category[] = [
  { id: 'all', name: 'Wszystkie', icon: Folder, count: 24 },
  { id: 'tutorials', name: 'Poradniki', icon: BookOpen, count: 8 },
  { id: 'slicing', name: 'Slicowanie', icon: FileText, count: 5 },
  { id: 'materials', name: 'Materiały', icon: Tag, count: 4 },
  { id: 'troubleshooting', name: 'Rozwiązywanie problemów', icon: ExternalLink, count: 4 },
  { id: 'design', name: 'Projektowanie', icon: Star, count: 3 },
];

const mockItems: KnowledgeItem[] = [
  {
    id: '1',
    title: 'Kompletny przewodnik po slicowaniu w PrusaSlicer',
    description: 'Od podstaw zaawansowanych - wszystko co musisz wiedzieć o slicowaniu',
    type: 'article',
    category: 'slicing',
    tags: ['prusa', 'slicer', 'tutorial'],
    url: 'https://help.prusa3d.com',
    createdAt: '2024-01-10',
    updatedAt: '2024-01-15',
    isFavorite: true,
  },
  {
    id: '2',
    title: 'Kalibracja First Layer - wideo',
    description: 'Jak idealnie skalibrować pierwszą warstwę',
    type: 'video',
    category: 'tutorials',
    tags: ['kalibracja', 'first-layer', 'video'],
    url: 'https://youtube.com',
    createdAt: '2024-01-05',
    updatedAt: '2024-01-05',
    isFavorite: false,
  },
  {
    id: '3',
    title: 'Tabela temperatur dla różnych filamentów',
    description: 'Optymalne temperatury dla PLA, PETG, ABS, TPU i innych',
    type: 'article',
    category: 'materials',
    tags: ['temperatury', 'filament', 'ustawienia'],
    createdAt: '2023-12-20',
    updatedAt: '2024-01-12',
    isFavorite: true,
  },
  {
    id: '4',
    title: 'Rozwiązywanie problemów z warpingiem',
    description: 'Przyczyny i rozwiązania problemu odchodzenia od stołu',
    type: 'article',
    category: 'troubleshooting',
    tags: ['warping', 'problemy', 'adhezja'],
    createdAt: '2024-01-08',
    updatedAt: '2024-01-08',
    isFavorite: false,
  },
  {
    id: '5',
    title: 'Thingiverse - biblioteka modeli 3D',
    description: 'Największa baza darmowych modeli do druku 3D',
    type: 'link',
    category: 'design',
    tags: ['modele', 'thingiverse', 'zasoby'],
    url: 'https://thingiverse.com',
    createdAt: '2023-11-15',
    updatedAt: '2023-11-15',
    isFavorite: true,
  },
];

const typeIcons: Record<string, React.ElementType> = {
  'article': FileText,
  'video': Video,
  'link': LinkIcon,
  'file': FileText,
};

const typeColors: Record<string, string> = {
  'article': 'bg-blue-500/10 text-blue-400',
  'video': 'bg-red-500/10 text-red-400',
  'link': 'bg-green-500/10 text-green-400',
  'file': 'bg-amber-500/10 text-amber-400',
};

export const KnowledgePage: React.FC = () => {
  const [items, setItems] = useState<KnowledgeItem[]>(mockItems);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const filteredItems = items.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesFavorites = !showFavoritesOnly || item.isFavorite;
    return matchesSearch && matchesCategory && matchesFavorites;
  });

  const toggleFavorite = (id: string) => {
    setItems(items.map(item => item.id === id ? { ...item, isFavorite: !item.isFavorite } : item));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Baza Wiedzy</h1>
          <p className="text-slate-400">Zbieraj i organizuj wiedzę o druku 3D</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Dodaj wpis
        </button>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj w bazie wiedzy..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <button
          onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
          className={`
            flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
            ${showFavoritesOnly 
              ? 'bg-amber-500 text-black' 
              : 'bg-[#1a1a1a] text-slate-400 border border-[#2a2a2a] hover:text-white'
            }
          `}
        >
          <Star size={16} className={showFavoritesOnly ? 'fill-black' : ''} />
          Ulubione
        </button>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`
              flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
              ${selectedCategory === category.id 
                ? 'bg-amber-500 text-black' 
                : 'bg-[#1a1a1a] text-slate-400 border border-[#2a2a2a] hover:text-white'
              }
            `}
          >
            <category.icon size={16} />
            <span>{category.name}</span>
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${selectedCategory === category.id ? 'bg-black/20' : 'bg-[#2a2a2a]'}`}>
              {category.count}
            </span>
          </button>
        ))}
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map((item) => {
          const TypeIcon = typeIcons[item.type];
          return (
            <div key={item.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all group">
              <div className="flex items-start justify-between mb-3">
                <div className={`p-2 rounded-lg ${typeColors[item.type]}`}>
                  <TypeIcon size={18} />
                </div>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => toggleFavorite(item.id)}
                    className={`p-1.5 rounded-lg transition-colors ${item.isFavorite ? 'text-amber-400' : 'text-slate-600 hover:text-amber-400'}`}
                  >
                    <Star size={16} className={item.isFavorite ? 'fill-amber-400' : ''} />
                  </button>
                  <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                    <Edit size={16} />
                  </button>
                  <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>

              <h3 className="font-semibold text-white mb-2 line-clamp-2">{item.title}</h3>
              <p className="text-sm text-slate-500 mb-4 line-clamp-2">{item.description}</p>

              <div className="flex flex-wrap gap-1 mb-4">
                {item.tags.map((tag, i) => (
                  <span key={i} className="px-2 py-0.5 bg-[#2a2a2a] text-slate-400 text-xs rounded-full">
                    #{tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 flex items-center gap-1">
                  <Clock size={12} />
                  {item.updatedAt}
                </span>
                {item.url && (
                  <a 
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1"
                  >
                    Otwórz
                    <ExternalLink size={12} />
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <div className="industrial-card p-12 text-center">
          <BookOpen size={64} className="mx-auto mb-4 text-slate-600" />
          <h3 className="text-xl font-semibold text-white mb-2">Brak wyników</h3>
          <p className="text-slate-500">Spróbuj zmienić kryteria wyszukiwania</p>
        </div>
      )}
    </div>
  );
};

export default KnowledgePage;
