import { useState } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  MoreHorizontal,
  Edit,
  Trash2,
  TrendingDown,
  TrendingUp,
  BarChart3,
  ArrowUpRight
} from 'lucide-react';

interface Filament {
  id: string;
  name: string;
  type: string;
  color: string;
  brand: string;
  weightTotal: number;
  weightRemaining: number;
  price: number;
  location: string;
  minStock: number;
  lastUsed: string;
}

const mockFilaments: Filament[] = [
  { id: '1', name: 'PLA Black', type: 'PLA', color: '#000000', brand: 'Prusament', weightTotal: 1000, weightRemaining: 150, price: 89, location: 'Półka A1', minStock: 200, lastUsed: '2024-01-14' },
  { id: '2', name: 'PETG White', type: 'PETG', color: '#FFFFFF', brand: 'Hatchbox', weightTotal: 1000, weightRemaining: 750, price: 75, location: 'Półka A2', minStock: 200, lastUsed: '2024-01-13' },
  { id: '3', name: 'PLA Galaxy Black', type: 'PLA', color: '#1a1a2e', brand: 'Prusament', weightTotal: 1000, weightRemaining: 420, price: 99, location: 'Półka A1', minStock: 200, lastUsed: '2024-01-12' },
  { id: '4', name: 'ABS Red', type: 'ABS', color: '#DC2626', brand: 'eSun', weightTotal: 1000, weightRemaining: 890, price: 65, location: 'Półka B1', minStock: 300, lastUsed: '2024-01-10' },
  { id: '5', name: 'TPU Flexible', type: 'TPU', color: '#F59E0B', brand: 'SainSmart', weightTotal: 500, weightRemaining: 180, price: 120, location: 'Półka C1', minStock: 100, lastUsed: '2024-01-08' },
  { id: '6', name: 'PLA Silk Silver', type: 'PLA', color: '#C0C0C0', brand: 'Geeetech', weightTotal: 1000, weightRemaining: 50, price: 55, location: 'Półka A3', minStock: 200, lastUsed: '2024-01-15' },
];

const typeColors: Record<string, string> = {
  'PLA': 'bg-green-500/10 text-green-400 border-green-500/20',
  'PETG': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'ABS': 'bg-red-500/10 text-red-400 border-red-500/20',
  'TPU': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  'ASA': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'Nylon': 'bg-pink-500/10 text-pink-400 border-pink-500/20',
};

export const InventoryPage: React.FC = () => {
  const [filaments, setFilaments] = useState<Filament[]>(mockFilaments);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredFilaments = filaments.filter(filament => {
    const matchesSearch = filament.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         filament.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || filament.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const lowStockFilaments = filaments.filter(f => f.weightRemaining < f.minStock);
  const totalValue = filaments.reduce((sum, f) => sum + (f.weightRemaining / 1000) * f.price, 0);
  const totalWeight = filaments.reduce((sum, f) => sum + f.weightRemaining, 0);

  const getStockStatus = (filament: Filament) => {
    const percentage = (filament.weightRemaining / filament.weightTotal) * 100;
    if (filament.weightRemaining < filament.minStock) return { label: 'Niski stan', color: 'text-red-400 bg-red-500/10' };
    if (percentage < 30) return { label: 'Krytyczny', color: 'text-amber-400 bg-amber-500/10' };
    return { label: 'OK', color: 'text-green-400 bg-green-500/10' };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Magazyn</h1>
          <p className="text-slate-400">Zarządzaj filamentami i materiałami</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors">
          <Plus size={18} />
          Dodaj filament
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 rounded-lg">
              <Package size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{filaments.length}</p>
              <p className="text-sm text-slate-500">Szpul filamentu</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/10 rounded-lg">
              <BarChart3 size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{(totalWeight / 1000).toFixed(1)} kg</p>
              <p className="text-sm text-slate-500">Całkowita waga</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 rounded-lg">
              <TrendingUp size={20} className="text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalValue.toFixed(0)} zł</p>
              <p className="text-sm text-slate-500">Wartość magazynu</p>
            </div>
          </div>
        </div>
        <div className="industrial-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-500/10 rounded-lg">
              <AlertTriangle size={20} className="text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{lowStockFilaments.length}</p>
              <p className="text-sm text-slate-500">Niski stan</p>
            </div>
          </div>
        </div>
      </div>

      {/* Low Stock Alert */}
      {lowStockFilaments.length > 0 && (
        <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={18} className="text-red-400" />
            <h3 className="font-semibold text-red-400">Uwaga: Niski stan filamentu</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {lowStockFilaments.map((f) => (
              <span key={f.id} className="px-3 py-1 bg-red-500/10 text-red-400 text-sm rounded-full">
                {f.name} ({f.weightRemaining}g)
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Szukaj filamentów..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50"
          />
        </div>
        
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white focus:outline-none focus:border-amber-500/50"
        >
          <option value="all">Wszystkie typy</option>
          <option value="PLA">PLA</option>
          <option value="PETG">PETG</option>
          <option value="ABS">ABS</option>
          <option value="TPU">TPU</option>
          <option value="ASA">ASA</option>
          <option value="Nylon">Nylon</option>
        </select>

        <div className="flex items-center gap-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg p-1">
          <button
            onClick={() => setViewMode('grid')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'grid' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Siatka
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${viewMode === 'list' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'}`}
          >
            Lista
          </button>
        </div>
      </div>

      {/* Filaments */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFilaments.map((filament) => {
            const stockStatus = getStockStatus(filament);
            const percentage = (filament.weightRemaining / filament.weightTotal) * 100;
            
            return (
              <div key={filament.id} className="industrial-card p-5 hover:border-amber-500/30 transition-all group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-lg border-2 border-[#2a2a2a]"
                      style={{ backgroundColor: filament.color }}
                    />
                    <div>
                      <h3 className="font-semibold text-white">{filament.name}</h3>
                      <p className="text-sm text-slate-500">{filament.brand}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                      <Edit size={16} />
                    </button>
                    <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <span className={`px-2.5 py-1 text-xs font-medium rounded-full border ${typeColors[filament.type]}`}>
                    {filament.type}
                  </span>
                  <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${stockStatus.color}`}>
                    {stockStatus.label}
                  </span>
                </div>

                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-slate-400">Pozostało</span>
                    <span className="text-white font-medium">{filament.weightRemaining}g / {filament.weightTotal}g</span>
                  </div>
                  <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        percentage < 20 ? 'bg-red-500' : percentage < 50 ? 'bg-amber-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">{filament.location}</span>
                  <span className="text-amber-400 font-medium">{filament.price} zł</span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="industrial-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2a2a2a]">
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Filament</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Typ</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Stan</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Lokalizacja</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Cena</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-slate-500 uppercase">Akcje</th>
              </tr>
            </thead>
            <tbody>
              {filteredFilaments.map((filament) => {
                const stockStatus = getStockStatus(filament);
                return (
                  <tr key={filament.id} className="border-b border-[#2a2a2a] hover:bg-[#1a1a1a] transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-8 h-8 rounded border-2 border-[#2a2a2a]"
                          style={{ backgroundColor: filament.color }}
                        />
                        <div>
                          <p className="text-sm font-medium text-white">{filament.name}</p>
                          <p className="text-xs text-slate-500">{filament.brand}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${typeColors[filament.type]}`}>
                        {filament.type}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-2 py-1 rounded-full ${stockStatus.color}`}>
                          {stockStatus.label}
                        </span>
                        <span className="text-sm text-slate-400">{filament.weightRemaining}g</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-slate-400">{filament.location}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-amber-400 font-medium">{filament.price} zł</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <button className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
                          <Edit size={16} />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default InventoryPage;
