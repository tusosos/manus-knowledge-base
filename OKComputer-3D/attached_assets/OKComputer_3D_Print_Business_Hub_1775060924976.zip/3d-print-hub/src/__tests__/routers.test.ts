import { describe, it, expect, beforeEach, vi } from 'vitest';
import { appRouter } from '../server/routers';
import { TRPCError } from '@trpc/server';

// Mock database
const mockDb = {
  query: {
    users: { findFirst: vi.fn() },
    tasks: { findFirst: vi.fn(), findMany: vi.fn() },
    projects: { findFirst: vi.fn(), findMany: vi.fn() },
    clients: { findFirst: vi.fn(), findMany: vi.fn() },
    filaments: { findFirst: vi.fn(), findMany: vi.fn() },
    printJobs: { findFirst: vi.fn(), findMany: vi.fn() },
    quotes: { findFirst: vi.fn(), findMany: vi.fn() },
    orders: { findMany: vi.fn() },
    printers: { findFirst: vi.fn() },
    quoteItems: { findMany: vi.fn() },
  },
  insert: vi.fn(() => ({ values: vi.fn(() => ({ returning: vi.fn() })) })),
  update: vi.fn(() => ({ set: vi.fn(() => ({ where: vi.fn() })) })),
  delete: vi.fn(() => ({ where: vi.fn() })),
};

// Mock session
const mockSession = {
  user: {
    id: 'user-1',
    email: 'test@example.com',
    name: 'Test User',
    role: 'ADMIN' as const,
  },
  expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
};

// Create caller
const createCaller = () => appRouter.createCaller({
  db: mockDb as any,
  session: mockSession,
});

describe('Auth Router', () => {
  const caller = createCaller();

  describe('getSession', () => {
    it('should return current session', async () => {
      const result = await caller.auth.getSession();
      expect(result).toEqual(mockSession);
    });
  });

  describe('getUser', () => {
    it('should return user data', async () => {
      const mockUser = {
        id: 'user-1',
        email: 'test@example.com',
        name: 'Test User',
        role: 'ADMIN',
        avatar: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      mockDb.query.users.findFirst.mockResolvedValue(mockUser);

      const result = await caller.auth.getUser();
      expect(result.id).toBe('user-1');
      expect(result.email).toBe('test@example.com');
    });

    it('should throw NOT_FOUND if user not found', async () => {
      mockDb.query.users.findFirst.mockResolvedValue(null);

      await expect(caller.auth.getUser()).rejects.toThrow(TRPCError);
    });
  });
});

describe('Tasks Router', () => {
  const caller = createCaller();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getAll', () => {
    it('should return paginated tasks', async () => {
      const mockTasks = [
        {
          id: 'task-1',
          title: 'Test Task',
          description: null,
          status: 'TODO',
          priority: 'MEDIUM',
          dueDate: null,
          assigneeId: null,
          projectId: null,
          tags: [],
          createdById: 'user-1',
          createdAt: new Date(),
          updatedAt: new Date(),
          assignee: null,
          project: null,
        },
      ];
      mockDb.query.tasks.findMany.mockResolvedValue(mockTasks);

      const result = await caller.tasks.getAll({ page: 1, limit: 10 });
      expect(result.tasks).toHaveLength(1);
      expect(result.page).toBe(1);
      expect(result.limit).toBe(10);
    });

    it('should filter by status', async () => {
      mockDb.query.tasks.findMany.mockResolvedValue([]);

      await caller.tasks.getAll({ status: 'TODO', page: 1, limit: 10 });
      expect(mockDb.query.tasks.findMany).toHaveBeenCalled();
    });
  });

  describe('getById', () => {
    it('should return task by id', async () => {
      const mockTask = {
        id: 'task-1',
        title: 'Test Task',
        description: null,
        status: 'TODO',
        priority: 'MEDIUM',
        dueDate: null,
        assigneeId: null,
        projectId: null,
        tags: [],
        createdById: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
        assignee: null,
        project: null,
      };
      mockDb.query.tasks.findFirst.mockResolvedValue(mockTask);

      const result = await caller.tasks.getById({ id: 'task-1' });
      expect(result.id).toBe('task-1');
    });

    it('should throw NOT_FOUND if task not found', async () => {
      mockDb.query.tasks.findFirst.mockResolvedValue(null);

      await expect(caller.tasks.getById({ id: 'non-existent' })).rejects.toThrow(TRPCError);
    });
  });
});

describe('Projects Router', () => {
  const caller = createCaller();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getAll', () => {
    it('should return paginated projects', async () => {
      const mockProjects = [
        {
          id: 'project-1',
          name: 'Test Project',
          description: null,
          status: 'DRAFT',
          priority: 'MEDIUM',
          startDate: null,
          deadline: null,
          clientId: null,
          budget: null,
          tags: [],
          progress: 0,
          createdById: 'user-1',
          createdAt: new Date(),
          updatedAt: new Date(),
          client: null,
        },
      ];
      mockDb.query.projects.findMany.mockResolvedValue(mockProjects);

      const result = await caller.projects.getAll({ page: 1, limit: 10 });
      expect(result.projects).toHaveLength(1);
    });
  });
});

describe('Clients Router', () => {
  const caller = createCaller();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('create', () => {
    it('should create a new client', async () => {
      const mockClient = {
        id: 'client-1',
        name: 'Test Client',
        email: 'client@example.com',
        phone: null,
        type: 'INDIVIDUAL',
        companyName: null,
        taxId: null,
        address: null,
        notes: null,
        totalOrders: 0,
        totalRevenue: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      mockDb.query.clients.findFirst.mockResolvedValue(null);
      mockDb.insert.mockReturnValue({
        values: vi.fn().mockReturnValue({
          returning: vi.fn().mockResolvedValue([mockClient]),
        }),
      });

      const result = await caller.clients.create({
        name: 'Test Client',
        email: 'client@example.com',
      });
      expect(result.name).toBe('Test Client');
    });

    it('should throw CONFLICT if email already exists', async () => {
      mockDb.query.clients.findFirst.mockResolvedValue({ id: 'existing' });

      await expect(caller.clients.create({
        name: 'Test Client',
        email: 'existing@example.com',
      })).rejects.toThrow(TRPCError);
    });
  });
});

describe('Filaments Router', () => {
  const caller = createCaller();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getLowStock', () => {
    it('should return filaments with low stock', async () => {
      const mockFilaments = [
        {
          id: 'filament-1',
          name: 'PLA Red',
          type: 'PLA',
          brand: 'Prusament',
          color: 'Red',
          colorHex: '#FF0000',
          diameter: 1.75,
          weightTotal: 1000,
          stockWeight: 100,
          pricePerKg: 25,
          nozzleTemp: { min: 200, max: 220 },
          bedTemp: { min: 60, max: 70 },
          location: null,
          notes: null,
          lowStockThreshold: 200,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
      mockDb.query.filaments.findMany.mockResolvedValue(mockFilaments);

      const result = await caller.filaments.getLowStock({ page: 1, limit: 10 });
      expect(result.filaments).toHaveLength(1);
      expect(result.filaments[0].isLowStock).toBe(true);
    });
  });
});

describe('Quotes Router', () => {
  const caller = createCaller();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('create', () => {
    it('should create a new quote with items', async () => {
      const mockQuote = {
        id: 'quote-1',
        quoteNumber: 'Q-20240101-0001',
        title: 'Test Quote',
        description: null,
        status: 'DRAFT',
        clientId: 'client-1',
        projectId: null,
        subtotal: 100,
        discount: 0,
        taxRate: 23,
        taxAmount: 23,
        totalAmount: 123,
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        notes: null,
        terms: null,
        sentAt: null,
        acceptedAt: null,
        createdById: 'user-1',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      mockDb.query.clients.findFirst.mockResolvedValue({ id: 'client-1' });
      mockDb.insert.mockReturnValue({
        values: vi.fn().mockReturnValue({
          returning: vi.fn().mockResolvedValue([mockQuote]),
        }),
      });
      mockDb.query.quotes.findFirst.mockResolvedValue({
        ...mockQuote,
        client: { id: 'client-1', name: 'Test Client', email: 'test@example.com', companyName: null },
        project: null,
        items: [],
      });

      const result = await caller.quotes.create({
        clientId: 'client-1',
        title: 'Test Quote',
        items: [
          { name: 'Item 1', quantity: 1, unitPrice: 100 },
        ],
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      });
      expect(result.title).toBe('Test Quote');
      expect(result.totalAmount).toBe(123);
    });
  });
});
