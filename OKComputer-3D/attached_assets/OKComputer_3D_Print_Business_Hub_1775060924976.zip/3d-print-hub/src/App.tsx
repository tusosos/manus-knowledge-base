import { Route, Switch } from 'wouter';
import { useState, useCallback } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';

// Page imports
import DashboardPage from './pages/DashboardPage';
import TasksPage from './pages/TasksPage';
import ProjectsPage from './pages/ProjectsPage';
import CalculatorPage from './pages/CalculatorPage';
import InventoryPage from './pages/InventoryPage';
import ClientsPage from './pages/ClientsPage';
import PrintQueuePage from './pages/PrintQueuePage';
import QuotesPage from './pages/QuotesPage';
import AnalyticsPage from './pages/AnalyticsPage';
import BestsellersPage from './pages/BestsellersPage';
import CompetitionPage from './pages/CompetitionPage';
import BusinessPlanPage from './pages/BusinessPlanPage';
import MulticolorPage from './pages/MulticolorPage';
import PrinterPage from './pages/PrinterPage';
import KnowledgePage from './pages/KnowledgePage';
import FilamentDealsPage from './pages/FilamentDealsPage';
import ListingGeneratorPage from './pages/ListingGeneratorPage';
import ShippingPage from './pages/ShippingPage';

// Layout wrapper component
interface LayoutProps {
  children: React.ReactNode;
  sidebarCollapsed: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, sidebarCollapsed }) => {
  return (
    <div className="min-h-screen bg-[#0a0a0a] industrial-grid">
      <Header sidebarCollapsed={sidebarCollapsed} />
      <main 
        className={`
          pt-16 min-h-screen transition-all duration-300
          ${sidebarCollapsed ? 'pl-16' : 'pl-64'}
        `}
      >
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
};

// Page wrapper with layout
const PageWrapper: React.FC<{ 
  children: React.ReactNode; 
  sidebarCollapsed: boolean;
}> = ({ children, sidebarCollapsed }) => (
  <Layout sidebarCollapsed={sidebarCollapsed}>
    {children}
  </Layout>
);

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleSidebar = useCallback(() => {
    setSidebarCollapsed(prev => !prev);
  }, []);

  return (
    <div className="font-sans antialiased">
      <Sidebar collapsed={sidebarCollapsed} onToggle={toggleSidebar} />
      
      <Switch>
        <Route path="/">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <DashboardPage />
          </PageWrapper>
        </Route>
        
        <Route path="/tasks">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <TasksPage />
          </PageWrapper>
        </Route>
        
        <Route path="/projects">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <ProjectsPage />
          </PageWrapper>
        </Route>
        
        <Route path="/calculator">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <CalculatorPage />
          </PageWrapper>
        </Route>
        
        <Route path="/inventory">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <InventoryPage />
          </PageWrapper>
        </Route>
        
        <Route path="/clients">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <ClientsPage />
          </PageWrapper>
        </Route>
        
        <Route path="/print-queue">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <PrintQueuePage />
          </PageWrapper>
        </Route>
        
        <Route path="/quotes">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <QuotesPage />
          </PageWrapper>
        </Route>
        
        <Route path="/analytics">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <AnalyticsPage />
          </PageWrapper>
        </Route>
        
        <Route path="/bestsellers">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <BestsellersPage />
          </PageWrapper>
        </Route>
        
        <Route path="/competition">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <CompetitionPage />
          </PageWrapper>
        </Route>
        
        <Route path="/business-plan">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <BusinessPlanPage />
          </PageWrapper>
        </Route>
        
        <Route path="/multicolor">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <MulticolorPage />
          </PageWrapper>
        </Route>
        
        <Route path="/printer">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <PrinterPage />
          </PageWrapper>
        </Route>
        
        <Route path="/knowledge">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <KnowledgePage />
          </PageWrapper>
        </Route>
        
        <Route path="/filament-deals">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <FilamentDealsPage />
          </PageWrapper>
        </Route>
        
        <Route path="/listing-generator">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <ListingGeneratorPage />
          </PageWrapper>
        </Route>
        
        <Route path="/shipping">
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <ShippingPage />
          </PageWrapper>
        </Route>
        
        {/* 404 Route */}
        <Route>
          <PageWrapper sidebarCollapsed={sidebarCollapsed}>
            <div className="flex flex-col items-center justify-center min-h-[60vh]">
              <div className="w-24 h-24 bg-amber-500/10 rounded-full flex items-center justify-center mb-6">
                <span className="text-4xl font-bold text-amber-400">404</span>
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Strona nie znaleziona</h1>
              <p className="text-slate-400 mb-6">Przepraszamy, ale strona której szukasz nie istnieje.</p>
              <a 
                href="/" 
                className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-black font-semibold rounded-lg transition-colors"
              >
                Wróć do Dashboard
              </a>
            </div>
          </PageWrapper>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
