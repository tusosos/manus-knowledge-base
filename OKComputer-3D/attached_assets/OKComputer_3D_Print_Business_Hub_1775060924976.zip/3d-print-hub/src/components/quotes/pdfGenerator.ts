// ============================================
// 3D Print Business Hub - PDF Generator
// ============================================

import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Quote, PDFConfig, DEFAULT_PDF_CONFIG } from './types';

// Rozszerzenie jsPDF o autotable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
    lastAutoTable: {
      finalY: number;
    };
  }
}

// ============================================
// Funkcje pomocnicze
// ============================================

/**
 * Formatuje cenę do wyświetlenia
 */
function formatPrice(price: number): string {
  return price.toLocaleString('pl-PL', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Formatuje datę
 */
function formatDate(date: Date): string {
  return date.toLocaleDateString('pl-PL', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// ============================================
// Główna funkcja generująca PDF
// ============================================

export interface GenerateQuotePDFOptions {
  quote: Quote;
  config?: Partial<PDFConfig>;
  includeTerms?: boolean;
}

export function generateQuotePDF(options: GenerateQuotePDFOptions): jsPDF {
  const { quote, config = {}, includeTerms = true } = options;
  const pdfConfig = { ...DEFAULT_PDF_CONFIG, ...config };

  // Inicjalizacja PDF (A4)
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Kolory
  const primaryColor = [59, 130, 246]; // Blue-500
  const secondaryColor = [75, 85, 99]; // Gray-600
  const darkColor = [17, 24, 39]; // Gray-900
  const lightGray = [243, 244, 246]; // Gray-100

  // Marginesy
  const margin = 20;
  let currentY = margin;

  // ============================================
  // Nagłówek - Logo i dane firmy
  // ============================================

  // Tło nagłówka
  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 0, 210, 45, 'F');

  // Nazwa firmy
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text(pdfConfig.companyName, margin, 20);

  // Podtytuł
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Profesjonalne usługi druku 3D', margin, 28);

  // Dane firmy (prawa strona)
  doc.setFontSize(8);
  const companyInfo = [
    pdfConfig.companyAddress,
    `Tel: ${pdfConfig.companyPhone}`,
    `Email: ${pdfConfig.companyEmail}`,
    `NIP: ${pdfConfig.companyNip}`,
  ];
  companyInfo.forEach((line, index) => {
    doc.text(line, 210 - margin, 15 + index * 5, { align: 'right' });
  });

  currentY = 55;

  // ============================================
  // Tytuł dokumentu
  // ============================================

  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('WYCENA', margin, currentY);

  // Numer wyceny
  doc.setFontSize(10);
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text(`Numer: ${quote.quoteNumber}`, margin, currentY + 6);

  // Data
  doc.text(
    `Data wystawienia: ${formatDate(quote.createdAt)}`,
    210 - margin,
    currentY,
    { align: 'right' }
  );
  doc.text(
    `Ważna do: ${formatDate(quote.validUntil)}`,
    210 - margin,
    currentY + 6,
    { align: 'right' }
  );

  currentY += 20;

  // ============================================
  // Dane klienta
  // ============================================

  // Tło sekcji
  doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
  doc.rect(margin, currentY - 5, 85, 35, 'F');

  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('DANE KLIENTA', margin + 3, currentY);

  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');

  const clientLines = [
    quote.client.company || quote.client.name,
    quote.client.company ? quote.client.name : '',
    quote.client.address,
    `${quote.client.postalCode} ${quote.client.city}`,
    quote.client.nip ? `NIP: ${quote.client.nip}` : '',
  ].filter(Boolean);

  clientLines.forEach((line, index) => {
    doc.text(line, margin + 3, currentY + 6 + index * 5);
  });

  // ============================================
  // Dane projektu
  // ============================================

  const projectX = 115;
  doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
  doc.rect(projectX, currentY - 5, 75, 35, 'F');

  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('PROJEKT', projectX + 3, currentY);

  doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');

  doc.text(`Nazwa: ${quote.item.projectName}`, projectX + 3, currentY + 6);
  doc.text(`Materiał: ${quote.item.material}`, projectX + 3, currentY + 11);
  doc.text(
    `Wymiary: ${quote.item.dimensions.length}×${quote.item.dimensions.width}×${quote.item.dimensions.height} mm`,
    projectX + 3,
    currentY + 16
  );
  doc.text(`Ilość: ${quote.item.quantity} szt.`, projectX + 3, currentY + 21);
  doc.text(`Czas druku: ${quote.item.printTime} h`, projectX + 3, currentY + 26);

  currentY += 45;

  // ============================================
  // Tabela pozycji
  // ============================================

  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('SZCZEGÓŁY WYCENY', margin, currentY);

  currentY += 5;

  // Przygotowanie danych tabeli
  const tableBody: any[] = [
    [
      '1',
      `Materiał: ${quote.item.material}\nWaga: ${quote.item.filamentWeight}g`,
      `${quote.item.quantity} szt.`,
      `${formatPrice(quote.costs.materialCost / quote.item.quantity)} PLN`,
      `${formatPrice(quote.costs.materialCost)} PLN`,
    ],
    [
      '2',
      'Koszt energii',
      `${quote.item.printTime} h`,
      `${formatPrice(quote.costs.energyCost / quote.item.printTime)} PLN/h`,
      `${formatPrice(quote.costs.energyCost)} PLN`,
    ],
    [
      '3',
      'Amortyzacja sprzętu',
      `${quote.item.printTime} h`,
      `${formatPrice(quote.costs.depreciationCost / quote.item.printTime)} PLN/h`,
      `${formatPrice(quote.costs.depreciationCost)} PLN`,
    ],
    [
      '4',
      'Koszt pracy',
      `${quote.item.printTime + 0.5} h`,
      `${formatPrice(quote.costs.laborCost / (quote.item.printTime + 0.5))} PLN/h`,
      `${formatPrice(quote.costs.laborCost)} PLN`,
    ],
  ];

  // Dodaj dodatkowe usługi
  let rowIndex = 5;
  quote.item.additionalServices
    .filter((s) => s.quantity > 0)
    .forEach((service) => {
      tableBody.push([
        String(rowIndex++),
        service.name,
        `${service.quantity} ${service.unit}`,
        `${formatPrice(service.pricePerUnit)} PLN`,
        `${formatPrice(service.pricePerUnit * service.quantity)} PLN`,
      ]);
    });

  // Generowanie tabeli
  doc.autoTable({
    startY: currentY,
    head: [['Lp.', 'Pozycja', 'Ilość', 'Cena jedn.', 'Wartość']],
    body: tableBody,
    theme: 'grid',
    headStyles: {
      fillColor: primaryColor,
      textColor: 255,
      fontStyle: 'bold',
      fontSize: 9,
    },
    bodyStyles: {
      fontSize: 8,
      textColor: darkColor,
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 70 },
      2: { cellWidth: 25, halign: 'center' },
      3: { cellWidth: 35, halign: 'right' },
      4: { cellWidth: 35, halign: 'right' },
    },
    margin: { left: margin, right: margin },
    styles: {
      cellPadding: 3,
      lineColor: [200, 200, 200],
      lineWidth: 0.5,
    },
  });

  currentY = doc.lastAutoTable.finalY + 10;

  // ============================================
  // Podsumowanie kosztów
  // ============================================

  const summaryX = 120;
  const summaryWidth = 70;

  // Tło podsumowania
  doc.setFillColor(lightGray[0], lightGray[1], lightGray[2]);
  doc.rect(summaryX, currentY - 5, summaryWidth, 55, 'F');

  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('PODSUMOWANIE', summaryX + 3, currentY);

  const summaryItems = [
    { label: 'Suma kosztów:', value: quote.costs.subtotal },
    { label: `Marża (${quote.costs.marginPercent}%):`, value: quote.costs.margin },
    { label: 'Usługi dodatkowe:', value: quote.costs.additionalServicesCost },
    { label: 'RAZEM NETTO:', value: quote.costs.totalNet, bold: true },
    { label: `VAT (${quote.costs.vatRate}%):`, value: quote.costs.vatAmount },
    { label: 'RAZEM BRUTTO:', value: quote.costs.totalGross, bold: true, total: true },
  ];

  let summaryY = currentY + 7;
  summaryItems.forEach((item) => {
    if (item.bold) {
      doc.setFont('helvetica', 'bold');
    } else {
      doc.setFont('helvetica', 'normal');
    }

    if (item.total) {
      doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.setFontSize(11);
    } else {
      doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
      doc.setFontSize(9);
    }

    doc.text(item.label, summaryX + 3, summaryY);
    doc.text(
      `${formatPrice(item.value)} PLN`,
      summaryX + summaryWidth - 3,
      summaryY,
      { align: 'right' }
    );

    summaryY += item.total ? 8 : 6;
  });

  // Cena za sztukę
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `Cena za sztukę: ${formatPrice(quote.costs.unitPrice)} PLN brutto`,
    summaryX + 3,
    summaryY + 2
  );

  currentY += 65;

  // ============================================
  // Warunki (jeśli włączone)
  // ============================================

  if (includeTerms && currentY < 250) {
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('WARUNKI', margin, currentY);

    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');

    const terms = [
      `Termin płatności: ${pdfConfig.paymentTerms}`,
      `Termin realizacji: ${pdfConfig.deliveryTerms}`,
      `Gwarancja: ${pdfConfig.warrantyInfo}`,
    ];

    if (quote.notes) {
      terms.push('', `Uwagi: ${quote.notes}`);
    }

    let termsY = currentY + 5;
    terms.forEach((term) => {
      doc.text(term, margin, termsY);
      termsY += 4;
    });

    // Numer konta
    doc.setFont('helvetica', 'italic');
    doc.text(`Numer konta: ${pdfConfig.bankAccount}`, margin, termsY + 3);
  }

  // ============================================
  // Stopka z podpisami
  // ============================================

  const footerY = 270;

  // Linie podpisów
  doc.setDrawColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.setLineWidth(0.3);

  // Podpis wystawcy
  doc.line(margin, footerY, margin + 60, footerY);
  doc.setFontSize(8);
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text('Podpis wystawcy', margin, footerY + 4);

  // Podpis klienta
  doc.line(130, footerY, 190, footerY);
  doc.text('Podpis klienta', 130, footerY + 4);

  // ============================================
  // Stopka strony
  // ============================================

  doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.rect(0, 287, 210, 10, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7);
  doc.text(
    `${pdfConfig.companyName} | ${pdfConfig.companyAddress} | ${pdfConfig.companyEmail}`,
    105,
    293,
    { align: 'center' }
  );

  return doc;
}

// ============================================
// Funkcje eksportu
// ============================================

/**
 * Pobiera PDF jako plik
 */
export function downloadQuotePDF(
  quote: Quote,
  filename?: string,
  config?: Partial<PDFConfig>
): void {
  const doc = generateQuotePDF({ quote, config });
  const defaultFilename = `Wycena_${quote.quoteNumber}_${quote.client.name.replace(/\s+/g, '_')}.pdf`;
  doc.save(filename || defaultFilename);
}

/**
 * Zwraca PDF jako Blob
 */
export function getQuotePDFBlob(
  quote: Quote,
  config?: Partial<PDFConfig>
): Blob {
  const doc = generateQuotePDF({ quote, config });
  return doc.output('blob');
}

/**
 * Zwraca PDF jako base64 string
 */
export function getQuotePDFBase64(
  quote: Quote,
  config?: Partial<PDFConfig>
): string {
  const doc = generateQuotePDF({ quote, config });
  return doc.output('datauristring');
}

/**
 * Otwiera PDF w nowym oknie
 */
export function previewQuotePDF(
  quote: Quote,
  config?: Partial<PDFConfig>
): void {
  const doc = generateQuotePDF({ quote, config });
  const pdfData = doc.output('datauristring');
  const newWindow = window.open();
  if (newWindow) {
    newWindow.document.write(
      `<iframe width="100%" height="100%" src="${pdfData}"></iframe>`
    );
  }
}

export default {
  generateQuotePDF,
  downloadQuotePDF,
  getQuotePDFBlob,
  getQuotePDFBase64,
  previewQuotePDF,
};
