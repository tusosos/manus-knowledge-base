// ============================================
// 3D Print Business Hub - Quote Preview Component
// ============================================

import React from 'react';
import {
  User,
  Building2,
  Mail,
  Phone,
  MapPin,
  Package,
  Ruler,
  Clock,
  Weight,
  Layers,
  TrendingUp,
  Percent,
  Calculator,
  FileText,
  Check,
  X,
  Edit,
  Download,
  Send,
  Printer,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Quote,
  CostBreakdown,
  STATUS_LABELS,
  QuoteStatus,
} from './types';

// ============================================
// Props
// ============================================

export interface QuotePreviewProps {
  quote?: Quote;
  previewData?: {
    client?: Quote['client'];
    item?: Quote['item'];
    costs?: CostBreakdown;
    notes?: string;
  };
  onEdit?: () => void;
  onSave?: () => void;
  onDownloadPDF?: () => void;
  onSendEmail?: () => void;
  onStatusChange?: (status: QuoteStatus) => void;
  onPrint?: () => void;
  isDraft?: boolean;
}

// ============================================
// Komponenty pomocnicze
// ============================================

function CostRow({
  label,
  value,
  isSubtotal = false,
  isTotal = false,
  isNegative = false,
}: {
  label: string;
  value: number;
  isSubtotal?: boolean;
  isTotal?: boolean;
  isNegative?: boolean;
}) {
  return (
    <div
      className={`flex justify-between items-center py-2 ${
        isTotal ? 'border-t-2 border-blue-500 pt-3' : ''
      } ${isSubtotal ? 'border-t border-gray-700 pt-2' : ''}`}
    >
      <span
        className={`${
          isTotal ? 'text-lg font-bold text-white' : isSubtotal ? 'font-semibold text-gray-200' : 'text-gray-400'
        }`}
      >
        {label}
      </span>
      <span
        className={`${
          isTotal
            ? 'text-xl font-bold text-blue-400'
            : isSubtotal
            ? 'font-semibold text-white'
            : isNegative
            ? 'text-red-400'
            : 'text-gray-300'
        }`}
      >
        {value.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} PLN
      </span>
    </div>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3 py-1">
      <Icon className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
      <div>
        <span className="text-xs text-gray-500">{label}</span>
        <div className="text-sm text-gray-200">{value}</div>
      </div>
    </div>
  );
}

// ============================================
// Główny komponent
// ============================================

export function QuotePreview({
  quote,
  previewData,
  onEdit,
  onSave,
  onDownloadPDF,
  onSendEmail,
  onStatusChange,
  onPrint,
  isDraft = false,
}: QuotePreviewProps) {
  // Użyj danych z quote lub previewData
  const data = quote || previewData;
  const client = data?.client;
  const item = data?.item;
  const costs = data?.costs;

  if (!client || !item || !costs) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-gray-500">
        <Calculator className="w-16 h-16 mb-4 opacity-50" />
        <p className="text-lg">Wypełnij formularz, aby zobaczyć podgląd wyceny</p>
      </div>
    );
  }

  const statusInfo = quote ? STATUS_LABELS[quote.status] : null;

  return (
    <div className="space-y-6">
      {/* Nagłówek z akcjami */}
      <div className="flex items-start justify-between">
        <div>
          {quote && (
            <div className="flex items-center gap-3 mb-2">
              <h2 className="text-2xl font-bold text-white">{quote.quoteNumber}</h2>
              {statusInfo && (
                <Badge className={`${statusInfo.color} text-white`}>
                  {statusInfo.label}
                </Badge>
              )}
            </div>
          )}
          <p className="text-gray-400">
            {quote ? (
              <>Utworzono: {quote.createdAt.toLocaleDateString('pl-PL')}</>
            ) : (
              'Podgląd wyceny'
            )}
          </p>
          {quote && (
            <p className="text-sm text-gray-500">
              Ważna do: {quote.validUntil.toLocaleDateString('pl-PL')}
            </p>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {onEdit && (
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="w-4 h-4 mr-2" />
              Edytuj
            </Button>
          )}
          {onSave && (
            <Button size="sm" onClick={onSave}>
              <Check className="w-4 h-4 mr-2" />
              Zapisz
            </Button>
          )}
          {onDownloadPDF && (
            <Button variant="outline" size="sm" onClick={onDownloadPDF}>
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
          )}
          {onPrint && (
            <Button variant="outline" size="sm" onClick={onPrint}>
              <Printer className="w-4 h-4 mr-2" />
              Drukuj
            </Button>
          )}
          {onSendEmail && (
            <Button variant="outline" size="sm" onClick={onSendEmail}>
              <Send className="w-4 h-4 mr-2" />
              Wyślij
            </Button>
          )}
        </div>
      </div>

      {/* Zmiana statusu */}
      {onStatusChange && quote && (
        <div className="flex flex-wrap gap-2">
          {quote.status === 'draft' && (
            <Button
              size="sm"
              onClick={() => onStatusChange('sent')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Send className="w-4 h-4 mr-2" />
              Oznacz jako wysłana
            </Button>
          )}
          {quote.status === 'sent' && (
            <>
              <Button
                size="sm"
                onClick={() => onStatusChange('accepted')}
                className="bg-green-600 hover:bg-green-700"
              >
                <Check className="w-4 h-4 mr-2" />
                Zaakceptowana
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => onStatusChange('rejected')}
              >
                <X className="w-4 h-4 mr-2" />
                Odrzucona
              </Button>
            </>
          )}
        </div>
      )}

      <Separator className="bg-gray-700" />

      {/* Dane klienta i projektu */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dane klienta */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="w-5 h-5 text-blue-400" />
              Dane klienta
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow
              icon={User}
              label="Nazwa"
              value={client.company ? `${client.name} (${client.company})` : client.name}
            />
            <InfoRow icon={Mail} label="Email" value={client.email} />
            <InfoRow icon={Phone} label="Telefon" value={client.phone} />
            <InfoRow
              icon={MapPin}
              label="Adres"
              value={`${client.address}, ${client.postalCode} ${client.city}`}
            />
            {client.nip && (
              <InfoRow icon={Building2} label="NIP" value={client.nip} />
            )}
          </CardContent>
        </Card>

        {/* Dane projektu */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-400" />
              Dane projektu
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <InfoRow icon={Package} label="Nazwa projektu" value={item.projectName} />
            <InfoRow icon={Layers} label="Materiał" value={item.material} />
            <InfoRow
              icon={Ruler}
              label="Wymiary"
              value={`${item.dimensions.length} × ${item.dimensions.width} × ${item.dimensions.height} mm`}
            />
            <InfoRow icon={Package} label="Ilość" value={`${item.quantity} szt.`} />
            <InfoRow icon={Clock} label="Czas druku" value={`${item.printTime} h`} />
            <InfoRow icon={Weight} label="Waga filamentu" value={`${item.filamentWeight} g`} />
          </CardContent>
        </Card>
      </div>

      {/* Podsumowanie kosztów */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Calculator className="w-5 h-5 text-blue-400" />
            Podsumowanie kosztów
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {/* Koszty bezpośrednie */}
            <CostRow label="Koszt materiału" value={costs.materialCost} />
            <CostRow label="Koszt energii" value={costs.energyCost} />
            <CostRow label="Amortyzacja sprzętu" value={costs.depreciationCost} />
            <CostRow label="Koszt pracy" value={costs.laborCost} />

            {/* Dodatkowe usługi */}
            {costs.additionalServicesCost > 0 && (
              <CostRow
                label="Dodatkowe usługi"
                value={costs.additionalServicesCost}
              />
            )}

            <CostRow label="Suma kosztów" value={costs.subtotal} isSubtotal />

            {/* Marża */}
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-400 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Marża ({costs.marginPercent}%)
              </span>
              <span className="text-green-400">
                +{costs.margin.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} PLN
              </span>
            </div>

            <CostRow label="RAZEM NETTO" value={costs.totalNet} isSubtotal />

            {/* VAT */}
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-400 flex items-center gap-2">
                <Percent className="w-4 h-4" />
                VAT ({costs.vatRate}%)
              </span>
              <span className="text-gray-300">
                {costs.vatAmount.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} PLN
              </span>
            </div>

            {/* Suma brutto */}
            <CostRow label="RAZEM BRUTTO" value={costs.totalGross} isTotal />
          </div>

          {/* Cena za sztukę */}
          <div className="mt-4 pt-4 border-t border-gray-700">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Cena za sztukę (brutto):</span>
              <span className="text-xl font-bold text-blue-400">
                {costs.unitPrice.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} PLN
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dodatkowe usługi - szczegóły */}
      {item.additionalServices.filter((s) => s.quantity > 0).length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-400" />
              Wybrane usługi dodatkowe
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {item.additionalServices
                .filter((s) => s.quantity > 0)
                .map((service) => (
                  <div
                    key={service.id}
                    className="flex justify-between items-center py-2 border-b border-gray-700 last:border-0"
                  >
                    <div>
                      <span className="text-gray-200">{service.name}</span>
                      <span className="text-gray-500 text-sm ml-2">
                        ({service.quantity} {service.unit})
                      </span>
                    </div>
                    <span className="text-gray-300">
                      {(service.pricePerUnit * service.quantity).toLocaleString('pl-PL', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}{' '}
                      PLN
                    </span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Uwagi */}
      {data.notes && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              Uwagi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 whitespace-pre-wrap">{data.notes}</p>
          </CardContent>
        </Card>
      )}

      {/* Warunki */}
      {quote && (
        <Card className="bg-gray-800/30 border-gray-700/50">
          <CardContent className="pt-6">
            <div className="text-sm text-gray-500 space-y-1">
              <p>Termin płatności: 14 dni od daty wystawienia faktury</p>
              <p>Termin realizacji: 7-14 dni roboczych od akceptacji wyceny</p>
              <p>Gwarancja: 12 miesięcy na wydruki</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default QuotePreview;
