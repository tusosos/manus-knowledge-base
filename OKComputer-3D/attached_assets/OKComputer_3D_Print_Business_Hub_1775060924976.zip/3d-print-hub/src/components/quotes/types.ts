// ============================================
// 3D Print Business Hub - Quote Generator Types
// ============================================

// Materiały druku 3D
export type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'PA' | 'PC';

// Status wyceny
export type QuoteStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';

// Dodatkowe usługi
export interface AdditionalService {
  id: string;
  name: string;
  description: string;
  pricePerUnit: number;
  unit: string;
  quantity: number;
}

// Dane klienta
export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  address: string;
  city: string;
  postalCode: string;
  nip?: string;
  createdAt: Date;
}

// Parametry materiału
export interface MaterialParams {
  type: MaterialType;
  pricePerKg: number;
  density: number;
  printSpeed: number;
  bedTemp: number;
  nozzleTemp: number;
}

// Dane projektu/wyceny
export interface QuoteItem {
  id: string;
  projectName: string;
  dimensions: {
    length: number; // mm
    width: number;  // mm
    height: number; // mm
  };
  material: MaterialType;
  quantity: number;
  printTime: number;      // godziny
  filamentWeight: number; // gramy
  infill: number;         // procent wypełnienia (domyślnie 20%)
  layerHeight: number;    // mm (domyślnie 0.2)
  additionalServices: AdditionalService[];
}

// Koszty kalkulacji
export interface CostBreakdown {
  materialCost: number;
  energyCost: number;
  depreciationCost: number;
  laborCost: number;
  additionalServicesCost: number;
  subtotal: number;
  margin: number;
  marginPercent: number;
  totalNet: number;
  vatRate: number;
  vatAmount: number;
  totalGross: number;
  unitPrice: number;
}

// Pełna wycena
export interface Quote {
  id: string;
  quoteNumber: string;
  client: Client;
  item: QuoteItem;
  costs: CostBreakdown;
  status: QuoteStatus;
  validUntil: Date;
  notes?: string;
  terms?: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  sentAt?: Date;
  acceptedAt?: Date;
  rejectedAt?: Date;
}

// Ustawienia kalkulacji
export interface CalculationSettings {
  energyPricePerKwh: number;
  printerPowerConsumption: number; // kW
  printerHourlyRate: number;
  operatorHourlyRate: number;
  filamentPrices: Record<MaterialType, number>;
  defaultMargin: number;
  vatRate: number;
  printerCost: number;
  printerLifespanHours: number;
  maintenanceCostPerHour: number;
}

// Stan formularza
export interface QuoteFormState {
  clientId: string;
  newClient: Partial<Client>;
  isNewClient: boolean;
  item: Partial<QuoteItem>;
}

// Filtry historii
export interface QuoteFilters {
  status?: QuoteStatus;
  clientId?: string;
  dateFrom?: Date;
  dateTo?: Date;
  searchQuery?: string;
}

// Konfiguracja PDF
export interface PDFConfig {
  companyName: string;
  companyLogo?: string;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  companyNip: string;
  bankAccount: string;
  paymentTerms: string;
  deliveryTerms: string;
  warrantyInfo: string;
}

// Domyślne ustawienia kalkulacji
export const DEFAULT_CALCULATION_SETTINGS: CalculationSettings = {
  energyPricePerKwh: 0.8,
  printerPowerConsumption: 0.3,
  printerHourlyRate: 15,
  operatorHourlyRate: 50,
  filamentPrices: {
    PLA: 75,
    PETG: 85,
    ABS: 90,
    TPU: 120,
    PA: 150,
    PC: 180,
  },
  defaultMargin: 100,
  vatRate: 23,
  printerCost: 5000,
  printerLifespanHours: 5000,
  maintenanceCostPerHour: 2,
};

// Domyślne dodatkowe usługi
export const DEFAULT_ADDITIONAL_SERVICES: AdditionalService[] = [
  {
    id: 'support-removal',
    name: 'Usuwanie podpór',
    description: 'Profesjonalne usuwanie struktur podporowych',
    pricePerUnit: 15,
    unit: 'szt',
    quantity: 0,
  },
  {
    id: 'sanding',
    name: 'Szlifowanie powierzchni',
    description: 'Wygładzanie powierzchni druku',
    pricePerUnit: 25,
    unit: 'szt',
    quantity: 0,
  },
  {
    id: 'priming',
    name: 'Podkład gruntingowy',
    description: 'Nanieśienie podkładu przed malowaniem',
    pricePerUnit: 20,
    unit: 'szt',
    quantity: 0,
  },
  {
    id: 'painting',
    name: 'Malowanie',
    description: 'Profesjonalne malowanie modelu',
    pricePerUnit: 50,
    unit: 'szt',
    quantity: 0,
  },
  {
    id: 'assembly',
    name: 'Montaż',
    description: 'Składanie wieloczęściowych modeli',
    pricePerUnit: 40,
    unit: 'godz',
    quantity: 0,
  },
  {
    id: 'packaging',
    name: 'Opakowanie ochronne',
    description: 'Profesjonalne zapakowanie do wysyłki',
    pricePerUnit: 10,
    unit: 'szt',
    quantity: 0,
  },
];

// Domyślna konfiguracja PDF
export const DEFAULT_PDF_CONFIG: PDFConfig = {
  companyName: '3D Print Business Hub',
  companyAddress: 'ul. Drukarska 123, 00-001 Warszawa',
  companyPhone: '+48 123 456 789',
  companyEmail: 'kontakt@3dprinthub.pl',
  companyNip: 'PL1234567890',
  bankAccount: 'PL 12 1234 5678 9012 3456 7890 1234',
  paymentTerms: '14 dni od daty wystawienia faktury',
  deliveryTerms: '7-14 dni roboczych od akceptacji wyceny',
  warrantyInfo: '12 miesięcy gwarancji na wydruki',
};

// Opcje materiałów dla Select
export const MATERIAL_OPTIONS: { value: MaterialType; label: string; description: string }[] = [
  { value: 'PLA', label: 'PLA', description: 'Polilaktyd - biodegradowalny, łatwy w druku' },
  { value: 'PETG', label: 'PETG', description: 'Trwały, odporny na wilgoć i chemikalia' },
  { value: 'ABS', label: 'ABS', description: 'Wytrzymały, temperaturowy, wymaga zamkniętej komory' },
  { value: 'TPU', label: 'TPU', description: 'Elastyczny, gumopodobny materiał' },
  { value: 'PA', label: 'PA (Nylon)', description: 'Bardzo wytrzymały, odporny na ścieranie' },
  { value: 'PC', label: 'PC (Poliwęglan)', description: 'Najwyższa wytrzymałość termiczna i mechaniczna' },
];

// Etykiety statusów
export const STATUS_LABELS: Record<QuoteStatus, { label: string; color: string }> = {
  draft: { label: 'Wersja robocza', color: 'bg-gray-500' },
  sent: { label: 'Wysłana', color: 'bg-blue-500' },
  accepted: { label: 'Zaakceptowana', color: 'bg-green-500' },
  rejected: { label: 'Odrzucona', color: 'bg-red-500' },
  expired: { label: 'Wygasła', color: 'bg-yellow-500' },
};
