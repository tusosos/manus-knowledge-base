// ============================================
// 3D Print Business Hub - Quote Settings Component
// ============================================

import React, { useState, useEffect } from 'react';
import {
  Settings,
  Zap,
  DollarSign,
  Clock,
  Package,
  TrendingUp,
  Percent,
  Save,
  RotateCcw,
  Calculator,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/use-toast';
import {
  CalculationSettings,
  MaterialType,
  MATERIAL_OPTIONS,
  DEFAULT_CALCULATION_SETTINGS,
} from './types';

// ============================================
// Props
// ============================================

export interface QuoteSettingsProps {
  settings: CalculationSettings;
  onSave: (settings: CalculationSettings) => void;
}

// ============================================
// Komponent
// ============================================

export function QuoteSettings({ settings, onSave }: QuoteSettingsProps) {
  const [localSettings, setLocalSettings] = useState<CalculationSettings>(settings);
  const [hasChanges, setHasChanges] = useState(false);

  // Sprawdź zmiany
  useEffect(() => {
    const changed = JSON.stringify(localSettings) !== JSON.stringify(settings);
    setHasChanges(changed);
  }, [localSettings, settings]);

  // Aktualizacja wartości
  const updateSetting = <K extends keyof CalculationSettings>(
    key: K,
    value: CalculationSettings[K]
  ) => {
    setLocalSettings((prev) => ({ ...prev, [key]: value }));
  };

  // Aktualizacja ceny filamentu
  const updateFilamentPrice = (material: MaterialType, price: number) => {
    setLocalSettings((prev) => ({
      ...prev,
      filamentPrices: {
        ...prev.filamentPrices,
        [material]: price,
      },
    }));
  };

  // Zapisz ustawienia
  const handleSave = () => {
    onSave(localSettings);
    toast({
      title: 'Ustawienia zapisane',
      description: 'Zmiany zostały zapisane pomyślnie.',
    });
  };

  // Resetuj do domyślnych
  const handleReset = () => {
    setLocalSettings(DEFAULT_CALCULATION_SETTINGS);
    toast({
      title: 'Ustawienia resetowane',
      description: 'Przywrócono domyślne wartości.',
    });
  };

  return (
    <div className="space-y-6">
      {/* Nagłówek */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Settings className="w-6 h-6 text-blue-400" />
            Ustawienia kalkulacji
          </h2>
          <p className="text-gray-400 mt-1">
            Skonfiguruj parametry używane do obliczania wycen
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Resetuj
          </Button>
          <Button onClick={handleSave} disabled={!hasChanges}>
            <Save className="w-4 h-4 mr-2" />
            Zapisz zmiany
          </Button>
        </div>
      </div>

      {hasChanges && (
        <Badge variant="outline" className="bg-yellow-900/30 border-yellow-600 text-yellow-400">
          Masz niezapisane zmiany
        </Badge>
      )}

      {/* Ceny materiałów */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-400" />
            Ceny filamentów
          </CardTitle>
          <CardDescription className="text-gray-400">
            Ustaw ceny za kilogram dla poszczególnych materiałów
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {MATERIAL_OPTIONS.map((material) => (
              <div key={material.value} className="space-y-2">
                <Label className="flex items-center gap-2">
                  {material.label}
                  <span className="text-xs text-gray-500">({material.description})</span>
                </Label>
                <div className="relative">
                  <Input
                    type="number"
                    min={0}
                    step={1}
                    value={localSettings.filamentPrices[material.value]}
                    onChange={(e) =>
                      updateFilamentPrice(material.value, Number(e.target.value))
                    }
                    className="bg-gray-900 border-gray-700 pr-12"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                    PLN/kg
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Koszty operacyjne */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            Koszty operacyjne
          </CardTitle>
          <CardDescription className="text-gray-400">
            Parametry związane z zużyciem energii i eksploatacją sprzętu
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="energyPrice">Cena energii elektrycznej</Label>
              <div className="relative">
                <Input
                  id="energyPrice"
                  type="number"
                  min={0}
                  step={0.01}
                  value={localSettings.energyPricePerKwh}
                  onChange={(e) =>
                    updateSetting('energyPricePerKwh', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-16"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  PLN/kWh
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="powerConsumption">Pobór mocy drukarki</Label>
              <div className="relative">
                <Input
                  id="powerConsumption"
                  type="number"
                  min={0}
                  step={0.1}
                  value={localSettings.printerPowerConsumption}
                  onChange={(e) =>
                    updateSetting('printerPowerConsumption', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  kW
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="printerCost">Wartość drukarki</Label>
              <div className="relative">
                <Input
                  id="printerCost"
                  type="number"
                  min={0}
                  step={100}
                  value={localSettings.printerCost}
                  onChange={(e) =>
                    updateSetting('printerCost', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  PLN
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="printerLifespan">Żywotność drukarki</Label>
              <div className="relative">
                <Input
                  id="printerLifespan"
                  type="number"
                  min={0}
                  step={100}
                  value={localSettings.printerLifespanHours}
                  onChange={(e) =>
                    updateSetting('printerLifespanHours', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-16"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  godz.
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenanceCost">Koszt konserwacji / godz.</Label>
              <div className="relative">
                <Input
                  id="maintenanceCost"
                  type="number"
                  min={0}
                  step={0.5}
                  value={localSettings.maintenanceCostPerHour}
                  onChange={(e) =>
                    updateSetting('maintenanceCostPerHour', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-16"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  PLN/godz.
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Koszty pracy */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="w-5 h-5 text-green-400" />
            Koszty pracy
          </CardTitle>
          <CardDescription className="text-gray-400">
            Stawki godzinowe dla operatorów i specjalistów
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="operatorRate">Stawka operatora drukarki</Label>
              <div className="relative">
                <Input
                  id="operatorRate"
                  type="number"
                  min={0}
                  step={5}
                  value={localSettings.operatorHourlyRate}
                  onChange={(e) =>
                    updateSetting('operatorHourlyRate', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-16"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  PLN/godz.
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="printerHourlyRate">Stawka za czas druku</Label>
              <div className="relative">
                <Input
                  id="printerHourlyRate"
                  type="number"
                  min={0}
                  step={1}
                  value={localSettings.printerHourlyRate}
                  onChange={(e) =>
                    updateSetting('printerHourlyRate', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-16"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  PLN/godz.
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Domyślne wartości */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Calculator className="w-5 h-5 text-purple-400" />
            Domyślne wartości
          </CardTitle>
          <CardDescription className="text-gray-400">
            Wartości domyślne używane przy tworzeniu nowych wycen
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="defaultMargin" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Domyślna marża
              </Label>
              <div className="relative">
                <Input
                  id="defaultMargin"
                  type="number"
                  min={0}
                  max={500}
                  step={5}
                  value={localSettings.defaultMargin}
                  onChange={(e) =>
                    updateSetting('defaultMargin', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  %
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="vatRate" className="flex items-center gap-2">
                <Percent className="w-4 h-4" />
                Stawka VAT
              </Label>
              <div className="relative">
                <Input
                  id="vatRate"
                  type="number"
                  min={0}
                  max={100}
                  step={1}
                  value={localSettings.vatRate}
                  onChange={(e) =>
                    updateSetting('vatRate', Number(e.target.value))
                  }
                  className="bg-gray-900 border-gray-700 pr-12"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  %
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Podsumowanie */}
      <Card className="bg-blue-900/20 border-blue-700/50">
        <CardHeader>
          <CardTitle className="text-lg text-blue-300">Podsumowanie ustawień</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Średnia cena filamentu:</span>
              <div className="text-white font-medium">
                {(
                  Object.values(localSettings.filamentPrices).reduce((a, b) => a + b, 0) /
                  Object.values(localSettings.filamentPrices).length
                ).toFixed(2)}{' '}
                PLN/kg
              </div>
            </div>
            <div>
              <span className="text-gray-500">Koszt energii / godz.:</span>
              <div className="text-white font-medium">
                {(
                  localSettings.energyPricePerKwh * localSettings.printerPowerConsumption
                ).toFixed(2)}{' '}
                PLN
              </div>
            </div>
            <div>
              <span className="text-gray-500">Amortyzacja / godz.:</span>
              <div className="text-white font-medium">
                {(localSettings.printerCost / localSettings.printerLifespanHours).toFixed(2)} PLN
              </div>
            </div>
            <div>
              <span className="text-gray-500">Domyślna marża:</span>
              <div className="text-white font-medium">{localSettings.defaultMargin}%</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default QuoteSettings;
