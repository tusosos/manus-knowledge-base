// ============================================
// 3D Print Business Hub - Quote Form Component
// ============================================

import React, { useState, useEffect, useCallback } from 'react';
import {
  User,
  Building2,
  Mail,
  Phone,
  MapPin,
  Package,
  Ruler,
  Clock,
  Weight,
  Layers,
  Plus,
  Search,
  ChevronDown,
  Check,
  X,
  Calculator,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Client,
  QuoteItem,
  MaterialType,
  AdditionalService,
  MATERIAL_OPTIONS,
  CalculationSettings,
} from './types';

// ============================================
// Props
// ============================================

export interface QuoteFormProps {
  clients: Client[];
  availableServices: AdditionalService[];
  settings: CalculationSettings;
  onSubmit: (data: {
    client: Client;
    item: QuoteItem;
    marginPercent: number;
    notes?: string;
  }) => void;
  onCalculate: (item: QuoteItem, marginPercent: number) => void;
  initialData?: Partial<{
    client: Client;
    item: QuoteItem;
    marginPercent: number;
    notes: string;
  }>;
}

// ============================================
// Komponent
// ============================================

export function QuoteForm({
  clients,
  availableServices,
  settings,
  onSubmit,
  onCalculate,
  initialData,
}: QuoteFormProps) {
  // Stan klienta
  const [selectedClientId, setSelectedClientId] = useState<string>(
    initialData?.client?.id || ''
  );
  const [isNewClient, setIsNewClient] = useState(!initialData?.client?.id);
  const [newClient, setNewClient] = useState<Partial<Client>>({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: '',
    city: '',
    postalCode: '',
    nip: '',
  });

  // Stan projektu
  const [projectName, setProjectName] = useState(
    initialData?.item?.projectName || ''
  );
  const [dimensions, setDimensions] = useState({
    length: initialData?.item?.dimensions?.length || 0,
    width: initialData?.item?.dimensions?.width || 0,
    height: initialData?.item?.dimensions?.height || 0,
  });
  const [material, setMaterial] = useState<MaterialType>(
    initialData?.item?.material || 'PLA'
  );
  const [quantity, setQuantity] = useState(initialData?.item?.quantity || 1);
  const [printTime, setPrintTime] = useState(initialData?.item?.printTime || 1);
  const [filamentWeight, setFilamentWeight] = useState(
    initialData?.item?.filamentWeight || 0
  );
  const [infill, setInfill] = useState(initialData?.item?.infill || 20);
  const [layerHeight, setLayerHeight] = useState(
    initialData?.item?.layerHeight || 0.2
  );

  // Dodatkowe usługi
  const [selectedServices, setSelectedServices] = useState<AdditionalService[]>(
    initialData?.item?.additionalServices || []
  );

  // Marża i uwagi
  const [marginPercent, setMarginPercent] = useState(
    initialData?.marginPercent || settings.defaultMargin
  );
  const [notes, setNotes] = useState(initialData?.notes || '');

  // Dialog nowego klienta
  const [newClientDialogOpen, setNewClientDialogOpen] = useState(false);

  // Szukanie klienta
  const [clientSearch, setClientSearch] = useState('');
  const filteredClients = clients.filter(
    (client) =>
      client.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
      client.email.toLowerCase().includes(clientSearch.toLowerCase()) ||
      client.company?.toLowerCase().includes(clientSearch.toLowerCase())
  );

  // Wybrany klient
  const selectedClient = clients.find((c) => c.id === selectedClientId);

  // Automatyczna kalkulacja przy zmianach
  useEffect(() => {
    const item: QuoteItem = {
      id: 'temp',
      projectName,
      dimensions,
      material,
      quantity: Math.max(1, quantity),
      printTime: Math.max(0.1, printTime),
      filamentWeight: Math.max(0, filamentWeight),
      infill,
      layerHeight,
      additionalServices: selectedServices,
    };
    onCalculate(item, marginPercent);
  }, [
    projectName,
    dimensions,
    material,
    quantity,
    printTime,
    filamentWeight,
    infill,
    layerHeight,
    selectedServices,
    marginPercent,
    onCalculate,
  ]);

  // Obsługa dodawania nowego klienta
  const handleAddNewClient = () => {
    if (newClient.name && newClient.email) {
      setIsNewClient(true);
      setSelectedClientId('');
      setNewClientDialogOpen(false);
    }
  };

  // Obsługa wyboru usługi
  const toggleService = (service: AdditionalService) => {
    setSelectedServices((prev) => {
      const exists = prev.find((s) => s.id === service.id);
      if (exists) {
        return prev.filter((s) => s.id !== service.id);
      }
      return [...prev, { ...service, quantity: 1 }];
    });
  };

  // Aktualizacja ilości usługi
  const updateServiceQuantity = (serviceId: string, quantity: number) => {
    setSelectedServices((prev) =>
      prev.map((s) => (s.id === serviceId ? { ...s, quantity: Math.max(0, quantity) } : s))
    );
  };

  // Submit formularza
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const client: Client = isNewClient
      ? ({
          ...newClient,
          id: 'new',
          createdAt: new Date(),
        } as Client)
      : selectedClient!;

    const item: QuoteItem = {
      id: 'temp',
      projectName,
      dimensions,
      material,
      quantity: Math.max(1, quantity),
      printTime: Math.max(0.1, printTime),
      filamentWeight: Math.max(0, filamentWeight),
      infill,
      layerHeight,
      additionalServices: selectedServices.filter((s) => s.quantity > 0),
    };

    onSubmit({ client, item, marginPercent, notes });
  };

  // Estymacja wagi filamentu na podstawie wymiarów
  const estimateFilamentWeight = useCallback(() => {
    const volume =
      (dimensions.length * dimensions.width * dimensions.height * infill) / 100;
    // Gęstość PLA ~1.24 g/cm³, z uwzględnieniem strat
    const density = 1.24;
    const estimatedWeight = (volume * density) / 1000;
    setFilamentWeight(Math.round(estimatedWeight));
  }, [dimensions, infill]);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Sekcja klienta */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <User className="w-5 h-5 text-blue-400" />
            Dane klienta
          </h3>
          <Dialog open={newClientDialogOpen} onOpenChange={setNewClientDialogOpen}>
            <DialogTrigger asChild>
              <Button type="button" variant="outline" size="sm" className="gap-2">
                <Plus className="w-4 h-4" />
                Nowy klient
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-lg">
              <DialogHeader>
                <DialogTitle>Dodaj nowego klienta</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Imię i nazwisko *</Label>
                    <Input
                      value={newClient.name}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, name: e.target.value }))
                      }
                      placeholder="Jan Kowalski"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Firma</Label>
                    <Input
                      value={newClient.company}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, company: e.target.value }))
                      }
                      placeholder="Nazwa firmy"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Email *</Label>
                    <Input
                      type="email"
                      value={newClient.email}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, email: e.target.value }))
                      }
                      placeholder="email@example.com"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Telefon</Label>
                    <Input
                      value={newClient.phone}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, phone: e.target.value }))
                      }
                      placeholder="+48 123 456 789"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Adres</Label>
                  <Input
                    value={newClient.address}
                    onChange={(e) =>
                      setNewClient((prev) => ({ ...prev, address: e.target.value }))
                    }
                    placeholder="ul. Przykładowa 1"
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Kod pocztowy</Label>
                    <Input
                      value={newClient.postalCode}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, postalCode: e.target.value }))
                      }
                      placeholder="00-001"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Miasto</Label>
                    <Input
                      value={newClient.city}
                      onChange={(e) =>
                        setNewClient((prev) => ({ ...prev, city: e.target.value }))
                      }
                      placeholder="Warszawa"
                      className="bg-gray-800 border-gray-700"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>NIP</Label>
                  <Input
                    value={newClient.nip}
                    onChange={(e) =>
                      setNewClient((prev) => ({ ...prev, nip: e.target.value }))
                    }
                    placeholder="PL1234567890"
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="outline">
                    Anuluj
                  </Button>
                </DialogClose>
                <Button
                  type="button"
                  onClick={handleAddNewClient}
                  disabled={!newClient.name || !newClient.email}
                >
                  Dodaj klienta
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {!isNewClient ? (
          <div className="relative">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                value={clientSearch}
                onChange={(e) => setClientSearch(e.target.value)}
                placeholder="Wyszukaj klienta..."
                className="pl-10 bg-gray-800 border-gray-700"
              />
            </div>
            {clientSearch && (
              <div className="absolute z-10 w-full mt-1 bg-gray-800 border border-gray-700 rounded-md shadow-lg max-h-60 overflow-auto">
                {filteredClients.map((client) => (
                  <button
                    key={client.id}
                    type="button"
                    onClick={() => {
                      setSelectedClientId(client.id);
                      setClientSearch('');
                    }}
                    className="w-full px-4 py-3 text-left hover:bg-gray-700 border-b border-gray-700 last:border-0"
                  >
                    <div className="font-medium text-white">{client.name}</div>
                    {client.company && (
                      <div className="text-sm text-gray-400">{client.company}</div>
                    )}
                    <div className="text-sm text-gray-500">{client.email}</div>
                  </button>
                ))}
                {filteredClients.length === 0 && (
                  <div className="px-4 py-3 text-gray-400">Nie znaleziono klientów</div>
                )}
              </div>
            )}
            {selectedClient && (
              <div className="mt-3 p-4 bg-gray-800/50 border border-gray-700 rounded-lg">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-medium text-white">{selectedClient.name}</div>
                    {selectedClient.company && (
                      <div className="text-sm text-gray-400 flex items-center gap-1">
                        <Building2 className="w-3 h-3" />
                        {selectedClient.company}
                      </div>
                    )}
                    <div className="text-sm text-gray-400 flex items-center gap-1 mt-1">
                      <Mail className="w-3 h-3" />
                      {selectedClient.email}
                    </div>
                    <div className="text-sm text-gray-400 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      {selectedClient.phone}
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedClientId('')}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-4 bg-blue-900/20 border border-blue-700/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-blue-300">Nowy klient</span>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setIsNewClient(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="text-sm text-gray-300">
              <div className="font-medium">{newClient.name}</div>
              {newClient.company && <div>{newClient.company}</div>}
              <div>{newClient.email}</div>
              <div>{newClient.phone}</div>
            </div>
          </div>
        )}
      </div>

      <Separator className="bg-gray-700" />

      {/* Sekcja projektu */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Package className="w-5 h-5 text-blue-400" />
          Dane projektu
        </h3>

        <div className="space-y-2">
          <Label htmlFor="projectName">Nazwa projektu *</Label>
          <Input
            id="projectName"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            placeholder="np. Obudowa czujnika"
            className="bg-gray-800 border-gray-700"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="material">Materiał *</Label>
            <Select value={material} onValueChange={(v) => setMaterial(v as MaterialType)}>
              <SelectTrigger className="bg-gray-800 border-gray-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700">
                {MATERIAL_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    <div>
                      <div>{opt.label}</div>
                      <div className="text-xs text-gray-400">{opt.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-xs text-gray-500">
              Cena: {settings.filamentPrices[material]} PLN/kg
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">Ilość sztuk *</Label>
            <Input
              id="quantity"
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              className="bg-gray-800 border-gray-700"
              required
            />
          </div>
        </div>

        {/* Wymiary */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Ruler className="w-4 h-4" />
            Wymiary (mm)
          </Label>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Input
                type="number"
                min={0}
                value={dimensions.length || ''}
                onChange={(e) =>
                  setDimensions((prev) => ({ ...prev, length: Number(e.target.value) }))
                }
                placeholder="Długość"
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Input
                type="number"
                min={0}
                value={dimensions.width || ''}
                onChange={(e) =>
                  setDimensions((prev) => ({ ...prev, width: Number(e.target.value) }))
                }
                placeholder="Szerokość"
                className="bg-gray-800 border-gray-700"
              />
            </div>
            <div>
              <Input
                type="number"
                min={0}
                value={dimensions.height || ''}
                onChange={(e) =>
                  setDimensions((prev) => ({ ...prev, height: Number(e.target.value) }))
                }
                placeholder="Wysokość"
                className="bg-gray-800 border-gray-700"
              />
            </div>
          </div>
        </div>

        {/* Parametry druku */}
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="params" className="border-gray-700">
            <AccordionTrigger className="text-sm text-gray-400 hover:text-white">
              Zaawansowane parametry druku
            </AccordionTrigger>
            <AccordionContent className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="infill">Wypełnienie (%)</Label>
                  <Input
                    id="infill"
                    type="number"
                    min={0}
                    max={100}
                    value={infill}
                    onChange={(e) => setInfill(Number(e.target.value))}
                    className="bg-gray-800 border-gray-700"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="layerHeight">Wysokość warstwy (mm)</Label>
                  <Select
                    value={String(layerHeight)}
                    onValueChange={(v) => setLayerHeight(Number(v))}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-700">
                      <SelectItem value="0.1">0.1 mm (Wysoka jakość)</SelectItem>
                      <SelectItem value="0.2">0.2 mm (Standard)</SelectItem>
                      <SelectItem value="0.3">0.3 mm (Szybki)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={estimateFilamentWeight}
                className="w-full"
              >
                <Calculator className="w-4 h-4 mr-2" />
                Szacuj wagę na podstawie wymiarów
              </Button>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="printTime" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Czas druku (h) *
            </Label>
            <Input
              id="printTime"
              type="number"
              min={0.1}
              step={0.1}
              value={printTime}
              onChange={(e) => setPrintTime(Number(e.target.value))}
              className="bg-gray-800 border-gray-700"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="filamentWeight" className="flex items-center gap-2">
              <Weight className="w-4 h-4" />
              Waga filamentu (g) *
            </Label>
            <Input
              id="filamentWeight"
              type="number"
              min={0}
              value={filamentWeight}
              onChange={(e) => setFilamentWeight(Number(e.target.value))}
              className="bg-gray-800 border-gray-700"
              required
            />
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Dodatkowe usługi */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-blue-400" />
          Dodatkowe usługi
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {availableServices.map((service) => {
            const isSelected = selectedServices.some((s) => s.id === service.id);
            const selectedService = selectedServices.find((s) => s.id === service.id);

            return (
              <div
                key={service.id}
                className={`p-3 border rounded-lg transition-colors ${
                  isSelected
                    ? 'bg-blue-900/30 border-blue-500'
                    : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                }`}
              >
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={() => toggleService(service)}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-white">{service.name}</div>
                    <div className="text-xs text-gray-400">{service.description}</div>
                    <div className="text-xs text-blue-400 mt-1">
                      {service.pricePerUnit} PLN/{service.unit}
                    </div>
                  </div>
                  {isSelected && (
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min={0}
                        value={selectedService?.quantity || 0}
                        onChange={(e) =>
                          updateServiceQuantity(service.id, Number(e.target.value))
                        }
                        className="w-16 h-8 bg-gray-800 border-gray-700 text-sm"
                      />
                      <span className="text-xs text-gray-400">{service.unit}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Marża i uwagi */}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="margin">Marża (%)</Label>
            <Input
              id="margin"
              type="number"
              min={0}
              max={500}
              value={marginPercent}
              onChange={(e) => setMarginPercent(Number(e.target.value))}
              className="bg-gray-800 border-gray-700"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Uwagi</Label>
          <textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Dodatkowe informacje dla klienta..."
            rows={3}
            className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </div>
      </div>

      {/* Przycisk submit */}
      <div className="pt-4">
        <Button
          type="submit"
          className="w-full"
          size="lg"
          disabled={!projectName || (!isNewClient && !selectedClientId)}
        >
          <Calculator className="w-5 h-5 mr-2" />
          Utwórz wycenę
        </Button>
      </div>
    </form>
  );
}

export default QuoteForm;
