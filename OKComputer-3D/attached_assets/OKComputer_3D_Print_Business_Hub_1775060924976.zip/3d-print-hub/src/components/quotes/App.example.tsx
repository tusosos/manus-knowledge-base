// ============================================
// 3D Print Business Hub - Example App Component
// ============================================

import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/toaster';
import { QuoteManager } from './QuoteManager';
import { QuoteSettings } from './QuoteSettings';
import { useQuotes } from './useQuotes';
import { CalculationSettings } from './types';

/**
 * Przykładowy komponent aplikacji pokazujący użycie Generatora Wycen
 * 
 * Wymagane zależności:
 * - react
 * - react-dom
 * - lucide-react
 * - jspdf
 * - jspdf-autotable
 * - @radix-ui/react-*
 * - class-variance-authority
 * - clsx
 * - tailwind-merge
 * 
 * Wymagane komponenty shadcn/ui:
 * - button
 * - input
 * - label
 * - select
 * - dialog
 * - card
 * - table
 * - tabs
 * - badge
 * - checkbox
 * - accordion
 * - dropdown-menu
 * - scroll-area
 * - separator
 * - toast
 */

export function App() {
  // Użyj hooka do zarządzania wycenami
  const { settings, updateSettings } = useQuotes();
  const [localSettings, setLocalSettings] = useState<CalculationSettings>(settings);

  // Handler zapisywania ustawień
  const handleSaveSettings = (newSettings: CalculationSettings) => {
    setLocalSettings(newSettings);
    updateSettings(newSettings);
  };

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Toast notifications */}
      <Toaster />

      {/* Główna nawigacja */}
      <Tabs defaultValue="quotes" className="w-full">
        <div className="bg-gray-900 border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <TabsList className="bg-transparent border-0">
              <TabsTrigger
                value="quotes"
                className="data-[state=active]:bg-gray-800 data-[state=active]:text-white"
              >
                Wyceny
              </TabsTrigger>
              <TabsTrigger
                value="settings"
                className="data-[state=active]:bg-gray-800 data-[state=active]:text-white"
              >
                Ustawienia
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        {/* Zakładka Wyceny */}
        <TabsContent value="quotes" className="m-0">
          <QuoteManager />
        </TabsContent>

        {/* Zakładka Ustawienia */}
        <TabsContent value="settings" className="m-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <QuoteSettings
              settings={localSettings}
              onSave={handleSaveSettings}
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default App;
