# 3D Print Business Hub - Generator Wycen PDF

Kompleksowy system generowania wycen dla biznesu druku 3D z automatyczną kalkulacją kosztów i eksportem do PDF.

## Funkcjonalności

### 1. Formularz Wyceny
- **Dane klienta**: wybór z bazy lub tworzenie nowego klienta
- **Dane projektu**: nazwa, wymiary (długość, szerokość, wysokość w mm)
- **Materiał**: PLA, PETG, ABS, TPU, PA (Nylon), PC (Poliwęglan)
- **Parametry druku**: czas druku, waga filamentu, wypełnienie, wysokość warstwy
- **Ilość sztuk**: wsparcie dla zamówień wielkoseryjnych
- **Dodatkowe usługi**: post-processing, malowanie, szlifowanie, montaż

### 2. Automatyczna Kalkulacja
- **Koszt materiału**: na podstawie wagi i ceny filamentu
- **Koszt energii**: zużycie prądu podczas druku
- **Amortyzacja**: koszt zużycia drukarki
- **Koszt pracy**: czas operatora
- **Koszt usług dodatkowych**: wybrane usługi post-processing
- **Marża**: konfigurowalny procent (domyślnie 100%)
- **VAT**: automatyczne obliczanie podatku

### 3. Podgląd Wyceny
- Podsumowanie wszystkich kosztów
- Szczegóły pozycji z cenami jednostkowymi
- Cena netto/brutto
- Cena za sztukę
- Wybrane usługi dodatkowe

### 4. Eksport PDF
- Profesjonalny szablon wyceny
- Nagłówek z danymi firmy
- Dane klienta i projektu
- Tabela pozycji z kosztami
- Podsumowanie z VAT
- Warunki płatności i realizacji
- Podpisy

### 5. Historia Wycen
- Lista wszystkich wycen z paginacją
- Filtrowanie po statusie, kliencie, dacie
- Wyszukiwanie pełnotekstowe
- Zarządzanie statusami (draft, sent, accepted, rejected, expired)
- Duplikowanie wycen
- Eksport do PDF
- Wysyłka email (placeholder)

## Instalacja

### Wymagane zależności

```bash
npm install jspdf jspdf-autotable lucide-react
```

### Komponenty shadcn/ui

```bash
npx shadcn add button input label select dialog card table tabs badge checkbox accordion dropdown-menu scroll-area separator toast
```

## Użycie

### Podstawowe użycie

```tsx
import { QuoteManager } from './components/quotes';

function App() {
  return <QuoteManager />;
}
```

### Z ustawieniami

```tsx
import { QuoteManager, QuoteSettings, useQuotes } from './components/quotes';

function App() {
  const { settings, updateSettings } = useQuotes();

  return (
    <div>
      <QuoteManager />
      <QuoteSettings settings={settings} onSave={updateSettings} />
    </div>
  );
}
```

### Użycie hooka useQuotes

```tsx
import { useQuotes } from './components/quotes';

function MyComponent() {
  const {
    quotes,
    clients,
    settings,
    addQuote,
    calculateCosts,
    updateQuoteStatus,
    downloadQuotePDF,
  } = useQuotes();

  // Oblicz koszty
  const costs = calculateCosts(item, 100); // 100% marży

  // Dodaj wycenę
  const newQuote = addQuote({
    client,
    item,
    costs,
    validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  });

  return <div>...</div>;
}
```

### Generowanie PDF

```tsx
import { downloadQuotePDF, previewQuotePDF, getQuotePDFBase64 } from './components/quotes';

// Pobierz PDF
function handleDownload(quote) {
  downloadQuotePDF(quote, 'moja-wycena.pdf');
}

// Podgląd w nowym oknie
function handlePreview(quote) {
  previewQuotePDF(quote);
}

// Pobierz jako base64 (do emaila)
function handleEmail(quote) {
  const base64 = getQuotePDFBase64(quote);
  // Wyślij email z załącznikiem
}
```

## Struktura katalogów

```
src/components/quotes/
├── types.ts           # Typy i interfejsy TypeScript
├── useQuotes.ts       # Hook zarządzania stanem wycen
├── pdfGenerator.ts    # Generator PDF (jsPDF)
├── QuoteForm.tsx      # Formularz wyceny
├── QuotePreview.tsx   # Podgląd wyceny
├── QuoteHistory.tsx   # Historia wycen (tabela)
├── QuoteSettings.tsx  # Ustawienia kalkulacji
├── QuoteManager.tsx   # Główny komponent
├── index.ts           # Eksporty
├── App.example.tsx    # Przykład użycia
└── README.md          # Dokumentacja
```

## Konfiguracja

### Domyślne ustawienia kalkulacji

```typescript
const DEFAULT_SETTINGS = {
  // Ceny filamentów (PLN/kg)
  filamentPrices: {
    PLA: 75,
    PETG: 85,
    ABS: 90,
    TPU: 120,
    PA: 150,
    PC: 180,
  },

  // Koszty operacyjne
  energyPricePerKwh: 0.8,        // PLN/kWh
  printerPowerConsumption: 0.3,  // kW
  printerCost: 5000,             // PLN
  printerLifespanHours: 5000,    // godziny
  maintenanceCostPerHour: 2,     // PLN/godz.

  // Koszty pracy
  operatorHourlyRate: 50,        // PLN/godz.
  printerHourlyRate: 15,         // PLN/godz.

  // Domyślne wartości
  defaultMargin: 100,            // %
  vatRate: 23,                   // %
};
```

### Konfiguracja PDF

```typescript
const PDF_CONFIG = {
  companyName: '3D Print Business Hub',
  companyAddress: 'ul. Drukarska 123, 00-001 Warszawa',
  companyPhone: '+48 123 456 789',
  companyEmail: 'kontakt@3dprinthub.pl',
  companyNip: 'PL1234567890',
  bankAccount: 'PL 12 1234 5678 9012 3456 7890 1234',
  paymentTerms: '14 dni od daty wystawienia faktury',
  deliveryTerms: '7-14 dni roboczych od akceptacji wyceny',
  warrantyInfo: '12 miesięcy gwarancji na wydruki',
};
```

## Formuła kalkulacji

```
1. Koszt materiału = (waga_filamentu / 1000) * cena_za_kg

2. Koszt energii = czas_druku * pobór_mocy * cena_prądu

3. Amortyzacja = czas_druku * (koszt_drukarki / żywotność)

4. Koszt pracy = (czas_druku + czas_przygotowania) * stawka_operatora

5. Koszt usług dodatkowych = suma(usługa.cena * usługa.ilość)

6. Suma kosztów = materiał + energia + amortyzacja + praca

7. Marża = suma_kosztów * (marża_procent / 100)

8. Cena netto = suma_kosztów + marża + usługi_dodatkowe

9. VAT = cena_netto * (vat_procent / 100)

10. Cena brutto = cena_netto + VAT
```

## API

### Typy

```typescript
interface Quote {
  id: string;
  quoteNumber: string;
  client: Client;
  item: QuoteItem;
  costs: CostBreakdown;
  status: QuoteStatus;
  validUntil: Date;
  createdAt: Date;
}

interface QuoteItem {
  projectName: string;
  dimensions: { length: number; width: number; height: number };
  material: MaterialType;
  quantity: number;
  printTime: number;
  filamentWeight: number;
  additionalServices: AdditionalService[];
}

interface CostBreakdown {
  materialCost: number;
  energyCost: number;
  depreciationCost: number;
  laborCost: number;
  additionalServicesCost: number;
  subtotal: number;
  margin: number;
  marginPercent: number;
  totalNet: number;
  vatRate: number;
  vatAmount: number;
  totalGross: number;
  unitPrice: number;
}
```

### Hook useQuotes

```typescript
const {
  // Dane
  quotes: Quote[],
  clients: Client[],
  settings: CalculationSettings,
  availableServices: AdditionalService[],

  // Filtry
  filters: QuoteFilters,
  setFilters: (filters: QuoteFilters) => void,
  filteredQuotes: Quote[],

  // Akcje
  addQuote: (data) => Quote,
  updateQuote: (id, updates) => void,
  deleteQuote: (id) => void,
  updateQuoteStatus: (id, status) => void,
  duplicateQuote: (id) => Quote | null,

  // Klienci
  addClient: (client) => Client,
  updateClient: (id, updates) => void,
  deleteClient: (id) => void,
  getClientById: (id) => Client | undefined,

  // Kalkulacja
  calculateCosts: (item, marginPercent?) => CostBreakdown,

  // Ustawienia
  updateSettings: (settings) => void,
  updateFilamentPrice: (material, price) => void,
} = useQuotes();
```

## Dostosowanie

### Dodanie nowego materiału

1. Dodaj typ do `MaterialType` w `types.ts`
2. Dodaj opcję do `MATERIAL_OPTIONS`
3. Dodaj domyślną cenę do `DEFAULT_CALCULATION_SETTINGS`

### Dodanie nowej usługi dodatkowej

1. Dodaj usługę do `DEFAULT_ADDITIONAL_SERVICES` w `types.ts`

```typescript
{
  id: 'moja-usluga',
  name: 'Nazwa usługi',
  description: 'Opis usługi',
  pricePerUnit: 50,
  unit: 'szt',
  quantity: 0,
}
```

### Modyfikacja szablonu PDF

Edytuj funkcję `generateQuotePDF` w `pdfGenerator.ts`:

```typescript
// Kolory
const primaryColor = [59, 130, 246]; // Blue-500

// Nagłówek
doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
doc.rect(0, 0, 210, 45, 'F');

// ...
```

## Licencja

MIT
