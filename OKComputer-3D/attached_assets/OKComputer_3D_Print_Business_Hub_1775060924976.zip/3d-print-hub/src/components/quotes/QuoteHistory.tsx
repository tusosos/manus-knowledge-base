// ============================================
// 3D Print Business Hub - Quote History Component
// ============================================

import React, { useState } from 'react';
import {
  Search,
  Filter,
  Download,
  Send,
  Eye,
  Copy,
  Trash2,
  MoreHorizontal,
  Calendar,
  User,
  Package,
  FileText,
  ChevronLeft,
  ChevronRight,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Quote,
  QuoteStatus,
  QuoteFilters,
  Client,
  STATUS_LABELS,
} from './types';
import { QuotePreview } from './QuotePreview';

// ============================================
// Props
// ============================================

export interface QuoteHistoryProps {
  quotes: Quote[];
  clients: Client[];
  filters: QuoteFilters;
  onFilterChange: (filters: QuoteFilters) => void;
  onViewQuote: (quote: Quote) => void;
  onDownloadPDF: (quote: Quote) => void;
  onSendEmail: (quote: Quote) => void;
  onDuplicateQuote: (quote: Quote) => void;
  onDeleteQuote: (quote: Quote) => void;
  onStatusChange: (quoteId: string, status: QuoteStatus) => void;
}

// ============================================
// Komponent
// ============================================

export function QuoteHistory({
  quotes,
  clients,
  filters,
  onFilterChange,
  onViewQuote,
  onDownloadPDF,
  onSendEmail,
  onDuplicateQuote,
  onDeleteQuote,
  onStatusChange,
}: QuoteHistoryProps) {
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [quoteToDelete, setQuoteToDelete] = useState<Quote | null>(null);

  // Paginacja
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const totalPages = Math.ceil(quotes.length / itemsPerPage);
  const paginatedQuotes = quotes.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Obsługa podglądu
  const handleViewQuote = (quote: Quote) => {
    setSelectedQuote(quote);
    setDetailDialogOpen(true);
    onViewQuote(quote);
  };

  // Obsługa usuwania
  const handleDeleteClick = (quote: Quote) => {
    setQuoteToDelete(quote);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (quoteToDelete) {
      onDeleteQuote(quoteToDelete);
      setDeleteDialogOpen(false);
      setQuoteToDelete(null);
    }
  };

  // Formatowanie daty
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pl-PL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  // Formatowanie ceny
  const formatPrice = (price: number) => {
    return price.toLocaleString('pl-PL', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  // Czyszczenie filtrów
  const clearFilters = () => {
    onFilterChange({});
  };

  const hasActiveFilters =
    filters.status || filters.clientId || filters.searchQuery;

  return (
    <div className="space-y-6">
      {/* Nagłówek i filtry */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Wyszukiwanie */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              value={filters.searchQuery || ''}
              onChange={(e) =>
                onFilterChange({ ...filters, searchQuery: e.target.value })
              }
              placeholder="Szukaj wycen..."
              className="pl-10 bg-gray-800 border-gray-700"
            />
          </div>

          {/* Filtr statusu */}
          <Select
            value={filters.status || 'all'}
            onValueChange={(value) =>
              onFilterChange({
                ...filters,
                status: value === 'all' ? undefined : (value as QuoteStatus),
              })
            }
          >
            <SelectTrigger className="w-[180px] bg-gray-800 border-gray-700">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-700">
              <SelectItem value="all">Wszystkie statusy</SelectItem>
              <SelectItem value="draft">Wersja robocza</SelectItem>
              <SelectItem value="sent">Wysłana</SelectItem>
              <SelectItem value="accepted">Zaakceptowana</SelectItem>
              <SelectItem value="rejected">Odrzucona</SelectItem>
              <SelectItem value="expired">Wygasła</SelectItem>
            </SelectContent>
          </Select>

          {/* Filtr klienta */}
          <Select
            value={filters.clientId || 'all'}
            onValueChange={(value) =>
              onFilterChange({
                ...filters,
                clientId: value === 'all' ? undefined : value,
              })
            }
          >
            <SelectTrigger className="w-[200px] bg-gray-800 border-gray-700">
              <User className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Klient" />
            </SelectTrigger>
            <SelectContent className="bg-gray-800 border-gray-700">
              <SelectItem value="all">Wszyscy klienci</SelectItem>
              {clients.map((client) => (
                <SelectItem key={client.id} value={client.id}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Czyść filtry */}
          {hasActiveFilters && (
            <Button variant="ghost" size="icon" onClick={clearFilters}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>

        {/* Licznik wyników */}
        <div className="text-sm text-gray-500">
          Znaleziono <span className="text-white font-medium">{quotes.length}</span> wycen
        </div>
      </div>

      {/* Tabela wycen */}
      <div className="border border-gray-700 rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-800/50 hover:bg-gray-800/50 border-gray-700">
              <TableHead className="text-gray-400">Numer</TableHead>
              <TableHead className="text-gray-400">Klient</TableHead>
              <TableHead className="text-gray-400">Projekt</TableHead>
              <TableHead className="text-gray-400">Data</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400 text-right">Wartość</TableHead>
              <TableHead className="text-gray-400 text-right">Akcje</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedQuotes.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="text-center py-12 text-gray-500"
                >
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Brak wycen do wyświetlenia</p>
                  {hasActiveFilters && (
                    <Button
                      variant="link"
                      onClick={clearFilters}
                      className="mt-2"
                    >
                      Wyczyść filtry
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ) : (
              paginatedQuotes.map((quote) => {
                const statusInfo = STATUS_LABELS[quote.status];
                return (
                  <TableRow
                    key={quote.id}
                    className="border-gray-700 hover:bg-gray-800/30 cursor-pointer"
                    onClick={() => handleViewQuote(quote)}
                  >
                    <TableCell className="font-medium text-white">
                      {quote.quoteNumber}
                    </TableCell>
                    <TableCell>
                      <div className="text-gray-200">{quote.client.name}</div>
                      {quote.client.company && (
                        <div className="text-xs text-gray-500">
                          {quote.client.company}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="text-gray-300">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-gray-500" />
                        {quote.item.projectName}
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-400">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {formatDate(quote.createdAt)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statusInfo.color} text-white text-xs`}>
                        {statusInfo.label}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium text-white">
                      {formatPrice(quote.costs.totalGross)} PLN
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent
                          align="end"
                          className="bg-gray-800 border-gray-700"
                        >
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewQuote(quote);
                            }}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Podgląd
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              onDownloadPDF(quote);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Pobierz PDF
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              onSendEmail(quote);
                            }}
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Wyślij email
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              onDuplicateQuote(quote);
                            }}
                          >
                            <Copy className="w-4 h-4 mr-2" />
                            Duplikuj
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="bg-gray-700" />
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteClick(quote);
                            }}
                            className="text-red-400"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Usuń
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Paginacja */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Strona {currentPage} z {totalPages}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Dialog szczegółów wyceny */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-hidden p-0">
          <DialogHeader className="px-6 pt-6 pb-2">
            <DialogTitle>Szczegóły wyceny</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[calc(90vh-120px)] px-6 pb-6">
            {selectedQuote && (
              <QuotePreview
                quote={selectedQuote}
                onDownloadPDF={() => onDownloadPDF(selectedQuote)}
                onSendEmail={() => onSendEmail(selectedQuote)}
                onStatusChange={(status) => {
                  onStatusChange(selectedQuote.id, status);
                  setDetailDialogOpen(false);
                }}
              />
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Dialog potwierdzenia usunięcia */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Potwierdź usunięcie</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-gray-400">
              Czy na pewno chcesz usunąć wycenę{' '}
              <span className="text-white font-medium">
                {quoteToDelete?.quoteNumber}
              </span>
              ?
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Tej operacji nie można cofnąć.
            </p>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Anuluj</Button>
            </DialogClose>
            <Button variant="destructive" onClick={confirmDelete}>
              Usuń
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default QuoteHistory;
