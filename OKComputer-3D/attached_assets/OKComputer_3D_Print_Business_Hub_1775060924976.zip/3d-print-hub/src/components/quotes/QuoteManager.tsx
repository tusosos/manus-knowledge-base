// ============================================
// 3D Print Business Hub - Quote Manager Component
// ============================================

import React, { useState, useCallback } from 'react';
import {
  Plus,
  History,
  Calculator,
  Settings,
  FileText,
  ChevronLeft,
  Check,
  X,
  Download,
  Send,
  Printer,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/components/ui/use-toast';

import { useQuotes } from './useQuotes';
import { QuoteForm } from './QuoteForm';
import { QuotePreview } from './QuotePreview';
import { QuoteHistory } from './QuoteHistory';
import {
  generateQuotePDF,
  downloadQuotePDF,
  previewQuotePDF,
  getQuotePDFBase64,
} from './pdfGenerator';
import {
  Quote,
  QuoteItem,
  CostBreakdown,
  Client,
  QuoteStatus,
  PDFConfig,
} from './types';

// ============================================
// Typy
// ============================================

type ViewMode = 'form' | 'preview' | 'history';

interface QuoteDraft {
  client?: Client;
  item?: QuoteItem;
  costs?: CostBreakdown;
  marginPercent: number;
  notes: string;
}

// ============================================
// Główny komponent
// ============================================

export function QuoteManager() {
  // Hook zarządzania wycenami
  const {
    quotes,
    clients,
    settings,
    availableServices,
    filters,
    setFilters,
    filteredQuotes,
    addQuote,
    updateQuote,
    deleteQuote,
    updateQuoteStatus,
    duplicateQuote,
    addClient,
    calculateCosts,
  } = useQuotes();

  // Stan widoku
  const [viewMode, setViewMode] = useState<ViewMode>('form');

  // Stan roboczej wyceny
  const [draft, setDraft] = useState<QuoteDraft>({
    marginPercent: settings.defaultMargin,
    notes: '',
  });

  // Stan podglądu kosztów
  const [previewCosts, setPreviewCosts] = useState<CostBreakdown | null>(null);

  // Stan zapisanej wyceny
  const [savedQuote, setSavedQuote] = useState<Quote | null>(null);

  // Dialog potwierdzenia
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [pendingQuote, setPendingQuote] = useState<QuoteDraft | null>(null);

  // ============================================
  // Handlery
  // ============================================

  // Kalkulacja kosztów w czasie rzeczywistym
  const handleCalculate = useCallback(
    (item: QuoteItem, marginPercent: number) => {
      const costs = calculateCosts(item, marginPercent);
      setPreviewCosts(costs);
      setDraft((prev) => ({ ...prev, item, marginPercent }));
    },
    [calculateCosts]
  );

  // Zatwierdzenie formularza
  const handleFormSubmit = useCallback(
    (data: {
      client: Client;
      item: QuoteItem;
      marginPercent: number;
      notes?: string;
    }) => {
      setPendingQuote({
        client: data.client,
        item: data.item,
        costs: calculateCosts(data.item, data.marginPercent),
        marginPercent: data.marginPercent,
        notes: data.notes || '',
      });
      setConfirmDialogOpen(true);
    },
    [calculateCosts]
  );

  // Potwierdzenie i zapisanie wyceny
  const confirmSaveQuote = useCallback(() => {
    if (!pendingQuote || !pendingQuote.client || !pendingQuote.item || !pendingQuote.costs) {
      return;
    }

    // Dodaj nowego klienta jeśli potrzeba
    let client = pendingQuote.client;
    if (client.id === 'new') {
      client = addClient({
        name: client.name,
        email: client.email,
        phone: client.phone || '',
        company: client.company,
        address: client.address || '',
        city: client.city || '',
        postalCode: client.postalCode || '',
        nip: client.nip,
      });
    }

    // Utwórz wycenę
    const newQuote = addQuote({
      client,
      item: pendingQuote.item,
      costs: pendingQuote.costs,
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 dni
      notes: pendingQuote.notes,
      terms: 'Standardowe warunki płatności: 14 dni',
      createdBy: 'Administrator',
    });

    setSavedQuote(newQuote);
    setDraft({
      marginPercent: settings.defaultMargin,
      notes: '',
    });
    setPreviewCosts(null);
    setPendingQuote(null);
    setConfirmDialogOpen(false);
    setViewMode('preview');

    toast({
      title: 'Wycena utworzona',
      description: `Wycena ${newQuote.quoteNumber} została pomyślnie zapisana.`,
    });
  }, [pendingQuote, addClient, addQuote, settings.defaultMargin]);

  // Pobierz PDF
  const handleDownloadPDF = useCallback(
    (quote: Quote) => {
      downloadQuotePDF(quote);
      toast({
        title: 'PDF pobrany',
        description: `Wycena ${quote.quoteNumber} została pobrana.`,
      });
    },
    []
  );

  // Podgląd PDF
  const handlePreviewPDF = useCallback((quote: Quote) => {
    previewQuotePDF(quote);
  }, []);

  // Wysłanie email (placeholder)
  const handleSendEmail = useCallback(
    (quote: Quote) => {
      // TODO: Implementacja wysyłki email
      toast({
        title: 'Wysyłka email',
        description: `Wycena ${quote.quoteNumber} została przygotowana do wysłania.`,
      });
    },
    []
  );

  // Duplikowanie wyceny
  const handleDuplicateQuote = useCallback(
    (quote: Quote) => {
      const duplicated = duplicateQuote(quote.id);
      if (duplicated) {
        toast({
          title: 'Wycena zduplikowana',
          description: `Utworzono kopię wyceny ${quote.quoteNumber}.`,
        });
        setViewMode('history');
      }
    },
    [duplicateQuote]
  );

  // Usuwanie wyceny
  const handleDeleteQuote = useCallback(
    (quote: Quote) => {
      deleteQuote(quote.id);
      if (savedQuote?.id === quote.id) {
        setSavedQuote(null);
      }
      toast({
        title: 'Wycena usunięta',
        description: `Wycena ${quote.quoteNumber} została usunięta.`,
      });
    },
    [deleteQuote, savedQuote]
  );

  // Zmiana statusu
  const handleStatusChange = useCallback(
    (quoteId: string, status: QuoteStatus) => {
      updateQuoteStatus(quoteId, status);
      const statusLabels: Record<QuoteStatus, string> = {
        draft: 'wersję roboczą',
        sent: 'wysłaną',
        accepted: 'zaakceptowaną',
        rejected: 'odrzuconą',
        expired: 'wygasłą',
      };
      toast({
        title: 'Status zmieniony',
        description: `Wycena oznaczona jako ${statusLabels[status]}.`,
      });
    },
    [updateQuoteStatus]
  );

  // Nowa wycena
  const handleNewQuote = useCallback(() => {
    setSavedQuote(null);
    setDraft({
      marginPercent: settings.defaultMargin,
      notes: '',
    });
    setPreviewCosts(null);
    setViewMode('form');
  }, [settings.defaultMargin]);

  // ============================================
  // Render
  // ============================================

  return (
    <div className="min-h-screen bg-gray-950">
      {/* Nagłówek */}
      <header className="bg-gray-900 border-b border-gray-800 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Calculator className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Generator Wycen</h1>
                  <p className="text-xs text-gray-500">3D Print Business Hub</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === 'form' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('form')}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Nowa wycena
              </Button>
              <Button
                variant={viewMode === 'history' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('history')}
                className="gap-2"
              >
                <History className="w-4 h-4" />
                Historia
                {quotes.length > 0 && (
                  <span className="ml-1 px-2 py-0.5 bg-blue-600 rounded-full text-xs">
                    {quotes.length}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Główna zawartość */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {viewMode === 'form' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Formularz */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-400" />
                Nowa wycena
              </h2>
              <QuoteForm
                clients={clients}
                availableServices={availableServices}
                settings={settings}
                onSubmit={handleFormSubmit}
                onCalculate={handleCalculate}
              />
            </div>

            {/* Podgląd na żywo */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-400" />
                Podgląd kalkulacji
              </h2>
              <QuotePreview
                previewData={{
                  client: draft.client,
                  item: draft.item,
                  costs: previewCosts || undefined,
                  notes: draft.notes,
                }}
                isDraft
              />
            </div>
          </div>
        )}

        {viewMode === 'preview' && savedQuote && (
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <Button
                variant="outline"
                onClick={() => setViewMode('history')}
                className="gap-2"
              >
                <ChevronLeft className="w-4 h-4" />
                Powrót do historii
              </Button>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleDownloadPDF(savedQuote)}
                  className="gap-2"
                >
                  <Download className="w-4 h-4" />
                  Pobierz PDF
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handlePreviewPDF(savedQuote)}
                  className="gap-2"
                >
                  <Printer className="w-4 h-4" />
                  Podgląd wydruku
                </Button>
                <Button
                  onClick={() => handleSendEmail(savedQuote)}
                  className="gap-2"
                >
                  <Send className="w-4 h-4" />
                  Wyślij email
                </Button>
              </div>
            </div>
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
              <QuotePreview
                quote={savedQuote}
                onDownloadPDF={() => handleDownloadPDF(savedQuote)}
                onSendEmail={() => handleSendEmail(savedQuote)}
                onPrint={() => handlePreviewPDF(savedQuote)}
                onStatusChange={(status) => handleStatusChange(savedQuote.id, status)}
              />
            </div>
          </div>
        )}

        {viewMode === 'history' && (
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
            <QuoteHistory
              quotes={filteredQuotes}
              clients={clients}
              filters={filters}
              onFilterChange={setFilters}
              onViewQuote={(quote) => {
                setSavedQuote(quote);
                setViewMode('preview');
              }}
              onDownloadPDF={handleDownloadPDF}
              onSendEmail={handleSendEmail}
              onDuplicateQuote={handleDuplicateQuote}
              onDeleteQuote={handleDeleteQuote}
              onStatusChange={handleStatusChange}
            />
          </div>
        )}
      </main>

      {/* Dialog potwierdzenia */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle>Potwierdź utworzenie wyceny</DialogTitle>
            <DialogDescription className="text-gray-400">
              Sprawdź podsumowanie przed zapisaniem wyceny.
            </DialogDescription>
          </DialogHeader>

          {pendingQuote?.costs && (
            <div className="space-y-4 py-4">
              <div className="bg-gray-800/50 rounded-lg p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Klient:</span>
                  <span className="text-white">{pendingQuote.client?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Projekt:</span>
                  <span className="text-white">{pendingQuote.item?.projectName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Materiał:</span>
                  <span className="text-white">{pendingQuote.item?.material}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Ilość:</span>
                  <span className="text-white">{pendingQuote.item?.quantity} szt.</span>
                </div>
              </div>

              <Separator className="bg-gray-700" />

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Suma kosztów:</span>
                  <span className="text-gray-300">
                    {pendingQuote.costs.subtotal.toLocaleString('pl-PL', {
                      minimumFractionDigits: 2,
                    })}{' '}
                    PLN
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Marża ({pendingQuote.marginPercent}%):</span>
                  <span className="text-green-400">
                    +{pendingQuote.costs.margin.toLocaleString('pl-PL', {
                      minimumFractionDigits: 2,
                    })}{' '}
                    PLN
                  </span>
                </div>
                <div className="flex justify-between text-lg font-semibold pt-2 border-t border-gray-700">
                  <span className="text-white">RAZEM BRUTTO:</span>
                  <span className="text-blue-400">
                    {pendingQuote.costs.totalGross.toLocaleString('pl-PL', {
                      minimumFractionDigits: 2,
                    })}{' '}
                    PLN
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
              <X className="w-4 h-4 mr-2" />
              Anuluj
            </Button>
            <Button onClick={confirmSaveQuote}>
              <Check className="w-4 h-4 mr-2" />
              Zapisz wycenę
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default QuoteManager;
