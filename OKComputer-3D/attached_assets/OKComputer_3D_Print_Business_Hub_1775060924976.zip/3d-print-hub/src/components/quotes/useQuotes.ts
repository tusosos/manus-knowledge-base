// ============================================
// 3D Print Business Hub - Quote Management Hook
// ============================================

import { useState, useCallback, useMemo } from 'react';
import {
  Quote,
  Client,
  QuoteItem,
  CostBreakdown,
  QuoteStatus,
  QuoteFilters,
  CalculationSettings,
  AdditionalService,
  MaterialType,
  DEFAULT_CALCULATION_SETTINGS,
  DEFAULT_ADDITIONAL_SERVICES,
} from './types';

// ============================================
// Funkcje kalkulacyjne
// ============================================

/**
 * Oblicza koszty wyceny na podstawie parametrów
 */
export function calculateQuoteCosts(
  item: QuoteItem,
  settings: CalculationSettings,
  marginPercent: number = settings.defaultMargin
): CostBreakdown {
  // 1. Koszt materiału
  const filamentPricePerKg = settings.filamentPrices[item.material];
  const materialCost = (item.filamentWeight / 1000) * filamentPricePerKg;

  // 2. Koszt energii (kWh * cena)
  const energyCost = item.printTime * settings.printerPowerConsumption * settings.energyPricePerKwh;

  // 3. Amortyzacja drukarki
  const depreciationCost = item.printTime * (settings.printerCost / settings.printerLifespanHours);

  // 4. Koszt pracy (czas druku + czas przygotowania)
  const preparationTime = 0.5; // 30 minut przygotowania
  const laborCost = (item.printTime + preparationTime) * settings.operatorHourlyRate;

  // 5. Koszt konserwacji
  const maintenanceCost = item.printTime * settings.maintenanceCostPerHour;

  // 6. Koszt dodatkowych usług
  const additionalServicesCost = item.additionalServices.reduce(
    (sum, service) => sum + service.pricePerUnit * service.quantity,
    0
  );

  // Suma kosztów bezpośrednich
  const subtotal = materialCost + energyCost + depreciationCost + laborCost + maintenanceCost;

  // Marża
  const margin = subtotal * (marginPercent / 100);

  // Cena netto
  const totalNet = subtotal + margin + additionalServicesCost;

  // VAT
  const vatAmount = totalNet * (settings.vatRate / 100);

  // Cena brutto
  const totalGross = totalNet + vatAmount;

  // Cena za sztukę
  const unitPrice = totalGross / item.quantity;

  return {
    materialCost: roundToTwo(materialCost),
    energyCost: roundToTwo(energyCost),
    depreciationCost: roundToTwo(depreciationCost),
    laborCost: roundToTwo(laborCost + maintenanceCost),
    additionalServicesCost: roundToTwo(additionalServicesCost),
    subtotal: roundToTwo(subtotal),
    margin: roundToTwo(margin),
    marginPercent,
    totalNet: roundToTwo(totalNet),
    vatRate: settings.vatRate,
    vatAmount: roundToTwo(vatAmount),
    totalGross: roundToTwo(totalGross),
    unitPrice: roundToTwo(unitPrice),
  };
}

/**
 * Zaokrągla liczbę do 2 miejsc po przecinku
 */
function roundToTwo(num: number): number {
  return Math.round(num * 100) / 100;
}

/**
 * Generuje numer wyceny
 */
function generateQuoteNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `WYC-${year}${month}-${random}`;
}

// ============================================
// Mock data dla klientów
// ============================================

const MOCK_CLIENTS: Client[] = [
  {
    id: '1',
    name: 'Jan Kowalski',
    email: 'jan.kowalski@example.com',
    phone: '+48 500 123 456',
    company: 'Kowalski Design Sp. z o.o.',
    address: 'ul. Przykładowa 1',
    city: 'Warszawa',
    postalCode: '00-001',
    nip: 'PL1234567890',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    name: 'Anna Nowak',
    email: 'anna.nowak@example.com',
    phone: '+48 600 789 012',
    address: 'ul. Testowa 42',
    city: 'Kraków',
    postalCode: '30-001',
    createdAt: new Date('2024-02-20'),
  },
  {
    id: '3',
    name: 'Piotr Wiśniewski',
    email: 'piotr.wisniewski@tech.pl',
    phone: '+48 700 345 678',
    company: 'Tech Solutions',
    address: 'ul. Innowacyjna 15',
    city: 'Wrocław',
    postalCode: '50-001',
    nip: 'PL9876543210',
    createdAt: new Date('2024-03-10'),
  },
];

// ============================================
// Hook useQuotes
// ============================================

export interface UseQuotesReturn {
  // Dane
  quotes: Quote[];
  clients: Client[];
  settings: CalculationSettings;
  availableServices: AdditionalService[];

  // Filtry
  filters: QuoteFilters;
  setFilters: (filters: QuoteFilters) => void;
  filteredQuotes: Quote[];

  // Akcje
  addQuote: (quoteData: Omit<Quote, 'id' | 'quoteNumber' | 'createdAt' | 'updatedAt' | 'status'>) => Quote;
  updateQuote: (id: string, updates: Partial<Quote>) => void;
  deleteQuote: (id: string) => void;
  updateQuoteStatus: (id: string, status: QuoteStatus) => void;
  duplicateQuote: (id: string) => Quote | null;

  // Klienci
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => Client;
  updateClient: (id: string, updates: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClientById: (id: string) => Client | undefined;

  // Kalkulacja
  calculateCosts: (item: QuoteItem, marginPercent?: number) => CostBreakdown;

  // Ustawienia
  updateSettings: (settings: Partial<CalculationSettings>) => void;
  updateFilamentPrice: (material: MaterialType, price: number) => void;
}

export function useQuotes(): UseQuotesReturn {
  // Stan
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [clients, setClients] = useState<Client[]>(MOCK_CLIENTS);
  const [settings, setSettings] = useState<CalculationSettings>(DEFAULT_CALCULATION_SETTINGS);
  const [availableServices] = useState<AdditionalService[]>(DEFAULT_ADDITIONAL_SERVICES);
  const [filters, setFilters] = useState<QuoteFilters>({});

  // Filtrowane wyceny
  const filteredQuotes = useMemo(() => {
    return quotes.filter((quote) => {
      if (filters.status && quote.status !== filters.status) return false;
      if (filters.clientId && quote.client.id !== filters.clientId) return false;
      if (filters.dateFrom && quote.createdAt < filters.dateFrom) return false;
      if (filters.dateTo && quote.createdAt > filters.dateTo) return false;
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const searchableText = `
          ${quote.quoteNumber}
          ${quote.client.name}
          ${quote.client.company || ''}
          ${quote.item.projectName}
        `.toLowerCase();
        if (!searchableText.includes(query)) return false;
      }
      return true;
    });
  }, [quotes, filters]);

  // Dodaj wycenę
  const addQuote = useCallback(
    (quoteData: Omit<Quote, 'id' | 'quoteNumber' | 'createdAt' | 'updatedAt' | 'status'>): Quote => {
      const now = new Date();
      const validUntil = new Date(now);
      validUntil.setDate(validUntil.getDate() + 30); // Ważna 30 dni

      const newQuote: Quote = {
        ...quoteData,
        id: crypto.randomUUID(),
        quoteNumber: generateQuoteNumber(),
        status: 'draft',
        createdAt: now,
        updatedAt: now,
        validUntil,
      };

      setQuotes((prev) => [newQuote, ...prev]);
      return newQuote;
    },
    []
  );

  // Aktualizuj wycenę
  const updateQuote = useCallback((id: string, updates: Partial<Quote>) => {
    setQuotes((prev) =>
      prev.map((quote) =>
        quote.id === id
          ? { ...quote, ...updates, updatedAt: new Date() }
          : quote
      )
    );
  }, []);

  // Usuń wycenę
  const deleteQuote = useCallback((id: string) => {
    setQuotes((prev) => prev.filter((quote) => quote.id !== id));
  }, []);

  // Aktualizuj status wyceny
  const updateQuoteStatus = useCallback((id: string, status: QuoteStatus) => {
    const now = new Date();
    setQuotes((prev) =>
      prev.map((quote) => {
        if (quote.id !== id) return quote;

        const updates: Partial<Quote> = { status };

        if (status === 'sent') updates.sentAt = now;
        if (status === 'accepted') updates.acceptedAt = now;
        if (status === 'rejected') updates.rejectedAt = now;

        return { ...quote, ...updates, updatedAt: now };
      })
    );
  }, []);

  // Duplikuj wycenę
  const duplicateQuote = useCallback(
    (id: string): Quote | null => {
      const originalQuote = quotes.find((q) => q.id === id);
      if (!originalQuote) return null;

      const now = new Date();
      const validUntil = new Date(now);
      validUntil.setDate(validUntil.getDate() + 30);

      const duplicatedQuote: Quote = {
        ...originalQuote,
        id: crypto.randomUUID(),
        quoteNumber: generateQuoteNumber(),
        status: 'draft',
        createdAt: now,
        updatedAt: now,
        validUntil,
        sentAt: undefined,
        acceptedAt: undefined,
        rejectedAt: undefined,
      };

      setQuotes((prev) => [duplicatedQuote, ...prev]);
      return duplicatedQuote;
    },
    [quotes]
  );

  // Dodaj klienta
  const addClient = useCallback((client: Omit<Client, 'id' | 'createdAt'>): Client => {
    const newClient: Client = {
      ...client,
      id: crypto.randomUUID(),
      createdAt: new Date(),
    };
    setClients((prev) => [...prev, newClient]);
    return newClient;
  }, []);

  // Aktualizuj klienta
  const updateClient = useCallback((id: string, updates: Partial<Client>) => {
    setClients((prev) =>
      prev.map((client) => (client.id === id ? { ...client, ...updates } : client))
    );
  }, []);

  // Usuń klienta
  const deleteClient = useCallback((id: string) => {
    setClients((prev) => prev.filter((client) => client.id !== id));
  }, []);

  // Pobierz klienta po ID
  const getClientById = useCallback(
    (id: string) => clients.find((client) => client.id === id),
    [clients]
  );

  // Oblicz koszty
  const calculateCosts = useCallback(
    (item: QuoteItem, marginPercent?: number) => {
      return calculateQuoteCosts(item, settings, marginPercent);
    },
    [settings]
  );

  // Aktualizuj ustawienia
  const updateSettings = useCallback((newSettings: Partial<CalculationSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  // Aktualizuj cenę filamentu
  const updateFilamentPrice = useCallback((material: MaterialType, price: number) => {
    setSettings((prev) => ({
      ...prev,
      filamentPrices: {
        ...prev.filamentPrices,
        [material]: price,
      },
    }));
  }, []);

  return {
    quotes,
    clients,
    settings,
    availableServices,
    filters,
    setFilters,
    filteredQuotes,
    addQuote,
    updateQuote,
    deleteQuote,
    updateQuoteStatus,
    duplicateQuote,
    addClient,
    updateClient,
    deleteClient,
    getClientById,
    calculateCosts,
    updateSettings,
    updateFilamentPrice,
  };
}

export default useQuotes;
