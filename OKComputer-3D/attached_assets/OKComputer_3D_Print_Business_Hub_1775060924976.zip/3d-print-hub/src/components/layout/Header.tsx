import { useState, useCallback } from 'react';
import { 
  Search, 
  Bell, 
  Settings, 
  Moon, 
  Sun, 
  Plus,
  Command,
  Printer,
  CheckCircle,
  AlertTriangle,
  Info
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface HeaderProps {
  sidebarCollapsed: boolean;
}

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'error';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'success',
    title: 'Drukowanie zakończone',
    message: 'Projekt "Obudowa Raspberry" został wydrukowany',
    time: '2 min temu',
    read: false,
  },
  {
    id: '2',
    type: 'warning',
    title: 'Niski poziom filamentu',
    message: 'Pozostało tylko 15% czarnego PLA',
    time: '15 min temu',
    read: false,
  },
  {
    id: '3',
    type: 'info',
    title: 'Nowe zamówienie',
    message: 'Otrzymałeś nowe zamówienie #1234',
    time: '1h temu',
    read: true,
  },
];

export const Header: React.FC<HeaderProps> = ({ sidebarCollapsed }) => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const [isDark, setIsDark] = useState(true);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleSearch = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log('Searching:', searchQuery);
    setShowSearch(false);
  }, [searchQuery]);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    );
  }, []);

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle size={16} className="text-green-400" />;
      case 'warning':
        return <AlertTriangle size={16} className="text-amber-400" />;
      case 'error':
        return <AlertTriangle size={16} className="text-red-400" />;
      default:
        return <Info size={16} className="text-blue-400" />;
    }
  };

  return (
    <header 
      className={`
        fixed top-0 right-0 h-16 bg-[#0f0f0f]/95 backdrop-blur-sm border-b border-[#2a2a2a] z-40
        transition-all duration-300
        ${sidebarCollapsed ? 'left-16' : 'left-64'}
      `}
    >
      <div className="h-full flex items-center justify-between px-6">
        {/* Left side - Search */}
        <div className="flex items-center gap-4 flex-1">
          <form onSubmit={handleSearch} className="relative">
            <div className="relative">
              <Search 
                size={18} 
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" 
              />
              <input
                type="text"
                placeholder="Szukaj..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setShowSearch(true)}
                className="w-64 pl-10 pr-10 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500/50 focus:ring-1 focus:ring-amber-500/50 transition-all"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-600">
                <Command size={12} />
                <span className="text-xs">K</span>
              </div>
            </div>
          </form>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-black text-sm font-medium rounded-lg transition-colors">
              <Plus size={16} />
              <span>Nowe zadanie</span>
            </button>
            <button className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] hover:bg-[#252525] text-slate-300 text-sm font-medium rounded-lg border border-[#2a2a2a] transition-colors">
              <Printer size={16} />
              <span>Dodaj do kolejki</span>
            </button>
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-3">
          {/* Theme Toggle */}
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors"
          >
            {isDark ? <Moon size={20} /> : <Sun size={20} />}
          </button>

          {/* Settings */}
          <button className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors">
            <Settings size={20} />
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors relative"
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-amber-500 text-black text-[10px] font-bold flex items-center justify-center rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {showNotifications && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowNotifications(false)} 
                />
                <div className="absolute right-0 top-full mt-2 w-80 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl shadow-2xl z-50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-[#2a2a2a]">
                    <h3 className="font-semibold text-white">Powiadomienia</h3>
                    {unreadCount > 0 && (
                      <button
                        onClick={markAllAsRead}
                        className="text-xs text-amber-400 hover:text-amber-300"
                      >
                        Oznacz wszystkie jako przeczytane
                      </button>
                    )}
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-slate-500">
                        Brak powiadomień
                      </div>
                    ) : (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          onClick={() => markAsRead(notification.id)}
                          className={`
                            flex items-start gap-3 p-4 cursor-pointer transition-colors
                            ${notification.read ? 'bg-transparent' : 'bg-amber-500/5'}
                            hover:bg-[#252525]
                          `}
                        >
                          <div className="mt-0.5">
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white">
                              {notification.title}
                            </p>
                            <p className="text-xs text-slate-400 mt-0.5">
                              {notification.message}
                            </p>
                            <p className="text-xs text-slate-600 mt-1">
                              {notification.time}
                            </p>
                          </div>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-amber-500 rounded-full mt-1.5" />
                          )}
                        </div>
                      ))
                    )}
                  </div>
                  <div className="p-3 border-t border-[#2a2a2a]">
                    <button className="w-full py-2 text-sm text-amber-400 hover:text-amber-300 transition-colors">
                      Zobacz wszystkie powiadomienia
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* User Avatar */}
          <div className="flex items-center gap-3 pl-3 border-l border-[#2a2a2a]">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">{user?.name || 'Admin'}</p>
              <p className="text-xs text-slate-500">{user?.role || 'Administrator'}</p>
            </div>
            <div className="w-9 h-9 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center">
              <span className="text-sm font-bold text-black">
                {user?.name?.charAt(0).toUpperCase() || 'A'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
