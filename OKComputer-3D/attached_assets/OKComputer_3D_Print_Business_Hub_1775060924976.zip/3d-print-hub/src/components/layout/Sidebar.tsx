import { Link, useLocation } from 'wouter';
import { 
  LayoutDashboard, 
  CheckSquare, 
  FolderKanban, 
  Calculator, 
  Package, 
  Users, 
  Printer, 
  FileText, 
  BarChart3, 
  Trophy, 
  Target, 
  FileSpreadsheet, 
  Palette, 
  Settings, 
  BookOpen, 
  Tag, 
  FileCode, 
  Truck,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Sparkles
} from 'lucide-react';
import { useState, useCallback } from 'react';
import { useAuth } from '../../hooks/useAuth';

interface NavItem {
  path: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
  category?: string;
}

const navItems: NavItem[] = [
  // Main
  { path: '/', label: 'Dashboard', icon: LayoutDashboard, category: 'main' },
  { path: '/tasks', label: 'Zadania', icon: CheckSquare, category: 'main' },
  { path: '/projects', label: 'Projekty', icon: FolderKanban, category: 'main' },
  { path: '/print-queue', label: 'Kolejka Druku', icon: Printer, badge: 3, category: 'main' },
  
  // Business
  { path: '/calculator', label: 'Kalkulator', icon: Calculator, category: 'business' },
  { path: '/quotes', label: 'Wyceny', icon: FileText, category: 'business' },
  { path: '/clients', label: 'Klienci', icon: Users, category: 'business' },
  { path: '/shipping', label: 'Wysyłka', icon: Truck, category: 'business' },
  
  // Inventory
  { path: '/inventory', label: 'Magazyn', icon: Package, category: 'inventory' },
  { path: '/filament-deals', label: 'Okazje Filamentów', icon: Tag, category: 'inventory' },
  { path: '/multicolor', label: 'Multicolor', icon: Palette, category: 'inventory' },
  
  // Analytics
  { path: '/analytics', label: 'Analizy', icon: BarChart3, category: 'analytics' },
  { path: '/bestsellers', label: 'Bestsellery', icon: Trophy, category: 'analytics' },
  { path: '/competition', label: 'Konkurencja', icon: Target, category: 'analytics' },
  
  // Tools
  { path: '/listing-generator', label: 'Generator Listingów', icon: FileCode, category: 'tools' },
  { path: '/business-plan', label: 'Biznes Plan', icon: FileSpreadsheet, category: 'tools' },
  { path: '/printer', label: 'Drukarka', icon: Settings, category: 'tools' },
  { path: '/knowledge', label: 'Baza Wiedzy', icon: BookOpen, category: 'tools' },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle }) => {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const handleLogout = useCallback(async () => {
    await logout();
  }, [logout]);

  const renderNavItem = (item: NavItem) => {
    const isActive = location === item.path;
    const Icon = item.icon;
    const isHovered = hoveredItem === item.path;

    return (
      <Link 
        key={item.path} 
        href={item.path}
        onMouseEnter={() => setHoveredItem(item.path)}
        onMouseLeave={() => setHoveredItem(null)}
      >
        <a
          className={`
            flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group
            ${isActive 
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' 
              : 'text-slate-400 hover:text-amber-400 hover:bg-amber-500/5 hover:border-amber-500/20 border border-transparent'
            }
          `}
        >
          <Icon 
            size={20} 
            className={`
              transition-all duration-200
              ${isActive ? 'text-amber-400' : 'group-hover:text-amber-400'}
              ${isHovered && !isActive ? 'scale-110' : ''}
            `}
          />
          {!collapsed && (
            <>
              <span className="flex-1 text-sm font-medium">{item.label}</span>
              {item.badge && (
                <span className="bg-amber-500 text-black text-xs font-bold px-2 py-0.5 rounded-full">
                  {item.badge}
                </span>
              )}
            </>
          )}
          {collapsed && item.badge && (
            <span className="absolute right-1 top-1 w-4 h-4 bg-amber-500 text-black text-[10px] font-bold flex items-center justify-center rounded-full">
              {item.badge}
            </span>
          )}
        </a>
      </Link>
    );
  };

  const renderCategory = (title: string, items: NavItem[]) => {
    if (items.length === 0) return null;
    
    return (
      <div key={title} className="mb-4">
        {!collapsed && (
          <h3 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2 px-3">
            {title}
          </h3>
        )}
        <nav className="space-y-1">
          {items.map(renderNavItem)}
        </nav>
      </div>
    );
  };

  const groupedItems = {
    main: navItems.filter(i => i.category === 'main'),
    business: navItems.filter(i => i.category === 'business'),
    inventory: navItems.filter(i => i.category === 'inventory'),
    analytics: navItems.filter(i => i.category === 'analytics'),
    tools: navItems.filter(i => i.category === 'tools'),
  };

  return (
    <aside 
      className={`
        fixed left-0 top-0 h-full bg-[#0f0f0f] border-r border-[#2a2a2a] z-50
        transition-all duration-300 ease-in-out flex flex-col
        ${collapsed ? 'w-16' : 'w-64'}
      `}
    >
      {/* Logo */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-[#2a2a2a]">
        <Link href="/">
          <a className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
              <Printer size={18} className="text-black" />
            </div>
            {!collapsed && (
              <span className="font-bold text-white text-lg">
                3D<span className="text-amber-400">Hub</span>
              </span>
            )}
          </a>
        </Link>
      </div>

      {/* Toggle Button */}
      <button
        onClick={onToggle}
        className="absolute -right-3 top-20 w-6 h-6 bg-amber-500 hover:bg-amber-400 rounded-full flex items-center justify-center transition-colors shadow-lg"
      >
        {collapsed ? <ChevronRight size={14} className="text-black" /> : <ChevronLeft size={14} className="text-black" />}
      </button>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto py-4 px-2">
        {renderCategory('Główne', groupedItems.main)}
        {renderCategory('Biznes', groupedItems.business)}
        {renderCategory('Magazyn', groupedItems.inventory)}
        {renderCategory('Analizy', groupedItems.analytics)}
        {renderCategory('Narzędzia', groupedItems.tools)}
      </div>

      {/* User Section */}
      <div className="border-t border-[#2a2a2a] p-3">
        {!collapsed ? (
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-slate-300">
                {user?.name?.charAt(0).toUpperCase() || 'U'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.name || 'Użytkownik'}</p>
              <p className="text-xs text-slate-500 truncate">{user?.email || 'user@example.com'}</p>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
              title="Wyloguj"
            >
              <LogOut size={18} />
            </button>
          </div>
        ) : (
          <button
            onClick={handleLogout}
            className="w-full p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors flex justify-center"
            title="Wyloguj"
          >
            <LogOut size={18} />
          </button>
        )}
      </div>

      {/* Pro Badge */}
      {!collapsed && (
        <div className="px-3 pb-3">
          <div className="bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/30 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} className="text-amber-400" />
              <span className="text-sm font-semibold text-amber-400">3D Hub Pro</span>
            </div>
            <p className="text-xs text-slate-400 mb-2">Odblokuj pełną moc druku 3D</p>
            <button className="w-full py-1.5 bg-amber-500 hover:bg-amber-400 text-black text-xs font-semibold rounded transition-colors">
              Ulepsz
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
