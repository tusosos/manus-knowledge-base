import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  History, 
  ShoppingCart, 
  Minus, 
  Plus, 
  Package,
  TrendingUp,
  Calendar
} from 'lucide-react';
import type { Filament, FilamentHistory } from './types';

interface FilamentHistoryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  filament: Filament | null;
}

const getHistoryIcon = (type: FilamentHistory['type']) => {
  switch (type) {
    case 'purchase':
      return ShoppingCart;
    case 'consumption':
      return Minus;
    case 'restock':
      return Plus;
    default:
      return Package;
  }
};

const getHistoryColor = (type: FilamentHistory['type']) => {
  switch (type) {
    case 'purchase':
      return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case 'consumption':
      return 'bg-red-500/20 text-red-400 border-red-500/30';
    case 'restock':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    default:
      return 'bg-zinc-500/20 text-zinc-400 border-zinc-500/30';
  }
};

const getHistoryLabel = (type: FilamentHistory['type']) => {
  switch (type) {
    case 'purchase':
      return 'Zakup';
    case 'consumption':
      return 'Zużycie';
    case 'restock':
      return 'Doładowanie';
    default:
      return 'Inne';
  }
};

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pl-PL', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
};

const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN',
    minimumFractionDigits: 2,
  }).format(value);
};

export function FilamentHistoryDialog({
  isOpen,
  onClose,
  filament,
}: FilamentHistoryDialogProps) {
  if (!filament) return null;

  // Calculate weighted average cost
  const purchaseHistory = filament.history.filter(
    h => h.type === 'purchase' || h.type === 'restock'
  );
  
  const totalCost = purchaseHistory.reduce(
    (sum, h) => sum + (h.pricePerKg || 0) * (h.amount / 1000), 
    0
  );
  
  const totalAmount = purchaseHistory.reduce(
    (sum, h) => sum + h.amount, 
    0
  );
  
  const weightedAvgCost = totalAmount > 0 ? (totalCost / totalAmount) * 1000 : filament.pricePerKg;

  // Calculate total consumption
  const totalConsumption = filament.history
    .filter(h => h.type === 'consumption')
    .reduce((sum, h) => sum + h.amount, 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl bg-zinc-900 border-zinc-800 text-zinc-100 max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <History className="w-5 h-5 text-amber-500" />
            Historia filamentu
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            <div className="flex items-center gap-2">
              <div
                className="w-4 h-4 rounded border border-zinc-600"
                style={{ backgroundColor: filament.color.hex }}
              />
              {filament.material} - {filament.color.name}
            </div>
          </DialogDescription>
        </DialogHeader>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
            <p className="text-xs text-zinc-500 uppercase">Stan aktualny</p>
            <p className="text-lg font-bold text-zinc-200">
              {filament.remainingGrams}g
            </p>
          </div>
          <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
            <p className="text-xs text-zinc-500 uppercase">Zużyto łącznie</p>
            <p className="text-lg font-bold text-red-400">
              {totalConsumption}g
            </p>
          </div>
          <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
            <p className="text-xs text-zinc-500 uppercase">Cena zakupu</p>
            <p className="text-lg font-bold text-zinc-200">
              {formatCurrency(filament.pricePerKg)}/kg
            </p>
          </div>
          <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
            <p className="text-xs text-zinc-500 uppercase">Średnia ważona</p>
            <p className="text-lg font-bold text-emerald-400">
              {formatCurrency(weightedAvgCost)}/kg
            </p>
          </div>
        </div>

        {/* History List */}
        <div className="mt-4">
          <h4 className="text-sm font-medium text-zinc-400 mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Historia operacji
          </h4>
          
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-2">
              <AnimatePresence>
                {[...filament.history].reverse().map((entry, index) => {
                  const Icon = getHistoryIcon(entry.type);
                  
                  return (
                    <motion.div
                      key={entry.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/30 border border-zinc-700/50 hover:bg-zinc-800/50 transition-colors"
                    >
                      {/* Icon */}
                      <div className={`
                        p-2 rounded-lg flex-shrink-0
                        ${getHistoryColor(entry.type)}
                      `}>
                        <Icon className="w-4 h-4" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge 
                            variant="outline" 
                            className={getHistoryColor(entry.type)}
                          >
                            {getHistoryLabel(entry.type)}
                          </Badge>
                          <span className="text-sm text-zinc-500">
                            {formatDate(entry.date)}
                          </span>
                        </div>
                        
                        <div className="mt-1 flex items-center gap-4">
                          <span className={`
                            font-medium
                            ${entry.type === 'consumption' ? 'text-red-400' : 'text-emerald-400'}
                          `}>
                            {entry.type === 'consumption' ? '-' : '+'}{entry.amount}g
                          </span>
                          
                          {entry.pricePerKg && (
                            <span className="text-sm text-zinc-500">
                              {formatCurrency(entry.pricePerKg)}/kg
                            </span>
                          )}
                          
                          {entry.supplier && (
                            <span className="text-sm text-zinc-500">
                              {entry.supplier}
                            </span>
                          )}
                        </div>

                        {entry.note && (
                          <p className="text-sm text-zinc-400 mt-1">
                            {entry.note}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </ScrollArea>
        </div>

        {/* Supplier Info */}
        <div className="mt-4 p-3 rounded-lg bg-zinc-800/30 border border-zinc-700/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-zinc-500 uppercase">Dostawca</p>
              <p className="text-sm font-medium text-zinc-300">
                {filament.supplier}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-zinc-500 uppercase">Data zakupu</p>
              <p className="text-sm font-medium text-zinc-300">
                {formatDate(filament.purchaseDate)}
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
