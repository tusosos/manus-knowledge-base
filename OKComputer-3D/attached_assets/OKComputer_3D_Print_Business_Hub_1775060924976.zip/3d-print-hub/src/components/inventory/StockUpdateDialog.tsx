import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Minus, Plus, Package, AlertCircle } from 'lucide-react';
import type { Filament } from './types';

interface StockUpdateDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (
    amount: number, 
    type: 'consumption' | 'restock',
    note?: string,
    pricePerKg?: number
  ) => void;
  filament: Filament | null;
}

export function StockUpdateDialog({
  isOpen,
  onClose,
  onUpdate,
  filament,
}: StockUpdateDialogProps) {
  const [amount, setAmount] = useState(100);
  const [note, setNote] = useState('');
  const [pricePerKg, setPricePerKg] = useState(100);
  const [activeTab, setActiveTab] = useState<'consumption' | 'restock'>('consumption');
  const [error, setError] = useState<string | null>(null);

  if (!filament) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (amount <= 0) {
      setError('Ilość musi być większa od 0');
      return;
    }

    if (amount > 5000) {
      setError('Maksymalna ilość to 5000g');
      return;
    }

    if (activeTab === 'consumption' && amount > filament.remainingGrams) {
      setError(`Nie można zużyć więcej niż ${filament.remainingGrams}g`);
      return;
    }

    onUpdate(
      amount, 
      activeTab, 
      note || undefined,
      activeTab === 'restock' ? pricePerKg : undefined
    );
    
    // Reset form
    setAmount(100);
    setNote('');
    setPricePerKg(100);
    onClose();
  };

  const handleClose = () => {
    setAmount(100);
    setNote('');
    setPricePerKg(100);
    setError(null);
    onClose();
  };

  const quickAmounts = [50, 100, 250, 500];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-zinc-900 border-zinc-800 text-zinc-100">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Package className="w-5 h-5 text-amber-500" />
            Aktualizuj stan
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            {filament.material} - {filament.color.name}
            <span className="block text-sm text-zinc-500 mt-1">
              Aktualny stan: {filament.remainingGrams}g
            </span>
          </DialogDescription>
        </DialogHeader>

        <Tabs 
          value={activeTab} 
          onValueChange={(v) => setActiveTab(v as 'consumption' | 'restock')}
          className="mt-4"
        >
          <TabsList className="grid w-full grid-cols-2 bg-zinc-800">
            <TabsTrigger 
              value="consumption"
              className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400"
            >
              <Minus className="w-4 h-4 mr-2" />
              Zużycie
            </TabsTrigger>
            <TabsTrigger 
              value="restock"
              className="data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400"
            >
              <Plus className="w-4 h-4 mr-2" />
              Doładowanie
            </TabsTrigger>
          </TabsList>

          <form onSubmit={handleSubmit} className="space-y-4 mt-4">
            {/* Amount */}
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-zinc-300">
                Ilość (g)
              </Label>
              <Input
                id="amount"
                type="number"
                min={1}
                max={5000}
                value={amount}
                onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
                className={`
                  bg-zinc-800 border-zinc-700 text-zinc-100 text-center text-2xl font-bold
                  ${error ? 'border-red-500' : ''}
                `}
              />
              
              {/* Quick amounts */}
              <div className="flex gap-2 justify-center mt-2">
                {quickAmounts.map(quickAmount => (
                  <Button
                    key={quickAmount}
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setAmount(quickAmount)}
                    className={`
                      border-zinc-700 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200
                      ${amount === quickAmount ? 'bg-zinc-700 text-zinc-200' : ''}
                    `}
                  >
                    {quickAmount}g
                  </Button>
                ))}
              </div>
            </div>

            {/* Price for restock */}
            {activeTab === 'restock' && (
              <div className="space-y-2">
                <Label htmlFor="pricePerKg" className="text-zinc-300">
                  Cena za kg (PLN)
                </Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500">
                    zł
                  </span>
                  <Input
                    id="pricePerKg"
                    type="number"
                    min={1}
                    max={1000}
                    step={0.01}
                    value={pricePerKg}
                    onChange={(e) => setPricePerKg(parseFloat(e.target.value) || 0)}
                    className="pl-10 bg-zinc-800 border-zinc-700 text-zinc-100"
                  />
                </div>
              </div>
            )}

            {/* Note */}
            <div className="space-y-2">
              <Label htmlFor="note" className="text-zinc-300">
                Notatka (opcjonalnie)
              </Label>
              <Textarea
                id="note"
                placeholder="np. Drukowanie obudowy..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="bg-zinc-800 border-zinc-700 text-zinc-100 resize-none"
                rows={2}
              />
            </div>

            {/* Error */}
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30"
              >
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-400">{error}</p>
              </motion.div>
            )}

            {/* Preview */}
            <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
              <p className="text-sm text-zinc-400">
                Nowy stan po operacji:
              </p>
              <p className={`
                text-lg font-bold
                ${activeTab === 'consumption' ? 'text-red-400' : 'text-emerald-400'}
              `}>
                {activeTab === 'consumption' 
                  ? filament.remainingGrams - amount
                  : filament.remainingGrams + amount
                }g
              </p>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
              >
                Anuluj
              </Button>
              <Button
                type="submit"
                className={`
                  font-medium
                  ${activeTab === 'consumption'
                    ? 'bg-red-500 hover:bg-red-600 text-white'
                    : 'bg-emerald-500 hover:bg-emerald-600 text-white'
                  }
                `}
              >
                {activeTab === 'consumption' ? 'Zapisz zużycie' : 'Doładuj'}
              </Button>
            </div>
          </form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
