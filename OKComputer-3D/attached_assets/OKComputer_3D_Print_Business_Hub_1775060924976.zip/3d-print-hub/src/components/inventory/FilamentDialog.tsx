import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Edit2, Package } from 'lucide-react';
import type { Filament, FilamentMaterial, FilamentColor } from './types';
import { 
  FILAMENT_MATERIALS, 
  FILAMENT_COLORS, 
  SUPPLIERS 
} from './types';

interface FilamentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (filament: Omit<Filament, 'id' | 'history'>) => void;
  filament?: Filament | null;
  mode: 'add' | 'edit';
}

const initialFormData = {
  material: 'PLA' as FilamentMaterial,
  color: FILAMENT_COLORS[0],
  remainingGrams: 1000,
  initialGrams: 1000,
  supplier: SUPPLIERS[0],
  purchaseDate: new Date().toISOString().split('T')[0],
  pricePerKg: 100,
};

export function FilamentDialog({
  isOpen,
  onClose,
  onSubmit,
  filament,
  mode,
}: FilamentDialogProps) {
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (filament && mode === 'edit') {
      setFormData({
        material: filament.material,
        color: filament.color,
        remainingGrams: filament.remainingGrams,
        initialGrams: filament.initialGrams,
        supplier: filament.supplier,
        purchaseDate: filament.purchaseDate,
        pricePerKg: filament.pricePerKg,
      });
    } else {
      setFormData(initialFormData);
    }
    setErrors({});
  }, [filament, mode, isOpen]);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (formData.remainingGrams < 0) {
      newErrors.remainingGrams = 'Ilość nie może być ujemna';
    }
    if (formData.remainingGrams > 10000) {
      newErrors.remainingGrams = 'Maksymalna ilość to 10000g';
    }
    if (formData.pricePerKg <= 0) {
      newErrors.pricePerKg = 'Cena musi być większa od 0';
    }
    if (formData.pricePerKg > 1000) {
      newErrors.pricePerKg = 'Maksymalna cena to 1000 PLN/kg';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit(formData);
    onClose();
  };

  const handleColorChange = (colorName: string) => {
    const color = FILAMENT_COLORS.find(c => c.name === colorName);
    if (color) {
      setFormData(prev => ({ ...prev, color }));
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg bg-zinc-900 border-zinc-800 text-zinc-100">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            {mode === 'add' ? (
              <>
                <Plus className="w-5 h-5 text-amber-500" />
                Dodaj nowy filament
              </>
            ) : (
              <>
                <Edit2 className="w-5 h-5 text-amber-500" />
                Edytuj filament
              </>
            )}
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            {mode === 'add' 
              ? 'Dodaj nowy filament do magazynu' 
              : 'Edytuj dane filamentu'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Material */}
          <div className="space-y-2">
            <Label htmlFor="material" className="text-zinc-300">
              Materiał
            </Label>
            <Select
              value={formData.material}
              onValueChange={(value: FilamentMaterial) => 
                setFormData(prev => ({ ...prev, material: value }))
              }
            >
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-zinc-100">
                <SelectValue placeholder="Wybierz materiał" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                {FILAMENT_MATERIALS.map(material => (
                  <SelectItem 
                    key={material} 
                    value={material}
                    className="text-zinc-100 focus:bg-zinc-700 focus:text-zinc-100"
                  >
                    {material}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Color */}
          <div className="space-y-2">
            <Label htmlFor="color" className="text-zinc-300">
              Kolor
            </Label>
            <Select
              value={formData.color.name}
              onValueChange={handleColorChange}
            >
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-zinc-100">
                <div className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded border border-zinc-600"
                    style={{ backgroundColor: formData.color.hex }}
                  />
                  <span>{formData.color.name}</span>
                </div>
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700 max-h-60">
                {FILAMENT_COLORS.map(color => (
                  <SelectItem 
                    key={color.name} 
                    value={color.name}
                    className="text-zinc-100 focus:bg-zinc-700 focus:text-zinc-100"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded border border-zinc-600"
                        style={{ backgroundColor: color.hex }}
                      />
                      <span>{color.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <Label htmlFor="remainingGrams" className="text-zinc-300">
              Ilość (g)
            </Label>
            <div className="relative">
              <Package className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                id="remainingGrams"
                type="number"
                min={0}
                max={10000}
                value={formData.remainingGrams}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  remainingGrams: parseInt(e.target.value) || 0 
                }))}
                className={`
                  pl-10 bg-zinc-800 border-zinc-700 text-zinc-100
                  ${errors.remainingGrams ? 'border-red-500' : ''}
                `}
              />
            </div>
            {errors.remainingGrams && (
              <p className="text-sm text-red-400">{errors.remainingGrams}</p>
            )}
          </div>

          {/* Supplier */}
          <div className="space-y-2">
            <Label htmlFor="supplier" className="text-zinc-300">
              Dostawca
            </Label>
            <Select
              value={formData.supplier}
              onValueChange={(value) => 
                setFormData(prev => ({ ...prev, supplier: value }))
              }
            >
              <SelectTrigger className="bg-zinc-800 border-zinc-700 text-zinc-100">
                <SelectValue placeholder="Wybierz dostawcę" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-800 border-zinc-700">
                {SUPPLIERS.map(supplier => (
                  <SelectItem 
                    key={supplier} 
                    value={supplier}
                    className="text-zinc-100 focus:bg-zinc-700 focus:text-zinc-100"
                  >
                    {supplier}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Purchase Date */}
          <div className="space-y-2">
            <Label htmlFor="purchaseDate" className="text-zinc-300">
              Data zakupu
            </Label>
            <Input
              id="purchaseDate"
              type="date"
              value={formData.purchaseDate}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                purchaseDate: e.target.value 
              }))}
              className="bg-zinc-800 border-zinc-700 text-zinc-100"
            />
          </div>

          {/* Price */}
          <div className="space-y-2">
            <Label htmlFor="pricePerKg" className="text-zinc-300">
              Cena za kg (PLN)
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500">
                zł
              </span>
              <Input
                id="pricePerKg"
                type="number"
                min={1}
                max={1000}
                step={0.01}
                value={formData.pricePerKg}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  pricePerKg: parseFloat(e.target.value) || 0 
                }))}
                className={`
                  pl-10 bg-zinc-800 border-zinc-700 text-zinc-100
                  ${errors.pricePerKg ? 'border-red-500' : ''}
                `}
              />
            </div>
            {errors.pricePerKg && (
              <p className="text-sm text-red-400">{errors.pricePerKg}</p>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
            >
              Anuluj
            </Button>
            <Button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-medium"
            >
              {mode === 'add' ? 'Dodaj filament' : 'Zapisz zmiany'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
