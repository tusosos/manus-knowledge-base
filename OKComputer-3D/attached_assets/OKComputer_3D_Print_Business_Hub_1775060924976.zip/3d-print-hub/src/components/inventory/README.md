# Moduł Magazynu Filamentów

Kompletny moduł do zarządzania magazynem filamentów dla "3D Print Business Hub".

## Funkcjonalności

### 1. Tabela Stanu Magazynu
- Kolumny: Materiał, Kolor, Pozostałość (g), Status, Akcje
- Materiały: PLA, PETG, ABS, TPU, PA, PC
- Pełna paleta kolorów (15+ kolorów)
- Progress bar pokazujący poziom
- Sortowanie po wszystkich kolumnach

### 2. Statusy
- **Dostępny** (>500g) - zielony
- **Niski stan** (200-500g) - amber
- **Krytyczny** (<200g) - czerwony

### 3. Alerty
- Sekcja z filamentami poniżej 200g
- Powiadomienia o niskim stanie
- Przycisk "Zamów więcej"
- Opcja "Zamów wszystkie" dla alertów

### 4. CRUD
- Dodaj nowy filament
- Edytuj ilość
- Usuń filament
- Aktualizuj stan (zużycie/doładowanie)

### 5. Historia
- Data zakupu
- Dostawca
- Cena za kg
- Koszt średni ważony
- Historia operacji (zakup/zużycie/doładowanie)

### 6. Statystyki
- Całkowita wartość magazynu
- Ilość materiałów
- Ilość szpulek
- Najczęściej używany materiał
- Liczba alertów niskiego stanu
- Liczba alertów krytycznych
- Wydajność magazynu

## Komponenty

### InventoryDashboard
Główny komponent łączący wszystkie funkcjonalności.

```tsx
import { InventoryDashboard } from './components/inventory';

function App() {
  return <InventoryDashboard />;
}
```

### InventoryStats
Wyświetla statystyki magazynu w formie kart.

### InventoryAlerts
Sekcja alertów dla filamentów z niskim stanem.

### FilamentTable
Tabela z listą filamentów i akcjami.

### FilamentDialog
Dialog do dodawania/edycji filamentu.

### StockUpdateDialog
Dialog do aktualizacji stanu (zużycie/doładowanie).

### FilamentHistoryDialog
Dialog z historią operacji dla filamentu.

## Hook useInventory

```tsx
const {
  filaments,           // Lista wszystkich filamentów
  addFilament,         // Dodaj nowy filament
  updateFilament,      // Edytuj filament
  deleteFilament,      // Usuń filament
  updateStock,         // Aktualizuj stan
  lowStockFilaments,   // Filamenty z niskim stanem
  criticalStockFilaments, // Filamenty z krytycznym stanem
  alertFilaments,      // Wszystkie alerty
  stats,               // Statystyki magazynu
} = useInventory();
```

## Typy

```tsx
type FilamentMaterial = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'PA' | 'PC';

type FilamentStatus = 'available' | 'low' | 'critical';

interface Filament {
  id: string;
  material: FilamentMaterial;
  color: FilamentColor;
  remainingGrams: number;
  initialGrams: number;
  supplier: string;
  purchaseDate: string;
  pricePerKg: number;
  history: FilamentHistory[];
}
```

## UI/UX

- Dark theme (zinc-950 background)
- Industrial aesthetic (czarny, szary, amber)
- shadcn/ui komponenty
- Framer Motion animacje
- Responsive design
- Mobile-first approach
- Accessibility (WCAG 2.1 AA)

## Zależności

- React 19
- TypeScript
- Tailwind CSS 4
- shadcn/ui
- Framer Motion
- Lucide React
