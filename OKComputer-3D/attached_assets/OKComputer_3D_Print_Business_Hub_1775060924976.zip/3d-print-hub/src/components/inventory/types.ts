// Types for Filament Inventory Module

export type FilamentMaterial = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'PA' | 'PC';

export type FilamentStatus = 'available' | 'low' | 'critical';

export interface FilamentColor {
  name: string;
  hex: string;
}

export interface FilamentHistory {
  id: string;
  date: string;
  type: 'purchase' | 'consumption' | 'restock';
  amount: number;
  supplier?: string;
  pricePerKg?: number;
  note?: string;
}

export interface Filament {
  id: string;
  material: FilamentMaterial;
  color: FilamentColor;
  remainingGrams: number;
  initialGrams: number;
  supplier: string;
  purchaseDate: string;
  pricePerKg: number;
  history: FilamentHistory[];
}

export interface InventoryStats {
  totalValue: number;
  totalMaterials: number;
  totalFilaments: number;
  mostUsedMaterial: FilamentMaterial | null;
  lowStockCount: number;
  criticalStockCount: number;
}

export const FILAMENT_MATERIALS: FilamentMaterial[] = ['PLA', 'PETG', 'ABS', 'TPU', 'PA', 'PC'];

export const FILAMENT_COLORS: FilamentColor[] = [
  { name: 'Czarny', hex: '#1a1a1a' },
  { name: 'Biały', hex: '#f5f5f5' },
  { name: 'Szary', hex: '#6b7280' },
  { name: 'Czerwony', hex: '#dc2626' },
  { name: 'Zielony', hex: '#16a34a' },
  { name: 'Niebieski', hex: '#2563eb' },
  { name: 'Żółty', hex: '#eab308' },
  { name: 'Pomarańczowy', hex: '#f97316' },
  { name: 'Fioletowy', hex: '#9333ea' },
  { name: 'Różowy', hex: '#ec4899' },
  { name: 'Brązowy', hex: '#92400e' },
  { name: 'Beżowy', hex: '#d4c4a8' },
  { name: 'Srebrny', hex: '#9ca3af' },
  { name: 'Złoty', hex: '#d97706' },
  { name: 'Przezroczysty', hex: '#e5e7eb' },
];

export const SUPPLIERS = [
  'Prusa Research',
  'Fiberlogy',
  'Spectrum',
  'Fillamentum',
  'Polymaker',
  'eSun',
  'Hatchbox',
  'Overture',
  'Inne',
];

export const getFilamentStatus = (grams: number): FilamentStatus => {
  if (grams < 200) return 'critical';
  if (grams < 500) return 'low';
  return 'available';
};

export const getStatusColor = (status: FilamentStatus): string => {
  switch (status) {
    case 'available':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    case 'low':
      return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    case 'critical':
      return 'bg-red-500/20 text-red-400 border-red-500/30';
    default:
      return 'bg-zinc-500/20 text-zinc-400 border-zinc-500/30';
  }
};

export const getStatusLabel = (status: FilamentStatus): string => {
  switch (status) {
    case 'available':
      return 'Dostępny';
    case 'low':
      return 'Niski stan';
    case 'critical':
      return 'Krytyczny';
    default:
      return 'Nieznany';
  }
};

export const calculateWeightedAverageCost = (filament: Filament): number => {
  const totalCost = filament.history
    .filter(h => h.type === 'purchase' || h.type === 'restock')
    .reduce((sum, h) => sum + (h.pricePerKg || 0) * (h.amount / 1000), 0);
  
  const totalAmount = filament.history
    .filter(h => h.type === 'purchase' || h.type === 'restock')
    .reduce((sum, h) => sum + h.amount, 0);
  
  return totalAmount > 0 ? (totalCost / totalAmount) * 1000 : filament.pricePerKg;
};
