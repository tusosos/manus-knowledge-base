import { useState, useCallback, useMemo } from 'react';
import type { 
  Filament, 
  FilamentMaterial, 
  FilamentColor, 
  FilamentHistory,
  InventoryStats 
} from './types';
import { getFilamentStatus } from './types';

// Sample initial data
const initialFilaments: Filament[] = [
  {
    id: '1',
    material: 'PLA',
    color: { name: 'Czarny', hex: '#1a1a1a' },
    remainingGrams: 850,
    initialGrams: 1000,
    supplier: 'Fiberlogy',
    purchaseDate: '2024-01-15',
    pricePerKg: 89,
    history: [
      { id: 'h1', date: '2024-01-15', type: 'purchase', amount: 1000, supplier: 'Fiberlogy', pricePerKg: 89, note: 'Zakup początkowy' },
      { id: 'h2', date: '2024-01-20', type: 'consumption', amount: 150, note: 'Drukowanie obudowy' },
    ],
  },
  {
    id: '2',
    material: 'PLA',
    color: { name: 'Biały', hex: '#f5f5f5' },
    remainingGrams: 420,
    initialGrams: 1000,
    supplier: 'Prusa Research',
    purchaseDate: '2024-01-10',
    pricePerKg: 129,
    history: [
      { id: 'h3', date: '2024-01-10', type: 'purchase', amount: 1000, supplier: 'Prusa Research', pricePerKg: 129 },
      { id: 'h4', date: '2024-01-18', type: 'consumption', amount: 200, note: 'Drukowanie figurek' },
      { id: 'h5', date: '2024-01-25', type: 'consumption', amount: 380, note: 'Wielkie zamówienie' },
    ],
  },
  {
    id: '3',
    material: 'PETG',
    color: { name: 'Szary', hex: '#6b7280' },
    remainingGrams: 150,
    initialGrams: 1000,
    supplier: 'Spectrum',
    purchaseDate: '2023-12-20',
    pricePerKg: 79,
    history: [
      { id: 'h6', date: '2023-12-20', type: 'purchase', amount: 1000, supplier: 'Spectrum', pricePerKg: 79 },
      { id: 'h7', date: '2024-01-05', type: 'consumption', amount: 400, note: 'Elementy mechaniczne' },
      { id: 'h8', date: '2024-01-22', type: 'consumption', amount: 450, note: 'Wsporniki' },
    ],
  },
  {
    id: '4',
    material: 'ABS',
    color: { name: 'Czerwony', hex: '#dc2626' },
    remainingGrams: 680,
    initialGrams: 1000,
    supplier: 'Fillamentum',
    purchaseDate: '2024-01-08',
    pricePerKg: 149,
    history: [
      { id: 'h9', date: '2024-01-08', type: 'purchase', amount: 1000, supplier: 'Fillamentum', pricePerKg: 149 },
      { id: 'h10', date: '2024-01-19', type: 'consumption', amount: 320, note: 'Części samochodowe' },
    ],
  },
  {
    id: '5',
    material: 'TPU',
    color: { name: 'Czarny', hex: '#1a1a1a' },
    remainingGrams: 95,
    initialGrams: 500,
    supplier: 'Polymaker',
    purchaseDate: '2023-12-15',
    pricePerKg: 169,
    history: [
      { id: 'h11', date: '2023-12-15', type: 'purchase', amount: 500, supplier: 'Polymaker', pricePerKg: 169 },
      { id: 'h12', date: '2024-01-12', type: 'consumption', amount: 150, note: 'Gumowe elementy' },
      { id: 'h13', date: '2024-01-28', type: 'consumption', amount: 255, note: 'Uszczelki' },
    ],
  },
  {
    id: '6',
    material: 'PA',
    color: { name: 'Naturalny', hex: '#f5deb3' },
    remainingGrams: 920,
    initialGrams: 1000,
    supplier: 'Prusa Research',
    purchaseDate: '2024-01-20',
    pricePerKg: 189,
    history: [
      { id: 'h14', date: '2024-01-20', type: 'purchase', amount: 1000, supplier: 'Prusa Research', pricePerKg: 189 },
      { id: 'h15', date: '2024-01-29', type: 'consumption', amount: 80, note: 'Części techniczne' },
    ],
  },
  {
    id: '7',
    material: 'PC',
    color: { name: 'Przezroczysty', hex: '#e5e7eb' },
    remainingGrams: 280,
    initialGrams: 1000,
    supplier: 'Polymaker',
    purchaseDate: '2023-12-05',
    pricePerKg: 219,
    history: [
      { id: 'h16', date: '2023-12-05', type: 'purchase', amount: 1000, supplier: 'Polymaker', pricePerKg: 219 },
      { id: 'h17', date: '2024-01-08', type: 'consumption', amount: 400, note: 'Osłony' },
      { id: 'h18', date: '2024-01-24', type: 'consumption', amount: 320, note: 'Wzmocnienia' },
    ],
  },
  {
    id: '8',
    material: 'PLA',
    color: { name: 'Niebieski', hex: '#2563eb' },
    remainingGrams: 1000,
    initialGrams: 1000,
    supplier: 'eSun',
    purchaseDate: '2024-01-28',
    pricePerKg: 69,
    history: [
      { id: 'h19', date: '2024-01-28', type: 'purchase', amount: 1000, supplier: 'eSun', pricePerKg: 69 },
    ],
  },
];

export function useInventory() {
  const [filaments, setFilaments] = useState<Filament[]>(initialFilaments);

  // Add new filament
  const addFilament = useCallback((filamentData: Omit<Filament, 'id' | 'history'>) => {
    const newFilament: Filament = {
      ...filamentData,
      id: `fil_${Date.now()}`,
      history: [
        {
          id: `h_${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          type: 'purchase',
          amount: filamentData.initialGrams,
          supplier: filamentData.supplier,
          pricePerKg: filamentData.pricePerKg,
          note: 'Zakup początkowy',
        },
      ],
    };
    setFilaments(prev => [...prev, newFilament]);
  }, []);

  // Update filament
  const updateFilament = useCallback((id: string, updates: Partial<Filament>) => {
    setFilaments(prev =>
      prev.map(f => (f.id === id ? { ...f, ...updates } : f))
    );
  }, []);

  // Delete filament
  const deleteFilament = useCallback((id: string) => {
    setFilaments(prev => prev.filter(f => f.id !== id));
  }, []);

  // Update stock (consumption or restock)
  const updateStock = useCallback((
    id: string, 
    amount: number, 
    type: 'consumption' | 'restock',
    note?: string,
    pricePerKg?: number
  ) => {
    setFilaments(prev =>
      prev.map(f => {
        if (f.id !== id) return f;
        
        const newRemaining = type === 'consumption' 
          ? Math.max(0, f.remainingGrams - amount)
          : f.remainingGrams + amount;
        
        const newHistory: FilamentHistory = {
          id: `h_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          date: new Date().toISOString().split('T')[0],
          type,
          amount,
          note,
          ...(pricePerKg && { pricePerKg }),
        };

        return {
          ...f,
          remainingGrams: newRemaining,
          history: [...f.history, newHistory],
        };
      })
    );
  }, []);

  // Get low stock filaments
  const lowStockFilaments = useMemo(() => {
    return filaments.filter(f => getFilamentStatus(f.remainingGrams) === 'low');
  }, [filaments]);

  // Get critical stock filaments
  const criticalStockFilaments = useMemo(() => {
    return filaments.filter(f => getFilamentStatus(f.remainingGrams) === 'critical');
  }, [filaments]);

  // Get all alert filaments (low + critical)
  const alertFilaments = useMemo(() => {
    return filaments.filter(f => {
      const status = getFilamentStatus(f.remainingGrams);
      return status === 'low' || status === 'critical';
    });
  }, [filaments]);

  // Calculate statistics
  const stats: InventoryStats = useMemo(() => {
    const totalValue = filaments.reduce((sum, f) => {
      return sum + (f.pricePerKg * f.remainingGrams / 1000);
    }, 0);

    const materialCounts = filaments.reduce((acc, f) => {
      acc[f.material] = (acc[f.material] || 0) + f.initialGrams - f.remainingGrams;
      return acc;
    }, {} as Record<string, number>);

    const mostUsedMaterial = Object.entries(materialCounts)
      .sort((a, b) => b[1] - a[1])[0]?.[0] as InventoryStats['mostUsedMaterial'];

    return {
      totalValue,
      totalMaterials: new Set(filaments.map(f => f.material)).size,
      totalFilaments: filaments.length,
      mostUsedMaterial,
      lowStockCount: lowStockFilaments.length,
      criticalStockCount: criticalStockFilaments.length,
    };
  }, [filaments, lowStockFilaments.length, criticalStockFilaments.length]);

  return {
    filaments,
    addFilament,
    updateFilament,
    deleteFilament,
    updateStock,
    lowStockFilaments,
    criticalStockFilaments,
    alertFilaments,
    stats,
  };
}
