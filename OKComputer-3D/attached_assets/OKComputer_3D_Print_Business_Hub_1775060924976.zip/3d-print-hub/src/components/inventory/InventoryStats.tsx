import { motion } from 'framer-motion';
import { 
  Package, 
  TrendingDown, 
  AlertTriangle, 
  TrendingUp,
  Layers,
  BarChart3
} from 'lucide-react';
import type { InventoryStats as Stats, FilamentMaterial } from './types';

interface InventoryStatsProps {
  stats: Stats;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: {
      type: 'spring',
      stiffness: 300,
      damping: 30,
    },
  },
};

const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN',
    minimumFractionDigits: 2,
  }).format(value);
};

export function InventoryStats({ stats }: InventoryStatsProps) {
  const cards = [
    {
      title: 'Wartość magazynu',
      value: formatCurrency(stats.totalValue),
      icon: Package,
      color: 'from-amber-500/20 to-amber-600/10',
      borderColor: 'border-amber-500/30',
      iconColor: 'text-amber-400',
    },
    {
      title: 'Ilość materiałów',
      value: stats.totalMaterials.toString(),
      subtitle: `${stats.totalFilaments} szpulek`,
      icon: Layers,
      color: 'from-blue-500/20 to-blue-600/10',
      borderColor: 'border-blue-500/30',
      iconColor: 'text-blue-400',
    },
    {
      title: 'Niski stan',
      value: stats.lowStockCount.toString(),
      subtitle: 'Wymaga uwagi',
      icon: TrendingDown,
      color: 'from-amber-500/20 to-amber-600/10',
      borderColor: 'border-amber-500/30',
      iconColor: 'text-amber-400',
      alert: stats.lowStockCount > 0,
    },
    {
      title: 'Krytyczny stan',
      value: stats.criticalStockCount.toString(),
      subtitle: 'Natychmiastowa akcja',
      icon: AlertTriangle,
      color: 'from-red-500/20 to-red-600/10',
      borderColor: 'border-red-500/30',
      iconColor: 'text-red-400',
      alert: stats.criticalStockCount > 0,
    },
    {
      title: 'Najczęściej używany',
      value: stats.mostUsedMaterial || '-',
      subtitle: 'Materiał',
      icon: BarChart3,
      color: 'from-emerald-500/20 to-emerald-600/10',
      borderColor: 'border-emerald-500/30',
      iconColor: 'text-emerald-400',
    },
    {
      title: 'Wydajność',
      value: `${Math.round((stats.totalFilaments - stats.criticalStockCount - stats.lowStockCount) / stats.totalFilaments * 100)}%`,
      subtitle: 'Dobry stan',
      icon: TrendingUp,
      color: 'from-violet-500/20 to-violet-600/10',
      borderColor: 'border-violet-500/30',
      iconColor: 'text-violet-400',
    },
  ];

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
    >
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          variants={itemVariants}
          className={`
            relative overflow-hidden rounded-xl border ${card.borderColor}
            bg-gradient-to-br ${card.color}
            p-4 backdrop-blur-sm
            ${card.alert ? 'ring-2 ring-red-500/50 animate-pulse' : ''}
          `}
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-zinc-400 uppercase tracking-wider">
                {card.title}
              </p>
              <p className="text-2xl font-bold text-zinc-100 mt-1">
                {card.value}
              </p>
              {card.subtitle && (
                <p className="text-xs text-zinc-500 mt-1">
                  {card.subtitle}
                </p>
              )}
            </div>
            <div className={`
              p-2 rounded-lg bg-zinc-900/50
              ${card.alert ? 'bg-red-500/20' : ''}
            `}>
              <card.icon className={`w-5 h-5 ${card.iconColor}`} />
            </div>
          </div>
          
          {/* Decorative gradient */}
          <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-gradient-to-br from-white/5 to-transparent rounded-full blur-xl" />
        </motion.div>
      ))}
    </motion.div>
  );
}
