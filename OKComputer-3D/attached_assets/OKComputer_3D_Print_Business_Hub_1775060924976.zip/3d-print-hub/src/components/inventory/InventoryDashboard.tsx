import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Plus,
  Search,
  Package,
  Filter,
  ShoppingCart,
} from 'lucide-react';
import { useInventory } from './useInventory';
import { InventoryStats } from './InventoryStats';
import { InventoryAlerts } from './InventoryAlerts';
import { FilamentTable } from './FilamentTable';
import { FilamentDialog } from './FilamentDialog';
import { StockUpdateDialog } from './StockUpdateDialog';
import { FilamentHistoryDialog } from './FilamentHistory';
import type { Filament } from './types';

export function InventoryDashboard() {
  const {
    filaments,
    addFilament,
    updateFilament,
    deleteFilament,
    updateStock,
    alertFilaments,
    stats,
  } = useInventory();

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isStockDialogOpen, setIsStockDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedFilament, setSelectedFilament] = useState<Filament | null>(null);

  // Search and filter
  const [searchQuery, setSearchQuery] = useState('');
  const [showAlertsOnly, setShowAlertsOnly] = useState(false);

  // Filter filaments based on search and alerts filter
  const filteredFilaments = filaments.filter(filament => {
    const matchesSearch = 
      filament.material.toLowerCase().includes(searchQuery.toLowerCase()) ||
      filament.color.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      filament.supplier.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (showAlertsOnly) {
      const isAlert = alertFilaments.some(af => af.id === filament.id);
      return matchesSearch && isAlert;
    }
    
    return matchesSearch;
  });

  // Handlers
  const handleAddFilament = (filamentData: Omit<Filament, 'id' | 'history'>) => {
    addFilament(filamentData);
  };

  const handleEditFilament = (filamentData: Omit<Filament, 'id' | 'history'>) => {
    if (selectedFilament) {
      updateFilament(selectedFilament.id, filamentData);
    }
  };

  const handleDeleteFilament = () => {
    if (selectedFilament) {
      deleteFilament(selectedFilament.id);
      setIsDeleteDialogOpen(false);
      setSelectedFilament(null);
    }
  };

  const handleUpdateStock = (
    amount: number,
    type: 'consumption' | 'restock',
    note?: string,
    pricePerKg?: number
  ) => {
    if (selectedFilament) {
      updateStock(selectedFilament.id, amount, type, note, pricePerKg);
    }
  };

  const handleOrderMore = (filament: Filament) => {
    // In a real app, this would open an order form or redirect to supplier
    const message = `Zamówienie: ${filament.material} - ${filament.color.name}\n` +
      `Dostawca: ${filament.supplier}\n` +
      `Sugerowana ilość: 1000g`;
    alert(message);
  };

  // Dialog openers
  const openEditDialog = (filament: Filament) => {
    setSelectedFilament(filament);
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (filament: Filament) => {
    setSelectedFilament(filament);
    setIsDeleteDialogOpen(true);
  };

  const openStockDialog = (filament: Filament) => {
    setSelectedFilament(filament);
    setIsStockDialogOpen(true);
  };

  const openHistoryDialog = (filament: Filament) => {
    setSelectedFilament(filament);
    setIsHistoryDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-4 md:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-zinc-100 flex items-center gap-3">
              <Package className="w-8 h-8 text-amber-500" />
              Magazyn Filamentów
            </h1>
            <p className="text-zinc-500 mt-1">
              Zarządzaj zapasami materiałów drukarskich
            </p>
          </div>
          
          <Button
            onClick={() => setIsAddDialogOpen(true)}
            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Dodaj filament
          </Button>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6"
      >
        <InventoryStats stats={stats} />
      </motion.div>

      {/* Alerts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-6"
      >
        <InventoryAlerts
          alertFilaments={alertFilaments}
          onOrderMore={handleOrderMore}
        />
      </motion.div>

      {/* Search and Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mb-6"
      >
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <Input
              placeholder="Szukaj filamentu..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-zinc-900 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
          
          <Button
            variant="outline"
            onClick={() => setShowAlertsOnly(!showAlertsOnly)}
            className={`
              border-zinc-800
              ${showAlertsOnly 
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' 
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'}
            `}
          >
            <Filter className="w-4 h-4 mr-2" />
            {showAlertsOnly ? 'Pokaż wszystkie' : 'Tylko alerty'}
          </Button>
        </div>
      </motion.div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <FilamentTable
          filaments={filteredFilaments}
          onEdit={openEditDialog}
          onDelete={openDeleteDialog}
          onUpdateStock={openStockDialog}
          onViewHistory={openHistoryDialog}
          onOrderMore={handleOrderMore}
        />
      </motion.div>

      {/* Dialogs */}
      <FilamentDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onSubmit={handleAddFilament}
        mode="add"
      />

      <FilamentDialog
        isOpen={isEditDialogOpen}
        onClose={() => setIsEditDialogOpen(false)}
        onSubmit={handleEditFilament}
        filament={selectedFilament}
        mode="edit"
      />

      <StockUpdateDialog
        isOpen={isStockDialogOpen}
        onClose={() => setIsStockDialogOpen(false)}
        onUpdate={handleUpdateStock}
        filament={selectedFilament}
      />

      <FilamentHistoryDialog
        isOpen={isHistoryDialogOpen}
        onClose={() => setIsHistoryDialogOpen(false)}
        filament={selectedFilament}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="bg-zinc-900 border-zinc-800 text-zinc-100">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-400">
              <Package className="w-5 h-5" />
              Usunąć filament?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-zinc-400">
              Czy na pewno chcesz usunąć{' '}
              <span className="text-zinc-200 font-medium">
                {selectedFilament?.material} - {selectedFilament?.color.name}
              </span>
              ? Tej operacji nie można cofnąć.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={() => setSelectedFilament(null)}
              className="bg-zinc-800 text-zinc-300 border-zinc-700 hover:bg-zinc-700"
            >
              Anuluj
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteFilament}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
