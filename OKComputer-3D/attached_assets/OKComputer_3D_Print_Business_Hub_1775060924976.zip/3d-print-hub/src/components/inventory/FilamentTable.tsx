import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  MoreHorizontal,
  Edit2,
  Trash2,
  History,
  Minus,
  Plus,
  ShoppingCart,
  Package,
  ArrowUpDown,
} from 'lucide-react';
import type { Filament } from './types';
import { getFilamentStatus, getStatusColor, getStatusLabel } from './types';

interface FilamentTableProps {
  filaments: Filament[];
  onEdit: (filament: Filament) => void;
  onDelete: (filament: Filament) => void;
  onUpdateStock: (filament: Filament) => void;
  onViewHistory: (filament: Filament) => void;
  onOrderMore: (filament: Filament) => void;
}

type SortField = 'material' | 'color' | 'remainingGrams' | 'status';
type SortDirection = 'asc' | 'desc';

export function FilamentTable({
  filaments,
  onEdit,
  onDelete,
  onUpdateStock,
  onViewHistory,
  onOrderMore,
}: FilamentTableProps) {
  const [sortField, setSortField] = useState<SortField>('remainingGrams');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedFilaments = [...filaments].sort((a, b) => {
    let comparison = 0;
    
    switch (sortField) {
      case 'material':
        comparison = a.material.localeCompare(b.material);
        break;
      case 'color':
        comparison = a.color.name.localeCompare(b.color.name);
        break;
      case 'remainingGrams':
        comparison = a.remainingGrams - b.remainingGrams;
        break;
      case 'status':
        const statusA = getFilamentStatus(a.remainingGrams);
        const statusB = getFilamentStatus(b.remainingGrams);
        const statusOrder = { critical: 0, low: 1, available: 2 };
        comparison = statusOrder[statusA] - statusOrder[statusB];
        break;
    }
    
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  const getProgressColor = (grams: number): string => {
    const status = getFilamentStatus(grams);
    switch (status) {
      case 'available':
        return 'bg-emerald-500';
      case 'low':
        return 'bg-amber-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-zinc-500';
    }
  };

  const getProgressPercentage = (grams: number): number => {
    return Math.min(100, Math.round((grams / 1000) * 100));
  };

  const SortHeader = ({ field, children }: { field: SortField; children: React.ReactNode }) => (
    <TableHead 
      className="cursor-pointer hover:bg-zinc-800/50 transition-colors"
      onClick={() => handleSort(field)}
    >
      <div className="flex items-center gap-1">
        {children}
        <ArrowUpDown className={`
          w-3 h-3 transition-colors
          ${sortField === field ? 'text-amber-500' : 'text-zinc-600'}
        `} />
      </div>
    </TableHead>
  );

  return (
    <div className="rounded-xl border border-zinc-800 overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <SortHeader field="material">Materiał</SortHeader>
              <SortHeader field="color">Kolor</SortHeader>
              <SortHeader field="remainingGrams">Pozostałość</SortHeader>
              <SortHeader field="status">Status</SortHeader>
              <TableHead className="text-right">Akcje</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence>
              {sortedFilaments.map((filament, index) => {
                const status = getFilamentStatus(filament.remainingGrams);
                const progressPercentage = getProgressPercentage(filament.remainingGrams);

                return (
                  <motion.tr
                    key={filament.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ delay: index * 0.03 }}
                    className="border-zinc-800 hover:bg-zinc-800/30 transition-colors"
                  >
                    {/* Material */}
                    <TableCell className="font-medium text-zinc-200">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-zinc-500" />
                        {filament.material}
                      </div>
                    </TableCell>

                    {/* Color */}
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-6 h-6 rounded-md border-2 border-zinc-700 shadow-inner"
                          style={{ backgroundColor: filament.color.hex }}
                        />
                        <span className="text-zinc-300">{filament.color.name}</span>
                      </div>
                    </TableCell>

                    {/* Remaining */}
                    <TableCell>
                      <div className="space-y-1 min-w-[150px]">
                        <div className="flex items-center justify-between text-sm">
                          <span className={`
                            font-medium
                            ${status === 'critical' ? 'text-red-400' : 
                              status === 'low' ? 'text-amber-400' : 'text-zinc-300'}
                          `}>
                            {filament.remainingGrams}g
                          </span>
                          <span className="text-zinc-500 text-xs">
                            / 1000g
                          </span>
                        </div>
                        <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${progressPercentage}%` }}
                            transition={{ duration: 0.5, delay: index * 0.05 }}
                            className={`
                              h-full rounded-full
                              ${getProgressColor(filament.remainingGrams)}
                            `}
                          />
                        </div>
                      </div>
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={getStatusColor(status)}
                      >
                        {getStatusLabel(status)}
                      </Badge>
                    </TableCell>

                    {/* Actions */}
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent 
                          align="end" 
                          className="w-48 bg-zinc-900 border-zinc-800"
                        >
                          <DropdownMenuItem
                            onClick={() => onUpdateStock(filament)}
                            className="text-zinc-300 focus:bg-zinc-800 focus:text-zinc-100 cursor-pointer"
                          >
                            <div className="flex items-center gap-2 w-full">
                              <div className="flex">
                                <Minus className="w-4 h-4 text-red-400" />
                                <Plus className="w-4 h-4 text-emerald-400 -ml-1" />
                              </div>
                              Aktualizuj stan
                            </div>
                          </DropdownMenuItem>
                          
                          <DropdownMenuItem
                            onClick={() => onViewHistory(filament)}
                            className="text-zinc-300 focus:bg-zinc-800 focus:text-zinc-100 cursor-pointer"
                          >
                            <History className="w-4 h-4 mr-2 text-blue-400" />
                            Historia
                          </DropdownMenuItem>
                          
                          <DropdownMenuItem
                            onClick={() => onOrderMore(filament)}
                            className="text-zinc-300 focus:bg-zinc-800 focus:text-zinc-100 cursor-pointer"
                          >
                            <ShoppingCart className="w-4 h-4 mr-2 text-amber-400" />
                            Zamów więcej
                          </DropdownMenuItem>
                          
                          <DropdownMenuSeparator className="bg-zinc-800" />
                          
                          <DropdownMenuItem
                            onClick={() => onEdit(filament)}
                            className="text-zinc-300 focus:bg-zinc-800 focus:text-zinc-100 cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4 mr-2 text-zinc-400" />
                            Edytuj
                          </DropdownMenuItem>
                          
                          <DropdownMenuItem
                            onClick={() => onDelete(filament)}
                            className="text-red-400 focus:bg-red-500/10 focus:text-red-400 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Usuń
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                );
              })}
            </AnimatePresence>
          </TableBody>
        </Table>
      </div>

      {filaments.length === 0 && (
        <div className="p-8 text-center">
          <Package className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-zinc-400">
            Brak filamentów w magazynie
          </h3>
          <p className="text-sm text-zinc-500 mt-1">
            Dodaj pierwszy filament, aby rozpocząć
          </p>
        </div>
      )}
    </div>
  );
}
