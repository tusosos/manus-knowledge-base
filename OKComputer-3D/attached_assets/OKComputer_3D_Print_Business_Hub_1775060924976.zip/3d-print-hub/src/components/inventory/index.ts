// Filament Inventory Module Exports

// Main Components
export { InventoryDashboard } from './InventoryDashboard';
export { InventoryStats } from './InventoryStats';
export { InventoryAlerts } from './InventoryAlerts';
export { FilamentTable } from './FilamentTable';

// Dialogs
export { FilamentDialog } from './FilamentDialog';
export { StockUpdateDialog } from './StockUpdateDialog';
export { FilamentHistoryDialog } from './FilamentHistory';

// Hooks
export { useInventory } from './useInventory';

// Types & Constants
export type {
  Filament,
  FilamentMaterial,
  FilamentColor,
  FilamentHistory,
  FilamentStatus,
  InventoryStats as InventoryStatsType,
} from './types';

export {
  FILAMENT_MATERIALS,
  FILAMENT_COLORS,
  SUPPLIERS,
  getFilamentStatus,
  getStatusColor,
  getStatusLabel,
  calculateWeightedAverageCost,
} from './types';
