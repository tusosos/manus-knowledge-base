import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, ShoppingCart, X, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Filament } from './types';
import { getFilamentStatus, getStatusColor, getStatusLabel } from './types';

interface InventoryAlertsProps {
  alertFilaments: Filament[];
  onOrderMore: (filament: Filament) => void;
  onDismiss?: (filamentId: string) => void;
}

export function InventoryAlerts({ 
  alertFilaments, 
  onOrderMore,
  onDismiss 
}: InventoryAlertsProps) {
  if (alertFilaments.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/20">
            <Package className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="font-semibold text-emerald-400">
              Magazyn w dobrym stanie
            </h3>
            <p className="text-sm text-emerald-400/70">
              Wszystkie filamenty mają wystarczającą ilość
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  const criticalCount = alertFilaments.filter(
    f => getFilamentStatus(f.remainingGrams) === 'critical'
  ).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl border border-amber-500/30 bg-amber-500/10 overflow-hidden"
    >
      {/* Header */}
      <div className="p-4 border-b border-amber-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`
              p-2 rounded-lg
              ${criticalCount > 0 ? 'bg-red-500/20' : 'bg-amber-500/20'}
            `}>
              <AlertTriangle className={`
                w-5 h-5
                ${criticalCount > 0 ? 'text-red-400' : 'text-amber-400'}
              `} />
            </div>
            <div>
              <h3 className="font-semibold text-amber-400">
                Alerty niskiego stanu
              </h3>
              <p className="text-sm text-amber-400/70">
                {alertFilaments.length} {alertFilaments.length === 1 ? 'filament wymaga' : 'filamentów wymaga'} uwagi
                {criticalCount > 0 && ` (${criticalCount} krytycznych)`}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="border-amber-500/30 text-amber-400 hover:bg-amber-500/20"
            onClick={() => alertFilaments.forEach(f => onOrderMore(f))}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Zamów wszystkie
          </Button>
        </div>
      </div>

      {/* Alert List */}
      <div className="divide-y divide-amber-500/20">
        <AnimatePresence>
          {alertFilaments.map((filament, index) => {
            const status = getFilamentStatus(filament.remainingGrams);
            const isCritical = status === 'critical';

            return (
              <motion.div
                key={filament.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
                className={`
                  p-4 flex items-center justify-between
                  ${isCritical ? 'bg-red-500/10' : 'bg-amber-500/5'}
                  hover:bg-amber-500/10 transition-colors
                `}
              >
                <div className="flex items-center gap-4">
                  {/* Color indicator */}
                  <div
                    className="w-8 h-8 rounded-lg border-2 border-zinc-700 shadow-inner"
                    style={{ backgroundColor: filament.color.hex }}
                  />
                  
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-zinc-200">
                        {filament.material} - {filament.color.name}
                      </span>
                      <Badge 
                        variant="outline" 
                        className={getStatusColor(status)}
                      >
                        {getStatusLabel(status)}
                      </Badge>
                    </div>
                    <p className="text-sm text-zinc-500">
                      Pozostało: <span className={isCritical ? 'text-red-400 font-medium' : 'text-amber-400'}>
                        {filament.remainingGrams}g
                      </span>
                      {' '}| Dostawca: {filament.supplier}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className={`
                      ${isCritical 
                        ? 'border-red-500/30 text-red-400 hover:bg-red-500/20' 
                        : 'border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
                      }
                    `}
                    onClick={() => onOrderMore(filament)}
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Zamów
                  </Button>
                  {onDismiss && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-zinc-500 hover:text-zinc-300"
                      onClick={() => onDismiss(filament.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
