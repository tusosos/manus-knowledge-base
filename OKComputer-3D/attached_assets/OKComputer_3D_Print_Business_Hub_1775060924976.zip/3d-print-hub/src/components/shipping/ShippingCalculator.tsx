"use client";

import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Truck,
  Package,
  Box,
  History,
  Calculator,
  Save,
  RotateCcw,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import { PackageData, PackagingItem, SavedCalculation, CarrierOption } from "./types";
import {
  packageTemplates,
  defaultPackagingItems,
  carriers,
  calculateCarrierPrice,
  calculatePackagingCost,
  formatPrice,
  formatPostalCode,
} from "./data";

import { PackageForm } from "./PackageForm";
import { PackageTemplates } from "./PackageTemplates";
import { PackagingCosts } from "./PackagingCosts";
import { CarrierComparison } from "./CarrierComparison";
import { ShippingSummary } from "./ShippingSummary";
import { SavedPackages } from "./SavedPackages";

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

export function ShippingCalculator() {
  // State
  const [packageData, setPackageData] = useState<PackageData>({
    weight: 1000,
    dimensions: { length: 20, width: 15, height: 10 },
    value: undefined,
    postalCode: "",
  });

  const [packaging, setPackaging] = useState<PackagingItem[]>(defaultPackagingItems);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("small");
  const [selectedCarrier, setSelectedCarrier] = useState<CarrierOption | null>(null);
  const [savedCalculations, setSavedCalculations] = useState<SavedCalculation[]>([]);
  const [showSummary, setShowSummary] = useState(false);
  const [activeTab, setActiveTab] = useState("calculator");

  // Calculate carrier prices
  const carrierOptions = carriers.flatMap((carrier) =>
    carrier.options.map((option) => ({
      ...option,
      price: calculateCarrierPrice(
        carrier.id,
        option.id,
        packageData.weight,
        packageData.dimensions
      ),
    }))
  );

  // Find cheapest option
  const cheapestOption = carrierOptions.reduce((cheapest, current) =>
    current.price < cheapest.price ? current : cheapest
  );

  // Calculate costs
  const packagingCost = calculatePackagingCost(packaging);
  const shippingCost = selectedCarrier?.price || 0;
  const totalCost = shippingCost + packagingCost;

  // Handle template selection
  const handleTemplateSelect = useCallback((templateId: string) => {
    setSelectedTemplate(templateId);
    const template = packageTemplates.find((t) => t.id === templateId);
    if (template && templateId !== "custom") {
      setPackageData((prev) => ({
        ...prev,
        weight: template.weight,
        dimensions: { ...template.dimensions },
      }));
    }
  }, []);

  // Handle packaging toggle
  const handlePackagingToggle = useCallback((itemId: string) => {
    setPackaging((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, selected: !item.selected } : item
      )
    );
  }, []);

  // Handle carrier selection
  const handleCarrierSelect = useCallback((carrier: CarrierOption) => {
    setSelectedCarrier(carrier);
    setShowSummary(true);
  }, []);

  // Save calculation
  const handleSaveCalculation = useCallback(() => {
    if (!selectedCarrier) return;

    const newCalculation: SavedCalculation = {
      id: Date.now().toString(),
      name: `Paczka ${savedCalculations.length + 1}`,
      date: new Date(),
      packageData: { ...packageData },
      packaging: [...packaging],
      selectedCarrier: { ...selectedCarrier },
      totalCost,
    };

    setSavedCalculations((prev) => [newCalculation, ...prev]);
  }, [selectedCarrier, packageData, packaging, totalCost, savedCalculations.length]);

  // Reset form
  const handleReset = useCallback(() => {
    setPackageData({
      weight: 1000,
      dimensions: { length: 20, width: 15, height: 10 },
      value: undefined,
      postalCode: "",
    });
    setSelectedTemplate("small");
    setPackaging(defaultPackagingItems);
    setSelectedCarrier(null);
    setShowSummary(false);
  }, []);

  // Load saved calculation
  const handleLoadCalculation = useCallback((calc: SavedCalculation) => {
    setPackageData(calc.packageData);
    setPackaging(calc.packaging);
    setSelectedCarrier(calc.selectedCarrier);
    setShowSummary(true);
    setActiveTab("calculator");
  }, []);

  // Delete saved calculation
  const handleDeleteCalculation = useCallback((id: string) => {
    setSavedCalculations((prev) => prev.filter((calc) => calc.id !== id));
  }, []);

  return (
    <motion.div
      className="w-full max-w-7xl mx-auto p-4 md:p-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Header */}
      <motion.div variants={itemVariants} className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-amber-500/10 rounded-lg">
            <Truck className="w-8 h-8 text-amber-500" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-zinc-100">
              Kalkulator Wysyłki
            </h1>
            <p className="text-zinc-400">
              Oblicz koszt wysyłki dla swoich wydruków 3D
            </p>
          </div>
        </div>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <motion.div variants={itemVariants}>
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-zinc-900">
            <TabsTrigger
              value="calculator"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Calculator className="w-4 h-4 mr-2" />
              Kalkulator
            </TabsTrigger>
            <TabsTrigger
              value="saved"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <History className="w-4 h-4 mr-2" />
              Zapisane
              {savedCalculations.length > 0 && (
                <Badge
                  variant="secondary"
                  className="ml-2 bg-zinc-800 text-zinc-300"
                >
                  {savedCalculations.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>
        </motion.div>

        <TabsContent value="calculator" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Form */}
            <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
              {/* Package Templates */}
              <PackageTemplates
                selectedTemplate={selectedTemplate}
                onSelect={handleTemplateSelect}
              />

              {/* Package Form */}
              <PackageForm
                data={packageData}
                onChange={setPackageData}
                isCustom={selectedTemplate === "custom"}
              />

              {/* Packaging Costs */}
              <PackagingCosts
                items={packaging}
                onToggle={handlePackagingToggle}
              />

              {/* Carrier Comparison */}
              <CarrierComparison
                options={carrierOptions}
                selectedCarrier={selectedCarrier}
                onSelect={handleCarrierSelect}
                cheapestOption={cheapestOption}
              />
            </motion.div>

            {/* Right Column - Summary */}
            <motion.div variants={itemVariants} className="space-y-6">
              {/* Summary Card */}
              <ShippingSummary
                shippingCost={shippingCost}
                packagingCost={packagingCost}
                totalCost={totalCost}
                cheapestOption={cheapestOption}
                selectedCarrier={selectedCarrier}
                showSummary={showSummary}
              />

              {/* Actions */}
              <Card className="bg-zinc-900 border-zinc-800">
                <CardContent className="p-4 space-y-3">
                  <Button
                    onClick={handleSaveCalculation}
                    disabled={!selectedCarrier}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-semibold disabled:opacity-50"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Zapisz kalkulację
                  </Button>
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    className="w-full border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Wyczyść formularz
                  </Button>
                </CardContent>
              </Card>

              {/* Quick Info */}
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-zinc-300 flex items-center gap-2">
                    <Box className="w-4 h-4 text-amber-500" />
                    Informacje
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2 text-sm text-zinc-400">
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-1">•</span>
                      <span>Ceny uwzględniają wymiary gabarytowe</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-1">•</span>
                      <span>Waga objętościowa może wpłynąć na cenę</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-1">•</span>
                      <span>Czas dostawy jest orientacyjny</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-500 mt-1">•</span>
                      <span>Ubezpieczenie dla przesyłek powyżej 500zł</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="saved" className="mt-0">
          <SavedPackages
            calculations={savedCalculations}
            onLoad={handleLoadCalculation}
            onDelete={handleDeleteCalculation}
          />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
}
