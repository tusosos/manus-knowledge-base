"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  History,
  Package,
  Truck,
  Calendar,
  Trash2,
  Upload,
  TrendingDown,
  Box,
  Weight,
  Ruler,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

import { SavedCalculation } from "./types";
import { formatPrice } from "./data";

interface SavedPackagesProps {
  calculations: SavedCalculation[];
  onLoad: (calc: SavedCalculation) => void;
  onDelete: (id: string) => void;
}

export function SavedPackages({ calculations, onLoad, onDelete }: SavedPackagesProps) {
  if (calculations.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-12 text-center">
            <div className="w-20 h-20 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-6">
              <History className="w-10 h-10 text-zinc-600" />
            </div>
            <h3 className="text-xl font-semibold text-zinc-300 mb-2">
              Brak zapisanych kalkulacji
            </h3>
            <p className="text-zinc-500 max-w-md mx-auto mb-6">
              Tutaj znajdziesz historię swoich obliczeń. Zapisz kalkulację,
              aby móc do niej wrócić w przyszłości.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-zinc-600">
              <Package className="w-4 h-4" />
              <span>Przejdź do kalkulatora, aby dodać pierwszą kalkulację</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-zinc-500">Zapisane kalkulacje</p>
                <p className="text-2xl font-bold text-zinc-100">{calculations.length}</p>
              </div>
              <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
                <History className="w-5 h-5 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-zinc-500">Średni koszt</p>
                <p className="text-2xl font-bold text-zinc-100">
                  {formatPrice(
                    calculations.reduce((sum, c) => sum + c.totalCost, 0) /
                      calculations.length
                  )}
                </p>
              </div>
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                <TrendingDown className="w-5 h-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-zinc-500">Najniższy koszt</p>
                <p className="text-2xl font-bold text-green-400">
                  {formatPrice(Math.min(...calculations.map((c) => c.totalCost)))}
                </p>
              </div>
              <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Saved Calculations List */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <History className="w-5 h-5 text-amber-500" />
            Historia kalkulacji
          </CardTitle>
          <CardDescription className="text-zinc-500">
            Kliknij na kalkulację, aby załadować jej dane
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-3">
              <AnimatePresence>
                {calculations.map((calc, index) => (
                  <motion.div
                    key={calc.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    className="group"
                  >
                    <Card
                      className="bg-zinc-950 border-zinc-800 hover:border-amber-500/50 transition-all cursor-pointer"
                      onClick={() => onLoad(calc)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 space-y-3">
                            {/* Header */}
                            <div className="flex items-center gap-3">
                              <Badge
                                variant="secondary"
                                className="bg-zinc-800 text-zinc-300"
                              >
                                <Calendar className="w-3 h-3 mr-1" />
                                {calc.date.toLocaleDateString("pl-PL", {
                                  day: "2-digit",
                                  month: "2-digit",
                                  year: "numeric",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </Badge>
                              <span className="text-lg font-semibold text-zinc-100">
                                {calc.name}
                              </span>
                            </div>

                            {/* Details */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                              <div className="flex items-center gap-2 text-sm text-zinc-400">
                                <Weight className="w-4 h-4 text-zinc-500" />
                                {calc.packageData.weight >= 1000
                                  ? `${calc.packageData.weight / 1000} kg`
                                  : `${calc.packageData.weight} g`}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-zinc-400">
                                <Ruler className="w-4 h-4 text-zinc-500" />
                                {calc.packageData.dimensions.length}×
                                {calc.packageData.dimensions.width}×
                                {calc.packageData.dimensions.height} cm
                              </div>
                              <div className="flex items-center gap-2 text-sm text-zinc-400">
                                <Truck className="w-4 h-4 text-zinc-500" />
                                {calc.selectedCarrier.name}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-zinc-400">
                                <Box className="w-4 h-4 text-zinc-500" />
                                {calc.packaging.filter((p) => p.selected).length} materiałów
                              </div>
                            </div>

                            {/* Carrier & Price */}
                            <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="outline"
                                  className="border-zinc-700 text-zinc-400"
                                >
                                  {calc.selectedCarrier.type}
                                </Badge>
                                <span className="text-sm text-zinc-500">
                                  {calc.selectedCarrier.deliveryTime}
                                </span>
                              </div>
                              <span className="text-xl font-bold text-amber-500 font-mono">
                                {formatPrice(calc.totalCost)}
                              </span>
                            </div>
                          </div>

                          {/* Actions */}
                          <div className="flex flex-col gap-2 ml-4">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                onLoad(calc);
                              }}
                              className="text-zinc-400 hover:text-amber-500 hover:bg-amber-500/10"
                            >
                              <Upload className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDelete(calc.id);
                              }}
                              className="text-zinc-400 hover:text-red-500 hover:bg-red-500/10"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </motion.div>
  );
}
