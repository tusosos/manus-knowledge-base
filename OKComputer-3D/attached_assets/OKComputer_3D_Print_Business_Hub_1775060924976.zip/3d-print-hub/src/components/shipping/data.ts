// Shipping data - carriers, templates, and pricing

import { Carrier, PackageTemplate, PackagingItem } from "./types";

// Package templates
export const packageTemplates: PackageTemplate[] = [
  {
    id: "small",
    name: "Mała paczka",
    weight: 1000,
    dimensions: { length: 20, width: 15, height: 10 },
    description: "Do 1kg, 20×15×10cm - idealna na małe wydruki",
    icon: "Box",
  },
  {
    id: "medium",
    name: "Średnia paczka",
    weight: 5000,
    dimensions: { length: 30, width: 20, height: 15 },
    description: "Do 5kg, 30×20×15cm - standardowy rozmiar",
    icon: "Package",
  },
  {
    id: "large",
    name: "Duża paczka",
    weight: 10000,
    dimensions: { length: 40, width: 30, height: 20 },
    description: "Do 10kg, 40×30×20cm - duże projekty",
    icon: "Container",
  },
  {
    id: "custom",
    name: "Własne wymiary",
    weight: 0,
    dimensions: { length: 0, width: 0, height: 0 },
    description: "Zdefiniuj własne parametry paczki",
    icon: "Ruler",
  },
];

// Packaging items
export const defaultPackagingItems: PackagingItem[] = [
  {
    id: "box",
    name: "Karton",
    price: 3.5,
    selected: true,
  },
  {
    id: "bubble",
    name: "Folia bąbelkowa",
    price: 2.0,
    selected: true,
  },
  {
    id: "filler",
    name: "Wypełniacz",
    price: 1.5,
    selected: false,
  },
  {
    id: "tape",
    name: "Taśma pakowa",
    price: 0.5,
    selected: true,
  },
];

// Carriers with pricing logic
export const carriers: Carrier[] = [
  {
    id: "inpost",
    name: "InPost",
    logo: "inpost",
    options: [
      {
        id: "inpost-paczkomat",
        name: "InPost",
        type: "Paczkomat 24/7",
        price: 0, // calculated dynamically
        deliveryTime: "1-2 dni",
        features: ["Odbiór 24/7", "Śledzenie", "Powiadomienia SMS"],
      },
      {
        id: "inpost-kurier",
        name: "InPost",
        type: "Kurier",
        price: 0,
        deliveryTime: "1 dzień",
        features: ["Dostawa do drzwi", "Śledzenie", "Kontakt z kurierem"],
      },
    ],
  },
  {
    id: "poczta",
    name: "Poczta Polska",
    logo: "poczta",
    options: [
      {
        id: "poczta-paczka",
        name: "Poczta Polska",
        type: "Paczka",
        price: 0,
        deliveryTime: "2-3 dni",
        features: ["Odbiór w placówce", "Śledzenie", "Dostępna w całym kraju"],
      },
      {
        id: "poczta-list",
        name: "Poczta Polska",
        type: "List polecony",
        price: 0,
        deliveryTime: "2-4 dni",
        features: ["Małe przesyłki", "Ekonomia", "Potwierdzenie doręczenia"],
      },
    ],
  },
  {
    id: "dpd",
    name: "DPD",
    logo: "dpd",
    options: [
      {
        id: "dpd-standard",
        name: "DPD",
        type: "DPD Classic",
        price: 0,
        deliveryTime: "1-2 dni",
        features: ["Dostawa do drzwi", "Śledzenie online", "Ubezpieczenie"],
      },
      {
        id: "dpd-pickup",
        name: "DPD",
        type: "DPD Pickup",
        price: 0,
        deliveryTime: "2-3 dni",
        features: ["Odbiór w punkcie", "Niższa cena", "Elastyczny odbiór"],
      },
    ],
  },
  {
    id: "dhl",
    name: "DHL",
    logo: "dhl",
    options: [
      {
        id: "dhl-parcel",
        name: "DHL",
        type: "DHL Parcel",
        price: 0,
        deliveryTime: "1-2 dni",
        features: ["Dostawa do drzwi", "Śledzenie", "Ubezpieczenie do 5000zł"],
      },
      {
        id: "dhl-servicepoint",
        name: "DHL",
        type: "DHL ServicePoint",
        price: 0,
        deliveryTime: "2-3 dni",
        features: ["Odbiór w punkcie", "Godziny otwarcia", "Powiadomienia"],
      },
    ],
  },
  {
    id: "orlen",
    name: "Orlen Paczka",
    logo: "orlen",
    options: [
      {
        id: "orlen-standard",
        name: "Orlen Paczka",
        type: "Odbiór w punkcie",
        price: 0,
        deliveryTime: "2-3 dni",
        features: ["Sieć stacji Orlen", "Długie godziny otwarcia", "Śledzenie"],
      },
      {
        id: "orlen-kurier",
        name: "Orlen Paczka",
        type: "Kurier",
        price: 0,
        deliveryTime: "1-2 dni",
        features: ["Dostawa do drzwi", "Szybka dostawa", "Kontakt z kurierem"],
      },
    ],
  },
];

// Pricing calculation based on weight and dimensions
export function calculateCarrierPrice(
  carrierId: string,
  optionId: string,
  weight: number,
  dimensions: { length: number; width: number; height: number }
): number {
  const volume = dimensions.length * dimensions.width * dimensions.height;
  const volumetricWeight = volume / 5000; // Standard volumetric weight divisor
  const chargeableWeight = Math.max(weight / 1000, volumetricWeight); // Convert g to kg

  // Base prices by carrier
  const basePrices: Record<string, number> = {
    "inpost-paczkomat": 11.99,
    "inpost-kurier": 14.99,
    "poczta-paczka": 13.5,
    "poczta-list": 9.5,
    "dpd-standard": 15.99,
    "dpd-pickup": 12.99,
    "dhl-parcel": 16.5,
    "dhl-servicepoint": 13.5,
    "orlen-standard": 10.99,
    "orlen-kurier": 14.5,
  };

  const basePrice = basePrices[optionId] || 15;

  // Weight tiers
  let weightMultiplier = 1;
  if (chargeableWeight <= 1) weightMultiplier = 1;
  else if (chargeableWeight <= 5) weightMultiplier = 1.3;
  else if (chargeableWeight <= 10) weightMultiplier = 1.6;
  else if (chargeableWeight <= 20) weightMultiplier = 2.0;
  else weightMultiplier = 2.5;

  // Size surcharge for large packages
  let sizeSurcharge = 0;
  if (volume > 24000) sizeSurcharge = 3; // > 30x20x40
  else if (volume > 9000) sizeSurcharge = 1.5; // > 30x20x15

  return Math.round((basePrice * weightMultiplier + sizeSurcharge) * 100) / 100;
}

// Calculate packaging cost
export function calculatePackagingCost(items: PackagingItem[]): number {
  return items
    .filter((item) => item.selected)
    .reduce((total, item) => total + item.price, 0);
}

// Format currency
export function formatPrice(price: number): string {
  return new Intl.NumberFormat("pl-PL", {
    style: "currency",
    currency: "PLN",
    minimumFractionDigits: 2,
  }).format(price);
}

// Validate Polish postal code
export function isValidPostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^\d{2}-\d{3}$/;
  return postalCodeRegex.test(postalCode);
}

// Format postal code
export function formatPostalCode(value: string): string {
  const cleaned = value.replace(/\D/g, "");
  if (cleaned.length >= 2) {
    return `${cleaned.slice(0, 2)}-${cleaned.slice(2, 5)}`;
  }
  return cleaned;
}
