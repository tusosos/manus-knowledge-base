"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  Truck,
  Clock,
  Check,
  Star,
  TrendingDown,
  Package,
  MapPin,
  Shield,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

import { CarrierOption } from "./types";
import { formatPrice } from "./data";

interface CarrierComparisonProps {
  options: CarrierOption[];
  selectedCarrier: CarrierOption | null;
  onSelect: (carrier: CarrierOption) => void;
  cheapestOption: CarrierOption;
}

// Carrier logos as simple colored badges
const carrierColors: Record<string, string> = {
  "inpost-paczkomat": "bg-amber-500",
  "inpost-kurier": "bg-amber-500",
  "poczta-paczka": "bg-red-500",
  "poczta-list": "bg-red-500",
  "dpd-standard": "bg-blue-500",
  "dpd-pickup": "bg-blue-500",
  "dhl-parcel": "bg-yellow-500",
  "dhl-servicepoint": "bg-yellow-500",
  "orlen-standard": "bg-green-500",
  "orlen-kurier": "bg-green-500",
};

const carrierLogos: Record<string, string> = {
  "inpost-paczkomat": "InPost",
  "inpost-kurier": "InPost",
  "poczta-paczka": "PP",
  "poczta-list": "PP",
  "dpd-standard": "DPD",
  "dpd-pickup": "DPD",
  "dhl-parcel": "DHL",
  "dhl-servicepoint": "DHL",
  "orlen-standard": "Orlen",
  "orlen-kurier": "Orlen",
};

export function CarrierComparison({
  options,
  selectedCarrier,
  onSelect,
  cheapestOption,
}: CarrierComparisonProps) {
  // Group options by carrier
  const groupedOptions = options.reduce((acc, option) => {
    const carrierName = option.name;
    if (!acc[carrierName]) {
      acc[carrierName] = [];
    }
    acc[carrierName].push(option);
    return acc;
  }, {} as Record<string, CarrierOption[]>);

  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-500" />
            Porównanie przewoźników
          </CardTitle>
          <Badge
            variant="secondary"
            className="bg-green-500/10 text-green-400 border border-green-500/30"
          >
            <TrendingDown className="w-3 h-3 mr-1" />
            Najtańsza: {formatPrice(cheapestOption.price)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <TooltipProvider>
          <div className="space-y-4">
            {Object.entries(groupedOptions).map(([carrierName, carrierOptions], groupIndex) => (
              <motion.div
                key={carrierName}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: groupIndex * 0.1 }}
                className="space-y-2"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className={`
                      w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-zinc-950
                      ${carrierColors[carrierOptions[0].id] || "bg-zinc-500"}
                    `}
                  >
                    {carrierLogos[carrierOptions[0].id] || carrierName.charAt(0)}
                  </div>
                  <span className="font-semibold text-zinc-200">{carrierName}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {carrierOptions.map((option) => {
                    const isSelected = selectedCarrier?.id === option.id;
                    const isCheapest = cheapestOption.id === option.id;

                    return (
                      <motion.div
                        key={option.id}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        onClick={() => onSelect(option)}
                        className={`
                          relative p-4 rounded-lg cursor-pointer transition-all duration-200
                          ${isSelected
                            ? "bg-amber-500/10 border-2 border-amber-500"
                            : "bg-zinc-950 border border-zinc-800 hover:border-zinc-600"
                          }
                        `}
                      >
                        {/* Badges */}
                        <div className="absolute top-2 right-2 flex gap-1">
                          {isCheapest && (
                            <Badge className="bg-green-500 text-zinc-950 text-xs">
                              <Star className="w-3 h-3 mr-1" />
                              Najtańsza
                            </Badge>
                          )}
                          {isSelected && (
                            <div className="w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center">
                              <Check className="w-3 h-3 text-zinc-950" />
                            </div>
                          )}
                        </div>

                        {/* Content */}
                        <div className="space-y-2">
                          <div>
                            <h4 className="font-medium text-zinc-200">{option.type}</h4>
                            <div className="flex items-center gap-1 text-sm text-zinc-500">
                              <Clock className="w-3 h-3" />
                              {option.deliveryTime}
                            </div>
                          </div>

                          {/* Features */}
                          <div className="flex flex-wrap gap-1">
                            {option.features.slice(0, 2).map((feature, idx) => (
                              <Tooltip key={idx}>
                                <TooltipTrigger asChild>
                                  <Badge
                                    variant="secondary"
                                    className="text-xs bg-zinc-800 text-zinc-400 cursor-help"
                                  >
                                    {feature}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{feature}</p>
                                </TooltipContent>
                              </Tooltip>
                            ))}
                            {option.features.length > 2 && (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge
                                    variant="secondary"
                                    className="text-xs bg-zinc-800 text-zinc-400 cursor-help"
                                  >
                                    +{option.features.length - 2}
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <ul className="space-y-1">
                                    {option.features.slice(2).map((f, i) => (
                                      <li key={i}>{f}</li>
                                    ))}
                                  </ul>
                                </TooltipContent>
                              </Tooltip>
                            )}
                          </div>

                          {/* Price */}
                          <div className="pt-2 border-t border-zinc-800">
                            <div className="flex items-baseline justify-between">
                              <span className="text-xs text-zinc-500">Cena:</span>
                              <span
                                className={`
                                  text-xl font-bold font-mono
                                  ${isCheapest ? "text-green-400" : "text-zinc-200"}
                                  ${isSelected ? "text-amber-500" : ""}
                                `}
                              >
                                {formatPrice(option.price)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </div>
        </TooltipProvider>

        {/* Legend */}
        <div className="mt-4 pt-4 border-t border-zinc-800 flex flex-wrap gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-green-400" />
            Najtańsza opcja
          </div>
          <div className="flex items-center gap-1">
            <Check className="w-3 h-3 text-amber-500" />
            Wybrana
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Czas dostawy
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
