// Types for Shipping Calculator

export interface PackageDimensions {
  length: number;
  width: number;
  height: number;
}

export interface PackageData {
  weight: number;
  dimensions: PackageDimensions;
  value?: number;
  postalCode: string;
}

export interface PackagingItem {
  id: string;
  name: string;
  price: number;
  selected: boolean;
}

export interface CarrierOption {
  id: string;
  name: string;
  type: string;
  price: number;
  deliveryTime: string;
  logo?: string;
  features: string[];
}

export interface Carrier {
  id: string;
  name: string;
  logo: string;
  options: CarrierOption[];
}

export interface PackageTemplate {
  id: string;
  name: string;
  weight: number;
  dimensions: PackageDimensions;
  description: string;
  icon: string;
}

export interface SavedCalculation {
  id: string;
  name: string;
  date: Date;
  packageData: PackageData;
  packaging: PackagingItem[];
  selectedCarrier: CarrierOption;
  totalCost: number;
}

export interface ShippingSummary {
  shippingCost: number;
  packagingCost: number;
  totalCost: number;
  cheapestOption: CarrierOption | null;
}
