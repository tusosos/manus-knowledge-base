"use client";

import React from "react";
import { motion } from "framer-motion";
import { Package, Check, Box, Layers, Tape } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

import { PackagingItem } from "./types";
import { formatPrice, calculatePackagingCost } from "./data";

interface PackagingCostsProps {
  items: PackagingItem[];
  onToggle: (itemId: string) => void;
}

const iconMap: Record<string, React.ElementType> = {
  box: Box,
  bubble: Layers,
  filler: Package,
  tape: Tape,
};

export function PackagingCosts({ items, onToggle }: PackagingCostsProps) {
  const totalCost = calculatePackagingCost(items);
  const selectedCount = items.filter((item) => item.selected).length;

  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-500" />
            Koszt opakowania
          </CardTitle>
          <Badge
            variant="secondary"
            className="bg-zinc-800 text-zinc-300"
          >
            {selectedCount} z {items.length}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Packaging Items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {items.map((item, index) => {
            const Icon = iconMap[item.id] || Package;

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onToggle(item.id)}
                className={`
                  flex items-center justify-between p-3 rounded-lg cursor-pointer
                  transition-all duration-200
                  ${item.selected
                    ? "bg-amber-500/10 border border-amber-500/50"
                    : "bg-zinc-950 border border-zinc-800 hover:border-zinc-700"
                  }
                `}
              >
                <div className="flex items-center gap-3">
                  <Checkbox
                    checked={item.selected}
                    onCheckedChange={() => onToggle(item.id)}
                    className={`
                      border-zinc-600 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500
                    `}
                  />
                  <div
                    className={`
                      p-1.5 rounded-md
                      ${item.selected ? "bg-amber-500/20" : "bg-zinc-800"}
                    `}
                  >
                    <Icon
                      className={`w-4 h-4 ${item.selected ? "text-amber-500" : "text-zinc-500"}`}
                    />
                  </div>
                  <span
                    className={`text-sm ${item.selected ? "text-zinc-100" : "text-zinc-400"}`}
                  >
                    {item.name}
                  </span>
                </div>
                <span
                  className={`text-sm font-mono ${
                    item.selected ? "text-amber-500" : "text-zinc-500"
                  }`}
                >
                  {formatPrice(item.price)}
                </span>
              </motion.div>
            );
          })}
        </div>

        {/* Total */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="pt-3 border-t border-zinc-800"
        >
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 text-sm">Koszt opakowania:</span>
            <span className="text-lg font-semibold text-amber-500 font-mono">
              {formatPrice(totalCost)}
            </span>
          </div>
        </motion.div>

        {/* Info */}
        <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
          <p className="text-xs text-zinc-500">
            Wybierz materiały opakowaniowe. Wysoka jakość opakowania zabezpieczy
            Twoje wydruki 3D podczas transportu.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
