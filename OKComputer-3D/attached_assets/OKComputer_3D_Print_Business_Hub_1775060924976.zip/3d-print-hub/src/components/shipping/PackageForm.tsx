"use client";

import React from "react";
import { motion } from "framer-motion";
import { Weight, Ruler, MapPin, Banknote } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { PackageData } from "./types";
import { formatPostalCode, isValidPostalCode } from "./data";

interface PackageFormProps {
  data: PackageData;
  onChange: (data: PackageData) => void;
  isCustom: boolean;
}

export function PackageForm({ data, onChange, isCustom }: PackageFormProps) {
  const handleWeightChange = (value: string) => {
    const weight = parseInt(value) || 0;
    onChange({ ...data, weight });
  };

  const handleDimensionChange = (dimension: keyof typeof data.dimensions, value: string) => {
    const numValue = parseInt(value) || 0;
    onChange({
      ...data,
      dimensions: { ...data.dimensions, [dimension]: numValue },
    });
  };

  const handleValueChange = (value: string) => {
    const numValue = value === "" ? undefined : parseFloat(value);
    onChange({ ...data, value: numValue });
  };

  const handlePostalCodeChange = (value: string) => {
    const formatted = formatPostalCode(value);
    onChange({ ...data, postalCode: formatted });
  };

  const isPostalCodeValid = data.postalCode === "" || isValidPostalCode(data.postalCode);

  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
          <Ruler className="w-5 h-5 text-amber-500" />
          Parametry paczki
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Weight */}
        <div className="space-y-2">
          <Label htmlFor="weight" className="text-zinc-300 flex items-center gap-2">
            <Weight className="w-4 h-4 text-zinc-500" />
            Waga paczki
          </Label>
          <div className="relative">
            <Input
              id="weight"
              type="number"
              min={0}
              max={50000}
              value={data.weight || ""}
              onChange={(e) => handleWeightChange(e.target.value)}
              disabled={!isCustom}
              className={`
                bg-zinc-950 border-zinc-800 text-zinc-100
                focus:border-amber-500 focus:ring-amber-500/20
                disabled:bg-zinc-950/50 disabled:text-zinc-500
                pr-12
              `}
              placeholder="Wprowadź wagę"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">
              g
            </span>
          </div>
          <p className="text-xs text-zinc-500">
            Maksymalna waga: 50kg (50000g)
          </p>
        </div>

        {/* Dimensions */}
        <div className="space-y-2">
          <Label className="text-zinc-300 flex items-center gap-2">
            <Ruler className="w-4 h-4 text-zinc-500" />
            Wymiary (dł × szer × wys)
          </Label>
          <div className="grid grid-cols-3 gap-3">
            <div className="relative">
              <Input
                type="number"
                min={1}
                max={150}
                value={data.dimensions.length || ""}
                onChange={(e) => handleDimensionChange("length", e.target.value)}
                disabled={!isCustom}
                className={`
                  bg-zinc-950 border-zinc-800 text-zinc-100 text-center
                  focus:border-amber-500 focus:ring-amber-500/20
                  disabled:bg-zinc-950/50 disabled:text-zinc-500
                  pr-10
                `}
                placeholder="Dł"
              />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">
                cm
              </span>
            </div>
            <div className="relative">
              <Input
                type="number"
                min={1}
                max={150}
                value={data.dimensions.width || ""}
                onChange={(e) => handleDimensionChange("width", e.target.value)}
                disabled={!isCustom}
                className={`
                  bg-zinc-950 border-zinc-800 text-zinc-100 text-center
                  focus:border-amber-500 focus:ring-amber-500/20
                  disabled:bg-zinc-950/50 disabled:text-zinc-500
                  pr-10
                `}
                placeholder="Szer"
              />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">
                cm
              </span>
            </div>
            <div className="relative">
              <Input
                type="number"
                min={1}
                max={150}
                value={data.dimensions.height || ""}
                onChange={(e) => handleDimensionChange("height", e.target.value)}
                disabled={!isCustom}
                className={`
                  bg-zinc-950 border-zinc-800 text-zinc-100 text-center
                  focus:border-amber-500 focus:ring-amber-500/20
                  disabled:bg-zinc-950/50 disabled:text-zinc-500
                  pr-10
                `}
                placeholder="Wys"
              />
              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">
                cm
              </span>
            </div>
          </div>
          <p className="text-xs text-zinc-500">
            Maksymalne wymiary: 150cm na każdą krawędź
          </p>
        </div>

        {/* Value and Postal Code */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Value */}
          <div className="space-y-2">
            <Label htmlFor="value" className="text-zinc-300 flex items-center gap-2">
              <Banknote className="w-4 h-4 text-zinc-500" />
              Wartość przesyłki
              <span className="text-zinc-500 text-xs">(opcjonalnie)</span>
            </Label>
            <div className="relative">
              <Input
                id="value"
                type="number"
                min={0}
                value={data.value ?? ""}
                onChange={(e) => handleValueChange(e.target.value)}
                className={`
                  bg-zinc-950 border-zinc-800 text-zinc-100
                  focus:border-amber-500 focus:ring-amber-500/20
                  pr-12
                `}
                placeholder="Wartość"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">
                zł
              </span>
            </div>
            <p className="text-xs text-zinc-500">
              Wymagane dla ubezpieczenia
            </p>
          </div>

          {/* Postal Code */}
          <div className="space-y-2">
            <Label htmlFor="postalCode" className="text-zinc-300 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-zinc-500" />
              Kod pocztowy
            </Label>
            <div className="relative">
              <Input
                id="postalCode"
                type="text"
                maxLength={6}
                value={data.postalCode}
                onChange={(e) => handlePostalCodeChange(e.target.value)}
                className={`
                  bg-zinc-950 border-zinc-800 text-zinc-100
                  focus:border-amber-500 focus:ring-amber-500/20
                  uppercase tracking-wider
                  ${!isPostalCodeValid && data.postalCode ? "border-red-500 focus:border-red-500" : ""}
                `}
                placeholder="00-000"
              />
            </div>
            {!isPostalCodeValid && data.postalCode && (
              <p className="text-xs text-red-400">
                Nieprawidłowy format kodu (XX-XXX)
              </p>
            )}
          </div>
        </div>

        {/* Volume Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="p-3 bg-zinc-950 rounded-lg border border-zinc-800"
        >
          <div className="flex justify-between items-center text-sm">
            <span className="text-zinc-500">Objętość:</span>
            <span className="text-zinc-300 font-mono">
              {(data.dimensions.length * data.dimensions.width * data.dimensions.height).toLocaleString("pl-PL")} cm³
            </span>
          </div>
          <div className="flex justify-between items-center text-sm mt-1">
            <span className="text-zinc-500">Waga objętościowa:</span>
            <span className="text-zinc-300 font-mono">
              {(
                (data.dimensions.length * data.dimensions.width * data.dimensions.height) /
                5000
              ).toFixed(2)} kg
            </span>
          </div>
        </motion.div>
      </CardContent>
    </Card>
  );
}
