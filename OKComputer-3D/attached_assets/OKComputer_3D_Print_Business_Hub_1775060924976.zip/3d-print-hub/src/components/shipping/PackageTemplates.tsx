"use client";

import React from "react";
import { motion } from "framer-motion";
import { Box, Package, Container, Ruler, Check } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

import { packageTemplates } from "./data";

interface PackageTemplatesProps {
  selectedTemplate: string;
  onSelect: (templateId: string) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Box,
  Package,
  Container,
  Ruler,
};

export function PackageTemplates({ selectedTemplate, onSelect }: PackageTemplatesProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {packageTemplates.map((template, index) => {
        const Icon = iconMap[template.icon] || Box;
        const isSelected = selectedTemplate === template.id;
        const isCustom = template.id === "custom";

        return (
          <motion.div
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card
              onClick={() => onSelect(template.id)}
              className={`
                cursor-pointer transition-all duration-200
                ${isSelected
                  ? "bg-amber-500/10 border-amber-500 ring-1 ring-amber-500/50"
                  : "bg-zinc-900 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/50"
                }
              `}
            >
              <CardContent className="p-4">
                <div className="flex flex-col items-center text-center">
                  <div
                    className={`
                      p-2 rounded-lg mb-2 transition-colors
                      ${isSelected ? "bg-amber-500/20" : "bg-zinc-800"}
                    `}
                  >
                    <Icon
                      className={`w-6 h-6 ${isSelected ? "text-amber-500" : "text-zinc-400"}`}
                    />
                  </div>
                  <h3
                    className={`font-medium text-sm mb-1 ${
                      isSelected ? "text-amber-500" : "text-zinc-300"
                    }`}
                  >
                    {template.name}
                  </h3>
                  <p className="text-xs text-zinc-500 mb-2">{template.description}</p>
                  
                  {!isCustom && (
                    <div className="flex flex-wrap gap-1 justify-center">
                      <Badge
                        variant="secondary"
                        className="text-xs bg-zinc-800 text-zinc-400"
                      >
                        {template.weight >= 1000
                          ? `${template.weight / 1000}kg`
                          : `${template.weight}g`}
                      </Badge>
                      <Badge
                        variant="secondary"
                        className="text-xs bg-zinc-800 text-zinc-400"
                      >
                        {template.dimensions.length}×{template.dimensions.width}×
                        {template.dimensions.height}cm
                      </Badge>
                    </div>
                  )}

                  {isSelected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="absolute top-2 right-2"
                    >
                      <div className="w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-zinc-950" />
                      </div>
                    </motion.div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}
