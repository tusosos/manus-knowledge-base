"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Receipt,
  Truck,
  Package,
  TrendingDown,
  Star,
  Clock,
  MapPin,
  AlertCircle,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

import { CarrierOption } from "./types";
import { formatPrice } from "./data";

interface ShippingSummaryProps {
  shippingCost: number;
  packagingCost: number;
  totalCost: number;
  cheapestOption: CarrierOption;
  selectedCarrier: CarrierOption | null;
  showSummary: boolean;
}

export function ShippingSummary({
  shippingCost,
  packagingCost,
  totalCost,
  cheapestOption,
  selectedCarrier,
  showSummary,
}: ShippingSummaryProps) {
  return (
    <Card className="bg-zinc-900 border-zinc-800 sticky top-4">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
          <Receipt className="w-5 h-5 text-amber-500" />
          Podsumowanie
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <AnimatePresence mode="wait">
          {showSummary && selectedCarrier ? (
            <motion.div
              key="summary"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-4"
            >
              {/* Selected Carrier */}
              <div className="p-4 bg-zinc-950 rounded-lg border border-zinc-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-zinc-500">Wybrany przewoźnik:</span>
                  {cheapestOption.id === selectedCarrier.id && (
                    <Badge className="bg-green-500/10 text-green-400 border border-green-500/30 text-xs">
                      <Star className="w-3 h-3 mr-1" />
                      Najtańsza
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-amber-500" />
                  <span className="font-medium text-zinc-200">{selectedCarrier.name}</span>
                </div>
                <div className="text-sm text-zinc-400 mt-1">{selectedCarrier.type}</div>
                <div className="flex items-center gap-1 text-sm text-zinc-500 mt-1">
                  <Clock className="w-3 h-3" />
                  {selectedCarrier.deliveryTime}
                </div>
              </div>

              {/* Cost Breakdown */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2 text-zinc-400">
                    <Truck className="w-4 h-4" />
                    <span className="text-sm">Wysyłka</span>
                  </div>
                  <span className="text-zinc-200 font-mono">{formatPrice(shippingCost)}</span>
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2 text-zinc-400">
                    <Package className="w-4 h-4" />
                    <span className="text-sm">Opakowanie</span>
                  </div>
                  <span className="text-zinc-200 font-mono">{formatPrice(packagingCost)}</span>
                </div>

                <Separator className="bg-zinc-800" />

                <motion.div
                  initial={{ scale: 1 }}
                  animate={{ scale: [1, 1.02, 1] }}
                  transition={{ duration: 0.3 }}
                  className="flex justify-between items-center p-3 bg-amber-500/10 rounded-lg border border-amber-500/30"
                >
                  <span className="font-semibold text-zinc-100">Suma:</span>
                  <span className="text-2xl font-bold text-amber-500 font-mono">
                    {formatPrice(totalCost)}
                  </span>
                </motion.div>
              </div>

              {/* Savings info */}
              {cheapestOption.id === selectedCarrier.id && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-3 bg-green-500/10 rounded-lg border border-green-500/30"
                >
                  <div className="flex items-center gap-2 text-green-400">
                    <TrendingDown className="w-4 h-4" />
                    <span className="text-sm font-medium">Wybrałeś najtańszą opcję!</span>
                  </div>
                </motion.div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-8"
            >
              <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-zinc-600" />
              </div>
              <p className="text-zinc-500 mb-2">Wybierz przewoźnika</p>
              <p className="text-zinc-600 text-sm">
                Kliknij na jedną z opcji powyżej, aby zobaczyć podsumowanie
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Cheapest Option Info */}
        <div className="pt-4 border-t border-zinc-800">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="w-4 h-4 text-green-400" />
            <span className="text-sm text-zinc-400">Najtańsza opcja:</span>
          </div>
          <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-zinc-300">
                  {cheapestOption.name} - {cheapestOption.type}
                </div>
                <div className="text-sm text-zinc-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {cheapestOption.deliveryTime}
                </div>
              </div>
              <span className="text-lg font-bold text-green-400 font-mono">
                {formatPrice(cheapestOption.price)}
              </span>
            </div>
          </div>
        </div>

        {/* Note */}
        <div className="flex items-start gap-2 p-3 bg-zinc-950 rounded-lg border border-zinc-800">
          <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-zinc-500">
            Ceny są orientacyjne i mogą się różnić w zależności od aktualnych
            cenników przewoźników.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
