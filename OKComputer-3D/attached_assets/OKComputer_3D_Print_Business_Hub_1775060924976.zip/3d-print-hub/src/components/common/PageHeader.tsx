import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface Breadcrumb {
  label: string;
  href?: string;
}

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumbs?: Breadcrumb[];
  actions?: React.ReactNode;
  className?: string;
}

export function PageHeader({ 
  title, 
  subtitle, 
  breadcrumbs = [], 
  actions,
  className 
}: PageHeaderProps) {
  return (
    <div className={cn('mb-6', className)}>
      {/* Breadcrumbs */}
      {breadcrumbs.length > 0 && (
        <nav className="flex items-center gap-2 text-sm text-zinc-500 mb-3">
          <a 
            href="/" 
            className="flex items-center gap-1 hover:text-amber-500 transition-colors"
          >
            <Home className="h-4 w-4" />
          </a>
          {breadcrumbs.map((crumb, index) => (
            <React.Fragment key={index}>
              <ChevronRight className="h-4 w-4" />
              {crumb.href ? (
                <a 
                  href={crumb.href}
                  className="hover:text-amber-500 transition-colors"
                >
                  {crumb.label}
                </a>
              ) : (
                <span className="text-zinc-300">{crumb.label}</span>
              )}
            </React.Fragment>
          ))}
        </nav>
      )}

      {/* Header Content */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-zinc-100">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-1 text-zinc-400 text-sm sm:text-base">
              {subtitle}
            </p>
          )}
        </div>
        
        {actions && (
          <div className="flex items-center gap-2 flex-wrap">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}

interface PageHeaderActionProps {
  children: React.ReactNode;
  variant?: 'default' | 'outline' | 'ghost';
  onClick?: () => void;
  icon?: React.ElementType;
}

export function PageHeaderAction({ 
  children, 
  variant = 'default',
  onClick,
  icon: Icon
}: PageHeaderActionProps) {
  return (
    <Button 
      variant={variant}
      onClick={onClick}
      className={cn(
        variant === 'default' && 'bg-amber-500 hover:bg-amber-600 text-zinc-950'
      )}
    >
      {Icon && <Icon className="mr-2 h-4 w-4" />}
      {children}
    </Button>
  );
}
