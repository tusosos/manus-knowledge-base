import React from 'react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export type StatusType = 
  | 'success' 
  | 'warning' 
  | 'error' 
  | 'info' 
  | 'pending' 
  | 'processing'
  | 'completed'
  | 'cancelled'
  | 'draft'
  | 'active'
  | 'inactive';

interface StatusBadgeProps {
  status: StatusType;
  label?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  pulse?: boolean;
}

const statusConfig: Record<StatusType, { 
  label: string; 
  variant: string;
  dotColor: string;
}> = {
  success: { 
    label: 'Sukces', 
    variant: 'bg-green-500/10 text-green-500 border-green-500/20',
    dotColor: 'bg-green-500'
  },
  warning: { 
    label: 'Ostrzeżenie', 
    variant: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    dotColor: 'bg-amber-500'
  },
  error: { 
    label: 'Błąd', 
    variant: 'bg-red-500/10 text-red-500 border-red-500/20',
    dotColor: 'bg-red-500'
  },
  info: { 
    label: 'Info', 
    variant: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    dotColor: 'bg-blue-500'
  },
  pending: { 
    label: 'Oczekujące', 
    variant: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
    dotColor: 'bg-zinc-500'
  },
  processing: { 
    label: 'W trakcie', 
    variant: 'bg-cyan-500/10 text-cyan-500 border-cyan-500/20',
    dotColor: 'bg-cyan-500'
  },
  completed: { 
    label: 'Zakończone', 
    variant: 'bg-green-500/10 text-green-500 border-green-500/20',
    dotColor: 'bg-green-500'
  },
  cancelled: { 
    label: 'Anulowane', 
    variant: 'bg-red-500/10 text-red-400 border-red-500/20',
    dotColor: 'bg-red-400'
  },
  draft: { 
    label: 'Wersja robocza', 
    variant: 'bg-zinc-600/10 text-zinc-500 border-zinc-600/20',
    dotColor: 'bg-zinc-500'
  },
  active: { 
    label: 'Aktywny', 
    variant: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    dotColor: 'bg-emerald-500'
  },
  inactive: { 
    label: 'Nieaktywny', 
    variant: 'bg-zinc-600/10 text-zinc-500 border-zinc-600/20',
    dotColor: 'bg-zinc-500'
  },
};

const sizeConfig = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-sm px-2.5 py-0.5',
  lg: 'text-base px-3 py-1',
};

export function StatusBadge({ 
  status, 
  label, 
  className,
  size = 'md',
  pulse = false
}: StatusBadgeProps) {
  const config = statusConfig[status];

  return (
    <Badge
      variant="outline"
      className={cn(
        'font-medium border inline-flex items-center gap-1.5',
        config.variant,
        sizeConfig[size],
        className
      )}
    >
      <span className={cn(
        'w-1.5 h-1.5 rounded-full',
        config.dotColor,
        pulse && 'animate-pulse'
      )} />
      {label || config.label}
    </Badge>
  );
}

// Specialized badges for 3D printing context
interface PrintStatusBadgeProps {
  status: 'queued' | 'printing' | 'paused' | 'completed' | 'failed' | 'cancelled';
  progress?: number;
  className?: string;
}

export function PrintStatusBadge({ status, progress, className }: PrintStatusBadgeProps) {
  const printStatusMap: Record<string, StatusType> = {
    queued: 'pending',
    printing: 'processing',
    paused: 'warning',
    completed: 'completed',
    failed: 'error',
    cancelled: 'cancelled',
  };

  const labels: Record<string, string> = {
    queued: 'W kolejce',
    printing: progress ? `Drukowanie ${progress}%` : 'Drukowanie',
    paused: 'Wstrzymane',
    completed: 'Ukończone',
    failed: 'Błąd',
    cancelled: 'Anulowane',
  };

  return (
    <StatusBadge
      status={printStatusMap[status]}
      label={labels[status]}
      className={className}
      pulse={status === 'printing'}
    />
  );
}

interface OrderStatusBadgeProps {
  status: 'new' | 'confirmed' | 'in_production' | 'ready' | 'shipped' | 'delivered' | 'cancelled';
  className?: string;
}

export function OrderStatusBadge({ status, className }: OrderStatusBadgeProps) {
  const orderStatusMap: Record<string, StatusType> = {
    new: 'info',
    confirmed: 'warning',
    in_production: 'processing',
    ready: 'success',
    shipped: 'success',
    delivered: 'completed',
    cancelled: 'cancelled',
  };

  const labels: Record<string, string> = {
    new: 'Nowe',
    confirmed: 'Potwierdzone',
    in_production: 'W produkcji',
    ready: 'Gotowe',
    shipped: 'Wysłane',
    delivered: 'Dostarczone',
    cancelled: 'Anulowane',
  };

  return (
    <StatusBadge
      status={orderStatusMap[status]}
      label={labels[status]}
      className={className}
    />
  );
}
