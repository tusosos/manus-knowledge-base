import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Package, Search, FolderOpen, Inbox, FileX, AlertCircle } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description?: string;
  icon?: 'package' | 'search' | 'folder' | 'inbox' | 'file' | 'alert' | React.ElementType;
  action?: {
    label: string;
    onClick: () => void;
  };
  secondaryAction?: {
    label: string;
    onClick: () => void;
  };
  className?: string;
}

const iconMap = {
  package: Package,
  search: Search,
  folder: FolderOpen,
  inbox: Inbox,
  file: FileX,
  alert: AlertCircle,
};

export function EmptyState({
  title,
  description,
  icon = 'inbox',
  action,
  secondaryAction,
  className,
}: EmptyStateProps) {
  const IconComponent = typeof icon === 'string' ? iconMap[icon] : icon;

  return (
    <div className={cn(
      'flex flex-col items-center justify-center text-center py-12 px-4',
      'bg-zinc-900/50 rounded-xl border border-zinc-800/50',
      className
    )}>
      <div className="w-16 h-16 bg-zinc-800/80 rounded-2xl flex items-center justify-center mb-4">
        <IconComponent className="h-8 w-8 text-zinc-500" />
      </div>
      
      <h3 className="text-lg font-semibold text-zinc-100 mb-2">
        {title}
      </h3>
      
      {description && (
        <p className="text-zinc-400 text-sm max-w-sm mb-6">
          {description}
        </p>
      )}
      
      <div className="flex flex-col sm:flex-row gap-3">
        {action && (
          <Button
            onClick={action.onClick}
            className="bg-amber-500 hover:bg-amber-600 text-zinc-950"
          >
            {action.label}
          </Button>
        )}
        
        {secondaryAction && (
          <Button
            variant="outline"
            onClick={secondaryAction.onClick}
            className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100"
          >
            {secondaryAction.label}
          </Button>
        )}
      </div>
    </div>
  );
}

// Pre-configured empty states for common scenarios
export function EmptySearchResults({ 
  searchTerm, 
  onClear 
}: { 
  searchTerm: string; 
  onClear: () => void;
}) {
  return (
    <EmptyState
      icon="search"
      title="Brak wyników wyszukiwania"
      description={`Nie znaleziono wyników dla "${searchTerm}". Spróbuj innych słów kluczowych.`}
      action={{
        label: 'Wyczyść wyszukiwanie',
        onClick: onClear,
      }}
    />
  );
}

export function EmptyProjects({ onCreate }: { onCreate: () => void }) {
  return (
    <EmptyState
      icon="folder"
      title="Brak projektów"
      description="Nie masz jeszcze żadnych projektów 3D. Utwórz pierwszy projekt, aby rozpocząć."
      action={{
        label: 'Utwórz projekt',
        onClick: onCreate,
      }}
    />
  );
}

export function EmptyFilaments({ onAdd }: { onAdd: () => void }) {
  return (
    <EmptyState
      icon="package"
      title="Magazyn pusty"
      description="Nie masz jeszcze żadnych filamentów w magazynie. Dodaj pierwszy filament."
      action={{
        label: 'Dodaj filament',
        onClick: onAdd,
      }}
    />
  );
}

export function EmptyQueue() {
  return (
    <EmptyState
      icon="inbox"
      title="Kolejka pusta"
      description="Brak zadań w kolejce druku. Dodaj nowe zadania, aby rozpocząć produkcję."
    />
  );
}

export function ErrorState({ 
  message, 
  onRetry 
}: { 
  message?: string; 
  onRetry?: () => void;
}) {
  return (
    <EmptyState
      icon="alert"
      title="Wystąpił błąd"
      description={message || 'Nie udało się załadować danych. Spróbuj ponownie później.'}
      action={onRetry ? {
        label: 'Spróbuj ponownie',
        onClick: onRetry,
      } : undefined}
    />
  );
}
