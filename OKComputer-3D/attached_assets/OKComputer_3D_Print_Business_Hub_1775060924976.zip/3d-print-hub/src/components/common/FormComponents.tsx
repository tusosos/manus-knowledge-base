import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle } from 'lucide-react';

// ============================================================================
// Form Input Component
// ============================================================================

interface FormInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  helperText?: string;
  error?: string;
  icon?: React.ElementType;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const FormInput = forwardRef<HTMLInputElement, FormInputProps>(
  ({ 
    label, 
    helperText, 
    error, 
    icon: Icon,
    iconPosition = 'left',
    fullWidth = true,
    className,
    ...props 
  }, ref) => {
    return (
      <div className={cn('space-y-2', fullWidth && 'w-full')}>
        {label && (
          <Label 
            htmlFor={props.id || props.name}
            className="text-sm font-medium text-zinc-300"
          >
            {label}
            {props.required && <span className="text-red-500 ml-1">*</span>}
          </Label>
        )}
        
        <div className="relative">
          {Icon && iconPosition === 'left' && (
            <Icon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
          )}
          
          <Input
            ref={ref}
            className={cn(
              'bg-zinc-900 border-zinc-700 text-zinc-100 placeholder:text-zinc-600',
              'focus:border-amber-500 focus:ring-amber-500/20',
              'disabled:bg-zinc-950 disabled:text-zinc-600',
              error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
              Icon && iconPosition === 'left' && 'pl-10',
              Icon && iconPosition === 'right' && 'pr-10',
              className
            )}
            {...props}
          />
          
          {Icon && iconPosition === 'right' && (
            <Icon className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
          )}
        </div>
        
        {error && (
          <div className="flex items-center gap-1.5 text-sm text-red-400">
            <AlertCircle className="h-4 w-4" />
            <span>{error}</span>
          </div>
        )}
        
        {helperText && !error && (
          <p className="text-sm text-zinc-500">{helperText}</p>
        )}
      </div>
    );
  }
);

FormInput.displayName = 'FormInput';

// ============================================================================
// Form Select Component
// ============================================================================

interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface FormSelectProps {
  label?: string;
  helperText?: string;
  error?: string;
  placeholder?: string;
  options: SelectOption[];
  value?: string;
  onChange?: (value: string) => void;
  disabled?: boolean;
  required?: boolean;
  id?: string;
  name?: string;
  fullWidth?: boolean;
  className?: string;
}

export function FormSelect({
  label,
  helperText,
  error,
  placeholder = 'Wybierz...',
  options,
  value,
  onChange,
  disabled = false,
  required = false,
  id,
  name,
  fullWidth = true,
  className,
}: FormSelectProps) {
  return (
    <div className={cn('space-y-2', fullWidth && 'w-full')}>
      {label && (
        <Label 
          htmlFor={id || name}
          className="text-sm font-medium text-zinc-300"
        >
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </Label>
      )}
      
      <Select value={value} onValueChange={onChange} disabled={disabled}>
        <SelectTrigger
          id={id || name}
          className={cn(
            'bg-zinc-900 border-zinc-700 text-zinc-100',
            'focus:ring-amber-500/20 focus:border-amber-500',
            'disabled:bg-zinc-950 disabled:text-zinc-600',
            error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
            className
          )}
        >
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent className="bg-zinc-900 border-zinc-700">
          {options.map((option) => (
            <SelectItem
              key={option.value}
              value={option.value}
              disabled={option.disabled}
              className="text-zinc-300 hover:bg-zinc-800 focus:bg-zinc-800 focus:text-zinc-100 cursor-pointer"
            >
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      {error && (
        <div className="flex items-center gap-1.5 text-sm text-red-400">
          <AlertCircle className="h-4 w-4" />
          <span>{error}</span>
        </div>
      )}
      
      {helperText && !error && (
        <p className="text-sm text-zinc-500">{helperText}</p>
      )}
    </div>
  );
}

// ============================================================================
// Form Textarea Component
// ============================================================================

interface FormTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  helperText?: string;
  error?: string;
  fullWidth?: boolean;
  rows?: number;
}

export const FormTextarea = forwardRef<HTMLTextAreaElement, FormTextareaProps>(
  ({ 
    label, 
    helperText, 
    error, 
    fullWidth = true,
    rows = 4,
    className,
    ...props 
  }, ref) => {
    return (
      <div className={cn('space-y-2', fullWidth && 'w-full')}>
        {label && (
          <Label 
            htmlFor={props.id || props.name}
            className="text-sm font-medium text-zinc-300"
          >
            {label}
            {props.required && <span className="text-red-500 ml-1">*</span>}
          </Label>
        )}
        
        <Textarea
          ref={ref}
          rows={rows}
          className={cn(
            'bg-zinc-900 border-zinc-700 text-zinc-100 placeholder:text-zinc-600',
            'focus:border-amber-500 focus:ring-amber-500/20 resize-vertical',
            'disabled:bg-zinc-950 disabled:text-zinc-600',
            error && 'border-red-500 focus:border-red-500 focus:ring-red-500/20',
            className
          )}
          {...props}
        />
        
        {error && (
          <div className="flex items-center gap-1.5 text-sm text-red-400">
            <AlertCircle className="h-4 w-4" />
            <span>{error}</span>
          </div>
        )}
        
        {helperText && !error && (
          <p className="text-sm text-zinc-500">{helperText}</p>
        )}
      </div>
    );
  }
);

FormTextarea.displayName = 'FormTextarea';

// ============================================================================
// Form Group Component
// ============================================================================

interface FormGroupProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  className?: string;
}

export function FormGroup({ 
  children, 
  title, 
  description,
  className 
}: FormGroupProps) {
  return (
    <div className={cn('space-y-4', className)}>
      {(title || description) && (
        <div className="space-y-1">
          {title && (
            <h3 className="text-lg font-medium text-zinc-100">{title}</h3>
          )}
          {description && (
            <p className="text-sm text-zinc-500">{description}</p>
          )}
        </div>
      )}
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );
}

// ============================================================================
// Form Row Component (for horizontal layouts)
// ============================================================================

interface FormRowProps {
  children: React.ReactNode;
  className?: string;
  gap?: 'sm' | 'md' | 'lg';
}

export function FormRow({ children, className, gap = 'md' }: FormRowProps) {
  const gapClasses = {
    sm: 'gap-2',
    md: 'gap-4',
    lg: 'gap-6',
  };

  return (
    <div className={cn(
      'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
      gapClasses[gap],
      className
    )}>
      {children}
    </div>
  );
}

// ============================================================================
// Form Section Component
// ============================================================================

interface FormSectionProps {
  children: React.ReactNode;
  title: string;
  description?: string;
  icon?: React.ElementType;
  className?: string;
}

export function FormSection({ 
  children, 
  title, 
  description,
  icon: Icon,
  className 
}: FormSectionProps) {
  return (
    <div className={cn(
      'bg-zinc-900/50 rounded-xl border border-zinc-800 p-6',
      className
    )}>
      <div className="flex items-start gap-4 mb-6">
        {Icon && (
          <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
            <Icon className="h-5 w-5 text-amber-500" />
          </div>
        )}
        <div>
          <h3 className="text-lg font-semibold text-zinc-100">{title}</h3>
          {description && (
            <p className="text-sm text-zinc-500 mt-1">{description}</p>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}
