'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, 
  LayoutList, 
  Calendar, 
  Settings2,
  Printer,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { usePrintQueue } from './usePrintQueue';
import { QueueListView } from './QueueListView';
import { CalendarView } from './CalendarView';
import { PrintJobForm } from './PrintJobForm';
import { QueueStatsPanel, ActiveJobProgress } from './QueueStats';
import { OptimizationPanel, QuickActions } from './OptimizationPanel';
import { PrintJobCard } from './PrintJobCard';
import type { PrintJob } from './types';

export function PrintQueueManager() {
  const {
    jobs,
    waitingJobs,
    activeJobs,
    completedJobs,
    isLoading,
    stats,
    suggestions,
    addJob,
    updateJob,
    deleteJob,
    reorderJobs,
    startPrint,
    pausePrint,
    resumePrint,
    completePrint,
    failPrint,
  } = usePrintQueue();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<PrintJob | null>(null);
  const [activeView, setActiveView] = useState('queue');

  const handleAddJob = () => {
    setEditingJob(null);
    setIsFormOpen(true);
  };

  const handleEditJob = (job: PrintJob) => {
    setEditingJob(job);
    setIsFormOpen(true);
  };

  const handleSaveJob = (jobData: Omit<PrintJob, 'id' | 'createdAt' | 'progress'>) => {
    if (editingJob) {
      updateJob(editingJob.id, jobData);
    } else {
      addJob(jobData);
    }
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingJob(null);
  };

  const handleApplyOptimization = (suggestion: { type: string; affectedJobs: string[] }) => {
    if (suggestion.type === 'group-material') {
      // Group jobs by material - reorder waiting jobs
      const materialOrder = ['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'Nylon', 'PC'];
      const sortedWaiting = [...waitingJobs].sort((a, b) => {
        const aIndex = materialOrder.indexOf(a.material);
        const bIndex = materialOrder.indexOf(b.material);
        return aIndex - bIndex;
      });
      reorderJobs([...activeJobs, ...sortedWaiting, ...completedJobs]);
    }
  };

  const handleOptimizePriority = () => {
    const sortedWaiting = [...waitingJobs].sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
    reorderJobs([...activeJobs, ...sortedWaiting, ...completedJobs]);
  };

  const handleClearCompleted = () => {
    completedJobs.forEach(job => deleteJob(job.id));
  };

  const currentPrintingJob = activeJobs.find(j => j.status === 'printing') || null;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        >
          <Printer className="w-12 h-12 text-amber-500" />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold text-zinc-100 flex items-center gap-3">
            <Printer className="w-8 h-8 text-amber-500" />
            Kolejka Druku
          </h1>
          <p className="text-zinc-500 mt-1">
            Zarządzaj zadaniami druku i optymalizuj kolejność
          </p>
        </div>
        <Button
          onClick={handleAddJob}
          className="bg-amber-500 hover:bg-amber-600 text-black font-medium"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nowe zadanie
        </Button>
      </motion.div>

      {/* Stats */}
      <QueueStatsPanel stats={stats} />

      {/* Active Job Progress */}
      {currentPrintingJob && (
        <ActiveJobProgress 
          job={{
            projectName: currentPrintingJob.projectName,
            progress: currentPrintingJob.progress,
            estimatedTimeMinutes: currentPrintingJob.estimatedTimeMinutes,
            material: currentPrintingJob.material,
          }}
        />
      )}

      {/* Main Content */}
      <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
        <TabsList className="bg-zinc-900 border border-zinc-800 p-1 w-full sm:w-auto">
          <TabsTrigger 
            value="queue" 
            className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-400 flex-1 sm:flex-none"
          >
            <LayoutList className="w-4 h-4 mr-2" />
            Kolejka
          </TabsTrigger>
          <TabsTrigger 
            value="calendar"
            className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-400 flex-1 sm:flex-none"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Kalendarz
          </TabsTrigger>
          <TabsTrigger 
            value="optimization"
            className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-400 flex-1 sm:flex-none"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Optymalizacja
          </TabsTrigger>
        </TabsList>

        <AnimatePresence mode="wait">
          <TabsContent value="queue" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <QueueListView
                jobs={jobs}
                waitingJobs={waitingJobs}
                activeJobs={activeJobs}
                completedJobs={completedJobs}
                onEdit={handleEditJob}
                onDelete={deleteJob}
                onStart={startPrint}
                onPause={pausePrint}
                onResume={resumePrint}
                onComplete={completePrint}
                onFail={failPrint}
                onReorder={reorderJobs}
              />
            </motion.div>
          </TabsContent>

          <TabsContent value="calendar" className="mt-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <CalendarView 
                jobs={jobs} 
                onJobClick={handleEditJob}
              />
            </motion.div>
          </TabsContent>

          <TabsContent value="optimization" className="mt-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <QuickActions
                onOptimizeMaterials={() => handleApplyOptimization({ type: 'group-material', affectedJobs: [] })}
                onOptimizePriority={handleOptimizePriority}
                onClearCompleted={handleClearCompleted}
              />
              
              <div className="mt-6">
                <OptimizationPanel
                  suggestions={suggestions}
                  onApply={handleApplyOptimization}
                />
              </div>
            </motion.div>
          </TabsContent>
        </AnimatePresence>
      </Tabs>

      {/* Job Form Dialog */}
      <PrintJobForm
        job={editingJob}
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSave={handleSaveJob}
      />
    </div>
  );
}
