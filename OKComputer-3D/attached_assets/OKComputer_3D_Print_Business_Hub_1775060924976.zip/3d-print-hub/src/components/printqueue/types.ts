export type PrintStatus = 'waiting' | 'printing' | 'paused' | 'completed' | 'failed';
export type PrinterHead = 'left' | 'right' | 'both';
export type ViewMode = 'list' | 'calendar-day' | 'calendar-week';
export type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'ASA' | 'Nylon' | 'PC';

export interface PrintJob {
  id: string;
  projectName: string;
  client: string;
  material: MaterialType;
  color: string;
  estimatedTimeMinutes: number;
  actualTimeMinutes?: number;
  status: PrintStatus;
  printerHead: PrinterHead;
  priority: number;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  progress: number;
  quantity: number;
  notes?: string;
  thumbnail?: string;
}

export interface TimeSlot {
  start: Date;
  end: Date;
  job: PrintJob;
}

export interface PrinterSchedule {
  date: Date;
  slots: TimeSlot[];
}

export interface OptimizationSuggestion {
  type: 'group-material' | 'reorder-priority' | 'combine-jobs';
  message: string;
  affectedJobs: string[];
  timeSaved: number;
}

export interface QueueStats {
  totalJobs: number;
  waitingJobs: number;
  printingJobs: number;
  completedJobs: number;
  totalEstimatedTime: number;
  estimatedCompletion: Date | null;
}

export const MATERIAL_COLORS: Record<MaterialType, string> = {
  PLA: '#22c55e',
  PETG: '#3b82f6',
  ABS: '#ef4444',
  TPU: '#a855f7',
  ASA: '#f59e0b',
  Nylon: '#ec4899',
  PC: '#06b6d4',
};

export const STATUS_COLORS: Record<PrintStatus, string> = {
  waiting: '#6b7280',
  printing: '#f59e0b',
  paused: '#ef4444',
  completed: '#22c55e',
  failed: '#dc2626',
};

export const STATUS_LABELS: Record<PrintStatus, string> = {
  waiting: 'Oczekuje',
  printing: 'Drukuje',
  paused: 'Wstrzymane',
  completed: 'Gotowe',
  failed: 'Błąd',
};

export const PRINTER_HEAD_LABELS: Record<PrinterHead, string> = {
  left: 'Lewa głowica',
  right: 'Prawa głowica',
  both: 'Obie głowice',
};
