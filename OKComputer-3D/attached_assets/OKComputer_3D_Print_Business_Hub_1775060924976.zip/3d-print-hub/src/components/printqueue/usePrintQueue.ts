'use client';

import { useState, useCallback, useMemo, useEffect } from 'react';
import type { PrintJob, PrintStatus, OptimizationSuggestion, QueueStats, MaterialType, PrinterHead } from './types';

const generateId = () => Math.random().toString(36).substring(2, 9);

const createMockJobs = (): PrintJob[] => [
  {
    id: generateId(),
    projectName: 'Obudowa Raspberry Pi 4',
    client: 'Tech Solutions Sp. z o.o.',
    material: 'PLA',
    color: 'Czarny',
    estimatedTimeMinutes: 180,
    status: 'printing',
    printerHead: 'left',
    priority: 1,
    createdAt: new Date(Date.now() - 3600000),
    startedAt: new Date(Date.now() - 1800000),
    progress: 45,
    quantity: 5,
    notes: 'Wysoka jakość powierzchni',
  },
  {
    id: generateId(),
    projectName: 'Wsporniki montażowe',
    client: 'Auto Parts Plus',
    material: 'PETG',
    color: 'Szary',
    estimatedTimeMinutes: 240,
    status: 'waiting',
    printerHead: 'right',
    priority: 2,
    createdAt: new Date(Date.now() - 7200000),
    progress: 0,
    quantity: 12,
  },
  {
    id: generateId(),
    projectName: 'Klucz dynamometryczny',
    client: 'Mechanik Pro',
    material: 'ABS',
    color: 'Czerwony',
    estimatedTimeMinutes: 360,
    status: 'waiting',
    printerHead: 'left',
    priority: 3,
    createdAt: new Date(Date.now() - 10800000),
    progress: 0,
    quantity: 2,
  },
  {
    id: generateId(),
    projectName: 'Uszczelki silnika',
    client: 'Auto Parts Plus',
    material: 'TPU',
    color: 'Czarny',
    estimatedTimeMinutes: 90,
    status: 'waiting',
    printerHead: 'right',
    priority: 2,
    createdAt: new Date(Date.now() - 14400000),
    progress: 0,
    quantity: 20,
  },
  {
    id: generateId(),
    projectName: 'Obudowa czujnika',
    client: 'SensorTech',
    material: 'ASA',
    color: 'Biały',
    estimatedTimeMinutes: 150,
    status: 'completed',
    printerHead: 'left',
    priority: 1,
    createdAt: new Date(Date.now() - 86400000),
    startedAt: new Date(Date.now() - 82800000),
    completedAt: new Date(Date.now() - 80000000),
    progress: 100,
    quantity: 3,
  },
];

export function usePrintQueue() {
  const [jobs, setJobs] = useState<PrintJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setJobs(createMockJobs());
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const addJob = useCallback((jobData: Omit<PrintJob, 'id' | 'createdAt' | 'progress'>) => {
    const newJob: PrintJob = {
      ...jobData,
      id: generateId(),
      createdAt: new Date(),
      progress: 0,
    };
    setJobs(prev => [...prev, newJob]);
    return newJob.id;
  }, []);

  const updateJob = useCallback((id: string, updates: Partial<PrintJob>) => {
    setJobs(prev => prev.map(job => 
      job.id === id ? { ...job, ...updates } : job
    ));
  }, []);

  const deleteJob = useCallback((id: string) => {
    setJobs(prev => prev.filter(job => job.id !== id));
  }, []);

  const reorderJobs = useCallback((newOrder: PrintJob[]) => {
    setJobs(newOrder);
  }, []);

  const startPrint = useCallback((id: string) => {
    setJobs(prev => prev.map(job => 
      job.id === id 
        ? { ...job, status: 'printing' as PrintStatus, startedAt: new Date() }
        : job
    ));
  }, []);

  const pausePrint = useCallback((id: string) => {
    setJobs(prev => prev.map(job => 
      job.id === id 
        ? { ...job, status: 'paused' as PrintStatus }
        : job
    ));
  }, []);

  const resumePrint = useCallback((id: string) => {
    setJobs(prev => prev.map(job => 
      job.id === id 
        ? { ...job, status: 'printing' as PrintStatus }
        : job
    ));
  }, []);

  const completePrint = useCallback((id: string) => {
    setJobs(prev => prev.map(job => 
      job.id === id 
        ? { ...job, status: 'completed' as PrintStatus, completedAt: new Date(), progress: 100 }
        : job
    ));
  }, []);

  const failPrint = useCallback((id: string) => {
    setJobs(prev => prev.map(job => 
      job.id === id 
        ? { ...job, status: 'failed' as PrintStatus }
        : job
    ));
  }, []);

  const updateProgress = useCallback((id: string, progress: number) => {
    setJobs(prev => prev.map(job => 
      job.id === id ? { ...job, progress: Math.min(100, Math.max(0, progress)) } : job
    ));
  }, []);

  const getOptimizationSuggestions = useCallback((): OptimizationSuggestion[] => {
    const suggestions: OptimizationSuggestion[] = [];
    const waitingJobs = jobs.filter(j => j.status === 'waiting');

    // Group by material
    const materialGroups = waitingJobs.reduce((acc, job) => {
      acc[job.material] = acc[job.material] || [];
      acc[job.material].push(job);
      return acc;
    }, {} as Record<string, PrintJob[]>);

    Object.entries(materialGroups).forEach(([material, materialJobs]) => {
      if (materialJobs.length >= 2) {
        const timeSaved = materialJobs.length * 15;
        suggestions.push({
          type: 'group-material',
          message: `Grupuj ${materialJobs.length} zadań z materiału ${material} - zaoszczędź ~${timeSaved} min na zmiany filamentu`,
          affectedJobs: materialJobs.map(j => j.id),
          timeSaved,
        });
      }
    });

    // Priority reorder suggestion
    const highPriorityWaiting = waitingJobs.filter(j => j.priority === 1);
    if (highPriorityWaiting.length > 0) {
      const lowerPriorityBefore = waitingJobs.filter(
        j => j.priority > 1 && waitingJobs.indexOf(j) < waitingJobs.findIndex(wj => wj.priority === 1)
      );
      if (lowerPriorityBefore.length > 0) {
        suggestions.push({
          type: 'reorder-priority',
          message: `${highPriorityWaiting.length} zadań o wysokim priorytecie czeka za zadaniami o niższym priorytecie`,
          affectedJobs: highPriorityWaiting.map(j => j.id),
          timeSaved: 0,
        });
      }
    }

    return suggestions;
  }, [jobs]);

  const stats = useMemo<QueueStats>(() => {
    const waitingJobs = jobs.filter(j => j.status === 'waiting');
    const printingJobs = jobs.filter(j => j.status === 'printing');
    const completedJobs = jobs.filter(j => j.status === 'completed');
    
    const totalEstimatedTime = waitingJobs.reduce((sum, job) => sum + job.estimatedTimeMinutes, 0);
    
    let estimatedCompletion: Date | null = null;
    if (waitingJobs.length > 0) {
      estimatedCompletion = new Date(Date.now() + totalEstimatedTime * 60000);
    }

    return {
      totalJobs: jobs.length,
      waitingJobs: waitingJobs.length,
      printingJobs: printingJobs.length,
      completedJobs: completedJobs.length,
      totalEstimatedTime,
      estimatedCompletion,
    };
  }, [jobs]);

  const sortedJobs = useMemo(() => {
    return [...jobs].sort((a, b) => {
      // Active jobs first
      if (a.status === 'printing' && b.status !== 'printing') return -1;
      if (b.status === 'printing' && a.status !== 'printing') return 1;
      
      // Then by priority
      if (a.priority !== b.priority) return a.priority - b.priority;
      
      // Then by creation date
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });
  }, [jobs]);

  const waitingJobs = useMemo(() => 
    sortedJobs.filter(j => j.status === 'waiting'),
    [sortedJobs]
  );

  const activeJobs = useMemo(() => 
    sortedJobs.filter(j => j.status === 'printing' || j.status === 'paused'),
    [sortedJobs]
  );

  const completedJobs = useMemo(() => 
    sortedJobs.filter(j => j.status === 'completed'),
    [sortedJobs]
  );

  return {
    jobs: sortedJobs,
    waitingJobs,
    activeJobs,
    completedJobs,
    isLoading,
    stats,
    suggestions: getOptimizationSuggestions(),
    addJob,
    updateJob,
    deleteJob,
    reorderJobs,
    startPrint,
    pausePrint,
    resumePrint,
    completePrint,
    failPrint,
    updateProgress,
  };
}
