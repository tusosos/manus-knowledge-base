'use client';

import { motion } from 'framer-motion';
import { 
  Clock, 
  Package, 
  Play, 
  CheckCircle2, 
  TrendingUp,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import type { QueueStats } from './types';

interface QueueStatsProps {
  stats: QueueStats;
}

function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins} min`;
  if (mins === 0) return `${hours} h`;
  return `${hours}h ${mins}min`;
}

export function QueueStatsPanel({ stats }: QueueStatsProps) {
  const completionPercentage = stats.totalJobs > 0 
    ? Math.round((stats.completedJobs / stats.totalJobs) * 100) 
    : 0;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-2 md:grid-cols-4 gap-4"
    >
      {/* Total Jobs */}
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-zinc-500 mb-1">Wszystkie zadania</p>
                <p className="text-2xl font-bold text-zinc-100">{stats.totalJobs}</p>
              </div>
              <div className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-zinc-400" />
              </div>
            </div>
            <div className="mt-3">
              <Progress value={completionPercentage} className="h-1.5 bg-zinc-800" />
              <p className="text-xs text-zinc-500 mt-1.5">
                {completionPercentage}% ukończono
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Active Jobs */}
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900 border-zinc-800 hover:border-amber-500/30 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-zinc-500 mb-1">Aktywne druki</p>
                <p className="text-2xl font-bold text-amber-400">{stats.printingJobs}</p>
              </div>
              <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
                <Play className="w-5 h-5 text-amber-500" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-amber-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${(stats.printingJobs / Math.max(stats.totalJobs, 1)) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Waiting Jobs */}
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-zinc-500 mb-1">Oczekujące</p>
                <p className="text-2xl font-bold text-zinc-100">{stats.waitingJobs}</p>
              </div>
              <div className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-zinc-400" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-xs text-zinc-500">
                Całkowity czas: <span className="text-zinc-300">{formatDuration(stats.totalEstimatedTime)}</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Estimated Completion */}
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900 border-zinc-800 hover:border-green-500/30 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-zinc-500 mb-1">Szacowane zakończenie</p>
                <p className="text-lg font-bold text-green-400">
                  {stats.estimatedCompletion ? (
                    stats.estimatedCompletion.toLocaleDateString('pl-PL', {
                      day: '2-digit',
                      month: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  ) : (
                    '—'
                  )}
                </p>
              </div>
              <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                <Calendar className="w-5 h-5 text-green-500" />
              </div>
            </div>
            <div className="mt-3">
              {stats.estimatedCompletion && (
                <p className="text-xs text-zinc-500">
                  Za <span className="text-zinc-300">{formatDuration(stats.totalEstimatedTime)}</span>
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

interface ActiveJobProgressProps {
  job: {
    projectName: string;
    progress: number;
    estimatedTimeMinutes: number;
    material: string;
  } | null;
}

export function ActiveJobProgress({ job }: ActiveJobProgressProps) {
  if (!job) return null;

  const remainingMinutes = Math.ceil(job.estimatedTimeMinutes * (1 - job.progress / 100));

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-amber-500/10 to-zinc-900 border border-amber-500/30 rounded-lg p-4"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-amber-500 animate-pulse" />
          </div>
          <div>
            <p className="text-sm text-zinc-500">Aktualnie drukowane</p>
            <p className="font-semibold text-zinc-100">{job.projectName}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-amber-400">{job.progress}%</p>
          <p className="text-xs text-zinc-500">
            Pozostało: {formatDuration(remainingMinutes)}
          </p>
        </div>
      </div>
      
      <div className="relative">
        <Progress value={job.progress} className="h-3 bg-zinc-800" />
        <motion.div
          className="absolute top-0 left-0 h-full bg-amber-500/30 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${job.progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      <div className="flex items-center justify-between mt-3 text-xs text-zinc-500">
        <span>Materiał: {job.material}</span>
        <span>Szacowany czas: {formatDuration(job.estimatedTimeMinutes)}</span>
      </div>
    </motion.div>
  );
}
