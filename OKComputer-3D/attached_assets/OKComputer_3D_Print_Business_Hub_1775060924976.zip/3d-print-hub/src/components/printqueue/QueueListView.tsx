'use client';

import { useState } from 'react';
import { motion, Reorder, AnimatePresence } from 'framer-motion';
import { 
  List, 
  Play, 
  Pause, 
  CheckCircle2, 
  Clock,
  AlertTriangle,
  ArrowUpDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PrintJobCard } from './PrintJobCard';
import type { PrintJob } from './types';

interface QueueListViewProps {
  jobs: PrintJob[];
  waitingJobs: PrintJob[];
  activeJobs: PrintJob[];
  completedJobs: PrintJob[];
  onEdit: (job: PrintJob) => void;
  onDelete: (id: string) => void;
  onStart: (id: string) => void;
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onComplete: (id: string) => void;
  onFail: (id: string) => void;
  onReorder: (jobs: PrintJob[]) => void;
}

export function QueueListView({
  jobs,
  waitingJobs,
  activeJobs,
  completedJobs,
  onEdit,
  onDelete,
  onStart,
  onPause,
  onResume,
  onComplete,
  onFail,
  onReorder,
}: QueueListViewProps) {
  const [activeTab, setActiveTab] = useState('all');

  const handleReorder = (newOrder: PrintJob[]) => {
    // Only allow reordering waiting jobs
    const reorderedWaiting = newOrder.filter(j => j.status === 'waiting');
    const otherJobs = jobs.filter(j => j.status !== 'waiting');
    onReorder([...activeJobs, ...reorderedWaiting, ...completedJobs]);
  };

  const getTabCount = (tab: string) => {
    switch (tab) {
      case 'active': return activeJobs.length;
      case 'waiting': return waitingJobs.length;
      case 'completed': return completedJobs.length;
      default: return jobs.length;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <List className="w-5 h-5 text-amber-500" />
          <h2 className="text-lg font-semibold text-zinc-100">Kolejka druku</h2>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-zinc-400 border-zinc-700">
            <ArrowUpDown className="w-3 h-3 mr-1" />
            Przeciągnij aby zmienić kolejność
          </Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
          <TabsTrigger 
            value="all" 
            className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-400"
          >
            Wszystkie
            <Badge variant="secondary" className="ml-2 text-xs">
              {getTabCount('all')}
            </Badge>
          </TabsTrigger>
          <TabsTrigger 
            value="active"
            className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400 text-zinc-400"
          >
            <Play className="w-3 h-3 mr-1" />
            Aktywne
            <Badge variant="secondary" className="ml-2 text-xs bg-amber-500/20 text-amber-400">
              {getTabCount('active')}
            </Badge>
          </TabsTrigger>
          <TabsTrigger 
            value="waiting"
            className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-400"
          >
            <Clock className="w-3 h-3 mr-1" />
            Oczekujące
            <Badge variant="secondary" className="ml-2 text-xs">
              {getTabCount('waiting')}
            </Badge>
          </TabsTrigger>
          <TabsTrigger 
            value="completed"
            className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400 text-zinc-400"
          >
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Zakończone
            <Badge variant="secondary" className="ml-2 text-xs bg-green-500/20 text-green-400">
              {getTabCount('completed')}
            </Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {/* Active jobs first */}
              {activeJobs.map((job) => (
                <PrintJobCard
                  key={job.id}
                  job={job}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onPause={onPause}
                  onResume={onResume}
                  onComplete={onComplete}
                  onFail={onFail}
                />
              ))}
              
              {/* Waiting jobs with drag */}
              {waitingJobs.length > 0 && (
                <div className="pt-2">
                  <div className="flex items-center gap-2 mb-3 px-2">
                    <Clock className="w-4 h-4 text-zinc-500" />
                    <span className="text-sm text-zinc-500">Oczekujące na druk</span>
                  </div>
                  <Reorder.Group 
                    axis="y" 
                    values={waitingJobs} 
                    onReorder={handleReorder}
                    className="space-y-3"
                  >
                    {waitingJobs.map((job) => (
                      <Reorder.Item 
                        key={job.id} 
                        value={job}
                        dragListener={true}
                      >
                        <PrintJobCard
                          job={job}
                          onEdit={onEdit}
                          onDelete={onDelete}
                          onStart={onStart}
                          dragHandleProps={{}}
                        />
                      </Reorder.Item>
                    ))}
                  </Reorder.Group>
                </div>
              )}

              {/* Completed jobs */}
              {completedJobs.length > 0 && (
                <div className="pt-2">
                  <div className="flex items-center gap-2 mb-3 px-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-green-500">Zakończone</span>
                  </div>
                  {completedJobs.map((job) => (
                    <PrintJobCard
                      key={job.id}
                      job={job}
                      onEdit={onEdit}
                      onDelete={onDelete}
                    />
                  ))}
                </div>
              )}
            </AnimatePresence>

            {jobs.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <List className="w-8 h-8 text-zinc-600" />
                </div>
                <h3 className="text-lg font-medium text-zinc-400 mb-2">
                  Kolejka jest pusta
                </h3>
                <p className="text-sm text-zinc-500">
                  Dodaj nowe zadanie druku, aby rozpocząć
                </p>
              </motion.div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="active" className="mt-4">
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {activeJobs.map((job) => (
                <PrintJobCard
                  key={job.id}
                  job={job}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onPause={onPause}
                  onResume={onResume}
                  onComplete={onComplete}
                  onFail={onFail}
                />
              ))}
            </AnimatePresence>
            {activeJobs.length === 0 && (
              <div className="text-center py-12">
                <Pause className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
                <p className="text-zinc-500">Brak aktywnych zadań druku</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="waiting" className="mt-4">
          <div className="space-y-3">
            {waitingJobs.length > 0 ? (
              <Reorder.Group 
                axis="y" 
                values={waitingJobs} 
                onReorder={handleReorder}
                className="space-y-3"
              >
                {waitingJobs.map((job) => (
                  <Reorder.Item 
                    key={job.id} 
                    value={job}
                    dragListener={true}
                  >
                    <PrintJobCard
                      job={job}
                      onEdit={onEdit}
                      onDelete={onDelete}
                      onStart={onStart}
                      dragHandleProps={{}}
                    />
                  </Reorder.Item>
                ))}
              </Reorder.Group>
            ) : (
              <div className="text-center py-12">
                <Clock className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
                <p className="text-zinc-500">Brak oczekujących zadań</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-4">
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {completedJobs.map((job) => (
                <PrintJobCard
                  key={job.id}
                  job={job}
                  onEdit={onEdit}
                  onDelete={onDelete}
                />
              ))}
            </AnimatePresence>
            {completedJobs.length === 0 && (
              <div className="text-center py-12">
                <CheckCircle2 className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
                <p className="text-zinc-500">Brak zakończonych zadań</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
