'use client';

import { useState, useEffect } from 'react';
import { X, Plus, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import type { PrintJob, MaterialType, PrinterHead } from './types';
import { MATERIAL_COLORS } from './types';

interface PrintJobFormProps {
  job?: PrintJob | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (job: Omit<PrintJob, 'id' | 'createdAt' | 'progress'>) => void;
}

const MATERIALS: MaterialType[] = ['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'Nylon', 'PC'];
const COLORS = ['Czarny', 'Biały', 'Szary', 'Czerwony', 'Niebieski', 'Zielony', 'Żółty', 'Pomarańczowy', 'Fioletowy', 'Różowy', 'Przezroczysty'];
const PRIORITIES = [
  { value: 1, label: 'Krytyczny' },
  { value: 2, label: 'Wysoki' },
  { value: 3, label: 'Normalny' },
  { value: 4, label: 'Niski' },
];

export function PrintJobForm({ job, isOpen, onClose, onSave }: PrintJobFormProps) {
  const [formData, setFormData] = useState({
    projectName: '',
    client: '',
    material: 'PLA' as MaterialType,
    color: 'Czarny',
    estimatedTimeMinutes: 60,
    status: 'waiting' as PrintJob['status'],
    printerHead: 'left' as PrinterHead,
    priority: 3,
    quantity: 1,
    notes: '',
  });

  useEffect(() => {
    if (job) {
      setFormData({
        projectName: job.projectName,
        client: job.client,
        material: job.material,
        color: job.color,
        estimatedTimeMinutes: job.estimatedTimeMinutes,
        status: job.status,
        printerHead: job.printerHead,
        priority: job.priority,
        quantity: job.quantity,
        notes: job.notes || '',
      });
    } else {
      setFormData({
        projectName: '',
        client: '',
        material: 'PLA',
        color: 'Czarny',
        estimatedTimeMinutes: 60,
        status: 'waiting',
        printerHead: 'left',
        priority: 3,
        quantity: 1,
        notes: '',
      });
    }
  }, [job, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const handleTimeChange = (value: string) => {
    const hours = parseInt(value) || 0;
    setFormData(prev => ({ ...prev, estimatedTimeMinutes: hours * 60 }));
  };

  const handleMinutesChange = (value: string) => {
    const mins = parseInt(value) || 0;
    setFormData(prev => ({ ...prev, estimatedTimeMinutes: mins }));
  };

  const hours = Math.floor(formData.estimatedTimeMinutes / 60);
  const minutes = formData.estimatedTimeMinutes % 60;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-zinc-100 max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold flex items-center gap-2">
            {job ? (
              <>
                <Save className="w-5 h-5 text-amber-500" />
                Edytuj zadanie druku
              </>
            ) : (
              <>
                <Plus className="w-5 h-5 text-amber-500" />
                Nowe zadanie druku
              </>
            )}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          {/* Project Name */}
          <div className="space-y-2">
            <Label htmlFor="projectName" className="text-zinc-300">
              Nazwa projektu <span className="text-red-500">*</span>
            </Label>
            <Input
              id="projectName"
              value={formData.projectName}
              onChange={(e) => setFormData(prev => ({ ...prev, projectName: e.target.value }))}
              placeholder="np. Obudowa czujnika"
              className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500"
              required
            />
          </div>

          {/* Client */}
          <div className="space-y-2">
            <Label htmlFor="client" className="text-zinc-300">
              Klient <span className="text-red-500">*</span>
            </Label>
            <Input
              id="client"
              value={formData.client}
              onChange={(e) => setFormData(prev => ({ ...prev, client: e.target.value }))}
              placeholder="np. Firma XYZ"
              className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500"
              required
            />
          </div>

          {/* Material & Color */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="material" className="text-zinc-300">Materiał</Label>
              <Select
                value={formData.material}
                onValueChange={(value) => setFormData(prev => ({ ...prev, material: value as MaterialType }))}
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {MATERIALS.map((mat) => (
                    <SelectItem key={mat} value={mat} className="text-zinc-100">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: MATERIAL_COLORS[mat] }}
                        />
                        {mat}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="color" className="text-zinc-300">Kolor</Label>
              <Select
                value={formData.color}
                onValueChange={(value) => setFormData(prev => ({ ...prev, color: value }))}
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {COLORS.map((color) => (
                    <SelectItem key={color} value={color} className="text-zinc-100">
                      {color}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Estimated Time */}
          <div className="space-y-2">
            <Label className="text-zinc-300">Szacowany czas druku</Label>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <Input
                  type="number"
                  min="0"
                  value={hours}
                  onChange={(e) => handleTimeChange(e.target.value)}
                  className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500"
                />
                <span className="text-xs text-zinc-500 mt-1">Godziny</span>
              </div>
              <span className="text-zinc-500">:</span>
              <div className="flex-1">
                <Input
                  type="number"
                  min="0"
                  max="59"
                  value={minutes}
                  onChange={(e) => handleMinutesChange(e.target.value)}
                  className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500"
                />
                <span className="text-xs text-zinc-500 mt-1">Minuty</span>
              </div>
            </div>
          </div>

          {/* Printer Head & Priority */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="printerHead" className="text-zinc-300">Głowica</Label>
              <Select
                value={formData.printerHead}
                onValueChange={(value) => setFormData(prev => ({ ...prev, printerHead: value as PrinterHead }))}
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  <SelectItem value="left" className="text-zinc-100">Lewa</SelectItem>
                  <SelectItem value="right" className="text-zinc-100">Prawa</SelectItem>
                  <SelectItem value="both" className="text-zinc-100">Obie</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority" className="text-zinc-300">Priorytet</Label>
              <Select
                value={formData.priority.toString()}
                onValueChange={(value) => setFormData(prev => ({ ...prev, priority: parseInt(value) }))}
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p.value} value={p.value.toString()} className="text-zinc-100">
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quantity */}
          <div className="space-y-2">
            <Label htmlFor="quantity" className="text-zinc-300">Ilość sztuk</Label>
            <Input
              id="quantity"
              type="number"
              min="1"
              value={formData.quantity}
              onChange={(e) => setFormData(prev => ({ ...prev, quantity: parseInt(e.target.value) || 1 }))}
              className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500"
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-zinc-300">Notatki</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Dodatkowe informacje o projekcie..."
              className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500 min-h-[80px]"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
            >
              <X className="w-4 h-4 mr-2" />
              Anuluj
            </Button>
            <Button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-black font-medium"
            >
              {job ? (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Zapisz zmiany
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  Dodaj do kolejki
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
