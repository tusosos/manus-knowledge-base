'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  Clock,
  Printer,
  CalendarDays,
  Calendar as CalendarIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import type { PrintJob, TimeSlot } from './types';
import { STATUS_COLORS, MATERIAL_COLORS } from './types';

interface CalendarViewProps {
  jobs: PrintJob[];
  onJobClick?: (job: PrintJob) => void;
}

type CalendarViewMode = 'day' | 'week';

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const DAYS = ['Pon', 'Wt', 'Śr', 'Czw', 'Pt', 'Sob', 'Ndz'];

function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}min`;
  return `${hours}h ${mins}min`;
}

function addMinutes(date: Date, minutes: number): Date {
  return new Date(date.getTime() + minutes * 60000);
}

export function CalendarView({ jobs, onJobClick }: CalendarViewProps) {
  const [viewMode, setViewMode] = useState<CalendarViewMode>('week');
  const [currentDate, setCurrentDate] = useState(new Date());

  const activeAndWaitingJobs = useMemo(() => 
    jobs.filter(j => j.status === 'printing' || j.status === 'waiting' || j.status === 'paused'),
    [jobs]
  );

  // Generate schedule based on jobs
  const schedule = useMemo(() => {
    const slots: TimeSlot[] = [];
    let currentTime = new Date();
    
    // Sort by priority and creation date
    const sortedJobs = [...activeAndWaitingJobs].sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    });

    sortedJobs.forEach((job) => {
      if (job.status === 'printing' && job.startedAt) {
        // For printing jobs, use actual start time
        const start = new Date(job.startedAt);
        const end = addMinutes(start, job.estimatedTimeMinutes);
        slots.push({ start, end, job });
      } else {
        // For waiting jobs, schedule after current time or last slot
        const lastSlot = slots[slots.length - 1];
        const start = lastSlot ? lastSlot.end : currentTime;
        const end = addMinutes(start, job.estimatedTimeMinutes);
        slots.push({ start, end, job });
      }
    });

    return slots;
  }, [activeAndWaitingJobs]);

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (viewMode === 'day') {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 1 : -1));
    } else {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
    }
    setCurrentDate(newDate);
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const getWeekDays = () => {
    const startOfWeek = new Date(currentDate);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1);
    startOfWeek.setDate(diff);
    
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      return date;
    });
  };

  const weekDays = getWeekDays();

  const getSlotsForDay = (date: Date) => {
    return schedule.filter(slot => {
      const slotDate = new Date(slot.start);
      return slotDate.toDateString() === date.toDateString();
    });
  };

  const getSlotPosition = (slot: TimeSlot) => {
    const startHour = slot.start.getHours() + slot.start.getMinutes() / 60;
    const duration = (slot.end.getTime() - slot.start.getTime()) / (1000 * 60 * 60);
    return { top: startHour * 60, height: duration * 60 };
  };

  const isToday = (date: Date) => {
    return date.toDateString() === new Date().toDateString();
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <Calendar className="w-5 h-5 text-amber-500" />
          <h2 className="text-lg font-semibold text-zinc-100">Kalendarz druku</h2>
        </div>
        
        <div className="flex items-center gap-3">
          <ToggleGroup 
            type="single" 
            value={viewMode}
            onValueChange={(v) => v && setViewMode(v as CalendarViewMode)}
            className="bg-zinc-900 border border-zinc-800 p-1 rounded-lg"
          >
            <ToggleGroupItem 
              value="day" 
              aria-label="Dzień"
              className="data-[state=on]:bg-zinc-800 data-[state=on]:text-zinc-100 text-zinc-400 px-3 py-1.5"
            >
              <CalendarIcon className="w-4 h-4 mr-1" />
              Dzień
            </ToggleGroupItem>
            <ToggleGroupItem 
              value="week" 
              aria-label="Tydzień"
              className="data-[state=on]:bg-zinc-800 data-[state=on]:text-zinc-100 text-zinc-400 px-3 py-1.5"
            >
              <CalendarDays className="w-4 h-4 mr-1" />
              Tydzień
            </ToggleGroupItem>
          </ToggleGroup>

          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigateDate('prev')}
              className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              onClick={goToToday}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-800"
            >
              Dziś
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigateDate('next')}
              className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Date Display */}
      <div className="text-center">
        <h3 className="text-xl font-semibold text-zinc-100">
          {viewMode === 'day' ? (
            currentDate.toLocaleDateString('pl-PL', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })
          ) : (
            `${weekDays[0].toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' })} - ${weekDays[6].toLocaleDateString('pl-PL', { day: 'numeric', month: 'short', year: 'numeric' })}`
          )}
        </h3>
      </div>

      {/* Calendar Grid */}
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg overflow-hidden">
        {viewMode === 'day' ? (
          // Day View
          <div className="flex">
            {/* Time Column */}
            <div className="w-16 border-r border-zinc-800 bg-zinc-900/80">
              <div className="h-12 border-b border-zinc-800" />
              {HOURS.map(hour => (
                <div 
                  key={hour} 
                  className="h-[60px] border-b border-zinc-800/50 flex items-start justify-center pt-1"
                >
                  <span className="text-xs text-zinc-500">{`${hour.toString().padStart(2, '0')}:00`}</span>
                </div>
              ))}
            </div>

            {/* Day Column */}
            <div className="flex-1 relative">
              <div className="h-12 border-b border-zinc-800 flex items-center justify-center bg-zinc-900/80">
                <span className={`font-medium ${isToday(currentDate) ? 'text-amber-400' : 'text-zinc-300'}`}>
                  {currentDate.toLocaleDateString('pl-PL', { weekday: 'long' })}
                </span>
              </div>
              
              {/* Hour grid lines */}
              {HOURS.map(hour => (
                <div 
                  key={hour} 
                  className="h-[60px] border-b border-zinc-800/30"
                />
              ))}

              {/* Current time indicator */}
              {isToday(currentDate) && (
                <div 
                  className="absolute left-0 right-0 border-t-2 border-red-500 z-20 pointer-events-none"
                  style={{ 
                    top: 12 + (new Date().getHours() * 60 + new Date().getMinutes()) 
                  }}
                >
                  <div className="absolute -left-1.5 -top-1.5 w-3 h-3 bg-red-500 rounded-full" />
                </div>
              )}

              {/* Job slots */}
              {getSlotsForDay(currentDate).map((slot, index) => {
                const pos = getSlotPosition(slot);
                const materialColor = MATERIAL_COLORS[slot.job.material];
                return (
                  <motion.div
                    key={slot.job.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute left-1 right-1 rounded-md p-2 cursor-pointer overflow-hidden"
                    style={{ 
                      top: 12 + pos.top,
                      height: Math.max(pos.height, 40),
                      backgroundColor: `${materialColor}30`,
                      borderLeft: `3px solid ${materialColor}`,
                    }}
                    onClick={() => onJobClick?.(slot.job)}
                  >
                    <div className="flex items-center gap-1.5">
                      <Printer className="w-3 h-3" style={{ color: materialColor }} />
                      <span className="text-xs font-medium text-zinc-100 truncate">
                        {slot.job.projectName}
                      </span>
                    </div>
                    <div className="text-xs text-zinc-400 mt-0.5">
                      {formatDuration(slot.job.estimatedTimeMinutes)}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        ) : (
          // Week View
          <div className="flex">
            {/* Time Column */}
            <div className="w-14 border-r border-zinc-800 bg-zinc-900/80">
              <div className="h-10 border-b border-zinc-800" />
              {HOURS.filter((_, i) => i % 2 === 0).map(hour => (
                <div 
                  key={hour} 
                  className="h-[120px] border-b border-zinc-800/50 flex items-start justify-center pt-1"
                >
                  <span className="text-xs text-zinc-500">{`${hour.toString().padStart(2, '0')}:00`}</span>
                </div>
              ))}
            </div>

            {/* Days Columns */}
            <div className="flex-1 grid grid-cols-7">
              {weekDays.map((date, dayIndex) => (
                <div 
                  key={dayIndex} 
                  className={`border-r border-zinc-800 last:border-r-0 relative ${isToday(date) ? 'bg-amber-500/5' : ''}`}
                >
                  {/* Day Header */}
                  <div className={`h-10 border-b border-zinc-800 flex flex-col items-center justify-center ${isToday(date) ? 'bg-amber-500/10' : 'bg-zinc-900/80'}`}>
                    <span className="text-xs text-zinc-500">{DAYS[dayIndex]}</span>
                    <span className={`text-sm font-medium ${isToday(date) ? 'text-amber-400' : 'text-zinc-300'}`}>
                      {date.getDate()}
                    </span>
                  </div>

                  {/* Hour grid lines */}
                  {HOURS.filter((_, i) => i % 2 === 0).map(hour => (
                    <div 
                      key={hour} 
                      className="h-[120px] border-b border-zinc-800/30"
                    />
                  ))}

                  {/* Current time indicator */}
                  {isToday(date) && (
                    <div 
                      className="absolute left-0 right-0 border-t-2 border-red-500 z-20 pointer-events-none"
                      style={{ 
                        top: 10 + ((new Date().getHours() * 60 + new Date().getMinutes()) / 2)
                      }}
                    >
                      <div className="absolute -left-1 -top-1 w-2 h-2 bg-red-500 rounded-full" />
                    </div>
                  )}

                  {/* Job slots */}
                  {getSlotsForDay(date).map((slot) => {
                    const pos = getSlotPosition(slot);
                    const materialColor = MATERIAL_COLORS[slot.job.material];
                    const height = pos.height / 2; // Scale down for week view
                    return (
                      <motion.div
                        key={slot.job.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="absolute left-0.5 right-0.5 rounded-sm p-1 cursor-pointer overflow-hidden"
                        style={{ 
                          top: 10 + (pos.top / 2),
                          height: Math.max(height, 20),
                          backgroundColor: `${materialColor}40`,
                          borderLeft: `2px solid ${materialColor}`,
                        }}
                        onClick={() => onJobClick?.(slot.job)}
                      >
                        <span className="text-[10px] font-medium text-zinc-100 truncate block">
                          {slot.job.projectName}
                        </span>
                        {height > 25 && (
                          <span className="text-[9px] text-zinc-400">
                            {slot.job.material}
                          </span>
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 flex-wrap">
        <span className="text-sm text-zinc-500">Materiały:</span>
        {Object.entries(MATERIAL_COLORS).map(([material, color]) => (
          <div key={material} className="flex items-center gap-1.5">
            <div 
              className="w-3 h-3 rounded"
              style={{ backgroundColor: color }}
            />
            <span className="text-xs text-zinc-400">{material}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
