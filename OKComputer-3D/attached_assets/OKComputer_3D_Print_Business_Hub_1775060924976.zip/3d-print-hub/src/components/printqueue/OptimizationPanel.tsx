'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { 
  Lightbulb, 
  Layers, 
  ArrowUpDown, 
  Combine, 
  Clock,
  CheckCircle2,
  X,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { OptimizationSuggestion } from './types';

interface OptimizationPanelProps {
  suggestions: OptimizationSuggestion[];
  onApply?: (suggestion: OptimizationSuggestion) => void;
  onDismiss?: (suggestion: OptimizationSuggestion) => void;
}

function getSuggestionIcon(type: OptimizationSuggestion['type']) {
  switch (type) {
    case 'group-material':
      return <Layers className="w-5 h-5 text-blue-400" />;
    case 'reorder-priority':
      return <ArrowUpDown className="w-5 h-5 text-amber-400" />;
    case 'combine-jobs':
      return <Combine className="w-5 h-5 text-green-400" />;
    default:
      return <Lightbulb className="w-5 h-5 text-zinc-400" />;
  }
}

function getSuggestionTitle(type: OptimizationSuggestion['type']) {
  switch (type) {
    case 'group-material':
      return 'Grupowanie materiałów';
    case 'reorder-priority':
      return 'Optymalizacja priorytetów';
    case 'combine-jobs':
      return 'Łączenie zadań';
    default:
      return 'Sugestia';
  }
}

export function OptimizationPanel({ 
  suggestions, 
  onApply, 
  onDismiss 
}: OptimizationPanelProps) {
  if (suggestions.length === 0) {
    return (
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-6 h-6 text-green-500" />
            </div>
            <h3 className="text-lg font-medium text-zinc-300 mb-1">
              Kolejka zoptymalizowana
            </h3>
            <p className="text-sm text-zinc-500">
              Brak sugestii optymalizacji. Kolejka jest dobrze zorganizowana.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalTimeSaved = suggestions.reduce((sum, s) => sum + s.timeSaved, 0);

  return (
    <Card className="bg-zinc-900 border-zinc-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            Sugestie optymalizacji
          </CardTitle>
          <Badge variant="secondary" className="bg-amber-500/20 text-amber-400">
            {suggestions.length}
          </Badge>
        </div>
        {totalTimeSaved > 0 && (
          <p className="text-sm text-zinc-500">
            Potencjalne zaoszczędzenie: <span className="text-green-400 font-medium">{totalTimeSaved} min</span>
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        <AnimatePresence mode="popLayout">
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={`${suggestion.type}-${index}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              layout
              className="bg-zinc-950 border border-zinc-800 rounded-lg p-4 hover:border-zinc-700 transition-colors"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-zinc-900 rounded-lg flex items-center justify-center flex-shrink-0">
                  {getSuggestionIcon(suggestion.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-zinc-200">
                      {getSuggestionTitle(suggestion.type)}
                    </h4>
                    {suggestion.timeSaved > 0 && (
                      <Badge variant="outline" className="text-xs text-green-400 border-green-400/30">
                        <Clock className="w-3 h-3 mr-1" />
                        -{suggestion.timeSaved} min
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-zinc-400">{suggestion.message}</p>
                  
                  {suggestion.affectedJobs.length > 0 && (
                    <p className="text-xs text-zinc-500 mt-2">
                      Dotyczy {suggestion.affectedJobs.length} zadań
                    </p>
                  )}
                </div>
                <div className="flex flex-col gap-2">
                  {onApply && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onApply(suggestion)}
                      className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Zastosuj
                    </Button>
                  )}
                  {onDismiss && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onDismiss(suggestion)}
                      className="text-zinc-500 hover:text-zinc-300"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}

interface QuickActionsProps {
  onOptimizeMaterials?: () => void;
  onOptimizePriority?: () => void;
  onClearCompleted?: () => void;
}

export function QuickActions({ 
  onOptimizeMaterials, 
  onOptimizePriority, 
  onClearCompleted 
}: QuickActionsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {onOptimizeMaterials && (
        <Button
          variant="outline"
          onClick={onOptimizeMaterials}
          className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-blue-400 justify-start"
        >
          <Layers className="w-4 h-4 mr-2 text-blue-400" />
          Grupuj materiały
        </Button>
      )}
      {onOptimizePriority && (
        <Button
          variant="outline"
          onClick={onOptimizePriority}
          className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-amber-400 justify-start"
        >
          <ArrowUpDown className="w-4 h-4 mr-2 text-amber-400" />
          Sortuj priorytetem
        </Button>
      )}
      {onClearCompleted && (
        <Button
          variant="outline"
          onClick={onClearCompleted}
          className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-green-400 justify-start"
        >
          <CheckCircle2 className="w-4 h-4 mr-2 text-green-400" />
          Wyczyść zakończone
        </Button>
      )}
    </div>
  );
}
