'use client';

import { motion } from 'framer-motion';
import { 
  Clock, 
  User, 
  Box, 
  Layers, 
  MoreVertical, 
  Play, 
  Pause, 
  CheckCircle2, 
  XCircle,
  AlertCircle,
  Printer,
  GripVertical
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { PrintJob } from './types';
import { MATERIAL_COLORS, STATUS_COLORS, STATUS_LABELS, PRINTER_HEAD_LABELS } from './types';

interface PrintJobCardProps {
  job: PrintJob;
  onEdit?: (job: PrintJob) => void;
  onDelete?: (id: string) => void;
  onStart?: (id: string) => void;
  onPause?: (id: string) => void;
  onResume?: (id: string) => void;
  onComplete?: (id: string) => void;
  onFail?: (id: string) => void;
  dragHandleProps?: object;
  isDragging?: boolean;
}

function formatDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}min`;
  return `${hours}h ${mins}min`;
}

function formatTimeRemaining(minutes: number, progress: number): string {
  const remainingMinutes = Math.ceil(minutes * (1 - progress / 100));
  return formatDuration(remainingMinutes);
}

export function PrintJobCard({
  job,
  onEdit,
  onDelete,
  onStart,
  onPause,
  onResume,
  onComplete,
  onFail,
  dragHandleProps,
  isDragging,
}: PrintJobCardProps) {
  const materialColor = MATERIAL_COLORS[job.material];
  const statusColor = STATUS_COLORS[job.status];

  const getStatusIcon = () => {
    switch (job.status) {
      case 'printing':
        return <Printer className="w-4 h-4 animate-pulse" />;
      case 'paused':
        return <Pause className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle2 className="w-4 h-4" />;
      case 'failed':
        return <XCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityBadge = () => {
    if (job.priority === 1) {
      return (
        <Badge variant="destructive" className="text-xs">
          Krytyczny
        </Badge>
      );
    }
    if (job.priority === 2) {
      return (
        <Badge variant="default" className="text-xs bg-amber-500">
          Wysoki
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="text-xs">
        Normalny
      </Badge>
    );
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ scale: isDragging ? 1.02 : 1 }}
      className={`
        relative bg-zinc-900/80 border border-zinc-800 rounded-lg p-4
        transition-all duration-200
        ${isDragging ? 'shadow-2xl shadow-amber-500/20 border-amber-500/50 z-50' : 'hover:border-zinc-700'}
        ${job.status === 'printing' ? 'ring-1 ring-amber-500/30' : ''}
      `}
    >
      {/* Drag Handle */}
      {dragHandleProps && (
        <div 
          {...dragHandleProps}
          className="absolute left-2 top-1/2 -translate-y-1/2 cursor-grab active:cursor-grabbing text-zinc-600 hover:text-zinc-400"
        >
          <GripVertical className="w-5 h-5" />
        </div>
      )}

      <div className={`${dragHandleProps ? 'pl-6' : ''}`}>
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-zinc-100 truncate">
                {job.projectName}
              </h3>
              {getPriorityBadge()}
            </div>
            <div className="flex items-center gap-2 mt-1 text-sm text-zinc-400">
              <User className="w-3.5 h-3.5" />
              <span className="truncate">{job.client}</span>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-zinc-400">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-zinc-900 border-zinc-800">
              {job.status === 'waiting' && onStart && (
                <DropdownMenuItem onClick={() => onStart(job.id)} className="text-green-400">
                  <Play className="w-4 h-4 mr-2" />
                  Rozpocznij druk
                </DropdownMenuItem>
              )}
              {job.status === 'printing' && onPause && (
                <DropdownMenuItem onClick={() => onPause(job.id)} className="text-amber-400">
                  <Pause className="w-4 h-4 mr-2" />
                  Wstrzymaj
                </DropdownMenuItem>
              )}
              {job.status === 'paused' && onResume && (
                <DropdownMenuItem onClick={() => onResume(job.id)} className="text-green-400">
                  <Play className="w-4 h-4 mr-2" />
                  Wznów
                </DropdownMenuItem>
              )}
              {(job.status === 'printing' || job.status === 'paused') && (
                <>
                  {onComplete && (
                    <DropdownMenuItem onClick={() => onComplete(job.id)} className="text-blue-400">
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      Zakończ
                    </DropdownMenuItem>
                  )}
                  {onFail && (
                    <DropdownMenuItem onClick={() => onFail(job.id)} className="text-red-400">
                      <AlertCircle className="w-4 h-4 mr-2" />
                      Oznacz jako błąd
                    </DropdownMenuItem>
                  )}
                </>
              )}
              <DropdownMenuSeparator className="bg-zinc-800" />
              {onEdit && (
                <DropdownMenuItem onClick={() => onEdit(job)}>
                  Edytuj
                </DropdownMenuItem>
              )}
              {onDelete && (
                <DropdownMenuItem onClick={() => onDelete(job.id)} className="text-red-400">
                  Usuń
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Material & Color */}
        <div className="flex items-center gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Box className="w-4 h-4 text-zinc-500" />
            <span 
              className="text-sm font-medium px-2 py-0.5 rounded"
              style={{ 
                backgroundColor: `${materialColor}20`,
                color: materialColor 
              }}
            >
              {job.material}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="w-4 h-4 rounded-full border border-zinc-700"
              style={{ backgroundColor: job.color.toLowerCase() }}
            />
            <span className="text-sm text-zinc-400">{job.color}</span>
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-zinc-500" />
            <span className="text-sm text-zinc-400">{job.quantity} szt.</span>
          </div>
        </div>

        {/* Status & Time */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Badge 
              variant="outline" 
              className="text-xs flex items-center gap-1.5"
              style={{ borderColor: statusColor, color: statusColor }}
            >
              {getStatusIcon()}
              {STATUS_LABELS[job.status]}
            </Badge>
            <Badge variant="outline" className="text-xs text-zinc-400 border-zinc-700">
              {PRINTER_HEAD_LABELS[job.printerHead]}
            </Badge>
          </div>
          <div className="text-right">
            <div className="text-sm text-zinc-400">
              <Clock className="w-3.5 h-3.5 inline mr-1" />
              {formatDuration(job.estimatedTimeMinutes)}
            </div>
          </div>
        </div>

        {/* Progress Bar for active jobs */}
        {(job.status === 'printing' || job.status === 'paused') && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-zinc-400">Postęp</span>
              <div className="flex items-center gap-3">
                <span className="text-amber-400 font-medium">{job.progress}%</span>
                <span className="text-zinc-500">
                  Pozostało: {formatTimeRemaining(job.estimatedTimeMinutes, job.progress)}
                </span>
              </div>
            </div>
            <Progress 
              value={job.progress} 
              className="h-2 bg-zinc-800"
            />
          </div>
        )}

        {/* Completion info */}
        {job.status === 'completed' && job.completedAt && (
          <div className="mt-3 pt-3 border-t border-zinc-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-green-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Zakończono
              </span>
              <span className="text-zinc-500">
                {new Date(job.completedAt).toLocaleString('pl-PL', {
                  day: '2-digit',
                  month: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>
          </div>
        )}

        {/* Notes */}
        {job.notes && (
          <div className="mt-3 pt-3 border-t border-zinc-800">
            <p className="text-xs text-zinc-500 italic">{job.notes}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
