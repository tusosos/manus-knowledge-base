# Kalkulator Kosztów Wydruku 3D

Kompletny kalkulator kosztów wydruku 3D dla drukarki **Bambu Lab H2D**.

## Funkcjonalności

### Formularz wprowadzania danych
- **Waga filamentu (g)** - input number z suwakiem (1-500g)
- **Czas druku (h)** - input number z suwakiem (0.5-24h)
- **Materiał** - select z opcjami: PLA, PETG, ABS, TPU, PA, PC
- **Ilość sztuk** - input number
- **Tryb multicolor** - toggle switch
- **Liczba kolorów** - slider 2-8 (widoczny gdy multicolor = true)

### Automatyczne obliczenia

#### Koszty:
| Koszt | Wzór | Wartość |
|-------|------|---------|
| Materiał | (waga/1000) × cena_kg | PLA: 70zł, PETG: 80zł, ABS: 90zł, TPU: 120zł, PA: 150zł, PC: 180zł |
| Energia | czas × 0.2kW × 1zł/kWh | 0.20 zł/h |
| Amortyzacja | czas × 2zł/h | 2.00 zł/h |
| AMS (multicolor) | +15% materiału (purge waste) | - |
| Praca | 15zł + 10zł + 5zł | 30 zł stałe |

### Wyniki
- **Koszt całkowity** - suma wszystkich kosztów
- **Wycena z marżą** - 50%, 100%, 200%, custom
- **Zysk** dla każdej marży
- **Cena za sztukę**

### Dodatkowe funkcje
- Copy-to-clipboard dla wszystkich cen
- Zapis wyceny do lokalnej bazy (localStorage)
- Lista zapisanych wycen z możliwością wczytania
- Reset formularza

## UI/UX

### Design
- **Dark theme** - tło slate-950/900
- **Amber akcenty** - przyciski, wyróżnienia, gradients
- **shadcn/ui** komponenty: Card, Input, Select, Slider, Button, Switch, Badge

### Layout
- **3-kolumnowy grid** na desktopie
- **Responsive** - stack na mobile
- **Sekcje**: Dane wydruku | Rozkład kosztów | Wycena z marżą

## Użycie

```tsx
import { PrintCostCalculator } from "@/components/calculator";

export default function Page() {
  return <PrintCostCalculator />;
}
```

## Zależności

```json
{
  "@radix-ui/react-select": "latest",
  "@radix-ui/react-slider": "latest",
  "@radix-ui/react-switch": "latest",
  "@radix-ui/react-tooltip": "latest",
  "lucide-react": "latest",
  "sonner": "latest"
}
```

## Struktura plików

```
src/components/calculator/
├── PrintCostCalculator.tsx    # Główny komponent
├── index.ts                   # Eksporty
└── README.md                  # Dokumentacja
```

## Konfiguracja materiałów

```typescript
const MATERIALS = {
  PLA: { pricePerKg: 70, color: "#22c55e" },
  PETG: { pricePerKg: 80, color: "#3b82f6" },
  ABS: { pricePerKg: 90, color: "#ef4444" },
  TPU: { pricePerKg: 120, color: "#a855f7" },
  PA: { pricePerKg: 150, color: "#f97316" },
  PC: { pricePerKg: 180, color: "#06b6d4" },
};
```

## Stałe kosztów

```typescript
const COST_CONSTANTS = {
  ENERGY_KW: 0.2,              // Zużycie prądu drukarki
  ENERGY_PRICE_PER_KWH: 1,     // Cena 1 kWh
  AMORTIZATION_PER_HOUR: 2,    // Amortyzacja na godzinę
  AMS_PURGE_WASTE_PERCENT: 0.15, // Odpad AMS
  LABOR_PREP: 15,              // Przygotowanie
  LABOR_POST: 10,              // Post-processing
  LABOR_PACK: 5,               // Pakowanie
};
```

## Licencja

MIT - 3D Print Business Hub
