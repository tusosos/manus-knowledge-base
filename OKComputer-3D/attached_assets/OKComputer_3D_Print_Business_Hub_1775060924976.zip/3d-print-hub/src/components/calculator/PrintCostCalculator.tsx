"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Calculator,
  Copy,
  Save,
  RotateCcw,
  Zap,
  Clock,
  Package,
  Palette,
  TrendingUp,
  DollarSign,
  Printer,
  Check,
  Database,
  Trash2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { toast } from "sonner";

// ============================================
// TYPY I INTERFEJSY
// ============================================

type MaterialType = "PLA" | "PETG" | "ABS" | "TPU" | "PA" | "PC";

interface MaterialConfig {
  name: MaterialType;
  pricePerKg: number;
  color: string;
  description: string;
}

interface CostBreakdown {
  materialCost: number;
  energyCost: number;
  amortizationCost: number;
  amsCost: number;
  laborCost: number;
  totalCost: number;
}

interface PricingResult {
  margin: number;
  price: number;
  profit: number;
  pricePerUnit: number;
}

interface SavedQuote {
  id: string;
  name: string;
  date: string;
  weight: number;
  time: number;
  material: MaterialType;
  quantity: number;
  multicolor: boolean;
  colors: number;
  totalCost: number;
  finalPrice: number;
  margin: number;
}

interface CalculatorState {
  weight: number;
  time: number;
  material: MaterialType;
  quantity: number;
  multicolor: boolean;
  colors: number;
  customMargin: number;
}

// ============================================
// KONFIGURACJA MATERIAŁÓW
// ============================================

const MATERIALS: Record<MaterialType, MaterialConfig> = {
  PLA: { name: "PLA", pricePerKg: 70, color: "#22c55e", description: "Podstawowy, łatwy w druku" },
  PETG: { name: "PETG", pricePerKg: 80, color: "#3b82f6", description: "Wytrzymały, odporny na wilgoć" },
  ABS: { name: "ABS", pricePerKg: 90, color: "#ef4444", description: "Wysoka temperatura, wytrzymały" },
  TPU: { name: "TPU", pricePerKg: 120, color: "#a855f7", description: "Elastyczny, gumowy" },
  PA: { name: "PA", pricePerKg: 150, color: "#f97316", description: "Poliamid, bardzo wytrzymały" },
  PC: { name: "PC", pricePerKg: 180, color: "#06b6d4", description: "Poliwęglan, przezroczysty" },
};

// ============================================
// STAŁE KOSZTÓW
// ============================================

const COST_CONSTANTS = {
  ENERGY_KW: 0.2,
  ENERGY_PRICE_PER_KWH: 1,
  AMORTIZATION_PER_HOUR: 2,
  AMS_PURGE_WASTE_PERCENT: 0.15,
  LABOR_PREP: 15,
  LABOR_POST: 10,
  LABOR_PACK: 5,
};

// ============================================
// KOMPONENT GŁÓWNY
// ============================================

export default function PrintCostCalculator() {
  // --- Stan formularza ---
  const [state, setState] = useState<CalculatorState>({
    weight: 50,
    time: 4,
    material: "PLA",
    quantity: 1,
    multicolor: false,
    colors: 2,
    customMargin: 100,
  });

  // --- Stan wyników ---
  const [costs, setCosts] = useState<CostBreakdown | null>(null);
  const [pricing, setPricing] = useState<PricingResult[]>([]);
  const [savedQuotes, setSavedQuotes] = useState<SavedQuote[]>([]);
  const [showSavedQuotes, setShowSavedQuotes] = useState(false);
  const [quoteName, setQuoteName] = useState("");

  // --- Obliczenia ---
  const calculateCosts = useCallback((): CostBreakdown => {
    const materialPrice = MATERIALS[state.material].pricePerKg;
    
    // Koszt materiału bazowego
    let materialCost = (state.weight / 1000) * materialPrice;
    
    // Dodatkowy koszt materiału dla multicolor (purge waste)
    let amsCost = 0;
    if (state.multicolor) {
      amsCost = materialCost * COST_CONSTANTS.AMS_PURGE_WASTE_PERCENT;
    }
    
    const totalMaterialCost = materialCost + amsCost;
    
    // Koszt energii
    const energyCost = state.time * COST_CONSTANTS.ENERGY_KW * COST_CONSTANTS.ENERGY_PRICE_PER_KWH;
    
    // Amortyzacja drukarki
    const amortizationCost = state.time * COST_CONSTANTS.AMORTIZATION_PER_HOUR;
    
    // Koszt pracy (przygotowanie + post-processing + pakowanie)
    const laborCost = COST_CONSTANTS.LABOR_PREP + COST_CONSTANTS.LABOR_POST + COST_CONSTANTS.LABOR_PACK;
    
    // Koszt całkowity
    const totalCost = totalMaterialCost + energyCost + amortizationCost + laborCost;
    
    return {
      materialCost: totalMaterialCost,
      energyCost,
      amortizationCost,
      amsCost,
      laborCost,
      totalCost,
    };
  }, [state]);

  const calculatePricing = useCallback((costs: CostBreakdown): PricingResult[] => {
    const margins = [50, 100, 200, state.customMargin];
    
    return margins.map((margin) => {
      const price = costs.totalCost * (1 + margin / 100);
      const profit = price - costs.totalCost;
      
      return {
        margin,
        price,
        profit,
        pricePerUnit: price / state.quantity,
      };
    });
  }, [state.quantity, state.customMargin]);

  // --- Efekty ---
  useEffect(() => {
    const newCosts = calculateCosts();
    setCosts(newCosts);
    setPricing(calculatePricing(newCosts));
  }, [calculateCosts, calculatePricing]);

  // --- Handlery ---
  const handleReset = () => {
    setState({
      weight: 50,
      time: 4,
      material: "PLA",
      quantity: 1,
      multicolor: false,
      colors: 2,
      customMargin: 100,
    });
    toast.info("Formularz został zresetowany");
  };

  const copyToClipboard = (value: number, label: string) => {
    navigator.clipboard.writeText(value.toFixed(2) + " zł");
    toast.success(`${label} skopiowano do schowka`);
  };

  const saveQuote = () => {
    if (!costs || pricing.length === 0) return;
    
    const selectedPricing = pricing.find((p) => p.margin === 100) || pricing[1];
    
    const newQuote: SavedQuote = {
      id: Date.now().toString(),
      name: quoteName || `Wycena #${savedQuotes.length + 1}`,
      date: new Date().toLocaleString("pl-PL"),
      weight: state.weight,
      time: state.time,
      material: state.material,
      quantity: state.quantity,
      multicolor: state.multicolor,
      colors: state.colors,
      totalCost: costs.totalCost,
      finalPrice: selectedPricing.price,
      margin: selectedPricing.margin,
    };
    
    setSavedQuotes((prev) => [newQuote, ...prev]);
    setQuoteName("");
    toast.success("Wycena została zapisana");
  };

  const deleteQuote = (id: string) => {
    setSavedQuotes((prev) => prev.filter((q) => q.id !== id));
    toast.info("Wycena została usunięta");
  };

  const loadQuote = (quote: SavedQuote) => {
    setState({
      weight: quote.weight,
      time: quote.time,
      material: quote.material,
      quantity: quote.quantity,
      multicolor: quote.multicolor,
      colors: quote.colors,
      customMargin: 100,
    });
    toast.success(`Wczytano wycenę: ${quote.name}`);
  };

  // --- Render ---
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Nagłówek */}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center gap-3 mb-2">
              <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20">
                <Printer className="w-8 h-8 text-amber-500" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 bg-clip-text text-transparent">
                3D Print Business Hub
              </h1>
            </div>
            <p className="text-slate-400">Kalkulator Kosztów Wydruku • Bambu Lab H2D</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* === LEWA KOLUMNA: FORMULARZ === */}
            <div className="lg:col-span-4 space-y-6">
              <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-amber-500" />
                    <CardTitle className="text-slate-100">Dane wydruku</CardTitle>
                  </div>
                  <CardDescription className="text-slate-400">
                    Wprowadź parametry wydruku
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {/* Waga filamentu */}
                  <div className="space-y-2">
                    <Label htmlFor="weight" className="text-slate-300 flex items-center gap-2">
                      <Package className="w-4 h-4 text-slate-500" />
                      Waga filamentu (g)
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      min={1}
                      max={5000}
                      value={state.weight}
                      onChange={(e) => setState((s) => ({ ...s, weight: Number(e.target.value) }))}
                      className="bg-slate-800 border-slate-700 text-slate-100 focus:border-amber-500 focus:ring-amber-500/20"
                    />
                    <Slider
                      value={[state.weight]}
                      onValueChange={([v]) => setState((s) => ({ ...s, weight: v }))}
                      min={1}
                      max={500}
                      step={1}
                      className="py-2"
                    />
                  </div>

                  {/* Czas druku */}
                  <div className="space-y-2">
                    <Label htmlFor="time" className="text-slate-300 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-500" />
                      Czas druku (h)
                    </Label>
                    <Input
                      id="time"
                      type="number"
                      min={0.1}
                      max={100}
                      step={0.1}
                      value={state.time}
                      onChange={(e) => setState((s) => ({ ...s, time: Number(e.target.value) }))}
                      className="bg-slate-800 border-slate-700 text-slate-100 focus:border-amber-500 focus:ring-amber-500/20"
                    />
                    <Slider
                      value={[state.time]}
                      onValueChange={([v]) => setState((s) => ({ ...s, time: v }))}
                      min={0.5}
                      max={24}
                      step={0.5}
                      className="py-2"
                    />
                  </div>

                  {/* Materiał */}
                  <div className="space-y-2">
                    <Label htmlFor="material" className="text-slate-300 flex items-center gap-2">
                      <Palette className="w-4 h-4 text-slate-500" />
                      Materiał
                    </Label>
                    <Select
                      value={state.material}
                      onValueChange={(v) => setState((s) => ({ ...s, material: v as MaterialType }))}
                    >
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-slate-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        {Object.entries(MATERIALS).map(([key, config]) => (
                          <SelectItem
                            key={key}
                            value={key}
                            className="text-slate-100 focus:bg-slate-700 focus:text-amber-400"
                          >
                            <div className="flex items-center gap-2">
                              <div
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: config.color }}
                              />
                              <span>{config.name}</span>
                              <span className="text-slate-500 text-xs">({config.pricePerKg} zł/kg)</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-slate-500">
                      {MATERIALS[state.material].description}
                    </p>
                  </div>

                  {/* Ilość sztuk */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity" className="text-slate-300 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-slate-500" />
                      Ilość sztuk
                    </Label>
                    <Input
                      id="quantity"
                      type="number"
                      min={1}
                      max={1000}
                      value={state.quantity}
                      onChange={(e) => setState((s) => ({ ...s, quantity: Number(e.target.value) }))}
                      className="bg-slate-800 border-slate-700 text-slate-100 focus:border-amber-500 focus:ring-amber-500/20"
                    />
                  </div>

                  {/* Multicolor toggle */}
                  <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                    <div className="flex items-center gap-2">
                      <Palette className="w-4 h-4 text-amber-500" />
                      <span className="text-slate-300">Tryb multicolor (AMS)</span>
                    </div>
                    <Switch
                      checked={state.multicolor}
                      onCheckedChange={(v) => setState((s) => ({ ...s, multicolor: v }))}
                      className="data-[state=checked]:bg-amber-500"
                    />
                  </div>

                  {/* Liczba kolorów */}
                  {state.multicolor && (
                    <div className="space-y-2 p-3 bg-amber-500/5 rounded-lg border border-amber-500/20">
                      <Label className="text-slate-300">Liczba kolorów</Label>
                      <div className="flex items-center gap-4">
                        <Slider
                          value={[state.colors]}
                          onValueChange={([v]) => setState((s) => ({ ...s, colors: v }))}
                          min={2}
                          max={8}
                          step={1}
                          className="flex-1"
                        />
                        <Badge
                          variant="outline"
                          className="border-amber-500/50 text-amber-400 min-w-[3rem] justify-center"
                        >
                          {state.colors}
                        </Badge>
                      </div>
                      <p className="text-xs text-amber-400/70">
                        +15% materiału na purge waste
                      </p>
                    </div>
                  )}

                  {/* Przyciski */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      onClick={handleReset}
                      className="flex-1 border-slate-700 text-slate-400 hover:text-slate-100 hover:bg-slate-800"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Zapisane wyceny */}
              <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm">
                <CardHeader
                  className="pb-2 cursor-pointer"
                  onClick={() => setShowSavedQuotes(!showSavedQuotes)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Database className="w-5 h-5 text-amber-500" />
                      <CardTitle className="text-slate-100 text-lg">Zapisane wyceny</CardTitle>
                    </div>
                    {showSavedQuotes ? (
                      <ChevronUp className="w-5 h-5 text-slate-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-500" />
                    )}
                  </div>
                </CardHeader>
                {showSavedQuotes && (
                  <CardContent>
                    <ScrollArea className="h-48">
                      {savedQuotes.length === 0 ? (
                        <p className="text-slate-500 text-center py-8">Brak zapisanych wycen</p>
                      ) : (
                        <div className="space-y-2">
                          {savedQuotes.map((quote) => (
                            <div
                              key={quote.id}
                              className="p-3 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-amber-500/50 transition-colors group"
                            >
                              <div className="flex items-center justify-between">
                                <div
                                  className="flex-1 cursor-pointer"
                                  onClick={() => loadQuote(quote)}
                                >
                                  <p className="text-slate-200 font-medium text-sm">{quote.name}</p>
                                  <p className="text-slate-500 text-xs">{quote.date}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Badge
                                      variant="outline"
                                      className="text-xs border-slate-600 text-slate-400"
                                    >
                                      {quote.material}
                                    </Badge>
                                    <span className="text-amber-400 text-sm font-semibold">
                                      {quote.finalPrice.toFixed(2)} zł
                                    </span>
                                  </div>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => deleteQuote(quote.id)}
                                  className="text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                )}
              </Card>
            </div>

            {/* === ŚRODKOWA KOLUMNA: KOSZTY === */}
            <div className="lg:col-span-4 space-y-6">
              <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm h-full">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-emerald-500" />
                    <CardTitle className="text-slate-100">Rozkład kosztów</CardTitle>
                  </div>
                  <CardDescription className="text-slate-400">
                    Szczegółowe koszty produkcji
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {costs && (
                    <>
                      {/* Koszt materiału */}
                      <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Package className="w-4 h-4 text-blue-400" />
                            <span className="text-slate-300">Materiał</span>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(costs.materialCost, "Koszt materiału")}
                                className="h-6 px-2 text-slate-500 hover:text-slate-300"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Kopiuj do schowka</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-slate-100">
                            {costs.materialCost.toFixed(2)}
                          </span>
                          <span className="text-slate-500">zł</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {(state.weight / 1000).toFixed(3)} kg × {MATERIALS[state.material].pricePerKg} zł/kg
                          {state.multicolor && (
                            <span className="text-amber-400 block mt-1">
                              + {costs.amsCost.toFixed(2)} zł (AMS purge)
                            </span>
                          )}
                        </p>
                      </div>

                      {/* Koszt energii */}
                      <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Zap className="w-4 h-4 text-yellow-400" />
                            <span className="text-slate-300">Energia</span>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(costs.energyCost, "Koszt energii")}
                                className="h-6 px-2 text-slate-500 hover:text-slate-300"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Kopiuj do schowka</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-slate-100">
                            {costs.energyCost.toFixed(2)}
                          </span>
                          <span className="text-slate-500">zł</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {state.time}h × {COST_CONSTANTS.ENERGY_KW}kW × {COST_CONSTANTS.ENERGY_PRICE_PER_KWH} zł/kWh
                        </p>
                      </div>

                      {/* Amortyzacja */}
                      <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Printer className="w-4 h-4 text-purple-400" />
                            <span className="text-slate-300">Amortyzacja</span>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(costs.amortizationCost, "Amortyzacja")}
                                className="h-6 px-2 text-slate-500 hover:text-slate-300"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Kopiuj do schowka</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-slate-100">
                            {costs.amortizationCost.toFixed(2)}
                          </span>
                          <span className="text-slate-500">zł</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          {state.time}h × {COST_CONSTANTS.AMORTIZATION_PER_HOUR} zł/h
                        </p>
                      </div>

                      {/* Koszt pracy */}
                      <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-orange-400" />
                            <span className="text-slate-300">Praca</span>
                          </div>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(costs.laborCost, "Koszt pracy")}
                                className="h-6 px-2 text-slate-500 hover:text-slate-300"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Kopiuj do schowka</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-slate-100">
                            {costs.laborCost.toFixed(2)}
                          </span>
                          <span className="text-slate-500">zł</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">
                          Przygotowanie {COST_CONSTANTS.LABOR_PREP}zł + Post-processing {COST_CONSTANTS.LABOR_POST}zł + Pakowanie {COST_CONSTANTS.LABOR_PACK}zł
                        </p>
                      </div>

                      <Separator className="bg-slate-700" />

                      {/* Koszt całkowity */}
                      <div className="p-5 bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-xl border border-amber-500/30">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-amber-400 font-medium">Koszt całkowity</span>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(costs.totalCost, "Koszt całkowity")}
                                className="h-6 px-2 text-amber-500 hover:text-amber-400"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Kopiuj do schowka</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-bold text-amber-400">
                            {costs.totalCost.toFixed(2)}
                          </span>
                          <span className="text-amber-500/70 text-xl">zł</span>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* === PRAWA KOLUMNA: WYCENA === */}
            <div className="lg:col-span-4 space-y-6">
              <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-amber-500" />
                    <CardTitle className="text-slate-100">Wycena z marżą</CardTitle>
                  </div>
                  <CardDescription className="text-slate-400">
                    Ceny sprzedaży dla różnych marż
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pricing.map((p, index) => (
                    <div
                      key={p.margin}
                      className={`p-4 rounded-xl border transition-all ${
                        index === 1
                          ? "bg-gradient-to-r from-amber-500/20 to-orange-500/20 border-amber-500/50 ring-1 ring-amber-500/30"
                          : "bg-slate-800/50 border-slate-700 hover:border-slate-600"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <Badge
                          variant={index === 1 ? "default" : "outline"}
                          className={
                            index === 1
                              ? "bg-amber-500 text-slate-950 font-bold"
                              : "border-slate-600 text-slate-400"
                          }
                        >
                          {p.margin === state.customMargin ? "Custom" : `${p.margin}%`} marży
                          {index === 1 && <Check className="w-3 h-3 ml-1" />}
                        </Badge>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(p.price, `Cena z ${p.margin}% marży`)}
                              className="h-6 px-2 text-slate-500 hover:text-slate-300"
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Kopiuj do schowka</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Cena całkowita</p>
                          <p
                            className={`text-xl font-bold ${
                              index === 1 ? "text-amber-400" : "text-slate-200"
                            }`}
                          >
                            {p.price.toFixed(2)} zł
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Cena za sztukę</p>
                          <p
                            className={`text-lg font-semibold ${
                              index === 1 ? "text-amber-400/80" : "text-slate-300"
                            }`}
                          >
                            {p.pricePerUnit.toFixed(2)} zł
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-700/50">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-slate-500">Zysk:</span>
                          <span
                            className={`text-sm font-medium ${
                              index === 1 ? "text-emerald-400" : "text-emerald-400/70"
                            }`}
                          >
                            +{p.profit.toFixed(2)} zł
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Custom margin slider */}
                  <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
                    <Label className="text-slate-300 mb-3 block">Własna marża</Label>
                    <div className="flex items-center gap-4">
                      <Slider
                        value={[state.customMargin]}
                        onValueChange={([v]) => setState((s) => ({ ...s, customMargin: v }))}
                        min={0}
                        max={500}
                        step={5}
                        className="flex-1"
                      />
                      <Badge
                        variant="outline"
                        className="border-amber-500/50 text-amber-400 min-w-[4rem] justify-center"
                      >
                        {state.customMargin}%
                      </Badge>
                    </div>
                  </div>

                  {/* Zapisz wycenę */}
                  <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700 space-y-3">
                    <Label className="text-slate-300">Zapisz wycenę</Label>
                    <Input
                      placeholder="Nazwa wyceny (opcjonalnie)"
                      value={quoteName}
                      onChange={(e) => setQuoteName(e.target.value)}
                      className="bg-slate-900 border-slate-700 text-slate-100 focus:border-amber-500"
                    />
                    <Button
                      onClick={saveQuote}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-semibold"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Zapisz wycenę
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Podsumowanie */}
              <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 border-slate-700">
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-xs text-slate-500 mb-1">Koszt/sztuka</p>
                      <p className="text-lg font-bold text-slate-300">
                        {costs ? (costs.totalCost / state.quantity).toFixed(2) : "0.00"} zł
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-slate-500 mb-1">Czas/sztuka</p>
                      <p className="text-lg font-bold text-slate-300">
                        {state.time}h
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-8 text-center text-slate-600 text-sm">
            <p>3D Print Business Hub • Kalkulator dla Bambu Lab H2D</p>
            <p className="mt-1">
              Ceny materiałów: PLA 70zł/kg • PETG 80zł/kg • ABS 90zł/kg • TPU 120zł/kg • PA 150zł/kg • PC 180zł/kg
            </p>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
}
