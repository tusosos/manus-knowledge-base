# 3D Print Business Hub - Komponenty UI

## Struktura katalogów

```
src/components/
├── layout/           # Komponenty layoutu
│   ├── MainLayout.tsx
│   ├── Header.tsx
│   ├── Sidebar.tsx
│   └── index.ts
├── common/           # Wspólne komponenty
│   ├── PageHeader.tsx
│   ├── StatusBadge.tsx
│   ├── LoadingSpinner.tsx
│   ├── EmptyState.tsx
│   ├── DataTable.tsx
│   ├── FormComponents.tsx
│   └── index.ts
├── ui/              # shadcn/ui komponenty
│   ├── button.tsx
│   ├── input.tsx
│   ├── select.tsx
│   ├── ...
│   └── index.ts
└── index.ts         # Główny eksport
```

## Komponenty Layout

### MainLayout
Główny layout aplikacji zawierający sidebar, header i content area.

```tsx
import { MainLayout } from '@/components/layout';

function App() {
  return (
    <MainLayout>
      <YourPageContent />
    </MainLayout>
  );
}
```

### Sidebar
Nawigacja boczna z sekcjami:
- GŁÓWNE: Dashboard, Codzienne Taski, Kolejka Druku
- NARZĘDZIA: Kalkulator Kosztów, Generator Wycen, Kalkulator Wysyłki
- ZASOBY: Projekty 3D, Magazyn Filamentów, Baza Klientów
- BIZNES: Analityka Sprzedaży, Analiza Konkurencji, Biznesplan, Bestsellery
- H2D ONLINE: Profil Drukarki, Planner Multicolor, Centrum Wiedzy

### Header
Header z logo, powiadomieniami i menu użytkownika.

## Komponenty Common

### PageHeader
Nagłówek strony z breadcrumbs i akcjami.

```tsx
import { PageHeader, PageHeaderAction } from '@/components/common';

<PageHeader
  title="Tytuł strony"
  subtitle="Opis strony"
  breadcrumbs={[
    { label: 'Dashboard', href: '/' },
    { label: 'Projekty', href: '/projects' },
    { label: 'Szczegóły' }
  ]}
  actions={
    <PageHeaderAction icon={Plus} onClick={handleAdd}>
      Dodaj
    </PageHeaderAction>
  }
/>
```

### StatusBadge
Badge statusu z różnymi wariantami.

```tsx
import { StatusBadge, PrintStatusBadge, OrderStatusBadge } from '@/components/common';

<StatusBadge status="success" />
<StatusBadge status="warning" label="Niskie zapasy" pulse />
<PrintStatusBadge status="printing" progress={75} />
<OrderStatusBadge status="in_production" />
```

### DataTable
Tabela danych z sortowaniem, filtrowaniem i paginacją.

```tsx
import { DataTable, Column } from '@/components/common';

const columns: Column<MyData>[] = [
  { key: 'name', header: 'Nazwa', sortable: true },
  { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
];

<DataTable
  data={data}
  columns={columns}
  keyExtractor={(row) => row.id}
  searchable
  pagination
  pageSize={10}
/>
```

### Form Components
Komponenty formularzy.

```tsx
import { FormInput, FormSelect, FormTextarea, FormSection } from '@/components/common';

<FormInput
  label="Nazwa"
  placeholder="Wpisz nazwę"
  required
  error={errors.name}
/>

<FormSelect
  label="Typ"
  options={[
    { value: 'pla', label: 'PLA' },
    { value: 'abs', label: 'ABS' },
  ]}
/>

<FormTextarea
  label="Opis"
  rows={4}
/>
```

### LoadingSpinner
Wskaźniki ładowania.

```tsx
import { LoadingSpinner, Skeleton, PageLoader } from '@/components/common';

<LoadingSpinner size="lg" text="Ładowanie..." />
<Skeleton className="h-20 w-full" />
<PageLoader />
```

### EmptyState
Komponenty pustego stanu.

```tsx
import { EmptyState, EmptyProjects, EmptyFilaments } from '@/components/common';

<EmptyState
  icon="folder"
  title="Brak projektów"
  description="Dodaj pierwszy projekt"
  action={{ label: 'Dodaj', onClick: handleAdd }}
/>

<EmptyProjects onCreate={handleCreate} />
<EmptyFilaments onAdd={handleAdd} />
```

## Design System

### Kolory
- **Background**: `bg-zinc-950`
- **Surface**: `bg-zinc-900`
- **Border**: `border-zinc-800`
- **Text Primary**: `text-zinc-100`
- **Text Secondary**: `text-zinc-400`
- **Accent**: `text-amber-500`, `bg-amber-500`

### Status Colors
- **Success**: `green-500`
- **Warning**: `amber-500`
- **Error**: `red-500`
- **Info**: `blue-500`
- **Processing**: `cyan-500`

## Zależności

```bash
npm install @radix-ui/react-*
npm install lucide-react
npm install clsx tailwind-merge
npm install class-variance-authority
```
