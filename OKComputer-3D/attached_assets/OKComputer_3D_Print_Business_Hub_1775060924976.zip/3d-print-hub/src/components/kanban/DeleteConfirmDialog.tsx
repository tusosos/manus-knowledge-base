'use client';

import { motion } from 'framer-motion';
import { AlertTriangle, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Task } from './types';

interface DeleteConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  task: Task | null;
}

export function DeleteConfirmDialog({ 
  isOpen, 
  onClose, 
  onConfirm, 
  task 
}: DeleteConfirmDialogProps) {
  if (!task) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-zinc-100 max-w-md">
        <DialogHeader className="space-y-4">
          <div className="mx-auto w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center">
            <AlertTriangle className="h-8 w-8 text-red-500" />
          </div>
          <DialogTitle className="text-xl font-semibold text-center">
            Usunąć zadanie?
          </DialogTitle>
          <DialogDescription className="text-zinc-400 text-center">
            Czy na pewno chcesz usunąć zadanie 
            <span className="text-zinc-200 font-medium block mt-1">
              "{task.title}"
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="bg-zinc-950/50 rounded-lg p-4 mt-4 border border-zinc-800">
          <p className="text-zinc-500 text-sm text-center">
            Tej operacji nie można cofnąć. Zadanie zostanie trwale usunięte z systemu.
          </p>
        </div>

        <div className="flex justify-center gap-3 mt-6">
          <Button
            variant="outline"
            onClick={onClose}
            className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100 min-w-[100px]"
          >
            Anuluj
          </Button>
          <Button
            onClick={onConfirm}
            className="bg-red-500 hover:bg-red-600 text-white min-w-[100px] flex items-center gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Usuń
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
