'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Tag, Repeat, AlertCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Task,
  TaskFormData,
  TaskStatus,
  TaskPriority,
  TaskCategory,
  RecurrenceType,
  CATEGORY_LABELS,
  PRIORITY_LABELS,
  RECURRENCE_LABELS,
  PRIORITY_COLORS,
  CATEGORY_COLORS,
} from './types';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: TaskFormData, taskId?: string) => void;
  task?: Task | null;
  defaultStatus?: TaskStatus;
}

const emptyFormData: TaskFormData = {
  title: '',
  description: '',
  priority: 'medium',
  category: 'other',
  deadline: '',
  tags: [],
  recurrence: 'none',
};

export function TaskModal({ isOpen, onClose, onSave, task, defaultStatus }: TaskModalProps) {
  const [formData, setFormData] = useState<TaskFormData>(emptyFormData);
  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isEditing = !!task;

  useEffect(() => {
    if (isOpen) {
      if (task) {
        setFormData({
          title: task.title,
          description: task.description || '',
          priority: task.priority,
          category: task.category,
          deadline: task.deadline ? task.deadline.toISOString().split('T')[0] : '',
          tags: [...task.tags],
          recurrence: task.recurrence,
        });
      } else {
        setFormData(emptyFormData);
      }
      setErrors({});
      setTagInput('');
    }
  }, [isOpen, task]);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) {
      newErrors.title = 'Tytuł jest wymagany';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;
    
    onSave(formData, task?.id);
    onClose();
  };

  const handleAddTag = () => {
    const trimmed = tagInput.trim().toLowerCase();
    if (trimmed && !formData.tags.includes(trimmed)) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, trimmed],
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove),
    }));
  };

  const handleTagKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-900 border-zinc-800 text-zinc-100 max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold flex items-center gap-2">
            <span className={isEditing ? 'text-amber-400' : 'text-emerald-400'}>
              {isEditing ? '✎' : '+'}
            </span>
            {isEditing ? 'Edytuj zadanie' : 'Nowe zadanie'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title" className="text-zinc-300">
              Tytuł <span className="text-red-400">*</span>
            </Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Wpisz tytuł zadania..."
              className={`
                bg-zinc-950 border-zinc-800 text-zinc-100
                placeholder:text-zinc-600
                focus:border-amber-500 focus:ring-amber-500/20
                ${errors.title ? 'border-red-500 focus:border-red-500' : ''}
              `}
            />
            {errors.title && (
              <p className="text-red-400 text-xs flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                {errors.title}
              </p>
            )}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-zinc-300">
              Opis
            </Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Dodaj opis zadania (opcjonalnie)..."
              rows={3}
              className="bg-zinc-950 border-zinc-800 text-zinc-100 placeholder:text-zinc-600 focus:border-amber-500 focus:ring-amber-500/20 resize-none"
            />
          </div>

          {/* Priority and Category */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-zinc-300">Priorytet</Label>
              <Select
                value={formData.priority}
                onValueChange={(value: TaskPriority) => 
                  setFormData(prev => ({ ...prev, priority: value }))
                }
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {(['low', 'medium', 'high'] as TaskPriority[]).map((p) => (
                    <SelectItem 
                      key={p} 
                      value={p}
                      className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                    >
                      <span className="flex items-center gap-2">
                        <span className={`
                          w-2 h-2 rounded-full
                          ${p === 'high' ? 'bg-red-500' : p === 'medium' ? 'bg-amber-500' : 'bg-blue-500'}
                        `} />
                        {PRIORITY_LABELS[p]}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300">Kategoria</Label>
              <Select
                value={formData.category}
                onValueChange={(value: TaskCategory) => 
                  setFormData(prev => ({ ...prev, category: value }))
                }
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {(['printing', 'design', 'shipping', 'customer-service', 'marketing', 'other'] as TaskCategory[]).map((c) => (
                    <SelectItem 
                      key={c} 
                      value={c}
                      className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                    >
                      {CATEGORY_LABELS[c]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Deadline and Recurrence */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="deadline" className="text-zinc-300 flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                Deadline
              </Label>
              <Input
                id="deadline"
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                className="bg-zinc-950 border-zinc-800 text-zinc-100 focus:border-amber-500 focus:ring-amber-500/20"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-zinc-300 flex items-center gap-1">
                <Repeat className="h-3.5 w-3.5" />
                Powtarzanie
              </Label>
              <Select
                value={formData.recurrence}
                onValueChange={(value: RecurrenceType) => 
                  setFormData(prev => ({ ...prev, recurrence: value }))
                }
              >
                <SelectTrigger className="bg-zinc-950 border-zinc-800 text-zinc-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-zinc-800">
                  {(['none', 'daily', 'weekly'] as RecurrenceType[]).map((r) => (
                    <SelectItem 
                      key={r} 
                      value={r}
                      className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                    >
                      {RECURRENCE_LABELS[r]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label className="text-zinc-300 flex items-center gap-1">
              <Tag className="h-3.5 w-3.5" />
              Tagi
            </Label>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleTagKeyDown}
                placeholder="Dodaj tag i naciśnij Enter..."
                className="bg-zinc-950 border-zinc-800 text-zinc-100 placeholder:text-zinc-600 focus:border-amber-500 focus:ring-amber-500/20"
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleAddTag}
                className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100"
              >
                Dodaj
              </Button>
            </div>
            <AnimatePresence mode="popLayout">
              {formData.tags.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex flex-wrap gap-1.5 mt-2"
                >
                  {formData.tags.map((tag) => (
                    <motion.div
                      key={tag}
                      layout
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                    >
                      <Badge
                        variant="secondary"
                        className="bg-zinc-800 text-zinc-300 hover:bg-zinc-700 cursor-pointer"
                        onClick={() => handleRemoveTag(tag)}
                      >
                        #{tag}
                        <X className="h-3 w-3 ml-1" />
                      </Badge>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-zinc-800">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100"
            >
              Anuluj
            </Button>
            <Button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-medium"
            >
              {isEditing ? 'Zapisz zmiany' : 'Dodaj zadanie'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
