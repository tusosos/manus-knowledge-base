'use client';

import { motion } from 'framer-motion';
import { Filter, SlidersHorizontal, X, Calendar, ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  FilterState,
  TaskCategory,
  TaskPriority,
  CATEGORY_LABELS,
  PRIORITY_LABELS,
} from './types';

interface KanbanFiltersProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  taskCount: number;
  filteredCount: number;
}

export function KanbanFilters({ 
  filters, 
  onFilterChange, 
  taskCount, 
  filteredCount 
}: KanbanFiltersProps) {
  const hasActiveFilters = filters.category !== 'all' || filters.priority !== 'all';

  const handleReset = () => {
    onFilterChange({
      category: 'all',
      priority: 'all',
      sortBy: 'deadline',
    });
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.category !== 'all') count++;
    if (filters.priority !== 'all') count++;
    return count;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 mb-6"
    >
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Left side - Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-zinc-400">
            <Filter className="h-4 w-4" />
            <span className="text-sm font-medium">Filtry:</span>
          </div>

          {/* Category Filter */}
          <Select
            value={filters.category}
            onValueChange={(value: TaskCategory | 'all') => 
              onFilterChange({ ...filters, category: value })
            }
          >
            <SelectTrigger className="w-[160px] bg-zinc-950 border-zinc-800 text-zinc-100 h-9">
              <SelectValue placeholder="Kategoria" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem 
                value="all"
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                Wszystkie kategorie
              </SelectItem>
              {(['printing', 'design', 'shipping', 'customer-service', 'marketing', 'other'] as TaskCategory[]).map((c) => (
                <SelectItem 
                  key={c} 
                  value={c}
                  className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                >
                  {CATEGORY_LABELS[c]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Priority Filter */}
          <Select
            value={filters.priority}
            onValueChange={(value: TaskPriority | 'all') => 
              onFilterChange({ ...filters, priority: value })
            }
          >
            <SelectTrigger className="w-[140px] bg-zinc-950 border-zinc-800 text-zinc-100 h-9">
              <SelectValue placeholder="Priorytet" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem 
                value="all"
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                Wszystkie priorytety
              </SelectItem>
              {(['low', 'medium', 'high'] as TaskPriority[]).map((p) => (
                <SelectItem 
                  key={p} 
                  value={p}
                  className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                >
                  <span className="flex items-center gap-2">
                    <span className={`
                      w-2 h-2 rounded-full
                      ${p === 'high' ? 'bg-red-500' : p === 'medium' ? 'bg-amber-500' : 'bg-blue-500'}
                    `} />
                    {PRIORITY_LABELS[p]}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sort */}
          <Select
            value={filters.sortBy}
            onValueChange={(value: 'deadline' | 'created' | 'priority') => 
              onFilterChange({ ...filters, sortBy: value })
            }
          >
            <SelectTrigger className="w-[140px] bg-zinc-950 border-zinc-800 text-zinc-100 h-9">
              <ArrowUpDown className="h-3.5 w-3.5 mr-2" />
              <SelectValue placeholder="Sortuj" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem 
                value="deadline"
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                <span className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5" />
                  Po dacie
                </span>
              </SelectItem>
              <SelectItem 
                value="created"
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                <span className="flex items-center gap-2">
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  Po utworzeniu
                </span>
              </SelectItem>
              <SelectItem 
                value="priority"
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                <span className="flex items-center gap-2">
                  <Filter className="h-3.5 w-3.5" />
                  Po priorytecie
                </span>
              </SelectItem>
            </SelectContent>
          </Select>

          {/* Reset button */}
          {hasActiveFilters && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={handleReset}
                className="text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 h-9"
              >
                <X className="h-3.5 w-3.5 mr-1" />
                Wyczyść
              </Button>
            </motion.div>
          )}
        </div>

        {/* Right side - Stats */}
        <div className="flex items-center gap-3">
          {getActiveFilterCount() > 0 && (
            <Badge 
              variant="outline" 
              className="bg-amber-500/10 text-amber-400 border-amber-500/30"
            >
              {getActiveFilterCount()} {getActiveFilterCount() === 1 ? 'filtr' : 'filtry'}
            </Badge>
          )}
          <div className="text-sm text-zinc-500">
            <span className="text-zinc-300 font-medium">{filteredCount}</span>
            {' / '}
            <span>{taskCount}</span>
            {' zadań'}
          </div>
        </div>
      </div>

      {/* Active filters display */}
      {hasActiveFilters && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-zinc-800/50"
        >
          {filters.category !== 'all' && (
            <Badge 
              variant="secondary"
              className="bg-zinc-800 text-zinc-300 hover:bg-zinc-700 cursor-pointer"
              onClick={() => onFilterChange({ ...filters, category: 'all' })}
            >
              {CATEGORY_LABELS[filters.category]}
              <X className="h-3 w-3 ml-1" />
            </Badge>
          )}
          {filters.priority !== 'all' && (
            <Badge 
              variant="secondary"
              className="bg-zinc-800 text-zinc-300 hover:bg-zinc-700 cursor-pointer"
              onClick={() => onFilterChange({ ...filters, priority: 'all' })}
            >
              {PRIORITY_LABELS[filters.priority]}
              <X className="h-3 w-3 ml-1" />
            </Badge>
          )}
        </motion.div>
      )}
    </motion.div>
  );
}
