'use client';

import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Layout, ListTodo, CheckCircle2, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { KanbanColumn } from './KanbanColumn';
import { TaskModal } from './TaskModal';
import { DeleteConfirmDialog } from './DeleteConfirmDialog';
import { KanbanFilters } from './KanbanFilters';
import {
  Task,
  TaskStatus,
  TaskFormData,
  FilterState,
  RecurrenceType,
} from './types';
import { useKanbanDrag } from './useKanbanDrag';

// Sample initial tasks
const initialTasks: Task[] = [
  {
    id: '1',
    title: 'Przygotować zamówienie #1234 - Wydruk 3D figurki',
    description: 'Wydruk wysokiej jakości figurki postaci z gry',
    status: 'todo',
    priority: 'high',
    category: 'printing',
    deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    tags: ['figurka', 'ekspres', 'klient-vip'],
    recurrence: 'none',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '2',
    title: 'Zaprojektować wsporniki dla drukarki',
    description: 'Nowe wsporniki stabilizujące dla Prusa i3',
    status: 'todo',
    priority: 'medium',
    category: 'design',
    deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    tags: ['projekt', 'wsporniki'],
    recurrence: 'none',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '3',
    title: 'Wysłać paczki z zamówieniami',
    description: '5 paczek do wysłania przez InPost',
    status: 'in-progress',
    priority: 'high',
    category: 'shipping',
    deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
    tags: ['wysyłka', 'inpost'],
    recurrence: 'none',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '4',
    title: 'Odpowiedzieć na zapytania klientów',
    description: 'Odpisać na 3 maile i 2 wiadomości na Facebooku',
    status: 'in-progress',
    priority: 'medium',
    category: 'customer-service',
    deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
    tags: ['kontakt', 'mail'],
    recurrence: 'daily',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '5',
    title: 'Przygotować post na social media',
    description: 'Zdjęcia nowych wydruków na Instagram',
    status: 'done',
    priority: 'low',
    category: 'marketing',
    deadline: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    tags: ['social', 'instagram'],
    recurrence: 'weekly',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '6',
    title: 'Kalibracja drukarki Ender 3',
    description: 'Sprawdzić poziom stołu i wyczyścić dyszę',
    status: 'todo',
    priority: 'medium',
    category: 'printing',
    deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    tags: ['konserwacja', 'ender3'],
    recurrence: 'weekly',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

const columns: TaskStatus[] = ['todo', 'in-progress', 'done'];

export function KanbanBoard() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [filters, setFilters] = useState<FilterState>({
    category: 'all',
    priority: 'all',
    sortBy: 'deadline',
  });
  
  // Modal states
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [defaultStatus, setDefaultStatus] = useState<TaskStatus>('todo');
  
  // Delete dialog state
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);

  // Drag & drop
  const { dragState, handleDragStart, handleDragEnd, handleDrop } = useKanbanDrag();
  const [dragOverColumn, setDragOverColumn] = useState<TaskStatus | null>(null);

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    let result = [...tasks];

    // Apply filters
    if (filters.category !== 'all') {
      result = result.filter(t => t.category === filters.category);
    }
    if (filters.priority !== 'all') {
      result = result.filter(t => t.priority === filters.priority);
    }

    // Apply sorting
    result.sort((a, b) => {
      switch (filters.sortBy) {
        case 'deadline':
          if (!a.deadline && !b.deadline) return 0;
          if (!a.deadline) return 1;
          if (!b.deadline) return -1;
          return a.deadline.getTime() - b.deadline.getTime();
        case 'created':
          return b.createdAt.getTime() - a.createdAt.getTime();
        case 'priority':
          const priorityOrder = { high: 0, medium: 1, low: 2 };
          return priorityOrder[a.priority] - priorityOrder[b.priority];
        default:
          return 0;
      }
    });

    return result;
  }, [tasks, filters]);

  // Get tasks by column
  const getTasksByColumn = useCallback((status: TaskStatus) => {
    return filteredTasks.filter(t => t.status === status);
  }, [filteredTasks]);

  // CRUD Operations
  const handleAddTask = useCallback((status: TaskStatus) => {
    setDefaultStatus(status);
    setEditingTask(null);
    setIsTaskModalOpen(true);
  }, []);

  const handleEditTask = useCallback((task: Task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  }, []);

  const handleSaveTask = useCallback((formData: TaskFormData, taskId?: string) => {
    if (taskId) {
      // Update existing task
      setTasks(prev => prev.map(t => 
        t.id === taskId 
          ? {
              ...t,
              title: formData.title,
              description: formData.description || undefined,
              priority: formData.priority,
              category: formData.category,
              deadline: formData.deadline ? new Date(formData.deadline) : undefined,
              tags: formData.tags,
              recurrence: formData.recurrence,
              updatedAt: new Date(),
            }
          : t
      ));
    } else {
      // Create new task
      const newTask: Task = {
        id: Date.now().toString(),
        title: formData.title,
        description: formData.description || undefined,
        status: defaultStatus,
        priority: formData.priority,
        category: formData.category,
        deadline: formData.deadline ? new Date(formData.deadline) : undefined,
        tags: formData.tags,
        recurrence: formData.recurrence,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setTasks(prev => [...prev, newTask]);
    }
  }, [defaultStatus]);

  const handleDeleteTask = useCallback((task: Task) => {
    setTaskToDelete(task);
    setIsDeleteDialogOpen(true);
  }, []);

  const handleConfirmDelete = useCallback(() => {
    if (taskToDelete) {
      setTasks(prev => prev.filter(t => t.id !== taskToDelete.id));
      setTaskToDelete(null);
      setIsDeleteDialogOpen(false);
    }
  }, [taskToDelete]);

  // Drag & Drop handlers
  const handleColumnDragOver = useCallback((e: React.DragEvent, columnId: TaskStatus) => {
    e.preventDefault();
    setDragOverColumn(columnId);
  }, []);

  const handleColumnDrop = useCallback((e: React.DragEvent, columnId: TaskStatus) => {
    e.preventDefault();
    handleDrop(columnId, (taskId, newStatus) => {
      setTasks(prev => prev.map(t => 
        t.id === taskId 
          ? { ...t, status: newStatus, updatedAt: new Date() }
          : t
      ));
    });
    setDragOverColumn(null);
  }, [handleDrop]);

  const handleDragLeave = useCallback(() => {
    setDragOverColumn(null);
  }, []);

  // Stats
  const stats = useMemo(() => ({
    total: tasks.length,
    todo: tasks.filter(t => t.status === 'todo').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
    done: tasks.filter(t => t.status === 'done').length,
  }), [tasks]);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
            <Layout className="h-5 w-5 text-zinc-950" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-zinc-100">Kanban Taski</h1>
            <p className="text-zinc-500 text-sm">Zarządzaj zadaniami w drukarni 3D</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Quick stats */}
          <div className="hidden md:flex items-center gap-2 bg-zinc-900/50 border border-zinc-800 rounded-lg p-1">
            <div className="flex items-center gap-1.5 px-3 py-1.5">
              <ListTodo className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-zinc-400">{stats.todo}</span>
            </div>
            <div className="w-px h-4 bg-zinc-800" />
            <div className="flex items-center gap-1.5 px-3 py-1.5">
              <Clock className="h-4 w-4 text-amber-400" />
              <span className="text-sm text-zinc-400">{stats.inProgress}</span>
            </div>
            <div className="w-px h-4 bg-zinc-800" />
            <div className="flex items-center gap-1.5 px-3 py-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <span className="text-sm text-zinc-400">{stats.done}</span>
            </div>
          </div>

          <Button
            onClick={() => handleAddTask('todo')}
            className="bg-amber-500 hover:bg-amber-600 text-zinc-950 font-medium"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nowe zadanie
          </Button>
        </div>
      </motion.div>

      {/* Filters */}
      <KanbanFilters
        filters={filters}
        onFilterChange={setFilters}
        taskCount={tasks.length}
        filteredCount={filteredTasks.length}
      />

      {/* Kanban Board */}
      <ScrollArea className="flex-1 -mx-2 px-2">
        <div className="flex gap-4 min-w-[1000px] lg:min-w-0 pb-4">
          {columns.map((columnId, index) => (
            <motion.div
              key={columnId}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex-1 min-w-[300px]"
              onDragLeave={handleDragLeave}
            >
              <KanbanColumn
                id={columnId}
                tasks={getTasksByColumn(columnId)}
                isDragOver={dragOverColumn === columnId}
                onDragStart={handleDragStart}
                onDragOver={handleColumnDragOver}
                onDrop={handleColumnDrop}
                onAddTask={handleAddTask}
                onEditTask={handleEditTask}
                onDeleteTask={handleDeleteTask}
              />
            </motion.div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      {/* Modals */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSave={handleSaveTask}
        task={editingTask}
        defaultStatus={defaultStatus}
      />

      <DeleteConfirmDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleConfirmDelete}
        task={taskToDelete}
      />
    </div>
  );
}
