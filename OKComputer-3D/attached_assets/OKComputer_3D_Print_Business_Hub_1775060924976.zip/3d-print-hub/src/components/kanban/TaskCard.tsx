'use client';

import { motion } from 'framer-motion';
import { 
  Calendar, 
  Tag, 
  Repeat, 
  AlertCircle,
  Clock,
  MoreVertical,
  Edit2,
  Trash2
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Task,
  TaskStatus,
  CATEGORY_LABELS,
  PRIORITY_LABELS,
  RECURRENCE_LABELS,
  PRIORITY_COLORS,
  CATEGORY_COLORS,
  STATUS_COLORS,
} from './types';

interface TaskCardProps {
  task: Task;
  columnId: TaskStatus;
  onDragStart: (task: Task, sourceColumn: TaskStatus) => void;
  onEdit: (task: Task) => void;
  onDelete: (task: Task) => void;
}

const priorityIcons: Record<string, string> = {
  low: '●',
  medium: '●●',
  high: '●●●',
};

function formatDate(date: Date): string {
  const today = new Date();
  const taskDate = new Date(date);
  const diffTime = taskDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Dzisiaj';
  if (diffDays === 1) return 'Jutro';
  if (diffDays === -1) return 'Wczoraj';
  if (diffDays < 0) return `${Math.abs(diffDays)} dni temu`;
  if (diffDays <= 7) return `Za ${diffDays} dni`;
  
  return taskDate.toLocaleDateString('pl-PL', {
    day: 'numeric',
    month: 'short',
  });
}

function getDeadlineColor(date: Date): string {
  const today = new Date();
  const taskDate = new Date(date);
  const diffTime = taskDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return 'text-red-400';
  if (diffDays === 0) return 'text-amber-400';
  if (diffDays <= 2) return 'text-orange-400';
  return 'text-gray-400';
}

export function TaskCard({ task, columnId, onDragStart, onEdit, onDelete }: TaskCardProps) {
  const handleDragStart = () => {
    onDragStart(task, columnId);
  };

  const isOverdue = task.deadline && new Date(task.deadline) < new Date();

  return (
    <motion.div
      layout
      layoutId={task.id}
      draggable
      onDragStart={handleDragStart}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ scale: 1.02 }}
      whileDrag={{ scale: 1.05, rotate: 2 }}
      transition={{
        layout: { duration: 0.2 },
        opacity: { duration: 0.15 },
        scale: { duration: 0.15 },
      }}
      className="cursor-grab active:cursor-grabbing"
    >
      <Card 
        className={`
          relative overflow-hidden 
          bg-zinc-900/80 border-zinc-800 
          hover:border-zinc-700 hover:bg-zinc-900/90
          transition-colors duration-200
          border-t-2 ${STATUS_COLORS[columnId]}
        `}
      >
        {/* Priority indicator stripe */}
        <div className={`absolute left-0 top-0 bottom-0 w-1 ${
          task.priority === 'high' ? 'bg-red-500' :
          task.priority === 'medium' ? 'bg-amber-500' :
          'bg-blue-500'
        }`} />

        <div className="p-4 pl-5">
          {/* Header with title and actions */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <h4 className="font-medium text-zinc-100 text-sm leading-tight line-clamp-2 flex-1">
              {task.title}
            </h4>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 -mr-2 -mt-1 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800"
                >
                  <MoreVertical className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-zinc-900 border-zinc-800">
                <DropdownMenuItem 
                  onClick={() => onEdit(task)}
                  className="text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800 cursor-pointer"
                >
                  <Edit2 className="h-4 w-4 mr-2" />
                  Edytuj
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => onDelete(task)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-500/10 cursor-pointer"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Usuń
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-zinc-500 text-xs mb-3 line-clamp-2">
              {task.description}
            </p>
          )}

          {/* Badges row */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            <Badge 
              variant="outline" 
              className={`text-[10px] px-1.5 py-0 h-5 ${CATEGORY_COLORS[task.category]}`}
            >
              {CATEGORY_LABELS[task.category]}
            </Badge>
            <Badge 
              variant="outline" 
              className={`text-[10px] px-1.5 py-0 h-5 ${PRIORITY_COLORS[task.priority]}`}
            >
              <span className="mr-1">{priorityIcons[task.priority]}</span>
              {PRIORITY_LABELS[task.priority]}
            </Badge>
          </div>

          {/* Footer with metadata */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              {task.deadline && (
                <span className={`flex items-center gap-1 ${getDeadlineColor(task.deadline)}`}>
                  <Calendar className="h-3 w-3" />
                  {formatDate(task.deadline)}
                  {isOverdue && <AlertCircle className="h-3 w-3" />}
                </span>
              )}
              {task.recurrence !== 'none' && (
                <span className="flex items-center gap-1 text-zinc-500" title={RECURRENCE_LABELS[task.recurrence]}>
                  <Repeat className="h-3 w-3" />
                </span>
              )}
            </div>
            
            {task.tags.length > 0 && (
              <div className="flex items-center gap-1 text-zinc-500">
                <Tag className="h-3 w-3" />
                <span className="text-[10px]">{task.tags.length}</span>
              </div>
            )}
          </div>

          {/* Tags display */}
          {task.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2 pt-2 border-t border-zinc-800/50">
              {task.tags.slice(0, 3).map((tag, index) => (
                <span 
                  key={index}
                  className="text-[10px] text-zinc-500 bg-zinc-800/50 px-1.5 py-0.5 rounded"
                >
                  #{tag}
                </span>
              ))}
              {task.tags.length > 3 && (
                <span className="text-[10px] text-zinc-600">
                  +{task.tags.length - 3}
                </span>
              )}
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}
