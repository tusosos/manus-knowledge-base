'use client';

import { useState, useCallback } from 'react';
import { Task, TaskStatus } from './types';

interface DragState {
  draggedTask: Task | null;
  sourceColumn: TaskStatus | null;
  isDragging: boolean;
}

interface UseKanbanDragReturn {
  dragState: DragState;
  handleDragStart: (task: Task, sourceColumn: TaskStatus) => void;
  handleDragEnd: () => void;
  handleDrop: (targetColumn: TaskStatus, onMove: (taskId: string, newStatus: TaskStatus) => void) => void;
}

export function useKanbanDrag(): UseKanbanDragReturn {
  const [dragState, setDragState] = useState<DragState>({
    draggedTask: null,
    sourceColumn: null,
    isDragging: false,
  });

  const handleDragStart = useCallback((task: Task, sourceColumn: TaskStatus) => {
    setDragState({
      draggedTask: task,
      sourceColumn,
      isDragging: true,
    });
  }, []);

  const handleDragEnd = useCallback(() => {
    setDragState({
      draggedTask: null,
      sourceColumn: null,
      isDragging: false,
    });
  }, []);

  const handleDrop = useCallback(
    (targetColumn: TaskStatus, onMove: (taskId: string, newStatus: TaskStatus) => void) => {
      if (dragState.draggedTask && dragState.sourceColumn !== targetColumn) {
        onMove(dragState.draggedTask.id, targetColumn);
      }
      handleDragEnd();
    },
    [dragState.draggedTask, dragState.sourceColumn, handleDragEnd]
  );

  return {
    dragState,
    handleDragStart,
    handleDragEnd,
    handleDrop,
  };
}
