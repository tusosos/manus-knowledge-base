export type TaskStatus = 'todo' | 'in-progress' | 'done';
export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskCategory = 'printing' | 'design' | 'shipping' | 'customer-service' | 'marketing' | 'other';
export type RecurrenceType = 'none' | 'daily' | 'weekly';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: TaskPriority;
  category: TaskCategory;
  deadline?: Date;
  tags: string[];
  recurrence: RecurrenceType;
  createdAt: Date;
  updatedAt: Date;
}

export interface TaskFormData {
  title: string;
  description: string;
  priority: TaskPriority;
  category: TaskCategory;
  deadline: string;
  tags: string[];
  recurrence: RecurrenceType;
}

export interface FilterState {
  category: TaskCategory | 'all';
  priority: TaskPriority | 'all';
  sortBy: 'deadline' | 'created' | 'priority';
}

export const CATEGORY_LABELS: Record<TaskCategory, string> = {
  printing: 'Druk',
  design: 'Projektowanie',
  shipping: 'Wysyłka',
  'customer-service': 'Obsługa klienta',
  marketing: 'Marketing',
  other: 'Inne',
};

export const PRIORITY_LABELS: Record<TaskPriority, string> = {
  low: 'Niski',
  medium: 'Średni',
  high: 'Wysoki',
};

export const RECURRENCE_LABELS: Record<RecurrenceType, string> = {
  none: 'Brak',
  daily: 'Codziennie',
  weekly: 'Tygodniowo',
};

export const STATUS_LABELS: Record<TaskStatus, string> = {
  todo: 'Do zrobienia',
  'in-progress': 'W trakcie',
  done: 'Gotowe',
};

export const PRIORITY_COLORS: Record<TaskPriority, string> = {
  low: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  medium: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  high: 'bg-red-500/20 text-red-400 border-red-500/30',
};

export const CATEGORY_COLORS: Record<TaskCategory, string> = {
  printing: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  design: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  shipping: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  'customer-service': 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  marketing: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
  other: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
};

export const STATUS_COLORS: Record<TaskStatus, string> = {
  todo: 'border-t-gray-500',
  'in-progress': 'border-t-amber-500',
  done: 'border-t-emerald-500',
};

export const COLUMN_COLORS: Record<TaskStatus, string> = {
  todo: 'bg-gray-500/5 border-gray-500/20',
  'in-progress': 'bg-amber-500/5 border-amber-500/20',
  done: 'bg-emerald-500/5 border-emerald-500/20',
};
