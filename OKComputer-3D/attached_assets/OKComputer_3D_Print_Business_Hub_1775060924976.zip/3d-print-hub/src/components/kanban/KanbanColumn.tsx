'use client';

import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { Task, TaskStatus, STATUS_LABELS, COLUMN_COLORS } from './types';
import { TaskCard } from './TaskCard';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

interface KanbanColumnProps {
  id: TaskStatus;
  tasks: Task[];
  isDragOver: boolean;
  onDragStart: (task: Task, sourceColumn: TaskStatus) => void;
  onDragOver: (e: React.DragEvent, columnId: TaskStatus) => void;
  onDrop: (e: React.DragEvent, columnId: TaskStatus) => void;
  onAddTask: (status: TaskStatus) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (task: Task) => void;
}

const columnIcons: Record<TaskStatus, string> = {
  todo: '○',
  'in-progress': '◐',
  done: '●',
};

const columnGradients: Record<TaskStatus, string> = {
  todo: 'from-gray-500/10 to-transparent',
  'in-progress': 'from-amber-500/10 to-transparent',
  done: 'from-emerald-500/10 to-transparent',
};

export function KanbanColumn({
  id,
  tasks,
  isDragOver,
  onDragStart,
  onDragOver,
  onDrop,
  onAddTask,
  onEditTask,
  onDeleteTask,
}: KanbanColumnProps) {
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    onDragOver(e, id);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    onDrop(e, id);
  };

  return (
    <motion.div
      layout
      className={`
        flex flex-col h-full min-h-[400px] rounded-xl
        border ${COLUMN_COLORS[id]}
        transition-all duration-300
        ${isDragOver ? 'ring-2 ring-amber-500/50 ring-offset-2 ring-offset-zinc-950' : ''}
      `}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Column Header */}
      <div className={`
        p-4 border-b border-zinc-800/50
        bg-gradient-to-b ${columnGradients[id]}
        rounded-t-xl
      `}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`
              text-lg font-bold
              ${id === 'todo' ? 'text-gray-400' : ''}
              ${id === 'in-progress' ? 'text-amber-400' : ''}
              ${id === 'done' ? 'text-emerald-400' : ''}
            `}>
              {columnIcons[id]}
            </span>
            <h3 className="font-semibold text-zinc-200 text-sm uppercase tracking-wider">
              {STATUS_LABELS[id]}
            </h3>
            <span className={`
              ml-2 px-2 py-0.5 rounded-full text-xs font-medium
              ${id === 'todo' ? 'bg-gray-500/20 text-gray-400' : ''}
              ${id === 'in-progress' ? 'bg-amber-500/20 text-amber-400' : ''}
              ${id === 'done' ? 'bg-emerald-500/20 text-emerald-400' : ''}
            `}>
              {tasks.length}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
            onClick={() => onAddTask(id)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Column Content */}
      <ScrollArea className="flex-1 p-3">
        <motion.div 
          className="space-y-3 min-h-[100px]"
          layout
        >
          {tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              columnId={id}
              onDragStart={onDragStart}
              onEdit={onEditTask}
              onDelete={onDeleteTask}
            />
          ))}
          
          {tasks.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-12 text-center"
            >
              <span className="text-4xl mb-2 opacity-20">
                {id === 'todo' ? '📝' : id === 'in-progress' ? '⚙️' : '✅'}
              </span>
              <p className="text-zinc-600 text-sm">
                Brak zadań
              </p>
              <p className="text-zinc-700 text-xs mt-1">
                Przeciągnij tutaj lub dodaj nowe
              </p>
            </motion.div>
          )}
        </motion.div>
      </ScrollArea>

      {/* Drop Zone Indicator */}
      {isDragOver && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className={`
            absolute inset-0 rounded-xl pointer-events-none
            border-2 border-dashed
            ${id === 'todo' ? 'border-gray-500/50 bg-gray-500/5' : ''}
            ${id === 'in-progress' ? 'border-amber-500/50 bg-amber-500/5' : ''}
            ${id === 'done' ? 'border-emerald-500/50 bg-emerald-500/5' : ''}
          `}
        />
      )}
    </motion.div>
  );
}
