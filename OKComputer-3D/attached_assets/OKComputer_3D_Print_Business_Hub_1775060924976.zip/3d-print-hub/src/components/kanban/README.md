# Kanban Task Module - 3D Print Business Hub

## Komponenty

### KanbanBoard
Główny komponent zarządzający całą tablicą Kanban.

```tsx
import { KanbanBoard } from '@/components/kanban';

export default function TasksPage() {
  return (
    <div className="h-screen p-6">
      <KanbanBoard />
    </div>
  );
}
```

### TaskCard
Pojedyncza karta zadania z drag & drop support.

### KanbanColumn
Kolumna zawierająca taski o określonym statusie.

### TaskModal
Modal do dodawania/edycji zadań.

### DeleteConfirmDialog
Dialog potwierdzenia usunięcia.

### KanbanFilters
Panel filtrów i sortowania.

## Funkcjonalności

- ✅ 3 kolumny: Do zrobienia, W trakcie, Gotowe
- ✅ Drag & drop między kolumnami (Framer Motion)
- ✅ CRUD operacje na taskach
- ✅ Filtry: kategoria, priorytet
- ✅ Sortowanie: data, utworzenie, priorytet
- ✅ Powtarzające się taski (codzienne, tygodniowe)
- ✅ Tagi dla tasków
- ✅ Deadline z ostrzeżeniami
- ✅ Responsive design
- ✅ Dark theme

## Typy

```typescript
interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'in-progress' | 'done';
  priority: 'low' | 'medium' | 'high';
  category: 'printing' | 'design' | 'shipping' | 'customer-service' | 'marketing' | 'other';
  deadline?: Date;
  tags: string[];
  recurrence: 'none' | 'daily' | 'weekly';
  createdAt: Date;
  updatedAt: Date;
}
```

## Kolory

### Priorytety
- Niski: niebieski
- Średni: amber
- Wysoki: czerwony

### Kategorie
- Druk: fioletowy
- Projektowanie: cyjan
- Wysyłka: pomarańczowy
- Obsługa klienta: różowy
- Marketing: indigo
- Inne: szary

### Statusy
- Do zrobienia: szary
- W trakcie: amber
- Gotowe: zielony
