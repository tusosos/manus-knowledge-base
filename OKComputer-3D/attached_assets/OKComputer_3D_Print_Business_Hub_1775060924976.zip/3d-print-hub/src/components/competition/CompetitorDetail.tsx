"use client";

import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  ExternalLink,
  CheckCircle,
  AlertTriangle,
  Clock,
  DollarSign,
  Layers,
  Award,
  Star,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react";
import { type Competitor, type Technology, yourBusiness, marketAverages } from "./data";

interface CompetitorDetailProps {
  competitor: Competitor;
}

const TechnologyBadge: React.FC<{ tech: Technology }> = ({ tech }) => {
  const colors: Record<Technology, string> = {
    FDM: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    SLA: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    SLS: "bg-orange-500/20 text-orange-400 border-orange-500/30",
    MJF: "bg-green-500/20 text-green-400 border-green-500/30",
    DLP: "bg-pink-500/20 text-pink-400 border-pink-500/30",
  };

  return (
    <Badge variant="outline" className={`${colors[tech]} text-xs`}>
      {tech}
    </Badge>
  );
};

const RatingStars: React.FC<{ rating: number; max?: number }> = ({ rating, max = 10 }) => {
  const stars = Math.round((rating / max) * 5);
  return (
    <div className="flex items-center gap-1">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < stars ? "fill-yellow-400 text-yellow-400" : "text-gray-600"
          }`}
        />
      ))}
      <span className="ml-2 text-sm text-gray-400">{rating.toFixed(1)}/{max}</span>
    </div>
  );
};

const ComparisonIndicator: React.FC<{ 
  yourValue: number; 
  competitorValue: number; 
  label: string;
  unit: string;
  lowerIsBetter?: boolean;
}> = ({ yourValue, competitorValue, label, unit, lowerIsBetter = false }) => {
  const diff = ((competitorValue - yourValue) / yourValue) * 100;
  const isBetter = lowerIsBetter ? diff > 0 : diff < 0;
  const Icon = isBetter ? TrendingDown : diff > 0 ? TrendingUp : Minus;
  const colorClass = isBetter ? "text-green-400" : diff > 0 ? "text-red-400" : "text-gray-400";

  return (
    <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
      <span className="text-sm text-gray-400">{label}</span>
      <div className="flex items-center gap-3">
        <span className="font-medium">{competitorValue.toFixed(2)} {unit}</span>
        <span className={`text-sm flex items-center gap-1 ${colorClass}`}>
          <Icon className="w-4 h-4" />
          {Math.abs(diff).toFixed(0)}%
        </span>
      </div>
    </div>
  );
};

const CompetitorDetail: React.FC<CompetitorDetailProps> = ({ competitor }) => {
  const priceDiff = ((competitor.pricing.perCm3 - yourBusiness.pricing.perCm3) / yourBusiness.pricing.perCm3) * 100;
  const timeDiff = ((competitor.leadTimeDays - yourBusiness.leadTimeDays) / yourBusiness.leadTimeDays) * 100;
  const qualityDiff = ((competitor.qualityScore - yourBusiness.qualityScore) / yourBusiness.qualityScore) * 100;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300">
          Szczegóły
          <ExternalLink className="w-4 h-4 ml-1" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-900 border-gray-800 text-gray-100">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3">
            {competitor.name}
            {competitor.marketPosition === "premium" && (
              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                Premium
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Szczegółowa analiza konkurenta
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-gray-800/50 rounded-lg text-center">
              <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">{competitor.pricing.perCm3.toFixed(2)}</p>
              <p className="text-xs text-gray-400">PLN/cm³</p>
            </div>
            <div className="p-4 bg-gray-800/50 rounded-lg text-center">
              <Clock className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">{competitor.leadTimeDays}</p>
              <p className="text-xs text-gray-400">dni realizacji</p>
            </div>
            <div className="p-4 bg-gray-800/50 rounded-lg text-center">
              <Award className="w-6 h-6 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">{competitor.qualityScore}</p>
              <p className="text-xs text-gray-400">jakość /10</p>
            </div>
            <div className="p-4 bg-gray-800/50 rounded-lg text-center">
              <Star className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">{competitor.overallRating}</p>
              <p className="text-xs text-gray-400">ocena ogólna</p>
            </div>
          </div>

          <Separator className="bg-gray-800" />

          {/* Pricing Details */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              Szczegółowy Cennik
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="p-3 bg-gray-800/50 rounded-lg flex justify-between">
                  <span className="text-gray-400">Cena za cm³</span>
                  <span className="font-medium">{competitor.pricing.perCm3.toFixed(2)} PLN</span>
                </div>
                <div className="p-3 bg-gray-800/50 rounded-lg flex justify-between">
                  <span className="text-gray-400">Cena za godzinę</span>
                  <span className="font-medium">{competitor.pricing.perHour.toFixed(2)} PLN</span>
                </div>
                <div className="p-3 bg-gray-800/50 rounded-lg flex justify-between">
                  <span className="text-gray-400">Cena za gram</span>
                  <span className="font-medium">{competitor.pricing.perGram.toFixed(2)} PLN</span>
                </div>
                <div className="p-3 bg-gray-800/50 rounded-lg flex justify-between">
                  <span className="text-gray-400">Opłata przygotowawcza</span>
                  <span className="font-medium">{competitor.pricing.setupFee.toFixed(2)} PLN</span>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-sm font-medium text-gray-400 mb-2">Porównanie z Twoją firmą:</h4>
                <ComparisonIndicator
                  yourValue={yourBusiness.pricing.perCm3}
                  competitorValue={competitor.pricing.perCm3}
                  label="Cena / cm³"
                  unit="PLN"
                  lowerIsBetter
                />
                <ComparisonIndicator
                  yourValue={yourBusiness.pricing.perHour}
                  competitorValue={competitor.pricing.perHour}
                  label="Cena / h"
                  unit="PLN"
                  lowerIsBetter
                />
                <ComparisonIndicator
                  yourValue={yourBusiness.leadTimeDays}
                  competitorValue={competitor.leadTimeDays}
                  label="Czas realizacji"
                  unit="dni"
                  lowerIsBetter
                />
              </div>
            </div>
          </div>

          <Separator className="bg-gray-800" />

          {/* Technologies & Materials */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-400" />
                Technologie
              </h3>
              <div className="flex flex-wrap gap-2">
                {competitor.technologies.map((tech) => (
                  <TechnologyBadge key={tech} tech={tech} />
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-400" />
                Materiały
              </h3>
              <div className="flex flex-wrap gap-2">
                {competitor.materials.map((material) => (
                  <Badge key={material} variant="outline" className="bg-gray-800/50 text-gray-300 border-gray-700">
                    {material}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <Separator className="bg-gray-800" />

          {/* Strengths & Weaknesses */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-green-400">
                <CheckCircle className="w-5 h-5" />
                Mocne Strony
              </h3>
              <ul className="space-y-2">
                {competitor.strengths.map((strength, index) => (
                  <li key={index} className="flex items-start gap-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <span className="text-green-500 font-bold mt-0.5">+</span>
                    <span className="text-sm text-gray-300">{strength}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-red-400">
                <AlertTriangle className="w-5 h-5" />
                Słabe Strony
              </h3>
              <ul className="space-y-2">
                {competitor.weaknesses.map((weakness, index) => (
                  <li key={index} className="flex items-start gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <span className="text-red-500 font-bold mt-0.5">-</span>
                    <span className="text-sm text-gray-300">{weakness}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <Separator className="bg-gray-800" />

          {/* Additional Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Dodatkowe Informacje</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-400 text-sm">Minimalna wartość zamówienia:</span>
                <p className="font-medium">{competitor.minOrderValue ? `${competitor.minOrderValue} PLN` : "Brak minimum"}</p>
              </div>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-400 text-sm">Opcje dostawy:</span>
                <p className="font-medium">{competitor.deliveryOptions.join(", ")}</p>
              </div>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <span className="text-gray-400 text-sm">Obsługa klienta:</span>
                <p className="font-medium capitalize">{competitor.customerService}</p>
              </div>
              {competitor.website && (
                <div className="p-3 bg-gray-800/50 rounded-lg">
                  <span className="text-gray-400 text-sm">Strona WWW:</span>
                  <a 
                    href={competitor.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="font-medium text-blue-400 hover:underline flex items-center gap-1"
                  >
                    {competitor.website.replace("https://", "")}
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CompetitorDetail;
