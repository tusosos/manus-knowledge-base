// Moduł Analizy Konkurencji dla 3D Print Business Hub
// Eksportuje wszystkie komponenty i dane związane z analizą konkurencji

// Główne komponenty
export { default as CompetitionAnalysis } from "./CompetitionAnalysis";
export { default as CompetitorDetail } from "./CompetitorDetail";

// Dane i typy
export {
  // Dane
  competitors,
  yourBusiness,
  pricingComparisonData,
  positioningData,
  marketAverages,
  strategicRecommendations,
  technologyDescriptions,
  materialDescriptions,
  
  // Typy
  type Competitor,
  type Technology,
  type YourBusiness,
} from "./data";

// Domyślny eksport
export { default } from "./CompetitionAnalysis";
