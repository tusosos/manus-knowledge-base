"use client";

import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ZAxis,
  Cell,
  ReferenceLine,
} from "recharts";
import {
  TrendingUp,
  TrendingDown,
  Target,
  Zap,
  Clock,
  DollarSign,
  Award,
  AlertTriangle,
  CheckCircle,
  Star,
  BarChart3,
  PieChart,
  MapPin,
  Lightbulb,
  ArrowRight,
  Crown,
  Sparkles,
  Layers,
  Palette,
  Maximize,
  Timer,
} from "lucide-react";
import {
  competitors,
  yourBusiness,
  pricingComparisonData,
  positioningData,
  marketAverages,
  strategicRecommendations,
  type Competitor,
  type Technology,
} from "./data";

// Komponenty pomocnicze
const TechnologyBadge: React.FC<{ tech: Technology }> = ({ tech }) => {
  const colors: Record<Technology, string> = {
    FDM: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    SLA: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    SLS: "bg-orange-500/20 text-orange-400 border-orange-500/30",
    MJF: "bg-green-500/20 text-green-400 border-green-500/30",
    DLP: "bg-pink-500/20 text-pink-400 border-pink-500/30",
  };

  return (
    <Badge variant="outline" className={`${colors[tech]} text-xs`}>
      {tech}
    </Badge>
  );
};

const RatingStars: React.FC<{ rating: number; max?: number }> = ({ rating, max = 10 }) => {
  const stars = Math.round((rating / max) * 5);
  return (
    <div className="flex items-center gap-1">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${
            i < stars ? "fill-yellow-400 text-yellow-400" : "text-gray-600"
          }`}
        />
      ))}
      <span className="ml-2 text-sm text-gray-400">{rating.toFixed(1)}/{max}</span>
    </div>
  );
};

const MarketPositionBadge: React.FC<{ position: string }> = ({ position }) => {
  const colors: Record<string, string> = {
    premium: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    mid: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    budget: "bg-green-500/20 text-green-400 border-green-500/30",
  };

  const labels: Record<string, string> = {
    premium: "Premium",
    mid: "Średni",
    budget: "Budget",
  };

  return (
    <Badge variant="outline" className={`${colors[position]} text-xs`}>
      {labels[position]}
    </Badge>
  );
};

const PriorityBadge: React.FC<{ priority: string }> = ({ priority }) => {
  const colors: Record<string, string> = {
    high: "bg-red-500/20 text-red-400 border-red-500/30",
    medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    low: "bg-green-500/20 text-green-400 border-green-500/30",
  };

  const labels: Record<string, string> = {
    high: "Wysoki",
    medium: "Średni",
    low: "Niski",
  };

  return (
    <Badge variant="outline" className={`${colors[priority]} text-xs`}>
      {labels[priority]}
    </Badge>
  );
};

// Główny komponent
const CompetitionAnalysis: React.FC = () => {
  const [activeTab, setActiveTab] = useState("overview");

  // Obliczenia statystyk
  const avgPricePerCm3 = marketAverages.perCm3;
  const yourPricePerCm3 = yourBusiness.pricing.perCm3;
  const priceDifference = ((yourPricePerCm3 - avgPricePerCm3) / avgPricePerCm3) * 100;

  const avgLeadTime = marketAverages.leadTime;
  const yourLeadTime = yourBusiness.leadTimeDays;
  const timeAdvantage = ((avgLeadTime - yourLeadTime) / avgLeadTime) * 100;

  // Dane do wykresu cen
  const priceChartData = pricingComparisonData.map((item) => ({
    ...item,
    isYou: item.name.includes("3D Print Hub"),
  }));

  // Dane do mapy pozycjonowania
  const scatterData = positioningData.map((item) => ({
    ...item,
    isYou: item.name.includes("3D Print Hub"),
  }));

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Analiza Konkurencji
            </h1>
            <p className="text-gray-400 mt-1">
              Kompleksowa analiza rynku druku 3D w Polsce
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 px-4 py-2">
              <Target className="w-4 h-4 mr-2" />
              6 konkurentów
            </Badge>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2">
              <TrendingUp className="w-4 h-4 mr-2" />
              Dane: 2024
            </Badge>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Twoja cena / cm³</p>
                  <p className="text-2xl font-bold text-white">{yourPricePerCm3.toFixed(2)} PLN</p>
                  <p className={`text-sm flex items-center gap-1 ${priceDifference < 0 ? "text-green-400" : "text-red-400"}`}>
                    {priceDifference < 0 ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
                    {Math.abs(priceDifference).toFixed(0)}% vs średnia
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Czas realizacji</p>
                  <p className="text-2xl font-bold text-white">{yourBusiness.leadTime}</p>
                  <p className="text-sm text-green-400 flex items-center gap-1">
                    <TrendingDown className="w-4 h-4" />
                    {timeAdvantage.toFixed(0)}% szybciej
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Jakość (ocena)</p>
                  <p className="text-2xl font-bold text-white">{yourBusiness.qualityScore}/10</p>
                  <p className="text-sm text-blue-400">
                    Top {(competitors.filter(c => c.qualityScore > yourBusiness.qualityScore).length + 1)} na rynku
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Award className="w-6 h-6 text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Unikalne technologie</p>
                  <p className="text-2xl font-bold text-white">Multicolor</p>
                  <p className="text-sm text-amber-400">
                    Tylko Ty oferujesz!
                  </p>
                </div>
                <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-amber-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content Tabs */}
      <div className="max-w-7xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-gray-900/50 border border-gray-800 mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <BarChart3 className="w-4 h-4 mr-2" />
              Przegląd
            </TabsTrigger>
            <TabsTrigger value="competitors" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <Target className="w-4 h-4 mr-2" />
              Konkurenci
            </TabsTrigger>
            <TabsTrigger value="pricing" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <DollarSign className="w-4 h-4 mr-2" />
              Cenniki
            </TabsTrigger>
            <TabsTrigger value="positioning" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <MapPin className="w-4 h-4 mr-2" />
              Pozycjonowanie
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <Lightbulb className="w-4 h-4 mr-2" />
              Rekomendacje
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Your Advantages */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-amber-400" />
                  Twoje Przewagi Konkurencyjne
                </CardTitle>
                <CardDescription>
                  Co wyróżnia 3D Print Business Hub na tle konkurencji
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    {
                      icon: Palette,
                      title: "Multicolor bez malowania",
                      description: "H2D + AMS - druk w wielu kolorach bez konieczności malowania",
                      unique: true,
                    },
                    {
                      icon: Layers,
                      title: "Dual Nozzle",
                      description: "Druk z supportami rozpuszczalnymi (BVOH/PVA) dla najwyższej jakości",
                      unique: false,
                    },
                    {
                      icon: Maximize,
                      title: "Duży Build Volume",
                      description: "300×300×400mm - jeden z największych na rynku FDM",
                      unique: false,
                    },
                    {
                      icon: Timer,
                      title: "Szybki czas realizacji",
                      description: "24-48h - średnio 60% szybciej niż konkurencja",
                      unique: false,
                    },
                  ].map((advantage, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border ${
                        advantage.unique
                          ? "bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30"
                          : "bg-gray-800/50 border-gray-700"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          advantage.unique ? "bg-amber-500/20" : "bg-blue-500/20"
                        }`}>
                          <advantage.icon className={`w-5 h-5 ${
                            advantage.unique ? "text-amber-400" : "text-blue-400"
                          }`} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-sm">{advantage.title}</h4>
                            {advantage.unique && (
                              <Badge className="bg-amber-500/20 text-amber-400 text-xs">UNIKALNE</Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-400 mt-1">{advantage.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <h4 className="font-semibold text-blue-400 mb-3 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Pełna lista przewag
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {yourBusiness.advantages.map((adv, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-300">
                        <div className="w-1.5 h-1.5 bg-blue-400 rounded-full" />
                        {adv}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Market Summary */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-400" />
                    Podsumowanie Rynku
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                      <span className="text-gray-400">Średnia cena / cm³</span>
                      <span className="font-semibold">{avgPricePerCm3.toFixed(2)} PLN</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                      <span className="text-gray-400">Średni czas realizacji</span>
                      <span className="font-semibold">{avgLeadTime.toFixed(1)} dni</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                      <span className="text-gray-400">Średnia ocena jakości</span>
                      <span className="font-semibold">{marketAverages.qualityScore.toFixed(1)}/10</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-800/50 rounded-lg">
                      <span className="text-gray-400">Liczba analizowanych firm</span>
                      <span className="font-semibold">{competitors.length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="w-5 h-5 text-purple-400" />
                    Segmentacja Rynku
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-amber-400 font-medium">Premium</span>
                        <span className="text-gray-400">
                          {competitors.filter((c) => c.marketPosition === "premium").length} firm
                        </span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{
                            width: `${(competitors.filter((c) => c.marketPosition === "premium").length / competitors.length) * 100}%`,
                          }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Wysoka jakość, wysokie ceny, długi czas realizacji
                      </p>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-blue-400 font-medium">Średni</span>
                        <span className="text-gray-400">
                          {competitors.filter((c) => c.marketPosition === "mid").length} firmy
                        </span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500 rounded-full"
                          style={{
                            width: `${(competitors.filter((c) => c.marketPosition === "mid").length / competitors.length) * 100}%`,
                          }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Dobra jakość, umiarkowane ceny, standardowy czas
                      </p>
                    </div>

                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-green-400 font-medium">Budget</span>
                        <span className="text-gray-400">
                          {competitors.filter((c) => c.marketPosition === "budget").length} firmy
                        </span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 rounded-full"
                          style={{
                            width: `${(competitors.filter((c) => c.marketPosition === "budget").length / competitors.length) * 100}%`,
                          }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Podstawowa jakość, niskie ceny, zmienny czas
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Competitors Tab */}
          <TabsContent value="competitors">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-400" />
                  Szczegółowa Analiza Konkurentów
                </CardTitle>
                <CardDescription>
                  Kompletne dane o wszystkich analizowanych firmach
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-800 hover:bg-transparent">
                        <TableHead className="text-gray-400">Firma</TableHead>
                        <TableHead className="text-gray-400">Cennik</TableHead>
                        <TableHead className="text-gray-400">Technologie</TableHead>
                        <TableHead className="text-gray-400">Materiały</TableHead>
                        <TableHead className="text-gray-400">Czas</TableHead>
                        <TableHead className="text-gray-400">Ocena</TableHead>
                        <TableHead className="text-gray-400">Pozycja</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {competitors.map((competitor) => (
                        <TableRow key={competitor.id} className="border-gray-800 hover:bg-gray-800/50">
                          <TableCell>
                            <div className="font-medium">{competitor.name}</div>
                            {competitor.website && (
                              <a
                                href={competitor.website}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-blue-400 hover:underline"
                              >
                                {competitor.website.replace("https://", "")}
                              </a>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm space-y-1">
                              <div>{competitor.pricing.perCm3.toFixed(2)} PLN/cm³</div>
                              <div className="text-gray-500">{competitor.pricing.perHour.toFixed(0)} PLN/h</div>
                              <div className="text-gray-500">{competitor.pricing.perGram.toFixed(2)} PLN/g</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {competitor.technologies.map((tech) => (
                                <TechnologyBadge key={tech} tech={tech} />
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {competitor.materials.slice(0, 3).join(", ")}
                              {competitor.materials.length > 3 && (
                                <span className="text-gray-500"> +{competitor.materials.length - 3}</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-gray-500" />
                              {competitor.leadTime}
                            </div>
                          </TableCell>
                          <TableCell>
                            <RatingStars rating={competitor.overallRating} />
                          </TableCell>
                          <TableCell>
                            <MarketPositionBadge position={competitor.marketPosition} />
                          </TableCell>
                        </TableRow>
                      ))}
                      {/* Your Business Row */}
                      <TableRow className="border-blue-500/30 bg-blue-500/5">
                        <TableCell>
                          <div className="font-bold text-blue-400 flex items-center gap-2">
                            <Crown className="w-4 h-4" />
                            {yourBusiness.name}
                          </div>
                          <span className="text-xs text-blue-400/70">(Twoja firma)</span>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm space-y-1">
                            <div className="font-semibold text-blue-400">{yourBusiness.pricing.perCm3.toFixed(2)} PLN/cm³</div>
                            <div className="text-gray-500">{yourBusiness.pricing.perHour.toFixed(0)} PLN/h</div>
                            <div className="text-gray-500">{yourBusiness.pricing.perGram.toFixed(2)} PLN/g</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {yourBusiness.technologies.map((tech) => (
                              <TechnologyBadge key={tech} tech={tech} />
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {yourBusiness.materials.slice(0, 3).join(", ")}
                            {yourBusiness.materials.length > 3 && (
                              <span className="text-gray-500"> +{yourBusiness.materials.length - 3}</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-green-400">
                            <Clock className="w-4 h-4" />
                            {yourBusiness.leadTime}
                          </div>
                        </TableCell>
                        <TableCell>
                          <RatingStars rating={yourBusiness.qualityScore} />
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                            Sweet Spot
                          </Badge>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                {/* Strengths & Weaknesses */}
                <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {competitors.slice(0, 3).map((competitor) => (
                    <Card key={competitor.id} className="bg-gray-800/30 border-gray-700">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg">{competitor.name}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-green-400 mb-2 flex items-center gap-2">
                            <CheckCircle className="w-4 h-4" />
                            Mocne strony
                          </h4>
                          <ul className="space-y-1">
                            {competitor.strengths.map((strength, idx) => (
                              <li key={idx} className="text-sm text-gray-400 flex items-start gap-2">
                                <span className="text-green-500 mt-1">+</span>
                                {strength}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium text-red-400 mb-2 flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" />
                            Słabe strony
                          </h4>
                          <ul className="space-y-1">
                            {competitor.weaknesses.map((weakness, idx) => (
                              <li key={idx} className="text-sm text-gray-400 flex items-start gap-2">
                                <span className="text-red-500 mt-1">-</span>
                                {weakness}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pricing Tab */}
          <TabsContent value="pricing" className="space-y-6">
            {/* Price Comparison Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-green-400" />
                    Porównanie Cen - PLN/cm³
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={priceChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="name" tick={{ fill: "#9CA3AF", fontSize: 12 }} angle={-45} textAnchor="end" height={80} />
                        <YAxis tick={{ fill: "#9CA3AF" }} />
                        <Tooltip
                          contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151", borderRadius: "8px" }}
                          labelStyle={{ color: "#F3F4F6" }}
                        />
                        <ReferenceLine y={avgPricePerCm3} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: "Średnia", fill: "#F59E0B" }} />
                        <Bar dataKey="perCm3" radius={[4, 4, 0, 0]}>
                          {priceChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.isYou ? "#3B82F6" : "#10B981"} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-blue-400" />
                    Porównanie Cen - PLN/godzinę
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={priceChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis dataKey="name" tick={{ fill: "#9CA3AF", fontSize: 12 }} angle={-45} textAnchor="end" height={80} />
                        <YAxis tick={{ fill: "#9CA3AF" }} />
                        <Tooltip
                          contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151", borderRadius: "8px" }}
                          labelStyle={{ color: "#F3F4F6" }}
                        />
                        <ReferenceLine y={marketAverages.perHour} stroke="#F59E0B" strokeDasharray="3 3" label={{ value: "Średnia", fill: "#F59E0B" }} />
                        <Bar dataKey="perHour" radius={[4, 4, 0, 0]}>
                          {priceChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.isYou ? "#3B82F6" : "#8B5CF6"} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Setup Fees */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="w-5 h-5 text-purple-400" />
                  Opłaty Przygotowawcze (Setup Fee)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={priceChartData} layout="vertical" margin={{ top: 20, right: 30, left: 100, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" horizontal={false} />
                      <XAxis type="number" tick={{ fill: "#9CA3AF" }} />
                      <YAxis dataKey="name" type="category" tick={{ fill: "#9CA3AF", fontSize: 12 }} width={100} />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151", borderRadius: "8px" }}
                        labelStyle={{ color: "#F3F4F6" }}
                        formatter={(value: number) => [`${value} PLN`, "Setup Fee"]}
                      />
                      <Bar dataKey="setupFee" radius={[0, 4, 4, 0]}>
                        {priceChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.isYou ? "#3B82F6" : "#EC4899"} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Price Analysis Summary */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle>Analiza Cenowa</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <h4 className="font-semibold text-green-400 mb-2">Twoja Przewaga Cenowa</h4>
                    <p className="text-3xl font-bold text-white">{Math.abs(priceDifference).toFixed(0)}%</p>
                    <p className="text-sm text-gray-400 mt-1">Poniżej średniej rynkowej</p>
                    <p className="text-xs text-green-400 mt-2">
                      Twoja cena: {yourPricePerCm3.toFixed(2)} PLN/cm³
                    </p>
                  </div>

                  <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                    <h4 className="font-semibold text-blue-400 mb-2">Najtańszy Konkurent</h4>
                    <p className="text-xl font-bold text-white">
                      {competitors.reduce((min, c) => (c.pricing.perCm3 < min.pricing.perCm3 ? c : min)).name}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">
                      {Math.min(...competitors.map((c) => c.pricing.perCm3)).toFixed(2)} PLN/cm³
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      Różnica: +{((yourPricePerCm3 - Math.min(...competitors.map((c) => c.pricing.perCm3))) / Math.min(...competitors.map((c) => c.pricing.perCm3)) * 100).toFixed(0)}%
                    </p>
                  </div>

                  <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                    <h4 className="font-semibold text-red-400 mb-2">Najdroższy Konkurent</h4>
                    <p className="text-xl font-bold text-white">
                      {competitors.reduce((max, c) => (c.pricing.perCm3 > max.pricing.perCm3 ? c : max)).name}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">
                      {Math.max(...competitors.map((c) => c.pricing.perCm3)).toFixed(2)} PLN/cm³
                    </p>
                    <p className="text-xs text-green-400 mt-2">
                      Różnica: -{((Math.max(...competitors.map((c) => c.pricing.perCm3)) - yourPricePerCm3) / Math.max(...competitors.map((c) => c.pricing.perCm3)) * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Positioning Tab */}
          <TabsContent value="positioning" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-purple-400" />
                  Mapa Pozycjonowania: Cena vs Jakość vs Czas
                </CardTitle>
                <CardDescription>
                  Oś X: Cena (wyższa = droższa) | Oś Y: Jakość | Rozmiar: Czas realizacji (mniejszy = szybciej)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis
                        type="number"
                        dataKey="price"
                        name="Cena"
                        tick={{ fill: "#9CA3AF" }}
                        label={{ value: "Cena (wyższa = droższa)", position: "bottom", fill: "#9CA3AF" }}
                        domain={[0, 10]}
                      />
                      <YAxis
                        type="number"
                        dataKey="quality"
                        name="Jakość"
                        tick={{ fill: "#9CA3AF" }}
                        label={{ value: "Jakość", angle: -90, position: "insideLeft", fill: "#9CA3AF" }}
                        domain={[0, 10]}
                      />
                      <ZAxis type="number" dataKey="size" range={[100, 500]} />
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-gray-800 border border-gray-700 p-3 rounded-lg shadow-lg">
                                <p className="font-semibold text-white">{data.name}</p>
                                <p className="text-sm text-gray-400">Jakość: {data.quality}/10</p>
                                <p className="text-sm text-gray-400">Cena: {data.price}/10</p>
                                <p className="text-sm text-gray-400">Czas: {data.time} dni</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Scatter data={scatterData}>
                        {scatterData.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={entry.isYou ? "#3B82F6" : "#10B981"}
                            stroke={entry.isYou ? "#60A5FA" : "#34D399"}
                            strokeWidth={entry.isYou ? 3 : 1}
                          />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>

                {/* Legend */}
                <div className="flex flex-wrap justify-center gap-6 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-blue-400" />
                    <span className="text-sm text-gray-400">Twoja firma</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-500 rounded-full" />
                    <span className="text-sm text-gray-400">Konkurenci</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-gray-500 rounded-full" />
                    <span className="text-sm text-gray-400">Mały = szybki czas</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 bg-gray-500 rounded-full" />
                    <span className="text-sm text-gray-400">Duży = wolny czas</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Position Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-400" />
                    Twoja Pozycja
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                      <h4 className="font-semibold text-blue-400 mb-2">Sweet Spot Rynku</h4>
                      <p className="text-sm text-gray-300">
                        Znajdujesz się w optymalnym punkcie: wysoka jakość (8.5/10) przy konkurencyjnej cenie.
                        Jesteś jedyną firmą oferującą multicolor bez malowania.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-400">Jakość vs rywalizacja</span>
                          <span className="text-sm text-green-400">Top 3</span>
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div className="h-full bg-green-500 rounded-full" style={{ width: "85%" }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-400">Cena vs rywalizacja</span>
                          <span className="text-sm text-green-400">Poniżej średniej</span>
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{ width: "45%" }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-400">Czas vs rywalizacja</span>
                          <span className="text-sm text-green-400">Najszybszy</span>
                        </div>
                        <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                          <div className="h-full bg-amber-500 rounded-full" style={{ width: "15%" }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-400" />
                    Przewagi Konkurencyjne
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { label: "Multicolor", you: true, competitors: 0 },
                      { label: "Dual nozzle", you: true, competitors: 2 },
                      { label: "Build volume >300mm", you: true, competitors: 3 },
                      { label: "Czas <48h", you: true, competitors: 1 },
                      { label: "Cena <1 PLN/cm³", you: true, competitors: 3 },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                        <span className="text-sm">{item.label}</span>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <span className="text-xs text-gray-500">Konkurenci: </span>
                            <span className="text-sm text-gray-400">{item.competitors}/6</span>
                          </div>
                          <Badge className={item.you ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}>
                            {item.you ? "TAK" : "NIE"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations" className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-400" />
                  Rekomendacje Strategiczne
                </CardTitle>
                <CardDescription>
                  Jak konkurować i rozwijać 3D Print Business Hub
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Pricing Strategy */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-green-400" />
                      {strategicRecommendations.pricing.title}
                    </h3>
                    <div className="space-y-3">
                      {strategicRecommendations.pricing.items.map((item, index) => (
                        <div key={index} className="p-3 bg-gray-800/50 rounded-lg flex items-start gap-3">
                          <PriorityBadge priority={item.priority} />
                          <p className="text-sm text-gray-300">{item.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Positioning */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Target className="w-5 h-5 text-blue-400" />
                      {strategicRecommendations.positioning.title}
                    </h3>
                    <div className="space-y-3">
                      {strategicRecommendations.positioning.items.map((item, index) => (
                        <div key={index} className="p-3 bg-gray-800/50 rounded-lg flex items-start gap-3">
                          <PriorityBadge priority={item.priority} />
                          <p className="text-sm text-gray-300">{item.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Marketing */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-purple-400" />
                      {strategicRecommendations.marketing.title}
                    </h3>
                    <div className="space-y-3">
                      {strategicRecommendations.marketing.items.map((item, index) => (
                        <div key={index} className="p-3 bg-gray-800/50 rounded-lg flex items-start gap-3">
                          <PriorityBadge priority={item.priority} />
                          <p className="text-sm text-gray-300">{item.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Operations */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                      <Layers className="w-5 h-5 text-orange-400" />
                      {strategicRecommendations.operations.title}
                    </h3>
                    <div className="space-y-3">
                      {strategicRecommendations.operations.items.map((item, index) => (
                        <div key={index} className="p-3 bg-gray-800/50 rounded-lg flex items-start gap-3">
                          <PriorityBadge priority={item.priority} />
                          <p className="text-sm text-gray-300">{item.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Plan */}
            <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ArrowRight className="w-5 h-5 text-blue-400" />
                  Plan Działania - Pierwsze 30 Dni
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="font-semibold text-red-400 mb-3">Tydzień 1-2</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start gap-2">
                        <span className="text-red-500">1.</span>
                        Stwórz galerię realizacji multicolor
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500">2.</span>
                        Przygotuj porównanie z konkurencją
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-500">3.</span>
                        Zaktualizuj stronę/www o USP
                      </li>
                    </ul>
                  </div>

                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="font-semibold text-yellow-400 mb-3">Tydzień 3-4</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-500">1.</span>
                        Uruchom kampanię social media
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-500">2.</span>
                        Skontaktuj się z 10 potencjalnymi klientami
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-yellow-500">3.</span>
                        Zbierz pierwsze opinie/referencje
                      </li>
                    </ul>
                  </div>

                  <div className="p-4 bg-gray-900/50 rounded-lg">
                    <h4 className="font-semibold text-green-400 mb-3">Tydzień 4+</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start gap-2">
                        <span className="text-green-500">1.</span>
                        Analizuj wyniki i dostosuj cennik
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-500">2.</span>
                        Rozważ program partnerski
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-green-500">3.</span>
                        Planuj rozszerzenie oferty
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CompetitionAnalysis;
