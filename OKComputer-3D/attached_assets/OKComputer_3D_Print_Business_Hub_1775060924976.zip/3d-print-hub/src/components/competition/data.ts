// Dane konkurentów dla 3D Print Business Hub
// Realistyczne dane rynkowe oparte na researchu rynku druku 3D w Polsce (2024)

export type Technology = "FDM" | "SLA" | "MJF" | "SLS" | "DLP";

export interface Competitor {
  id: string;
  name: string;
  logo?: string;
  pricing: {
    perCm3: number;      // Cena za cm³ (PLN)
    perHour: number;     // Cena za godzinę druku (PLN)
    perGram: number;     // Cena za gram materiału (PLN)
    setupFee: number;    // Opłata przygotowawcza (PLN)
  };
  technologies: Technology[];
  materials: string[];
  leadTime: string;      // Czas realizacji
  leadTimeDays: number;  // Czas w dniach (dla wykresów)
  strengths: string[];
  weaknesses: string[];
  overallRating: number; // 1-10
  qualityScore: number;  // 1-10 (dla mapy pozycjonowania)
  priceScore: number;    // 1-10 (dla mapy pozycjonowania - wyższa = droższa)
  marketPosition: "premium" | "mid" | "budget";
  website?: string;
  minOrderValue?: number;
  deliveryOptions: string[];
  customerService: "excellent" | "good" | "average" | "poor";
}

export interface YourBusiness {
  name: string;
  pricing: {
    perCm3: number;
    perHour: number;
    perGram: number;
    setupFee: number;
  };
  technologies: Technology[];
  materials: string[];
  leadTime: string;
  leadTimeDays: number;
  advantages: string[];
  qualityScore: number;
  priceScore: number;
}

// Dane Twojej firmy - 3D Print Business Hub
export const yourBusiness: YourBusiness = {
  name: "3D Print Business Hub",
  pricing: {
    perCm3: 0.85,
    perHour: 18.0,
    perGram: 0.42,
    setupFee: 15.0,
  },
  technologies: ["FDM", "SLA"],
  materials: [
    "PLA",
    "PETG",
    "ABS",
    "TPU",
    "ASA",
    "Multicolor (H2D + AMS)",
    "Resina Standard",
    "Resina Tough",
  ],
  leadTime: "24-48h",
  leadTimeDays: 1.5,
  advantages: [
    "Multicolor bez malowania (H2D + AMS)",
    "Dual nozzle - druk z supportami rozpuszczalnymi",
    "Duży build volume (300×300×400mm)",
    "Szybki czas realizacji (24-48h)",
    "Konkurencyjne ceny",
    "Druk wielomateriałowy",
    "Precyzyjne wykończenie (±0.1mm)",
    "Lokalna produkcja - brak wysyłki z zagranicy",
  ],
  qualityScore: 8.5,
  priceScore: 4.5, // Niska cena = niski score (odwrotnie niż quality)
};

// Dane konkurentów
export const competitors: Competitor[] = [
  {
    id: "fibometry",
    name: "Fibometry",
    pricing: {
      perCm3: 1.2,
      perHour: 25.0,
      perGram: 0.65,
      setupFee: 30.0,
    },
    technologies: ["FDM", "SLA", "SLS"],
    materials: [
      "PLA",
      "PETG",
      "ABS",
      "TPU",
      "Nylon",
      "Resina",
      "PA12 (SLS)",
    ],
    leadTime: "3-5 dni",
    leadTimeDays: 4,
    strengths: [
      "Duże doświadczenie na rynku",
      "Szeroka gama technologii",
      "Wysoka jakość wykończenia",
      "Profesjonalna obsługa klienta",
      "Certyfikaty jakości",
    ],
    weaknesses: [
      "Wysokie ceny",
      "Długi czas realizacji",
      "Wysoka minimalna wartość zamówienia",
      "Brak multicolor bez malowania",
    ],
    overallRating: 8.2,
    qualityScore: 9.0,
    priceScore: 8.5,
    marketPosition: "premium",
    website: "https://fibometry.com",
    minOrderValue: 100,
    deliveryOptions: ["Kurier", "Odbiór osobisty"],
    customerService: "excellent",
  },
  {
    id: "send3d",
    name: "Send3D",
    pricing: {
      perCm3: 0.95,
      perHour: 22.0,
      perGram: 0.48,
      setupFee: 20.0,
    },
    technologies: ["FDM", "SLA", "MJF"],
    materials: [
      "PLA",
      "PETG",
      "ABS",
      "ASA",
      "PC",
      "Resina",
      "PA11 (MJF)",
    ],
    leadTime: "2-4 dni",
    leadTimeDays: 3,
    strengths: [
      "Szybka wycena online",
      "Dobra jakość druku",
      "Przyjazny interfejs zamówień",
      "Program lojalnościowy",
    ],
    weaknesses: [
      "Ograniczone moce przerobowe",
      "Brak druku multicolor",
      "Wysokie ceny dla małych zamówień",
      "Długi czas realizacji w peak",
    ],
    overallRating: 7.5,
    qualityScore: 7.8,
    priceScore: 6.5,
    marketPosition: "mid",
    website: "https://send3d.pl",
    minOrderValue: 50,
    deliveryOptions: ["Kurier", "InPost", "Odbiór osobisty"],
    customerService: "good",
  },
  {
    id: "3d-innowacje",
    name: "3D-innowacje",
    pricing: {
      perCm3: 1.5,
      perHour: 35.0,
      perGram: 0.85,
      setupFee: 50.0,
    },
    technologies: ["FDM", "SLA", "SLS", "MJF"],
    materials: [
      "PLA",
      "PETG",
      "ABS",
      "PC",
      "PEEK",
      "Resina",
      "PA12",
      "Metal (bound metal)",
    ],
    leadTime: "5-7 dni",
    leadTimeDays: 6,
    strengths: [
      "Najwyższa jakość na rynku",
      "Druk z materiałów technicznych (PEEK)",
      "Certyfikaty branżowe",
      "Wsparcie inżynieryjne",
      "Druk metalowy",
    ],
    weaknesses: [
      "Bardzo wysokie ceny",
      "Bardzo długi czas realizacji",
      "Wysoka bariera wejścia",
      "Skierowani do dużych firm",
    ],
    overallRating: 9.0,
    qualityScore: 9.8,
    priceScore: 9.5,
    marketPosition: "premium",
    website: "https://3d-innowacje.pl",
    minOrderValue: 500,
    deliveryOptions: ["Kurier", "Dostawa własna"],
    customerService: "excellent",
  },
  {
    id: "craft3d",
    name: "Craft3D",
    pricing: {
      perCm3: 0.65,
      perHour: 15.0,
      perGram: 0.35,
      setupFee: 10.0,
    },
    technologies: ["FDM"],
    materials: ["PLA", "PETG", "ABS"],
    leadTime: "2-3 dni",
    leadTimeDays: 2.5,
    strengths: [
      "Niskie ceny",
      "Szybka realizacja prostych zleceń",
      "Brak minimalnej wartości zamówienia",
      "Przyjazny dla hobbystów",
    ],
    weaknesses: [
      "Tylko FDM",
      "Ograniczone materiały",
      "Niższa jakość wykończenia",
      "Brak wsparcia technicznego",
      "Brak druku technicznego",
    ],
    overallRating: 6.0,
    qualityScore: 5.5,
    priceScore: 3.0,
    marketPosition: "budget",
    website: "https://craft3d.pl",
    minOrderValue: 0,
    deliveryOptions: ["Kurier", "InPost", "Odbiór osobisty"],
    customerService: "average",
  },
  {
    id: "p3drc",
    name: "P3DRC",
    pricing: {
      perCm3: 0.78,
      perHour: 17.5,
      perGram: 0.4,
      setupFee: 12.0,
    },
    technologies: ["FDM", "SLA"],
    materials: [
      "PLA",
      "PETG",
      "ABS",
      "TPU",
      "ASA",
      "Resina Standard",
      "Resina Tough",
    ],
    leadTime: "2-4 dni",
    leadTimeDays: 3,
    strengths: [
      "Dobre ceny",
      "Szeroka gama materiałów FDM",
      "Dobra jakość SLA",
      "Elastyczne terminy",
    ],
    weaknesses: [
      "Brak zaawansowanych technologii",
      "Ograniczona przepustowość",
      "Brak druku multicolor",
      "Słabsza obsługa klienta",
    ],
    overallRating: 6.8,
    qualityScore: 6.5,
    priceScore: 4.0,
    marketPosition: "mid",
    website: "https://p3drc.pl",
    minOrderValue: 30,
    deliveryOptions: ["Kurier", "Odbiór osobisty"],
    customerService: "average",
  },
  {
    id: "drukarnie-lokalne",
    name: "Drukarnie Lokalne",
    pricing: {
      perCm3: 0.55,
      perHour: 12.0,
      perGram: 0.28,
      setupFee: 0.0,
    },
    technologies: ["FDM"],
    materials: ["PLA", "PETG"],
    leadTime: "1-7 dni",
    leadTimeDays: 4,
    strengths: [
      "Najniższe ceny",
      "Lokalny kontakt",
      "Brak opłat przygotowawczych",
      "Negocjacje cenowe",
    ],
    weaknesses: [
      "Niestabilna jakość",
      "Brak gwarancji terminów",
      "Ograniczone możliwości",
      "Brak faktur/profesjonalizmu",
      "Tylko podstawowe materiały",
    ],
    overallRating: 4.5,
    qualityScore: 4.0,
    priceScore: 1.5,
    marketPosition: "budget",
    website: undefined,
    minOrderValue: 0,
    deliveryOptions: ["Odbiór osobisty"],
    customerService: "poor",
  },
];

// Dane do wykresów
export const pricingComparisonData = [
  {
    name: "Fibometry",
    perCm3: 1.2,
    perHour: 25.0,
    perGram: 0.65,
    setupFee: 30.0,
  },
  {
    name: "Send3D",
    perCm3: 0.95,
    perHour: 22.0,
    perGram: 0.48,
    setupFee: 20.0,
  },
  {
    name: "3D-innowacje",
    perCm3: 1.5,
    perHour: 35.0,
    perGram: 0.85,
    setupFee: 50.0,
  },
  {
    name: "Craft3D",
    perCm3: 0.65,
    perHour: 15.0,
    perGram: 0.35,
    setupFee: 10.0,
  },
  {
    name: "P3DRC",
    perCm3: 0.78,
    perHour: 17.5,
    perGram: 0.4,
    setupFee: 12.0,
  },
  {
    name: "Drukarnie Lokalne",
    perCm3: 0.55,
    perHour: 12.0,
    perGram: 0.28,
    setupFee: 0.0,
  },
  {
    name: "3D Print Hub (Ty)",
    perCm3: 0.85,
    perHour: 18.0,
    perGram: 0.42,
    setupFee: 15.0,
    isYou: true,
  },
];

// Dane do mapy pozycjonowania
export const positioningData = [
  { name: "Fibometry", price: 8.5, quality: 9.0, time: 4, size: 300 },
  { name: "Send3D", price: 6.5, quality: 7.8, time: 3, size: 250 },
  { name: "3D-innowacje", price: 9.5, quality: 9.8, time: 6, size: 200 },
  { name: "Craft3D", price: 3.0, quality: 5.5, time: 2.5, size: 200 },
  { name: "P3DRC", price: 4.0, quality: 6.5, time: 3, size: 180 },
  { name: "Drukarnie Lokalne", price: 1.5, quality: 4.0, time: 4, size: 150 },
  { name: "3D Print Hub (Ty)", price: 4.5, quality: 8.5, time: 1.5, size: 350, isYou: true },
];

// Średnie rynkowe
export const marketAverages = {
  perCm3: competitors.reduce((acc, c) => acc + c.pricing.perCm3, 0) / competitors.length,
  perHour: competitors.reduce((acc, c) => acc + c.pricing.perHour, 0) / competitors.length,
  perGram: competitors.reduce((acc, c) => acc + c.pricing.perGram, 0) / competitors.length,
  setupFee: competitors.reduce((acc, c) => acc + c.pricing.setupFee, 0) / competitors.length,
  leadTime: competitors.reduce((acc, c) => acc + c.leadTimeDays, 0) / competitors.length,
  qualityScore: competitors.reduce((acc, c) => acc + c.qualityScore, 0) / competitors.length,
};

// Rekomendacje strategiczne
export const strategicRecommendations = {
  pricing: {
    title: "Strategia Cenowa",
    items: [
      {
        priority: "high",
        text: "Utrzymaj obecne ceny - jesteś 15% poniżej średniej rynkowej",
      },
      {
        priority: "medium",
        text: "Wprowadź rabaty progresywne przy zamówieniach powyżej 500 PLN",
      },
      {
        priority: "medium",
        text: "Dodaj opcję 'Express' z dopłatą 30% za realizację w 24h",
      },
      {
        priority: "low",
        text: "Rozważ pakiet startowy dla nowych klientów (-20% na pierwsze zamówienie)",
      },
    ],
  },
  positioning: {
    title: "Pozycjonowanie",
    items: [
      {
        priority: "high",
        text: "Skup się na multicolor - unikalna przewaga nad konkurencją",
      },
      {
        priority: "high",
        text: "Promuj szybki czas realizacji (24-48h) jako kluczowy USP",
      },
      {
        priority: "medium",
        text: "Targetuj małe i średnie firmy oraz projektantów produktów",
      },
      {
        priority: "medium",
        text: "Buduj wizerunek 'szybkiej i jakościowej' alternatywy",
      },
    ],
  },
  marketing: {
    title: "Marketing",
    items: [
      {
        priority: "high",
        text: "Stwórz galerię realizacji multicolor - pokaż możliwości",
      },
      {
        priority: "high",
        text: "Nagraj timelapse druku multicolor na social media",
      },
      {
        priority: "medium",
        text: "Współpracuj z influencerami z branży 3D/tech",
      },
      {
        priority: "medium",
        text: "Oferuj darmowe próbki materiałów potencjalnym klientom",
      },
    ],
  },
  operations: {
    title: "Operacje",
    items: [
      {
        priority: "high",
        text: "Zainwestuj w dodatkowe AMS dla większej elastyczności kolorów",
      },
      {
        priority: "medium",
        text: "Rozważ dodanie druku SLA dla prototypów wysokiej rozdzielczości",
      },
      {
        priority: "medium",
        text: "Wdrażaj system zarządzania zamówieniami (CRM)",
      },
      {
        priority: "low",
        text: "Planuj rozszerzenie o druk SLS w przyszłości",
      },
    ],
  },
};

// Technologie - opisy
export const technologyDescriptions: Record<Technology, { name: string; description: string; useCases: string[] }> = {
  FDM: {
    name: "FDM (Fused Deposition Modeling)",
    description: "Najpopularniejsza technologia druku 3D. Materiał termoplastyczny jest rozgrzewany i nakładany warstwa po warstwie.",
    useCases: ["Prototypy", "Elementy funkcjonalne", "Modele", "Obudowy"],
  },
  SLA: {
    name: "SLA (Stereolithography)",
    description: "Technologia żywiczna zapewniająca najwyższą precyzję i jakość powierzchni.",
    useCases: ["Wysokiej jakości prototypy", "Modele detalistyczne", "Formy", "Biżuteria"],
  },
  SLS: {
    name: "SLS (Selective Laser Sintering)",
    description: "Spiekanie proszku poliamidowego laserem. Nie wymaga supportów.",
    useCases: ["Elementy techniczne", "Prototypy funkcjonalne", "Małe serie produkcyjne"],
  },
  MJF: {
    name: "MJF (Multi Jet Fusion)",
    description: "Technologia HP do produkcji funkcjonalnych części z najwyższą wytrzymałością.",
    useCases: ["Części techniczne", "Produkcja końcowa", "Złożone geometrie"],
  },
  DLP: {
    name: "DLP (Digital Light Processing)",
    description: "Podobna do SLA, ale używa projektora zamiast lasera. Szybsza dla większych partii.",
    useCases: ["Prototypy", "Modele stomatologiczne", "Biżuteria"],
  },
};

// Materiały - opisy
export const materialDescriptions: Record<string, { name: string; properties: string[]; applications: string[]; priceRange: string }> = {
  "PLA": {
    name: "PLA (Polylactic Acid)",
    properties: ["Łatwy w druku", "Biodegradowalny", "Niska wytrzymałość termiczna", "Dobra sztywność"],
    applications: ["Modele", "Prototypy wizualne", "Elementy dekoracyjne"],
    priceRange: "0.30-0.50 PLN/g",
  },
  "PETG": {
    name: "PETG",
    properties: ["Wysoka wytrzymałość", "Odporność chemiczna", "Łatwy w druku", "Przezroczysty"],
    applications: ["Elementy funkcjonalne", "Pojemniki", "Części mechaniczne"],
    priceRange: "0.40-0.60 PLN/g",
  },
  "ABS": {
    name: "ABS",
    properties: ["Wysoka wytrzymałość", "Odporność na temperaturę", "Wymaga zamkniętej komory"],
    applications: ["Części techniczne", "Automotive", "Elektronika"],
    priceRange: "0.45-0.70 PLN/g",
  },
  "TPU": {
    name: "TPU (Termoplastyczny poliuretan)",
    properties: ["Elastyczny", "Odporny na ścieranie", "Gumowaty"],
    applications: ["Uszczelki", "Pokrowce", "Elementy amortyzujące"],
    priceRange: "0.60-0.90 PLN/g",
  },
  "ASA": {
    name: "ASA",
    properties: ["Odporny na UV", "Wysoka wytrzymałość", "Dobry na zewnątrz"],
    applications: ["Elementy zewnętrzne", "Automotive", "Ogród"],
    priceRange: "0.50-0.80 PLN/g",
  },
};
