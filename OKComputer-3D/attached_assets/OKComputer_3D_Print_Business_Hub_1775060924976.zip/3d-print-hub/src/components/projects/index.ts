// Types
export type {
  Project,
  ProjectStatus,
  ProjectCategory,
  MaterialType,
  DifficultyLevel,
  ProjectLink,
  StatusHistoryEntry,
  MarginCalculation,
  ProjectFilters,
} from './types';

// Constants
export {
  STATUS_CONFIG,
  CATEGORY_OPTIONS,
  MATERIAL_OPTIONS,
  DIFFICULTY_OPTIONS,
  PLATFORM_CONFIG,
} from './types';

// Hooks
export { useProjects } from './useProjects';

// Components
export { ProjectsModule } from './ProjectsModule';
export { ProjectCard } from './ProjectCard';
export { ProjectGrid } from './ProjectGrid';
export { ProjectFilters } from './ProjectFilters';
export { ProjectDetails } from './ProjectDetails';
export { ProjectForm } from './ProjectForm';
export { MarginCalculator } from './MarginCalculator';
export { StatusChangeDialog } from './StatusChangeDialog';
export { DeleteConfirmDialog } from './DeleteConfirmDialog';
