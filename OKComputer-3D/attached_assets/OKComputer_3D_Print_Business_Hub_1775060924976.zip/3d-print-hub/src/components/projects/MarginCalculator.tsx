'use client';

import { useEffect, useCallback } from 'react';
import { Calculator, TrendingUp, Wallet, Tag } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { MarginCalculation } from './types';

interface MarginCalculatorProps {
  value: MarginCalculation;
  onChange: (value: MarginCalculation) => void;
  readOnly?: boolean;
}

export function MarginCalculator({ value, onChange, readOnly = false }: MarginCalculatorProps) {
  const calculateMargin = useCallback((materialCost: number, suggestedPrice: number): MarginCalculation => {
    const marginAmount = suggestedPrice - materialCost;
    const marginPercent = suggestedPrice > 0 ? (marginAmount / suggestedPrice) * 100 : 0;
    
    return {
      materialCost,
      suggestedPrice,
      marginPercent,
      marginAmount,
    };
  }, []);

  const handleMaterialCostChange = (newCost: string) => {
    const cost = parseFloat(newCost) || 0;
    onChange(calculateMargin(cost, value.suggestedPrice));
  };

  const handleSuggestedPriceChange = (newPrice: string) => {
    const price = parseFloat(newPrice) || 0;
    onChange(calculateMargin(value.materialCost, price));
  };

  const getMarginColor = (percent: number) => {
    if (percent >= 70) return 'text-emerald-400';
    if (percent >= 50) return 'text-amber-400';
    if (percent >= 30) return 'text-orange-400';
    return 'text-red-400';
  };

  const getMarginBg = (percent: number) => {
    if (percent >= 70) return 'bg-emerald-500/20 border-emerald-500/30';
    if (percent >= 50) return 'bg-amber-500/20 border-amber-500/30';
    if (percent >= 30) return 'bg-orange-500/20 border-orange-500/30';
    return 'bg-red-500/20 border-red-500/30';
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2 text-zinc-300">
        <Calculator className="w-4 h-4 text-amber-500" />
        <span className="font-medium">Kalkulacja marży</span>
      </div>

      {/* Inputs */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-zinc-400 text-sm flex items-center gap-1.5">
            <Wallet className="w-3.5 h-3.5" />
            Koszt materiału
          </Label>
          <div className="relative">
            <Input
              type="number"
              min="0"
              step="0.01"
              value={value.materialCost || ''}
              onChange={(e) => handleMaterialCostChange(e.target.value)}
              disabled={readOnly}
              className="bg-zinc-900/50 border-zinc-700 text-zinc-100 pr-10 focus:border-amber-500/50 disabled:opacity-70"
              placeholder="0.00"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">
              zł
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-zinc-400 text-sm flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5" />
            Cena sprzedaży
          </Label>
          <div className="relative">
            <Input
              type="number"
              min="0"
              step="0.01"
              value={value.suggestedPrice || ''}
              onChange={(e) => handleSuggestedPriceChange(e.target.value)}
              disabled={readOnly}
              className="bg-zinc-900/50 border-zinc-700 text-zinc-100 pr-10 focus:border-amber-500/50 disabled:opacity-70"
              placeholder="0.00"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">
              zł
            </span>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className={`p-4 rounded-lg border ${getMarginBg(value.marginPercent)}`}>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-zinc-500 mb-1">Zysk netto</div>
            <div className={`text-xl font-bold ${getMarginColor(value.marginPercent)}`}>
              {value.marginAmount.toFixed(2)} zł
            </div>
          </div>
          <div>
            <div className="text-xs text-zinc-500 mb-1">Marża</div>
            <div className={`text-xl font-bold flex items-center gap-1.5 ${getMarginColor(value.marginPercent)}`}>
              <TrendingUp className="w-5 h-5" />
              {value.marginPercent.toFixed(1)}%
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-3">
          <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                value.marginPercent >= 70
                  ? 'bg-emerald-500'
                  : value.marginPercent >= 50
                  ? 'bg-amber-500'
                  : value.marginPercent >= 30
                  ? 'bg-orange-500'
                  : 'bg-red-500'
              }`}
              style={{ width: `${Math.min(value.marginPercent, 100)}%` }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs text-zinc-600">
            <span>0%</span>
            <span>50%</span>
            <span>100%</span>
          </div>
        </div>
      </div>

      {/* Quick Tips */}
      {!readOnly && value.marginPercent > 0 && value.marginPercent < 30 && (
        <div className="text-xs text-orange-400 bg-orange-500/10 border border-orange-500/20 rounded p-2">
          ⚠️ Marża poniżej 30%. Rozważ podwyższenie ceny lub obniżenie kosztów.
        </div>
      )}
      {!readOnly && value.marginPercent >= 70 && (
        <div className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded p-2">
          ✅ Świetna marża! Projekt jest bardzo zyskowny.
        </div>
      )}
    </div>
  );
}
