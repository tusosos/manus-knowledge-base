'use client';

import { useState } from 'react';
import { AlertTriangle, ArrowRight } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import type { ProjectStatus } from './types';
import { STATUS_CONFIG } from './types';

interface StatusChangeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (note?: string) => void;
  currentStatus: ProjectStatus;
  newStatus: ProjectStatus;
}

export function StatusChangeDialog({
  isOpen,
  onClose,
  onConfirm,
  currentStatus,
  newStatus,
}: StatusChangeDialogProps) {
  const [note, setNote] = useState('');

  const currentConfig = STATUS_CONFIG[currentStatus];
  const newConfig = STATUS_CONFIG[newStatus];

  const handleConfirm = () => {
    onConfirm(note.trim() || undefined);
    setNote('');
  };

  const handleClose = () => {
    setNote('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-zinc-950 border-zinc-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Zmiana statusu
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            Czy na pewno chcesz zmienić status tego projektu?
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {/* Status Transition */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className={`px-4 py-2 rounded-lg ${currentConfig.bgColor} ${currentConfig.color} border`}>
              {currentConfig.label}
            </div>
            <ArrowRight className="w-5 h-5 text-zinc-500" />
            <div className={`px-4 py-2 rounded-lg ${newConfig.bgColor} ${newConfig.color} border`}>
              {newConfig.label}
            </div>
          </div>

          {/* Note Input */}
          <div className="space-y-2">
            <label className="text-sm text-zinc-400">
              Notatka do zmiany statusu (opcjonalnie)
            </label>
            <Textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="np. 'Prototyp przetestowany, wszystko działa poprawnie'"
              className="bg-zinc-900 border-zinc-700 text-zinc-100 focus:border-amber-500/50 min-h-[100px]"
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={handleClose}
            className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
          >
            Anuluj
          </Button>
          <Button
            onClick={handleConfirm}
            className="bg-amber-600 hover:bg-amber-700 text-white"
          >
            Potwierdź zmianę
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
