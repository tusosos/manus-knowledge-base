'use client';

import { motion } from 'framer-motion';
import { Box, Layers, Palette, MoreHorizontal } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { Project } from './types';
import { STATUS_CONFIG } from './types';

interface ProjectCardProps {
  project: Project;
  onClick: () => void;
  onEdit: () => void;
}

export function ProjectCard({ project, onClick, onEdit }: ProjectCardProps) {
  const statusConfig = STATUS_CONFIG[project.status];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card 
        className="group cursor-pointer overflow-hidden bg-zinc-900/50 border-zinc-800 hover:border-amber-500/50 transition-colors"
        onClick={onClick}
      >
        {/* Thumbnail */}
        <div className="relative aspect-[4/3] bg-gradient-to-br from-zinc-800 to-zinc-900 overflow-hidden">
          {project.thumbnail ? (
            <img
              src={project.thumbnail}
              alt={project.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                <Box className="w-16 h-16 text-zinc-600" strokeWidth={1.5} />
                <motion.div
                  className="absolute inset-0"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                >
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-500/50" />
                  </div>
                </motion.div>
              </div>
            </div>
          )}
          
          {/* Status Badge */}
          <div className="absolute top-3 left-3">
            <Badge 
              variant="outline" 
              className={`${statusConfig.bgColor} ${statusConfig.color} border backdrop-blur-sm`}
            >
              {statusConfig.label}
            </Badge>
          </div>

          {/* Multicolor Indicator */}
          {project.isMulticolor && (
            <div className="absolute top-3 right-3">
              <Badge 
                variant="outline" 
                className="bg-purple-500/20 border-purple-500/30 text-purple-400 backdrop-blur-sm"
              >
                <Palette className="w-3 h-3 mr-1" />
                Multi
              </Badge>
            </div>
          )}

          {/* Hover Overlay */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              className="bg-zinc-800/90 hover:bg-zinc-700 text-zinc-100"
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
            >
              Edytuj
            </Button>
          </div>
        </div>

        {/* Content */}
        <CardContent className="p-4">
          <h3 className="font-semibold text-zinc-100 truncate mb-2 group-hover:text-amber-400 transition-colors">
            {project.name}
          </h3>
          
          {/* Tags Row */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            <Badge variant="secondary" className="bg-zinc-800 text-zinc-400 text-xs">
              <Layers className="w-3 h-3 mr-1" />
              {project.material}
            </Badge>
            <Badge variant="secondary" className="bg-zinc-800 text-zinc-400 text-xs capitalize">
              {project.category}
            </Badge>
          </div>

          {/* Tags */}
          {project.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {project.tags.slice(0, 3).map((tag) => (
                <span 
                  key={tag} 
                  className="text-xs text-zinc-500 bg-zinc-800/50 px-2 py-0.5 rounded"
                >
                  #{tag}
                </span>
              ))}
              {project.tags.length > 3 && (
                <span className="text-xs text-zinc-500 px-1">
                  +{project.tags.length - 3}
                </span>
              )}
            </div>
          )}

          {/* Margin Preview */}
          <div className="mt-3 pt-3 border-t border-zinc-800 flex items-center justify-between">
            <span className="text-xs text-zinc-500">Marża</span>
            <span className={`text-sm font-medium ${
              project.marginCalculation.marginPercent >= 70 
                ? 'text-emerald-400' 
                : project.marginCalculation.marginPercent >= 40 
                  ? 'text-amber-400' 
                  : 'text-zinc-400'
            }`}>
              {project.marginCalculation.marginPercent.toFixed(1)}%
            </span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
