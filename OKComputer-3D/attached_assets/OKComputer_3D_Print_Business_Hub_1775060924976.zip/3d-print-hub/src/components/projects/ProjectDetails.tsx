'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  ExternalLink, 
  Calendar, 
  Tag, 
  Layers, 
  AlertTriangle, 
  Palette,
  Clock,
  ChevronDown,
  ChevronUp,
  Edit2,
  Trash2,
  MoreVertical,
  History
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import type { Project, ProjectStatus } from './types';
import { STATUS_CONFIG, PLATFORM_CONFIG, DIFFICULTY_OPTIONS } from './types';
import { MarginCalculator } from './MarginCalculator';

interface ProjectDetailsProps {
  project: Project | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onStatusChange: (status: ProjectStatus, note?: string) => void;
}

export function ProjectDetails({
  project,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onStatusChange,
}: ProjectDetailsProps) {
  const [showStatusHistory, setShowStatusHistory] = useState(false);
  const [statusNote, setStatusNote] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  if (!project) return null;

  const statusConfig = STATUS_CONFIG[project.status];

  const handleStatusChange = (newStatus: ProjectStatus) => {
    onStatusChange(newStatus, statusNote);
    setStatusNote('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0 bg-zinc-950 border-zinc-800 overflow-hidden">
        {/* Header Image */}
        <div className="relative h-48 bg-gradient-to-br from-zinc-800 to-zinc-900">
          {project.thumbnail ? (
            <img
              src={project.thumbnail}
              alt={project.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative">
                <div className="w-24 h-24 border-2 border-dashed border-zinc-700 rounded-lg flex items-center justify-center">
                  <Layers className="w-10 h-10 text-zinc-600" />
                </div>
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>
            </div>
          )}
          
          {/* Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-transparent" />
          
          {/* Status Badge */}
          <div className="absolute top-4 left-4">
            <Badge 
              variant="outline" 
              className={`${statusConfig.bgColor} ${statusConfig.color} border backdrop-blur-sm text-sm px-3 py-1`}
            >
              {statusConfig.label}
            </Badge>
          </div>

          {/* Actions */}
          <div className="absolute top-4 right-4 flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="secondary" 
                  size="icon"
                  className="bg-zinc-900/80 backdrop-blur-sm hover:bg-zinc-800"
                >
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-zinc-900 border-zinc-800">
                <DropdownMenuItem 
                  onClick={onEdit}
                  className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                >
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edytuj projekt
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-zinc-800" />
                <DropdownMenuItem 
                  onClick={onDelete}
                  className="text-red-400 focus:bg-red-500/10 focus:text-red-400"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Usuń projekt
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              variant="secondary" 
              size="icon"
              onClick={onClose}
              className="bg-zinc-900/80 backdrop-blur-sm hover:bg-zinc-800"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Title */}
          <div className="absolute bottom-4 left-4 right-4">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-zinc-100">
                {project.name}
              </DialogTitle>
            </DialogHeader>
          </div>
        </div>

        {/* Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
          <TabsList className="w-full justify-start rounded-none border-b border-zinc-800 bg-zinc-900/50 px-4">
            <TabsTrigger 
              value="overview" 
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
            >
              Przegląd
            </TabsTrigger>
            <TabsTrigger 
              value="margin"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
            >
              Kalkulacja
            </TabsTrigger>
            <TabsTrigger 
              value="history"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
            >
              Historia
            </TabsTrigger>
            <TabsTrigger 
              value="notes"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
            >
              Notatki
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[calc(90vh-280px)]">
            {/* Overview Tab */}
            <TabsContent value="overview" className="p-6 mt-0">
              <div className="space-y-6">
                {/* Description */}
                <div>
                  <h4 className="text-sm font-medium text-zinc-400 mb-2">Opis</h4>
                  <p className="text-zinc-300 leading-relaxed">
                    {project.description || 'Brak opisu projektu.'}
                  </p>
                </div>

                {/* Links */}
                {project.links.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-zinc-400 mb-3">Linki do modeli</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.links.map((link) => {
                        const config = PLATFORM_CONFIG[link.platform];
                        return (
                          <a
                            key={link.platform}
                            href={link.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`
                              flex items-center gap-2 px-3 py-2 rounded-lg 
                              ${config.color} text-white text-sm font-medium
                              hover:opacity-90 transition-opacity
                            `}
                          >
                            <span className="w-5 h-5 rounded bg-white/20 flex items-center justify-center text-xs font-bold">
                              {config.icon}
                            </span>
                            {config.label}
                            <ExternalLink className="w-3 h-3 opacity-70" />
                          </a>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Details Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-zinc-900/50 rounded-lg p-3 border border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-500 text-xs mb-1">
                      <Layers className="w-3.5 h-3.5" />
                      Materiał
                    </div>
                    <div className="text-zinc-200 font-medium">{project.material}</div>
                  </div>
                  <div className="bg-zinc-900/50 rounded-lg p-3 border border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-500 text-xs mb-1">
                      <Tag className="w-3.5 h-3.5" />
                      Kategoria
                    </div>
                    <div className="text-zinc-200 font-medium capitalize">{project.category}</div>
                  </div>
                  <div className="bg-zinc-900/50 rounded-lg p-3 border border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-500 text-xs mb-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Trudność
                    </div>
                    <div className="text-zinc-200 font-medium">{project.difficulty}</div>
                  </div>
                  <div className="bg-zinc-900/50 rounded-lg p-3 border border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-500 text-xs mb-1">
                      <Palette className="w-3.5 h-3.5" />
                      Multicolor
                    </div>
                    <div className="text-zinc-200 font-medium">
                      {project.isMulticolor ? 'Tak' : 'Nie'}
                    </div>
                  </div>
                </div>

                {/* Tags */}
                {project.tags.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-zinc-400 mb-2">Tagi</h4>
                    <div className="flex flex-wrap gap-1.5">
                      {project.tags.map((tag) => (
                        <span 
                          key={tag}
                          className="text-xs bg-zinc-800 text-zinc-400 px-2.5 py-1 rounded-full"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Dates */}
                <div className="flex gap-4 text-xs text-zinc-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    Utworzono: {project.createdAt}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Zaktualizowano: {project.updatedAt}
                  </span>
                </div>
              </div>
            </TabsContent>

            {/* Margin Tab */}
            <TabsContent value="margin" className="p-6 mt-0">
              <MarginCalculator 
                value={project.marginCalculation} 
                onChange={() => {}} 
                readOnly 
              />
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history" className="p-6 mt-0">
              <div className="space-y-6">
                {/* Status Change */}
                <div className="bg-zinc-900/50 rounded-lg p-4 border border-zinc-800">
                  <h4 className="text-sm font-medium text-zinc-300 mb-3">Zmień status</h4>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {Object.entries(STATUS_CONFIG).map(([key, config]) => (
                      <button
                        key={key}
                        onClick={() => handleStatusChange(key as ProjectStatus)}
                        disabled={project.status === key}
                        className={`
                          px-3 py-1.5 rounded-lg text-sm font-medium transition-all
                          ${project.status === key 
                            ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                            : `${config.bgColor} ${config.color} hover:opacity-80`
                          }
                        `}
                      >
                        {config.label}
                      </button>
                    ))}
                  </div>
                  <Textarea
                    placeholder="Notatka do zmiany statusu (opcjonalnie)..."
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    className="bg-zinc-900 border-zinc-700 text-zinc-100 text-sm min-h-[80px]"
                  />
                </div>

                {/* History Timeline */}
                <div>
                  <h4 className="text-sm font-medium text-zinc-300 mb-3 flex items-center gap-2">
                    <History className="w-4 h-4" />
                    Historia zmian
                  </h4>
                  <div className="space-y-3">
                    {[...project.statusHistory].reverse().map((entry, index) => {
                      const entryConfig = STATUS_CONFIG[entry.status];
                      return (
                        <div 
                          key={index}
                          className="flex items-start gap-3 p-3 bg-zinc-900/30 rounded-lg border border-zinc-800/50"
                        >
                          <div className={`w-2 h-2 rounded-full mt-1.5 ${entryConfig.color.replace('text-', 'bg-')}`} />
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-sm font-medium ${entryConfig.color}`}>
                                {entryConfig.label}
                              </span>
                              <span className="text-xs text-zinc-500">{entry.date}</span>
                            </div>
                            {entry.note && (
                              <p className="text-sm text-zinc-400 mt-1">{entry.note}</p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Notes Tab */}
            <TabsContent value="notes" className="p-6 mt-0">
              <div className="bg-zinc-900/50 rounded-lg p-4 border border-zinc-800 min-h-[200px]">
                {project.notes ? (
                  <p className="text-zinc-300 whitespace-pre-wrap">{project.notes}</p>
                ) : (
                  <p className="text-zinc-500 italic">Brak notatek dla tego projektu.</p>
                )}
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
