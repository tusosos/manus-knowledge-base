'use client';

// Przykład użycia modułu ProjectsModule w aplikacji Next.js
// Umieść ten kod w pages/projects.tsx lub app/projects/page.tsx

import { ProjectsModule } from './index';

export default function ProjectsPage() {
  return <ProjectsModule />;
}

// Alternatywnie - użycie poszczególnych komponentów:

/*
import { useState } from 'react';
import { 
  useProjects, 
  ProjectCard, 
  ProjectFilters, 
  ProjectForm,
  ProjectDetails 
} from './index';
import type { Project } from './index';

function CustomProjectsView() {
  const { 
    filteredProjects, 
    filters, 
    updateFilters, 
    resetFilters,
    addProject,
    updateProject,
    deleteProject,
    changeStatus,
    getAllTags 
  } = useProjects();

  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  return (
    <div>
      <ProjectFilters
        filters={filters}
        onUpdateFilters={updateFilters}
        onResetFilters={resetFilters}
        availableTags={getAllTags}
        totalProjects={filteredProjects.length}
        filteredCount={filteredProjects.length}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProjects.map((project) => (
          <ProjectCard
            key={project.id}
            project={project}
            onClick={() => setSelectedProject(project)}
            onEdit={() => {
              setSelectedProject(project);
              setIsFormOpen(true);
            }}
          />
        ))}
      </div>

      <ProjectForm
        project={selectedProject}
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={(data) => {
          if (selectedProject) {
            updateProject(selectedProject.id, data);
          } else {
            addProject(data);
          }
          setIsFormOpen(false);
        }}
      />
    </div>
  );
}
*/
