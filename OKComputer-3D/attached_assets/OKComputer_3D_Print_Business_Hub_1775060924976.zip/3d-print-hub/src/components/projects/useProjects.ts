'use client';

import { useState, useCallback, useMemo } from 'react';
import type { 
  Project, 
  ProjectStatus, 
  ProjectFilters,
  ProjectCategory,
  MaterialType 
} from './types';

const generateId = () => Math.random().toString(36).substring(2, 9);

const getCurrentDate = () => new Date().toISOString().split('T')[0];

const createEmptyProject = (): Omit<Project, 'id' | 'createdAt' | 'updatedAt'> => ({
  name: '',
  description: '',
  status: 'idea',
  category: 'inne',
  material: 'PLA',
  difficulty: 'łatwy',
  isMulticolor: false,
  tags: [],
  links: [],
  marginCalculation: {
    materialCost: 0,
    suggestedPrice: 0,
    marginPercent: 0,
    marginAmount: 0,
  },
  statusHistory: [{ status: 'idea', date: getCurrentDate() }],
  notes: '',
});

const sampleProjects: Project[] = [
  {
    id: '1',
    name: 'Articulated Dragon',
    description: 'Smok z ruchomymi segmentami, idealny jako zabawka lub dekoracja. Wymaga drukowania bez wsporników.',
    status: 'ready',
    category: 'zabawki',
    material: 'PLA',
    difficulty: 'średni',
    isMulticolor: true,
    tags: ['articulated', 'dragon', 'flexible', 'popular'],
    links: [
      { platform: 'makerworld', url: 'https://makerworld.com' },
      { platform: 'printables', url: 'https://printables.com' },
    ],
    marginCalculation: {
      materialCost: 15,
      suggestedPrice: 89,
      marginPercent: 83.1,
      marginAmount: 74,
    },
    statusHistory: [
      { status: 'idea', date: '2024-01-15' },
      { status: 'prototype', date: '2024-01-20' },
      { status: 'testing', date: '2024-02-01' },
      { status: 'ready', date: '2024-02-10' },
    ],
    notes: 'Bardzo popularny model, warto mieć na stanie. Klientom podoba się opcja multicolor.',
    createdAt: '2024-01-15',
    updatedAt: '2024-02-10',
  },
  {
    id: '2',
    name: 'Gridfinity Organizer',
    description: 'System modułowych organizerów do warsztatu. Kompatybilny z Gridfinity.',
    status: 'prototype',
    category: 'organizery',
    material: 'PETG',
    difficulty: 'łatwy',
    isMulticolor: false,
    tags: ['gridfinity', 'organizer', 'workshop', 'modular'],
    links: [
      { platform: 'printables', url: 'https://printables.com' },
    ],
    marginCalculation: {
      materialCost: 8,
      suggestedPrice: 35,
      marginPercent: 77.1,
      marginAmount: 27,
    },
    statusHistory: [
      { status: 'idea', date: '2024-02-01' },
      { status: 'prototype', date: '2024-02-05' },
    ],
    notes: 'Testuję różne warianty rozmiarów. PETG daje lepszą wytrzymałość niż PLA.',
    createdAt: '2024-02-01',
    updatedAt: '2024-02-05',
  },
  {
    id: '3',
    name: 'Mechanical Keyboard Case',
    description: 'Obudowa do klawiatury mechanicznej 60%. Wymaga dokładnego kalibracji drukarki.',
    status: 'testing',
    category: 'mechaniczne',
    material: 'ASA',
    difficulty: 'trudny',
    isMulticolor: false,
    tags: ['keyboard', 'mechanical', 'precision', 'electronics'],
    links: [
      { platform: 'thingiverse', url: 'https://thingiverse.com' },
      { platform: 'cults3d', url: 'https://cults3d.com' },
    ],
    marginCalculation: {
      materialCost: 45,
      suggestedPrice: 199,
      marginPercent: 77.4,
      marginAmount: 154,
    },
    statusHistory: [
      { status: 'idea', date: '2024-01-10' },
      { status: 'prototype', date: '2024-01-25' },
      { status: 'testing', date: '2024-02-08' },
    ],
    notes: 'ASA daje świetny finish, ale wymaga zamkniętej komory. Testuję tolerancje na różnych drukarkach.',
    createdAt: '2024-01-10',
    updatedAt: '2024-02-08',
  },
  {
    id: '4',
    name: 'Miniature Terrain Set',
    description: 'Zestaw terenów do gier bitewnych i RPG. Wieloelementowy projekt z dużą ilością detali.',
    status: 'idea',
    category: 'figurki',
    material: 'Resin',
    difficulty: 'ekspert',
    isMulticolor: false,
    tags: ['miniature', 'terrain', 'rpg', 'wargaming', 'detailed'],
    links: [],
    marginCalculation: {
      materialCost: 120,
      suggestedPrice: 450,
      marginPercent: 73.3,
      marginAmount: 330,
    },
    statusHistory: [
      { status: 'idea', date: '2024-02-15' },
    ],
    notes: 'Duży projekt, wymaga przetestowania różnych żywic. Potencjalnie bardzo zyskowny.',
    createdAt: '2024-02-15',
    updatedAt: '2024-02-15',
  },
  {
    id: '5',
    name: 'Phone Stand Pro',
    description: 'Profesjonalna podstawka pod telefon z kanałem na kabel ładujący.',
    status: 'ready',
    category: 'praktyczne',
    material: 'PLA',
    difficulty: 'łatwy',
    isMulticolor: true,
    tags: ['phone', 'stand', 'useful', 'cable-management'],
    links: [
      { platform: 'makerworld', url: 'https://makerworld.com' },
    ],
    marginCalculation: {
      materialCost: 5,
      suggestedPrice: 29,
      marginPercent: 82.8,
      marginAmount: 24,
    },
    statusHistory: [
      { status: 'idea', date: '2024-01-05' },
      { status: 'prototype', date: '2024-01-10' },
      { status: 'testing', date: '2024-01-15' },
      { status: 'ready', date: '2024-01-20' },
    ],
    notes: 'Szybki i łatwy do druku. Dobry produkt na start dla nowych klientów.',
    createdAt: '2024-01-05',
    updatedAt: '2024-01-20',
  },
  {
    id: '6',
    name: 'Cosplay Armor Pieces',
    description: 'Elementy zbroi do cosplayu - naramienniki i nagolenniki. Wymagają dużej ilości materiału.',
    status: 'prototype',
    category: 'cosplay',
    material: 'PLA',
    difficulty: 'trudny',
    isMulticolor: false,
    tags: ['cosplay', 'armor', 'large', 'post-processing'],
    links: [
      { platform: 'cults3d', url: 'https://cults3d.com' },
    ],
    marginCalculation: {
      materialCost: 85,
      suggestedPrice: 350,
      marginPercent: 75.7,
      marginAmount: 265,
    },
    statusHistory: [
      { status: 'idea', date: '2024-02-01' },
      { status: 'prototype', date: '2024-02-12' },
    ],
    notes: 'Wymaga dużo post-processingu (szlifowanie, szpachlowanie, malowanie).',
    createdAt: '2024-02-01',
    updatedAt: '2024-02-12',
  },
];

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>(sampleProjects);
  const [filters, setFilters] = useState<ProjectFilters>({
    status: 'all',
    category: 'all',
    material: 'all',
    tags: [],
    searchQuery: '',
  });

  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      if (filters.status !== 'all' && project.status !== filters.status) return false;
      if (filters.category !== 'all' && project.category !== filters.category) return false;
      if (filters.material !== 'all' && project.material !== filters.material) return false;
      if (filters.tags.length > 0 && !filters.tags.some((tag) => project.tags.includes(tag))) return false;
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesName = project.name.toLowerCase().includes(query);
        const matchesDescription = project.description.toLowerCase().includes(query);
        const matchesTags = project.tags.some((tag) => tag.toLowerCase().includes(query));
        if (!matchesName && !matchesDescription && !matchesTags) return false;
      }
      return true;
    });
  }, [projects, filters]);

  const addProject = useCallback((projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProject: Project = {
      ...projectData,
      id: generateId(),
      createdAt: getCurrentDate(),
      updatedAt: getCurrentDate(),
    };
    setProjects((prev) => [newProject, ...prev]);
    return newProject;
  }, []);

  const updateProject = useCallback((id: string, updates: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((project) =>
        project.id === id
          ? { ...project, ...updates, updatedAt: getCurrentDate() }
          : project
      )
    );
  }, []);

  const deleteProject = useCallback((id: string) => {
    setProjects((prev) => prev.filter((project) => project.id !== id));
  }, []);

  const changeStatus = useCallback((id: string, newStatus: ProjectStatus, note?: string) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id !== id) return project;
        const newHistoryEntry = {
          status: newStatus,
          date: getCurrentDate(),
          note,
        };
        return {
          ...project,
          status: newStatus,
          statusHistory: [...project.statusHistory, newHistoryEntry],
          updatedAt: getCurrentDate(),
        };
      })
    );
  }, []);

  const updateFilters = useCallback((newFilters: Partial<ProjectFilters>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({
      status: 'all',
      category: 'all',
      material: 'all',
      tags: [],
      searchQuery: '',
    });
  }, []);

  const getProjectById = useCallback(
    (id: string) => projects.find((p) => p.id === id),
    [projects]
  );

  const getAllTags = useMemo(() => {
    const tagSet = new Set<string>();
    projects.forEach((p) => p.tags.forEach((tag) => tagSet.add(tag)));
    return Array.from(tagSet).sort();
  }, [projects]);

  return {
    projects,
    filteredProjects,
    filters,
    addProject,
    updateProject,
    deleteProject,
    changeStatus,
    updateFilters,
    resetFilters,
    getProjectById,
    getAllTags,
    createEmptyProject,
  };
}
