'use client';

import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Plus, Box, LayoutGrid, List, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useProjects } from './useProjects';
import { ProjectGrid } from './ProjectGrid';
import { ProjectFilters } from './ProjectFilters';
import { ProjectDetails } from './ProjectDetails';
import { ProjectForm } from './ProjectForm';
import { StatusChangeDialog } from './StatusChangeDialog';
import { DeleteConfirmDialog } from './DeleteConfirmDialog';
import type { Project, ProjectStatus } from './types';
import { STATUS_CONFIG } from './types';

export function ProjectsModule() {
  const {
    projects,
    filteredProjects,
    filters,
    addProject,
    updateProject,
    deleteProject,
    changeStatus,
    updateFilters,
    resetFilters,
    getAllTags,
  } = useProjects();

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // Modal states
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [pendingStatusChange, setPendingStatusChange] = useState<ProjectStatus | null>(null);

  // Statistics
  const stats = {
    total: projects.length,
    idea: projects.filter((p) => p.status === 'idea').length,
    prototype: projects.filter((p) => p.status === 'prototype').length,
    testing: projects.filter((p) => p.status === 'testing').length,
    ready: projects.filter((p) => p.status === 'ready').length,
  };

  // Handlers
  const handleProjectClick = useCallback((project: Project) => {
    setSelectedProject(project);
    setIsDetailsOpen(true);
  }, []);

  const handleAddProject = useCallback(() => {
    setSelectedProject(null);
    setIsFormOpen(true);
  }, []);

  const handleEditProject = useCallback((project: Project) => {
    setSelectedProject(project);
    setIsFormOpen(true);
  }, []);

  const handleSaveProject = useCallback((projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (selectedProject) {
      updateProject(selectedProject.id, projectData);
    } else {
      addProject(projectData);
    }
  }, [selectedProject, addProject, updateProject]);

  const handleDeleteProject = useCallback(() => {
    if (selectedProject) {
      deleteProject(selectedProject.id);
      setIsDeleteDialogOpen(false);
      setIsDetailsOpen(false);
      setSelectedProject(null);
    }
  }, [selectedProject, deleteProject]);

  const handleStatusChange = useCallback((newStatus: ProjectStatus, note?: string) => {
    if (selectedProject && pendingStatusChange) {
      changeStatus(selectedProject.id, pendingStatusChange, note);
      setPendingStatusChange(null);
      setIsStatusDialogOpen(false);
      // Update selected project to reflect changes
      const updatedProject = { ...selectedProject };
      updatedProject.status = pendingStatusChange;
      updatedProject.statusHistory = [
        ...updatedProject.statusHistory,
        { status: pendingStatusChange, date: new Date().toISOString().split('T')[0], note },
      ];
      setSelectedProject(updatedProject);
    }
  }, [selectedProject, pendingStatusChange, changeStatus]);

  const initiateStatusChange = useCallback((newStatus: ProjectStatus) => {
    setPendingStatusChange(newStatus);
    setIsStatusDialogOpen(true);
  }, []);

  const openDeleteDialog = useCallback(() => {
    setIsDeleteDialogOpen(true);
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-950/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            {/* Title */}
            <div className="flex items-center gap-3">
              <div className="relative">
                <Box className="w-8 h-8 text-amber-500" />
                <motion.div
                  className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full"
                  animate={{ scale: [1, 1.3, 1], opacity: [1, 0.7, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-zinc-100">Projekty 3D</h1>
                <p className="text-sm text-zinc-500">
                  Zarządzaj swoimi projektami druku 3D
                </p>
              </div>
            </div>

            {/* Stats Overview */}
            <div className="flex flex-wrap gap-2">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 rounded-lg border border-zinc-800">
                <span className="w-2 h-2 rounded-full bg-zinc-500" />
                <span className="text-xs text-zinc-400">Pomysł:</span>
                <span className="text-sm font-medium text-zinc-200">{stats.idea}</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 rounded-lg border border-zinc-800">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-xs text-zinc-400">Prototyp:</span>
                <span className="text-sm font-medium text-zinc-200">{stats.prototype}</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 rounded-lg border border-zinc-800">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-xs text-zinc-400">Testowany:</span>
                <span className="text-sm font-medium text-zinc-200">{stats.testing}</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 rounded-lg border border-zinc-800">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-xs text-zinc-400">Gotowy:</span>
                <span className="text-sm font-medium text-zinc-200">{stats.ready}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'grid' | 'list')}>
                <TabsList className="bg-zinc-900 border border-zinc-800">
                  <TabsTrigger 
                    value="grid" 
                    className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
                  >
                    <LayoutGrid className="w-4 h-4" />
                  </TabsTrigger>
                  <TabsTrigger 
                    value="list"
                    className="data-[state=active]:bg-zinc-800 data-[state=active]:text-amber-400"
                  >
                    <List className="w-4 h-4" />
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              <Button
                onClick={handleAddProject}
                className="bg-amber-600 hover:bg-amber-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nowy projekt
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Filters */}
        <div className="mb-6">
          <ProjectFilters
            filters={filters}
            onUpdateFilters={updateFilters}
            onResetFilters={resetFilters}
            availableTags={getAllTags}
            totalProjects={stats.total}
            filteredCount={filteredProjects.length}
          />
        </div>

        {/* Projects Grid */}
        <ProjectGrid
          projects={filteredProjects}
          onProjectClick={handleProjectClick}
          onEditProject={handleEditProject}
          onAddProject={handleAddProject}
        />
      </div>

      {/* Modals */}
      <ProjectDetails
        project={selectedProject}
        isOpen={isDetailsOpen}
        onClose={() => {
          setIsDetailsOpen(false);
          setSelectedProject(null);
        }}
        onEdit={() => {
          setIsDetailsOpen(false);
          setIsFormOpen(true);
        }}
        onDelete={openDeleteDialog}
        onStatusChange={initiateStatusChange}
      />

      <ProjectForm
        project={selectedProject}
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          if (!isDetailsOpen) {
            setSelectedProject(null);
          }
        }}
        onSave={handleSaveProject}
      />

      <StatusChangeDialog
        isOpen={isStatusDialogOpen}
        onClose={() => {
          setIsStatusDialogOpen(false);
          setPendingStatusChange(null);
        }}
        onConfirm={handleStatusChange}
        currentStatus={selectedProject?.status || 'idea'}
        newStatus={pendingStatusChange || 'idea'}
      />

      <DeleteConfirmDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleDeleteProject}
        projectName={selectedProject?.name || ''}
      />
    </div>
  );
}
