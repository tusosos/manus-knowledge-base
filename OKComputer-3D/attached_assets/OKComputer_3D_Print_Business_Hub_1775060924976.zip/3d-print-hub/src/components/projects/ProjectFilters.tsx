'use client';

import { Search, X, Filter, SlidersHorizontal } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { ProjectFilters as ProjectFiltersType, ProjectStatus, ProjectCategory, MaterialType } from './types';
import { STATUS_CONFIG, CATEGORY_OPTIONS, MATERIAL_OPTIONS } from './types';

interface ProjectFiltersProps {
  filters: ProjectFiltersType;
  onUpdateFilters: (filters: Partial<ProjectFiltersType>) => void;
  onResetFilters: () => void;
  availableTags: string[];
  totalProjects: number;
  filteredCount: number;
}

export function ProjectFilters({
  filters,
  onUpdateFilters,
  onResetFilters,
  availableTags,
  totalProjects,
  filteredCount,
}: ProjectFiltersProps) {
  const hasActiveFilters = 
    filters.status !== 'all' || 
    filters.category !== 'all' || 
    filters.material !== 'all' || 
    filters.tags.length > 0 || 
    filters.searchQuery;

  const activeFilterCount = [
    filters.status !== 'all',
    filters.category !== 'all',
    filters.material !== 'all',
    filters.tags.length > 0,
    !!filters.searchQuery,
  ].filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Search and Main Filters */}
      <div className="flex flex-col lg:flex-row gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Szukaj projektów..."
            value={filters.searchQuery}
            onChange={(e) => onUpdateFilters({ searchQuery: e.target.value })}
            className="pl-10 bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600 focus:border-amber-500/50"
          />
          {filters.searchQuery && (
            <button
              onClick={() => onUpdateFilters({ searchQuery: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Status Filter */}
        <Select
          value={filters.status}
          onValueChange={(value) => onUpdateFilters({ status: value as ProjectStatus | 'all' })}
        >
          <SelectTrigger className="w-full lg:w-44 bg-zinc-900/50 border-zinc-800 text-zinc-100">
            <Filter className="w-4 h-4 mr-2 text-zinc-500" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
              Wszystkie statusy
            </SelectItem>
            {Object.entries(STATUS_CONFIG).map(([key, config]) => (
              <SelectItem 
                key={key} 
                value={key}
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                <span className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${config.color.replace('text-', 'bg-')}`} />
                  {config.label}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Category Filter */}
        <Select
          value={filters.category}
          onValueChange={(value) => onUpdateFilters({ category: value as ProjectCategory | 'all' })}
        >
          <SelectTrigger className="w-full lg:w-48 bg-zinc-900/50 border-zinc-800 text-zinc-100">
            <SlidersHorizontal className="w-4 h-4 mr-2 text-zinc-500" />
            <SelectValue placeholder="Kategoria" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            {CATEGORY_OPTIONS.map((option) => (
              <SelectItem 
                key={option.value} 
                value={option.value}
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Material Filter */}
        <Select
          value={filters.material}
          onValueChange={(value) => onUpdateFilters({ material: value as MaterialType | 'all' })}
        >
          <SelectTrigger className="w-full lg:w-44 bg-zinc-900/50 border-zinc-800 text-zinc-100">
            <SelectValue placeholder="Materiał" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            {MATERIAL_OPTIONS.map((option) => (
              <SelectItem 
                key={option.value} 
                value={option.value}
                className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
              >
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Reset Button */}
        {hasActiveFilters && (
          <Button
            variant="outline"
            onClick={onResetFilters}
            className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
          >
            <X className="w-4 h-4 mr-2" />
            Wyczyść
          </Button>
        )}
      </div>

      {/* Tag Filters */}
      {availableTags.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm text-zinc-500 mr-1">Tagi:</span>
          {availableTags.slice(0, 10).map((tag) => {
            const isSelected = filters.tags.includes(tag);
            return (
              <button
                key={tag}
                onClick={() => {
                  const newTags = isSelected
                    ? filters.tags.filter((t) => t !== tag)
                    : [...filters.tags, tag];
                  onUpdateFilters({ tags: newTags });
                }}
                className={`
                  text-xs px-2.5 py-1 rounded-full transition-all
                  ${isSelected 
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                    : 'bg-zinc-800/50 text-zinc-500 border border-zinc-700/50 hover:border-zinc-600 hover:text-zinc-400'
                  }
                `}
              >
                #{tag}
              </button>
            );
          })}
          {availableTags.length > 10 && (
            <span className="text-xs text-zinc-600">
              +{availableTags.length - 10} więcej
            </span>
          )}
        </div>
      )}

      {/* Results Count */}
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <span className="text-zinc-500">
            Wyniki: <span className="text-zinc-300 font-medium">{filteredCount}</span>
            {filteredCount !== totalProjects && (
              <span className="text-zinc-600"> / {totalProjects}</span>
            )}
          </span>
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 text-xs">
              {activeFilterCount} {activeFilterCount === 1 ? 'filtr' : activeFilterCount < 5 ? 'filtry' : 'filtrów'}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
