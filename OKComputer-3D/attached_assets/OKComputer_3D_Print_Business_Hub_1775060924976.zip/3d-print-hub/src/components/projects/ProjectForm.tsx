'use client';

import { useState, useCallback } from 'react';
import { X, Plus, Link2, Trash2, Upload } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import type { 
  Project, 
  ProjectStatus, 
  ProjectCategory, 
  MaterialType, 
  DifficultyLevel,
  ProjectLink 
} from './types';
import { 
  STATUS_CONFIG, 
  CATEGORY_OPTIONS, 
  MATERIAL_OPTIONS, 
  DIFFICULTY_OPTIONS,
  PLATFORM_CONFIG 
} from './types';
import { MarginCalculator } from './MarginCalculator';

interface ProjectFormProps {
  project?: Project | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

const emptyProject: Omit<Project, 'id' | 'createdAt' | 'updatedAt'> = {
  name: '',
  description: '',
  thumbnail: '',
  status: 'idea',
  category: 'inne',
  material: 'PLA',
  difficulty: 'łatwy',
  isMulticolor: false,
  tags: [],
  links: [],
  marginCalculation: {
    materialCost: 0,
    suggestedPrice: 0,
    marginPercent: 0,
    marginAmount: 0,
  },
  statusHistory: [{ status: 'idea', date: new Date().toISOString().split('T')[0] }],
  notes: '',
};

export function ProjectForm({ project, isOpen, onClose, onSave }: ProjectFormProps) {
  const isEditing = !!project;
  const [formData, setFormData] = useState<Omit<Project, 'id' | 'createdAt' | 'updatedAt'>>(
    project || emptyProject
  );
  const [newTag, setNewTag] = useState('');
  const [newLink, setNewLink] = useState<Partial<ProjectLink>>({ platform: 'makerworld', url: '' });

  const handleChange = useCallback(<K extends keyof typeof formData>(
    field: K, 
    value: typeof formData[K]
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleAddTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData((prev) => ({ ...prev, tags: [...prev.tags, newTag.trim()] }));
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData((prev) => ({ 
      ...prev, 
      tags: prev.tags.filter((tag) => tag !== tagToRemove) 
    }));
  };

  const handleAddLink = () => {
    if (newLink.platform && newLink.url?.trim()) {
      setFormData((prev) => ({ 
        ...prev, 
        links: [...prev.links, { platform: newLink.platform!, url: newLink.url!.trim() }] 
      }));
      setNewLink({ platform: 'makerworld', url: '' });
    }
  };

  const handleRemoveLink = (index: number) => {
    setFormData((prev) => ({ 
      ...prev, 
      links: prev.links.filter((_, i) => i !== index) 
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name.trim()) {
      onSave(formData);
      if (!isEditing) {
        setFormData(emptyProject);
      }
      onClose();
    }
  };

  const handleClose = () => {
    if (!isEditing) {
      setFormData(emptyProject);
    }
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0 bg-zinc-950 border-zinc-800 overflow-hidden">
        <DialogHeader className="px-6 py-4 border-b border-zinc-800">
          <DialogTitle className="text-xl font-bold text-zinc-100">
            {isEditing ? 'Edytuj projekt' : 'Dodaj nowy projekt'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <ScrollArea className="h-[calc(90vh-140px)]">
            <div className="p-6 space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Podstawowe informacje
                </h4>
                
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-zinc-300">
                    Nazwa projektu <span className="text-red-400">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="np. Articulated Dragon"
                    className="bg-zinc-900/50 border-zinc-700 text-zinc-100 focus:border-amber-500/50"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-zinc-300">
                    Opis
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Opisz projekt, wymagania druku, uwagi..."
                    className="bg-zinc-900/50 border-zinc-700 text-zinc-100 focus:border-amber-500/50 min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-300">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleChange('status', value as ProjectStatus)}
                    >
                      <SelectTrigger className="bg-zinc-900/50 border-zinc-700 text-zinc-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        {Object.entries(STATUS_CONFIG).map(([key, config]) => (
                          <SelectItem 
                            key={key} 
                            value={key}
                            className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                          >
                            <span className="flex items-center gap-2">
                              <span className={`w-2 h-2 rounded-full ${config.color.replace('text-', 'bg-')}`} />
                              {config.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-zinc-300">Kategoria</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => handleChange('category', value as ProjectCategory)}
                    >
                      <SelectTrigger className="bg-zinc-900/50 border-zinc-700 text-zinc-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        {CATEGORY_OPTIONS.filter(o => o.value !== 'all').map((option) => (
                          <SelectItem 
                            key={option.value} 
                            value={option.value}
                            className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                          >
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator className="bg-zinc-800" />

              {/* Technical Details */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Szczegóły techniczne
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-zinc-300">Materiał</Label>
                    <Select
                      value={formData.material}
                      onValueChange={(value) => handleChange('material', value as MaterialType)}
                    >
                      <SelectTrigger className="bg-zinc-900/50 border-zinc-700 text-zinc-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        {MATERIAL_OPTIONS.filter(o => o.value !== 'all').map((option) => (
                          <SelectItem 
                            key={option.value} 
                            value={option.value}
                            className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                          >
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-zinc-300">Trudność</Label>
                    <Select
                      value={formData.difficulty}
                      onValueChange={(value) => handleChange('difficulty', value as DifficultyLevel)}
                    >
                      <SelectTrigger className="bg-zinc-900/50 border-zinc-700 text-zinc-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-zinc-900 border-zinc-800">
                        {DIFFICULTY_OPTIONS.map((option) => (
                          <SelectItem 
                            key={option.value} 
                            value={option.value}
                            className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                          >
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="multicolor"
                    checked={formData.isMulticolor}
                    onCheckedChange={(checked) => handleChange('isMulticolor', checked as boolean)}
                    className="border-zinc-600 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
                  />
                  <Label htmlFor="multicolor" className="text-zinc-300 cursor-pointer">
                    Projekt wielokolorowy (Multicolor / MMU)
                  </Label>
                </div>
              </div>

              <Separator className="bg-zinc-800" />

              {/* Tags */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Tagi
                </h4>

                <div className="flex gap-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Dodaj tag..."
                    className="bg-zinc-900/50 border-zinc-700 text-zinc-100 focus:border-amber-500/50"
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAddTag}
                    className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1 text-sm bg-zinc-800 text-zinc-300 px-2.5 py-1 rounded-full"
                    >
                      #{tag}
                      <button
                        type="button"
                        onClick={() => handleRemoveTag(tag)}
                        className="text-zinc-500 hover:text-red-400"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <Separator className="bg-zinc-800" />

              {/* Links */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Linki do modeli
                </h4>

                <div className="flex gap-2">
                  <Select
                    value={newLink.platform}
                    onValueChange={(value) => setNewLink((prev) => ({ ...prev, platform: value as ProjectLink['platform'] }))}
                  >
                    <SelectTrigger className="w-40 bg-zinc-900/50 border-zinc-700 text-zinc-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-800">
                      {Object.entries(PLATFORM_CONFIG).map(([key, config]) => (
                        <SelectItem 
                          key={key} 
                          value={key}
                          className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                        >
                          {config.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    value={newLink.url}
                    onChange={(e) => setNewLink((prev) => ({ ...prev, url: e.target.value }))}
                    placeholder="https://..."
                    className="flex-1 bg-zinc-900/50 border-zinc-700 text-zinc-100 focus:border-amber-500/50"
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddLink())}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAddLink}
                    className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
                  >
                    <Link2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  {formData.links.map((link, index) => {
                    const config = PLATFORM_CONFIG[link.platform];
                    return (
                      <div
                        key={index}
                        className="flex items-center gap-2 p-2 bg-zinc-900/50 rounded-lg border border-zinc-800"
                      >
                        <span className={`w-6 h-6 rounded ${config.color} flex items-center justify-center text-xs font-bold text-white`}>
                          {config.icon}
                        </span>
                        <span className="flex-1 text-sm text-zinc-400 truncate">{link.url}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveLink(index)}
                          className="text-zinc-500 hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              <Separator className="bg-zinc-800" />

              {/* Margin Calculator */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Kalkulacja marży
                </h4>
                <MarginCalculator
                  value={formData.marginCalculation}
                  onChange={(value) => handleChange('marginCalculation', value)}
                />
              </div>

              <Separator className="bg-zinc-800" />

              {/* Notes */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-amber-500 uppercase tracking-wider">
                  Notatki
                </h4>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => handleChange('notes', e.target.value)}
                  placeholder="Dodatkowe notatki, uwagi, pomysły..."
                  className="bg-zinc-900/50 border-zinc-700 text-zinc-100 focus:border-amber-500/50 min-h-[120px]"
                />
              </div>
            </div>
          </ScrollArea>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-zinc-800 flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
            >
              Anuluj
            </Button>
            <Button
              type="submit"
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              {isEditing ? 'Zapisz zmiany' : 'Dodaj projekt'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
