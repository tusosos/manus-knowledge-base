export type ProjectStatus = 'idea' | 'prototype' | 'testing' | 'ready';

export type ProjectCategory = 
  | 'figurki'
  | 'mechaniczne'
  | 'dekoracje'
  | 'praktyczne'
  | 'organizery'
  | 'zabawki'
  | 'cosplay'
  | 'inne';

export type MaterialType =
  | 'PLA'
  | 'PETG'
  | 'ABS'
  | 'ASA'
  | 'TPU'
  | 'Nylon'
  | 'Resin'
  | 'Multicolor';

export type DifficultyLevel = 'łatwy' | 'średni' | 'trudny' | 'ekspert';

export interface ProjectLink {
  platform: 'makerworld' | 'printables' | 'thingiverse' | 'cults3d';
  url: string;
}

export interface StatusHistoryEntry {
  status: ProjectStatus;
  date: string;
  note?: string;
}

export interface MarginCalculation {
  materialCost: number;
  suggestedPrice: number;
  marginPercent: number;
  marginAmount: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  thumbnail?: string;
  status: ProjectStatus;
  category: ProjectCategory;
  material: MaterialType;
  difficulty: DifficultyLevel;
  isMulticolor: boolean;
  tags: string[];
  links: ProjectLink[];
  marginCalculation: MarginCalculation;
  statusHistory: StatusHistoryEntry[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProjectFilters {
  status: ProjectStatus | 'all';
  category: ProjectCategory | 'all';
  material: MaterialType | 'all';
  tags: string[];
  searchQuery: string;
}

export const STATUS_CONFIG: Record<ProjectStatus, { label: string; color: string; bgColor: string }> = {
  idea: {
    label: 'Pomysł',
    color: 'text-zinc-400',
    bgColor: 'bg-zinc-500/20 border-zinc-500/30',
  },
  prototype: {
    label: 'Prototyp',
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/20 border-blue-500/30',
  },
  testing: {
    label: 'Testowany',
    color: 'text-amber-400',
    bgColor: 'bg-amber-500/20 border-amber-500/30',
  },
  ready: {
    label: 'Gotowy do sprzedaży',
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/20 border-emerald-500/30',
  },
};

export const CATEGORY_OPTIONS: { value: ProjectCategory | 'all'; label: string }[] = [
  { value: 'all', label: 'Wszystkie kategorie' },
  { value: 'figurki', label: 'Figurki' },
  { value: 'mechaniczne', label: 'Elementy mechaniczne' },
  { value: 'dekoracje', label: 'Dekoracje' },
  { value: 'praktyczne', label: 'Przedmioty praktyczne' },
  { value: 'organizery', label: 'Organizery' },
  { value: 'zabawki', label: 'Zabawki' },
  { value: 'cosplay', label: 'Cosplay' },
  { value: 'inne', label: 'Inne' },
];

export const MATERIAL_OPTIONS: { value: MaterialType | 'all'; label: string }[] = [
  { value: 'all', label: 'Wszystkie materiały' },
  { value: 'PLA', label: 'PLA' },
  { value: 'PETG', label: 'PETG' },
  { value: 'ABS', label: 'ABS' },
  { value: 'ASA', label: 'ASA' },
  { value: 'TPU', label: 'TPU' },
  { value: 'Nylon', label: 'Nylon' },
  { value: 'Resin', label: 'Żywica' },
  { value: 'Multicolor', label: 'Multicolor' },
];

export const DIFFICULTY_OPTIONS: { value: DifficultyLevel; label: string }[] = [
  { value: 'łatwy', label: 'Łatwy' },
  { value: 'średni', label: 'Średni' },
  { value: 'trudny', label: 'Trudny' },
  { value: 'ekspert', label: 'Ekspert' },
];

export const PLATFORM_CONFIG: Record<ProjectLink['platform'], { label: string; icon: string; color: string }> = {
  makerworld: {
    label: 'MakerWorld',
    icon: 'M',
    color: 'bg-gradient-to-br from-orange-500 to-red-500',
  },
  printables: {
    label: 'Printables',
    icon: 'P',
    color: 'bg-gradient-to-br from-orange-400 to-amber-500',
  },
  thingiverse: {
    label: 'Thingiverse',
    icon: 'T',
    color: 'bg-gradient-to-br from-blue-500 to-cyan-500',
  },
  cults3d: {
    label: 'Cults3D',
    icon: 'C',
    color: 'bg-gradient-to-br from-purple-500 to-pink-500',
  },
};
