'use client';

import { AlertTriangle, Trash2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface DeleteConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  projectName: string;
}

export function DeleteConfirmDialog({
  isOpen,
  onClose,
  onConfirm,
  projectName,
}: DeleteConfirmDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-zinc-950 border-zinc-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            Potwierdź usunięcie
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            Czy na pewno chcesz usunąć ten projekt? Tej operacji nie można cofnąć.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
            <p className="text-sm text-red-400">
              Projekt do usunięcia:
            </p>
            <p className="text-lg font-medium text-zinc-100 mt-1">
              "{projectName}"
            </p>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
          >
            Anuluj
          </Button>
          <Button
            onClick={onConfirm}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Usuń projekt
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
