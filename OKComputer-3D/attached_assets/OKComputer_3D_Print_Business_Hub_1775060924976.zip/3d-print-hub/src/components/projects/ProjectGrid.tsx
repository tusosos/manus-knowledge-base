'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Box, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Project } from './types';
import { ProjectCard } from './ProjectCard';

interface ProjectGridProps {
  projects: Project[];
  onProjectClick: (project: Project) => void;
  onEditProject: (project: Project) => void;
  onAddProject: () => void;
}

export function ProjectGrid({ 
  projects, 
  onProjectClick, 
  onEditProject,
  onAddProject 
}: ProjectGridProps) {
  if (projects.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-20 px-4"
      >
        <div className="relative mb-6">
          <Box className="w-20 h-20 text-zinc-700" strokeWidth={1.5} />
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
          >
            <div className="w-28 h-28 border-2 border-dashed border-zinc-700 rounded-full" />
          </motion.div>
        </div>
        <h3 className="text-xl font-semibold text-zinc-300 mb-2">
          Brak projektów
        </h3>
        <p className="text-zinc-500 text-center max-w-md mb-6">
          Nie znaleziono projektów pasujących do wybranych filtrów. 
          Dodaj nowy projekt lub zmień kryteria wyszukiwania.
        </p>
        <Button 
          onClick={onAddProject}
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Dodaj pierwszy projekt
        </Button>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
      <AnimatePresence mode="popLayout">
        {projects.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ 
              duration: 0.3, 
              delay: index * 0.05,
              ease: [0.25, 0.46, 0.45, 0.94]
            }}
          >
            <ProjectCard
              project={project}
              onClick={() => onProjectClick(project)}
              onEdit={() => onEditProject(project)}
            />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
