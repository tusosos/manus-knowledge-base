export type Platform = "allegro" | "etsy" | "olx" | "website" | "facebook";

export interface ProductData {
  name: string;
  description: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
  };
  material: string;
  printTime: string;
  price: string;
  images: string[];
  category: string;
  color: string;
  weight: string;
}

export interface GeneratedContent {
  title: string;
  description: string;
  shortDescription: string;
  tags: string[];
  keywords: string[];
  specifications: {
    label: string;
    value: string;
  }[];
  deliveryTerms: string;
  returnPolicy: string;
  seoTitle: string;
  seoDescription: string;
}

export interface MarketingContent {
  headlines: string[];
  callToActions: string[];
  benefits: string[];
  socialProof: string[];
  urgencyPhrases: string[];
  uniqueSellingPoints: string[];
}

export interface PlatformConfig {
  id: Platform;
  name: string;
  icon: string;
  maxTitleLength: number;
  maxDescriptionLength: number;
  maxTags: number;
  tagFormat: "hash" | "comma" | "space";
  supportsHtml: boolean;
  supportsFormatting: boolean;
  categoryRequired: boolean;
  priceFormat: "pln" | "usd" | "eur" | "multi";
}

export interface Tip {
  id: string;
  title: string;
  content: string;
  category: "writing" | "photography" | "pricing" | "seo";
  icon: string;
}

export const MATERIALS = [
  { value: "PLA", label: "PLA - Polilaktyd", color: "bg-green-500/20 text-green-400" },
  { value: "PETG", label: "PETG", color: "bg-blue-500/20 text-blue-400" },
  { value: "ABS", label: "ABS", color: "bg-red-500/20 text-red-400" },
  { value: "TPU", label: "TPU - Filament elastyczny", color: "bg-purple-500/20 text-purple-400" },
  { value: "ASA", label: "ASA", color: "bg-yellow-500/20 text-yellow-400" },
  { value: "Nylon", label: "Nylon/PA", color: "bg-orange-500/20 text-orange-400" },
  { value: "Wood", label: "Drewnopodobny", color: "bg-amber-700/20 text-amber-600" },
  { value: "Metal", label: "Metal-filled", color: "bg-gray-500/20 text-gray-400" },
  { value: "Carbon", label: "Włókno węglowe", color: "bg-slate-500/20 text-slate-400" },
  { value: "Resin", label: "Żywica (Resin)", color: "bg-cyan-500/20 text-cyan-400" },
];

export const CATEGORIES = [
  { value: "dekoracje", label: "Dekoracje i ozdoby" },
  { value: "gadzety", label: "Gadżety i akcesoria" },
  { value: "narzedzia", label: "Narzędzia i części" },
  { value: "zabawki", label: "Zabawki i modele" },
  { value: "biuro", label: "Akcesoria biurowe" },
  { value: "kuchnia", label: "Akcesoria kuchenne" },
  { value: "ogrod", label: "Ogród i outdoor" },
  { value: "cosplay", label: "Cosplay i rekwizyty" },
  { value: "elektronika", label: "Obudowy elektroniki" },
  { value: "jewelry", label: "Biżuteria" },
  { value: "lampy", label: "Lampy i oświetlenie" },
  { value: "organizery", label: "Organizery" },
];

export const PLATFORM_CONFIGS: Record<Platform, PlatformConfig> = {
  allegro: {
    id: "allegro",
    name: "Allegro",
    icon: "Store",
    maxTitleLength: 50,
    maxDescriptionLength: 40000,
    maxTags: 10,
    tagFormat: "comma",
    supportsHtml: true,
    supportsFormatting: true,
    categoryRequired: true,
    priceFormat: "pln",
  },
  etsy: {
    id: "etsy",
    name: "Etsy",
    icon: "ShoppingBag",
    maxTitleLength: 140,
    maxDescriptionLength: 50000,
    maxTags: 13,
    tagFormat: "comma",
    supportsHtml: true,
    supportsFormatting: true,
    categoryRequired: true,
    priceFormat: "usd",
  },
  olx: {
    id: "olx",
    name: "OLX",
    icon: "Globe",
    maxTitleLength: 70,
    maxDescriptionLength: 5000,
    maxTags: 5,
    tagFormat: "space",
    supportsHtml: false,
    supportsFormatting: false,
    categoryRequired: true,
    priceFormat: "pln",
  },
  website: {
    id: "website",
    name: "Własna Strona",
    icon: "Globe",
    maxTitleLength: 200,
    maxDescriptionLength: 100000,
    maxTags: 20,
    tagFormat: "comma",
    supportsHtml: true,
    supportsFormatting: true,
    categoryRequired: false,
    priceFormat: "multi",
  },
  facebook: {
    id: "facebook",
    name: "Facebook Marketplace",
    icon: "Facebook",
    maxTitleLength: 100,
    maxDescriptionLength: 5000,
    maxTags: 0,
    tagFormat: "hash",
    supportsHtml: false,
    supportsFormatting: false,
    categoryRequired: true,
    priceFormat: "pln",
  },
};
