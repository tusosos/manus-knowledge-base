"use client";

import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Copy,
  Check,
  Tag,
  FileText,
  Search,
  Truck,
  RefreshCcw,
  List,
  Hash,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { GeneratedContent, Platform } from "./types";

interface ContentPreviewProps {
  content: GeneratedContent;
  platform: Platform;
  onCopy: (text: string, section: string) => void;
  copiedSection: string | null;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
    },
  },
};

interface CopyButtonProps {
  text: string;
  section: string;
  onCopy: (text: string, section: string) => void;
  isCopied: boolean;
}

function CopyButton({ text, section, onCopy, isCopied }: CopyButtonProps) {
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => onCopy(text, section)}
      className={cn(
        "h-8 px-2 transition-all duration-200",
        isCopied
          ? "text-green-400 hover:text-green-400 hover:bg-green-500/10"
          : "text-gray-400 hover:text-amber-400 hover:bg-amber-500/10"
      )}
    >
      {isCopied ? (
        <>
          <Check className="w-4 h-4 mr-1" />
          Skopiowano!
        </>
      ) : (
        <>
          <Copy className="w-4 h-4 mr-1" />
          Kopiuj
        </>
      )}
    </Button>
  );
}

export function ContentPreview({
  content,
  platform,
  onCopy,
  copiedSection,
}: ContentPreviewProps) {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Title Section */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800 border-l-4 border-l-amber-500">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-amber-500" />
                Tytuł Oferty
              </CardTitle>
              <CopyButton
                text={content.title}
                section="title"
                onCopy={onCopy}
                isCopied={copiedSection === "title"}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-gray-800/50 rounded-lg">
              <p className="text-white text-lg font-medium">{content.title}</p>
            </div>
            <p className="text-gray-500 text-sm mt-2">
              Zoptymalizowany tytuł pod {platform}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* SEO Section */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <Search className="w-5 h-5 text-green-500" />
                SEO - Tytuł i Opis
              </CardTitle>
              <div className="flex gap-2">
                <CopyButton
                  text={content.seoTitle}
                  section="seoTitle"
                  onCopy={onCopy}
                  isCopied={copiedSection === "seoTitle"}
                />
                <CopyButton
                  text={content.seoDescription}
                  section="seoDescription"
                  onCopy={onCopy}
                  isCopied={copiedSection === "seoDescription"}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-400 text-sm mb-1 block">
                Meta Title
              </Label>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-white">{content.seoTitle}</p>
              </div>
            </div>
            <div>
              <Label className="text-gray-400 text-sm mb-1 block">
                Meta Description
              </Label>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-gray-300 text-sm">{content.seoDescription}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Description Section */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-blue-500" />
                Opis Produktu
              </CardTitle>
              <CopyButton
                text={content.description}
                section="description"
                onCopy={onCopy}
                isCopied={copiedSection === "description"}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-gray-800/50 rounded-lg whitespace-pre-wrap">
              <p className="text-gray-300 leading-relaxed">{content.description}</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Short Description */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-purple-500" />
                Krótki Opis
              </CardTitle>
              <CopyButton
                text={content.shortDescription}
                section="shortDescription"
                onCopy={onCopy}
                isCopied={copiedSection === "shortDescription"}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-gray-800/50 rounded-lg">
              <p className="text-gray-300">{content.shortDescription}</p>
            </div>
            <p className="text-gray-500 text-sm mt-2">
              Idealny do podglądów i wycinków
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Tags Section */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <Tag className="w-5 h-5 text-pink-500" />
                Tagi i Słowa Kluczowe
              </CardTitle>
              <div className="flex gap-2">
                <CopyButton
                  text={content.tags.join(", ")}
                  section="tags"
                  onCopy={onCopy}
                  isCopied={copiedSection === "tags"}
                />
                <CopyButton
                  text={content.keywords.join(", ")}
                  section="keywords"
                  onCopy={onCopy}
                  isCopied={copiedSection === "keywords"}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-400 text-sm mb-2 block">
                Tagi ({content.tags.length})
              </Label>
              <div className="flex flex-wrap gap-2">
                {content.tags.map((tag, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="bg-pink-500/10 text-pink-400 border border-pink-500/30"
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-gray-400 text-sm mb-2 block">
                Słowa kluczowe SEO ({content.keywords.length})
              </Label>
              <div className="flex flex-wrap gap-2">
                {content.keywords.map((keyword, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="bg-purple-500/10 text-purple-400 border border-purple-500/30"
                  >
                    <Hash className="w-3 h-3 mr-1" />
                    {keyword}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Specifications */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <List className="w-5 h-5 text-cyan-500" />
                Specyfikacja Techniczna
              </CardTitle>
              <CopyButton
                text={content.specifications
                  .map((s) => `${s.label}: ${s.value}`)
                  .join("\n")}
                section="specifications"
                onCopy={onCopy}
                isCopied={copiedSection === "specifications"}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {content.specifications.map((spec, index) => (
                <div
                  key={index}
                  className="flex justify-between p-3 bg-gray-800/50 rounded-lg"
                >
                  <span className="text-gray-400">{spec.label}</span>
                  <span className="text-white font-medium">{spec.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Delivery & Returns */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2 text-lg">
                <Truck className="w-5 h-5 text-orange-500" />
                Dostawa i Zwroty
              </CardTitle>
              <div className="flex gap-2">
                <CopyButton
                  text={content.deliveryTerms}
                  section="deliveryTerms"
                  onCopy={onCopy}
                  isCopied={copiedSection === "deliveryTerms"}
                />
                <CopyButton
                  text={content.returnPolicy}
                  section="returnPolicy"
                  onCopy={onCopy}
                  isCopied={copiedSection === "returnPolicy"}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-400 text-sm mb-1 block">
                Warunki Dostawy
              </Label>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-gray-300 text-sm">{content.deliveryTerms}</p>
              </div>
            </div>
            <div>
              <Label className="text-gray-400 text-sm mb-1 block">
                Polityka Zwrotów
              </Label>
              <div className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-gray-300 text-sm">{content.returnPolicy}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

function Label({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <label className={cn("text-sm font-medium", className)}>{children}</label>;
}
