// Main component
export { ListingGenerator } from "./ListingGenerator";

// Sub-components
export { PlatformSelector } from "./PlatformSelector";
export { ProductForm } from "./ProductForm";
export { ContentPreview } from "./ContentPreview";
export { MarketingTexts } from "./MarketingTexts";
export { TipsSection } from "./TipsSection";
export { ExportModal } from "./ExportModal";

// Utilities
export { generateContent, generateMarketingTexts } from "./utils";

// Types
export type {
  Platform,
  ProductData,
  GeneratedContent,
  MarketingContent,
  PlatformConfig,
  Tip,
} from "./types";

// Constants
export {
  MATERIALS,
  CATEGORIES,
  PLATFORM_CONFIGS,
} from "./types";
