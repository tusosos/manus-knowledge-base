"use client";

import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Copy,
  Check,
  Sparkles,
  Megaphone,
  Target,
  Users,
  Zap,
  Star,
  TrendingUp,
  Clock,
  Award,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { MarketingContent } from "./types";

interface MarketingTextsProps {
  content: MarketingContent;
  onCopy: (text: string, section: string) => void;
  copiedSection: string | null;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
    },
  },
};

interface CopyButtonProps {
  text: string;
  section: string;
  onCopy: (text: string, section: string) => void;
  isCopied: boolean;
  label?: string;
}

function CopyButton({
  text,
  section,
  onCopy,
  isCopied,
  label = "Kopiuj",
}: CopyButtonProps) {
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => onCopy(text, section)}
      className={cn(
        "h-8 px-2 transition-all duration-200",
        isCopied
          ? "text-green-400 hover:text-green-400 hover:bg-green-500/10"
          : "text-gray-400 hover:text-amber-400 hover:bg-amber-500/10"
      )}
    >
      {isCopied ? (
        <>
          <Check className="w-4 h-4 mr-1" />
          Skopiowano!
        </>
      ) : (
        <>
          <Copy className="w-4 h-4 mr-1" />
          {label}
        </>
      )}
    </Button>
  );
}

interface SectionCardProps {
  title: string;
  icon: React.ElementType;
  iconColor: string;
  children: React.ReactNode;
  action?: React.ReactNode;
}

function SectionCard({ title, icon: Icon, iconColor, children, action }: SectionCardProps) {
  return (
    <Card className="bg-gray-900/50 border-gray-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2 text-lg">
            <Icon className={cn("w-5 h-5", iconColor)} />
            {title}
          </CardTitle>
          {action}
        </div>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export function MarketingTexts({
  content,
  onCopy,
  copiedSection,
}: MarketingTextsProps) {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Headlines */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Headlines - Nagłówki"
          icon={Megaphone}
          iconColor="text-amber-500"
          action={
            <CopyButton
              text={content.headlines.join("\n")}
              section="headlines"
              onCopy={onCopy}
              isCopied={copiedSection === "headlines"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="space-y-3">
            {content.headlines.map((headline, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg group hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Badge
                    variant="secondary"
                    className="bg-amber-500/10 text-amber-400 border-0"
                  >
                    #{index + 1}
                  </Badge>
                  <p className="text-white">{headline}</p>
                </div>
                <CopyButton
                  text={headline}
                  section={`headline-${index}`}
                  onCopy={onCopy}
                  isCopied={copiedSection === `headline-${index}`}
                />
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      {/* Call-to-Actions */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Call-to-Action - Zachęty do Zakupu"
          icon={Target}
          iconColor="text-green-500"
          action={
            <CopyButton
              text={content.callToActions.join("\n")}
              section="ctas"
              onCopy={onCopy}
              isCopied={copiedSection === "ctas"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {content.callToActions.map((cta, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between p-3 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-lg border border-green-500/20"
              >
                <p className="text-white text-sm">{cta}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onCopy(cta, `cta-${index}`)}
                  className="h-6 px-2 text-gray-400 hover:text-green-400"
                >
                  {copiedSection === `cta-${index}` ? (
                    <Check className="w-3 h-3" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                </Button>
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      {/* Benefits */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Korzyści dla Klienta"
          icon={Star}
          iconColor="text-yellow-500"
          action={
            <CopyButton
              text={content.benefits.join("\n")}
              section="benefits"
              onCopy={onCopy}
              isCopied={copiedSection === "benefits"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {content.benefits.map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-start gap-3 p-3 bg-gray-800/50 rounded-lg"
              >
                <div className="w-6 h-6 rounded-full bg-yellow-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Sparkles className="w-3 h-3 text-yellow-500" />
                </div>
                <p className="text-gray-300 text-sm flex-1">{benefit}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onCopy(benefit, `benefit-${index}`)}
                  className="h-6 px-2 text-gray-400 hover:text-yellow-400 flex-shrink-0"
                >
                  {copiedSection === `benefit-${index}` ? (
                    <Check className="w-3 h-3" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                </Button>
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      {/* Social Proof */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Social Proof - Dowody Społeczne"
          icon={Users}
          iconColor="text-blue-500"
          action={
            <CopyButton
              text={content.socialProof.join("\n")}
              section="socialProof"
              onCopy={onCopy}
              isCopied={copiedSection === "socialProof"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="space-y-3">
            {content.socialProof.map((proof, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-lg border border-blue-500/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                    <Users className="w-4 h-4 text-blue-500" />
                  </div>
                  <p className="text-white">{proof}</p>
                </div>
                <CopyButton
                  text={proof}
                  section={`proof-${index}`}
                  onCopy={onCopy}
                  isCopied={copiedSection === `proof-${index}`}
                />
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      {/* Urgency Phrases */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Frazy Urgency - Poczucie Pilności"
          icon={Clock}
          iconColor="text-red-500"
          action={
            <CopyButton
              text={content.urgencyPhrases.join("\n")}
              section="urgency"
              onCopy={onCopy}
              isCopied={copiedSection === "urgency"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="flex flex-wrap gap-2">
            {content.urgencyPhrases.map((phrase, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="group"
              >
                <Badge
                  variant="secondary"
                  className="bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 cursor-pointer px-3 py-1.5"
                  onClick={() => onCopy(phrase, `urgency-${index}`)}
                >
                  {copiedSection === `urgency-${index}` ? (
                    <Check className="w-3 h-3 mr-1" />
                  ) : (
                    <Zap className="w-3 h-3 mr-1" />
                  )}
                  {phrase}
                </Badge>
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>

      {/* Unique Selling Points */}
      <motion.div variants={itemVariants}>
        <SectionCard
          title="Unikalne Cechy Produktu (USP)"
          icon={Award}
          iconColor="text-purple-500"
          action={
            <CopyButton
              text={content.uniqueSellingPoints.join("\n")}
              section="usp"
              onCopy={onCopy}
              isCopied={copiedSection === "usp"}
              label="Kopiuj wszystkie"
            />
          }
        >
          <div className="grid grid-cols-1 gap-3">
            {content.uniqueSellingPoints.map((usp, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-lg border border-purple-500/20"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <Badge
                      variant="secondary"
                      className="bg-purple-500/20 text-purple-400 border-0 mb-1"
                    >
                      USP #{index + 1}
                    </Badge>
                    <p className="text-white">{usp}</p>
                  </div>
                </div>
                <CopyButton
                  text={usp}
                  section={`usp-${index}`}
                  onCopy={onCopy}
                  isCopied={copiedSection === `usp-${index}`}
                />
              </motion.div>
            ))}
          </div>
        </SectionCard>
      </motion.div>
    </motion.div>
  );
}
