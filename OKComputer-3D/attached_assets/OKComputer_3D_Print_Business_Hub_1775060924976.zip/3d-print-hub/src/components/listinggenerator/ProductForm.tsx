"use client";

import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Package,
  Ruler,
  Clock,
  DollarSign,
  Palette,
  Weight,
  Tag,
  Image,
  Layers,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProductData, Platform } from "./types";
import { MATERIALS, CATEGORIES, PLATFORM_CONFIGS } from "./types";

interface ProductFormProps {
  productData: ProductData;
  onFieldChange: (field: keyof ProductData, value: string | string[]) => void;
  onDimensionChange: (dimension: keyof ProductData["dimensions"], value: string) => void;
  selectedPlatform: Platform;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.3,
    },
  },
};

export function ProductForm({
  productData,
  onFieldChange,
  onDimensionChange,
  selectedPlatform,
}: ProductFormProps) {
  const config = PLATFORM_CONFIGS[selectedPlatform];

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      {/* Basic Info */}
      <Card className="bg-gray-900/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-500" />
            Podstawowe Informacje
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <motion.div variants={itemVariants} className="space-y-2">
            <Label htmlFor="name" className="text-gray-300">
              Nazwa Produktu
              <span className="text-amber-500 ml-1">*</span>
            </Label>
            <Input
              id="name"
              value={productData.name}
              onChange={(e) => onFieldChange("name", e.target.value)}
              placeholder="np. Wieszak na klucze - Geometryczny wzór"
              className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 focus:ring-amber-500/20"
              maxLength={config.maxTitleLength}
            />
            <div className="flex justify-between text-xs">
              <span className="text-gray-500">
                Maksymalnie {config.maxTitleLength} znaków dla {config.name}
              </span>
              <span
                className={cn(
                  productData.name.length > config.maxTitleLength * 0.9
                    ? "text-amber-500"
                    : "text-gray-500"
                )}
              >
                {productData.name.length}/{config.maxTitleLength}
              </span>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category" className="text-gray-300">
                Kategoria
              </Label>
              <Select
                value={productData.category}
                onValueChange={(value) => onFieldChange("category", value)}
              >
                <SelectTrigger className="bg-gray-800/50 border-gray-700 text-white">
                  <SelectValue placeholder="Wybierz kategorię" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  {CATEGORIES.map((cat) => (
                    <SelectItem
                      key={cat.value}
                      value={cat.value}
                      className="text-white hover:bg-gray-700 focus:bg-gray-700"
                    >
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="material" className="text-gray-300">
                Materiał
              </Label>
              <Select
                value={productData.material}
                onValueChange={(value) => onFieldChange("material", value)}
              >
                <SelectTrigger className="bg-gray-800/50 border-gray-700 text-white">
                  <SelectValue placeholder="Wybierz materiał" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700 max-h-64">
                  {MATERIALS.map((mat) => (
                    <SelectItem
                      key={mat.value}
                      value={mat.value}
                      className="text-white hover:bg-gray-700 focus:bg-gray-700"
                    >
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="secondary"
                          className={cn("text-xs", mat.color)}
                        >
                          {mat.value}
                        </Badge>
                        <span>{mat.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">
              Opis Produktu
            </Label>
            <Textarea
              id="description"
              value={productData.description}
              onChange={(e) => onFieldChange("description", e.target.value)}
              placeholder="Opisz swój produkt - co go wyróżnia, do czego służy, jakie ma zastosowanie..."
              className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 focus:ring-amber-500/20 min-h-[120px] resize-none"
            />
            <p className="text-xs text-gray-500">
              Im bardziej szczegółowy opis, tym lepsza wygenerowana treść
            </p>
          </motion.div>
        </CardContent>
      </Card>

      {/* Dimensions */}
      <Card className="bg-gray-900/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Ruler className="w-5 h-5 text-amber-500" />
            Wymiary i Specyfikacja
          </CardTitle>
        </CardHeader>
        <CardContent>
          <motion.div
            variants={itemVariants}
            className="grid grid-cols-3 gap-4"
          >
            <div className="space-y-2">
              <Label htmlFor="length" className="text-gray-300">
                Długość (mm)
              </Label>
              <div className="relative">
                <Input
                  id="length"
                  type="number"
                  value={productData.dimensions.length}
                  onChange={(e) => onDimensionChange("length", e.target.value)}
                  placeholder="0"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  mm
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="width" className="text-gray-300">
                Szerokość (mm)
              </Label>
              <div className="relative">
                <Input
                  id="width"
                  type="number"
                  value={productData.dimensions.width}
                  onChange={(e) => onDimensionChange("width", e.target.value)}
                  placeholder="0"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  mm
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="height" className="text-gray-300">
                Wysokość (mm)
              </Label>
              <div className="relative">
                <Input
                  id="height"
                  type="number"
                  value={productData.dimensions.height}
                  onChange={(e) => onDimensionChange("height", e.target.value)}
                  placeholder="0"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  mm
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="grid grid-cols-2 gap-4 mt-4"
          >
            <div className="space-y-2">
              <Label htmlFor="weight" className="text-gray-300 flex items-center gap-2">
                <Weight className="w-4 h-4 text-gray-500" />
                Waga (g)
              </Label>
              <div className="relative">
                <Input
                  id="weight"
                  type="number"
                  value={productData.weight}
                  onChange={(e) => onFieldChange("weight", e.target.value)}
                  placeholder="np. 45"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  g
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="color" className="text-gray-300 flex items-center gap-2">
                <Palette className="w-4 h-4 text-gray-500" />
                Kolor
              </Label>
              <Input
                id="color"
                value={productData.color}
                onChange={(e) => onFieldChange("color", e.target.value)}
                placeholder="np. Czarny mat"
                className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500"
              />
            </div>
          </motion.div>
        </CardContent>
      </Card>

      {/* Pricing & Time */}
      <Card className="bg-gray-900/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-amber-500" />
            Cena i Czas Realizacji
          </CardTitle>
        </CardHeader>
        <CardContent>
          <motion.div
            variants={itemVariants}
            className="grid grid-cols-2 gap-4"
          >
            <div className="space-y-2">
              <Label htmlFor="price" className="text-gray-300 flex items-center gap-2">
                <Tag className="w-4 h-4 text-gray-500" />
                Cena (PLN)
              </Label>
              <div className="relative">
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={productData.price}
                  onChange={(e) => onFieldChange("price", e.target.value)}
                  placeholder="0.00"
                  className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500 pl-10"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                  zł
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="printTime" className="text-gray-300 flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-500" />
                Czas Realizacji
              </Label>
              <Input
                id="printTime"
                value={productData.printTime}
                onChange={(e) => onFieldChange("printTime", e.target.value)}
                placeholder="np. 2-3 dni robocze"
                className="bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-amber-500"
              />
            </div>
          </motion.div>
        </CardContent>
      </Card>

      {/* Images Placeholder */}
      <Card className="bg-gray-900/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Image className="w-5 h-5 text-amber-500" />
            Zdjęcia Produktu
          </CardTitle>
        </CardHeader>
        <CardContent>
          <motion.div variants={itemVariants}>
            <div className="border-2 border-dashed border-gray-700 rounded-xl p-8 text-center hover:border-amber-500/50 transition-colors cursor-pointer group">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-800 flex items-center justify-center group-hover:bg-amber-500/10 transition-colors">
                <Layers className="w-8 h-8 text-gray-500 group-hover:text-amber-500 transition-colors" />
              </div>
              <p className="text-gray-300 font-medium mb-1">
                Dodaj zdjęcia produktu
              </p>
              <p className="text-gray-500 text-sm mb-4">
                Przeciągnij i upuść lub kliknij, aby wybrać pliki
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                  JPG, PNG, WEBP
                </Badge>
                <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                  Max 10MB
                </Badge>
                <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                  Min. 1000x1000px
                </Badge>
              </div>
            </div>
            
            {productData.images.length > 0 && (
              <div className="mt-4 grid grid-cols-4 gap-2">
                {productData.images.map((img, index) => (
                  <div
                    key={index}
                    className="aspect-square rounded-lg bg-gray-800 flex items-center justify-center"
                  >
                    <Image className="w-6 h-6 text-gray-600" />
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
