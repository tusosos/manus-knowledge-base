"use client";

import React, { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  ShoppingBag,
  Globe,
  Facebook,
  Store,
  Sparkles,
  Lightbulb,
  Copy,
  Check,
  Download,
  RefreshCw,
} from "lucide-react";
import { PlatformSelector } from "./PlatformSelector";
import { ProductForm } from "./ProductForm";
import { ContentPreview } from "./ContentPreview";
import { MarketingTexts } from "./MarketingTexts";
import { TipsSection } from "./TipsSection";
import { ExportModal } from "./ExportModal";
import type {
  Platform,
  ProductData,
  GeneratedContent,
  MarketingContent,
} from "./types";
import { generateContent, generateMarketingTexts } from "./utils";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  },
};

const initialProductData: ProductData = {
  name: "",
  description: "",
  dimensions: {
    length: "",
    width: "",
    height: "",
  },
  material: "PLA",
  printTime: "",
  price: "",
  images: [],
  category: "dekoracje",
  color: "",
  weight: "",
};

export function ListingGenerator() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>("allegro");
  const [productData, setProductData] = useState<ProductData>(initialProductData);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [marketingContent, setMarketingContent] = useState<MarketingContent | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleProductDataChange = useCallback(
    (field: keyof ProductData, value: string | string[] | ProductData["dimensions"]) => {
      setProductData((prev) => ({ ...prev, [field]: value }));
    },
    []
  );

  const handleDimensionChange = useCallback(
    (dimension: keyof ProductData["dimensions"], value: string) => {
      setProductData((prev) => ({
        ...prev,
        dimensions: { ...prev.dimensions, [dimension]: value },
      }));
    },
    []
  );

  const handleGenerate = useCallback(async () => {
    if (!productData.name.trim()) return;

    setIsGenerating(true);
    
    // Simulate API delay for generation
    await new Promise((resolve) => setTimeout(resolve, 800));

    const content = generateContent(productData, selectedPlatform);
    const marketing = generateMarketingTexts(productData, selectedPlatform);

    setGeneratedContent(content);
    setMarketingContent(marketing);
    setIsGenerating(false);
  }, [productData, selectedPlatform]);

  const handleCopy = useCallback(async (text: string, section: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  }, []);

  const handleReset = useCallback(() => {
    setProductData(initialProductData);
    setGeneratedContent(null);
    setMarketingContent(null);
  }, []);

  const hasContent = generatedContent !== null && marketingContent !== null;

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="w-full max-w-7xl mx-auto space-y-6"
    >
      {/* Header */}
      <motion.div variants={itemVariants} className="text-center space-y-2">
        <div className="flex items-center justify-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Generator Treści Ofert
          </h1>
        </div>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Twórz profesjonalne oferty sprzedaży dla swoich produktów 3D. 
          Optymalizowane pod różne platformy e-commerce.
        </p>
      </motion.div>

      {/* Platform Selector */}
      <motion.div variants={itemVariants}>
        <PlatformSelector
          selectedPlatform={selectedPlatform}
          onPlatformChange={setSelectedPlatform}
        />
      </motion.div>

      {/* Main Content */}
      <motion.div variants={itemVariants}>
        <Tabs defaultValue="form" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-900/50 border border-gray-800">
            <TabsTrigger
              value="form"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
            >
              <FileText className="w-4 h-4 mr-2" />
              Formularz
            </TabsTrigger>
            <TabsTrigger
              value="preview"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
              disabled={!hasContent}
            >
              <ShoppingBag className="w-4 h-4 mr-2" />
              Podgląd
            </TabsTrigger>
            <TabsTrigger
              value="marketing"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
              disabled={!hasContent}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Marketing
            </TabsTrigger>
            <TabsTrigger
              value="tips"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
            >
              <Lightbulb className="w-4 h-4 mr-2" />
              Porady
            </TabsTrigger>
          </TabsList>

          {/* Form Tab */}
          <TabsContent value="form" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ProductForm
                  productData={productData}
                  onFieldChange={handleProductDataChange}
                  onDimensionChange={handleDimensionChange}
                  selectedPlatform={selectedPlatform}
                />
              </div>
              <div className="space-y-4">
                <Card className="bg-gray-900/50 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">
                      Akcje
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      onClick={handleGenerate}
                      disabled={!productData.name.trim() || isGenerating}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white"
                    >
                      {isGenerating ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Generowanie...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generuj Treść
                        </>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleReset}
                      className="w-full border-gray-700 text-gray-300 hover:bg-gray-800"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Wyczyść Formularz
                    </Button>
                  </CardContent>
                </Card>

                {hasContent && (
                  <Card className="bg-gray-900/50 border-gray-800 border-l-4 border-l-amber-500">
                    <CardHeader>
                      <CardTitle className="text-white text-lg">
                        Szybkie Akcje
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Button
                        variant="outline"
                        onClick={() => setShowExportModal(true)}
                        className="w-full border-gray-700 text-gray-300 hover:bg-gray-800"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Eksportuj Ofertę
                      </Button>
                    </CardContent>
                  </Card>
                )}

                <Card className="bg-gray-900/50 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">
                      Wybrana Platforma
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                      {selectedPlatform === "allegro" && <Store className="w-6 h-6 text-amber-500" />}
                      {selectedPlatform === "etsy" && <ShoppingBag className="w-6 h-6 text-orange-500" />}
                      {selectedPlatform === "olx" && <Globe className="w-6 h-6 text-blue-500" />}
                      {selectedPlatform === "website" && <Globe className="w-6 h-6 text-green-500" />}
                      {selectedPlatform === "facebook" && <Facebook className="w-6 h-6 text-blue-600" />}
                      <div>
                        <p className="text-white font-medium capitalize">
                          {selectedPlatform === "website" ? "Własna Strona" : selectedPlatform}
                        </p>
                        <p className="text-gray-400 text-sm">
                          Treść zoptymalizowana pod tę platformę
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="mt-6">
            {generatedContent && (
              <ContentPreview
                content={generatedContent}
                platform={selectedPlatform}
                onCopy={handleCopy}
                copiedSection={copiedSection}
              />
            )}
          </TabsContent>

          {/* Marketing Tab */}
          <TabsContent value="marketing" className="mt-6">
            {marketingContent && (
              <MarketingTexts
                content={marketingContent}
                onCopy={handleCopy}
                copiedSection={copiedSection}
              />
            )}
          </TabsContent>

          {/* Tips Tab */}
          <TabsContent value="tips" className="mt-6">
            <TipsSection />
          </TabsContent>
        </Tabs>
      </motion.div>

      {/* Export Modal */}
      <ExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        productData={productData}
        generatedContent={generatedContent}
        marketingContent={marketingContent}
        platform={selectedPlatform}
      />
    </motion.div>
  );
}
