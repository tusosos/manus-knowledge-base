"use client";

import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Store,
  ShoppingBag,
  Globe,
  Facebook,
  Check,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Platform } from "./types";

interface PlatformSelectorProps {
  selectedPlatform: Platform;
  onPlatformChange: (platform: Platform) => void;
}

const platforms: {
  id: Platform;
  name: string;
  description: string;
  icon: React.ElementType;
  color: string;
  gradient: string;
  features: string[];
}[] = [
  {
    id: "allegro",
    name: "Allegro",
    description: "Największy polski marketplace",
    icon: Store,
    color: "text-amber-500",
    gradient: "from-amber-500/20 to-orange-500/20",
    features: ["50 znaków tytuł", "HTML w opisie", "10 tagów"],
  },
  {
    id: "etsy",
    name: "Etsy",
    description: "Globalna platforma handmade",
    icon: ShoppingBag,
    color: "text-orange-500",
    gradient: "from-orange-500/20 to-red-500/20",
    features: ["140 znaków tytuł", "SEO-friendly", "13 tagów"],
  },
  {
    id: "olx",
    name: "OLX",
    description: "Popularne ogłoszenia lokalne",
    icon: Globe,
    color: "text-blue-500",
    gradient: "from-blue-500/20 to-cyan-500/20",
    features: ["70 znaków tytuł", "Prosty opis", "Lokalna sprzedaż"],
  },
  {
    id: "website",
    name: "Własna Strona",
    description: "Twoja własna witryna e-commerce",
    icon: Globe,
    color: "text-green-500",
    gradient: "from-green-500/20 to-emerald-500/20",
    features: ["Pełna kontrola", "Własne SEO", "Bez prowizji"],
  },
  {
    id: "facebook",
    name: "Facebook Marketplace",
    description: "Społecznościowa sprzedaż",
    icon: Facebook,
    color: "text-blue-600",
    gradient: "from-blue-600/20 to-indigo-500/20",
    features: ["Lokalna sprzedaż", "Grupy tematyczne", "Bez opłat"],
  },
];

export function PlatformSelector({
  selectedPlatform,
  onPlatformChange,
}: PlatformSelectorProps) {
  return (
    <Card className="bg-gray-900/50 border-gray-800 overflow-hidden">
      <CardContent className="p-6">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-white mb-1">
            Wybierz Platformę
          </h2>
          <p className="text-gray-400 text-sm">
            Treść oferty zostanie zoptymalizowana pod wybraną platformę
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {platforms.map((platform) => {
            const Icon = platform.icon;
            const isSelected = selectedPlatform === platform.id;

            return (
              <motion.button
                key={platform.id}
                onClick={() => onPlatformChange(platform.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={cn(
                  "relative p-4 rounded-xl border-2 transition-all duration-300 text-left",
                  "bg-gradient-to-br",
                  platform.gradient,
                  isSelected
                    ? "border-amber-500 shadow-lg shadow-amber-500/20"
                    : "border-gray-700 hover:border-gray-600"
                )}
              >
                {/* Selected indicator */}
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-2 right-2"
                  >
                    <div className="w-5 h-5 rounded-full bg-amber-500 flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  </motion.div>
                )}

                <div className="space-y-3">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center",
                      "bg-gray-900/50"
                    )}
                  >
                    <Icon className={cn("w-5 h-5", platform.color)} />
                  </div>

                  <div>
                    <h3 className="font-semibold text-white text-sm">
                      {platform.name}
                    </h3>
                    <p className="text-gray-400 text-xs mt-0.5">
                      {platform.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {platform.features.map((feature, index) => (
                      <Badge
                        key={index}
                        variant="secondary"
                        className="text-[10px] bg-gray-800/50 text-gray-400 border-0"
                      >
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
