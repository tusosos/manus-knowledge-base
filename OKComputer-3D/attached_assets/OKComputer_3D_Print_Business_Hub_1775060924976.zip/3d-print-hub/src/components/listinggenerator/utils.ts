import type {
  ProductData,
  Platform,
  GeneratedContent,
  MarketingContent,
  PLATFORM_CONFIGS,
} from "./types";

// Helper function to capitalize first letter
const capitalize = (str: string): string => {
  return str.charAt(0).toUpperCase() + str.slice(1);
};

// Generate category-specific keywords
const getCategoryKeywords = (category: string): string[] => {
  const keywords: Record<string, string[]> = {
    dekoracje: ["dekoracja", "ozdoba", "wystrój wnętrz", "prezent", "handmade", "unikalny"],
    gadzety: ["gadżet", "akcesorium", "praktyczny", "funkcjonalny", "innowacyjny"],
    narzedzia: ["narzędzie", "część zamienna", "funkcjonalny", "wytrzymały", "praktyczny"],
    zabawki: ["zabawka", "model", "kolekcjonerski", "edukacyjny", "dla dzieci"],
    biuro: ["biuro", "organizer", "praktyczny", "elegancki", "profesjonalny"],
    kuchnia: ["kuchenny", "praktyczny", "funkcjonalny", "do kuchni", "użytkowy"],
    ogrod: ["ogród", "outdoor", "zewnętrzny", "wytrzymały", "pogodoodporny"],
    cosplay: ["cosplay", "rekwizyt", "kostium", "fan", "kolekcjonerski"],
    elektronika: ["elektronika", "obudowa", "tech", "nowoczesny", "funkcjonalny"],
    jewelry: ["biżuteria", "elegancki", "modny", "prezent", "unikalny"],
    lampy: ["lampa", "oświetlenie", "dekoracyjny", "klimatyczny", "design"],
    organizery: ["organizer", "przechowywanie", "porządek", "funkcjonalny", "praktyczny"],
  };

  return keywords[category] || ["3D print", "druk 3D", "handmade", "polski produkt"];
};

// Generate material-specific benefits
const getMaterialBenefits = (material: string): string[] => {
  const benefits: Record<string, string[]> = {
    PLA: ["ekologiczny", "łatwy w recyklingu", "bezpieczny", "przyjazny środowisku"],
    PETG: ["wytrzymały", "odporny na wilgoć", "łatwy w czyszczeniu", "trwały"],
    ABS: ["bardzo wytrzymały", "odporny na wysokie temperatury", "twardy", "profesjonalny"],
    TPU: ["elastyczny", "odporny na uderzenia", "miękki w dotyku", "wygodny"],
    ASA: ["odporny na UV", "pogodoodporny", "trwały na zewnątrz", "wytrzymały"],
    Nylon: ["ekstremalnie wytrzymały", "profesjonalny", "wysoka jakość", "trwały"],
    Wood: ["naturalny wygląd", "elegancki", "unikalny", "ekologiczny"],
    Metal: ["metaliczny wygląd", "elegancki", "premium", "luksusowy"],
    Carbon: ["lekki", "wytrzymały", "sportowy wygląd", "nowoczesny"],
    Resin: ["wysoka precyzja", "gładka powierzchnia", "detale", "premium"],
  };

  return benefits[material] || ["wysoka jakość", "wytrzymały", "precyzyjny wydruk"];
};

// Generate platform-specific title
const generateTitle = (product: ProductData, platform: Platform): string => {
  const { name, material, category } = product;
  const categoryLabel = getCategoryKeywords(category)[0];

  const titles: Record<Platform, string> = {
    allegro: `${name} | ${material} | ${capitalize(categoryLabel)} 3D Print`,
    etsy: `${name} - ${material} - Handmade 3D Printed ${capitalize(categoryLabel)} - Gift Idea`,
    olx: `${name} ${material} druk 3D ${categoryLabel}`,
    website: `${name} | Premium ${material} 3D Print | ${capitalize(categoryLabel)}`,
    facebook: `${name} - ${material} - Druk 3D - ${capitalize(categoryLabel)}`,
  };

  // Truncate if needed
  const maxLength = {
    allegro: 50,
    etsy: 140,
    olx: 70,
    website: 200,
    facebook: 100,
  }[platform];

  let title = titles[platform];
  if (title.length > maxLength) {
    title = title.substring(0, maxLength - 3) + "...";
  }

  return title;
};

// Generate description based on platform
const generateDescription = (product: ProductData, platform: Platform): string => {
  const { name, description, material, dimensions, printTime, color, weight, category } = product;
  const categoryKeywords = getCategoryKeywords(category);
  const materialBenefits = getMaterialBenefits(material);

  const dimText =
    dimensions.length && dimensions.width && dimensions.height
      ? `${dimensions.length} x ${dimensions.width} x ${dimensions.height} mm`
      : "Wymiary na zamówienie";

  const baseDescription = description || `${name} to wysokiej jakości produkt wykonany w technologii druku 3D.`;

  const descriptions: Record<Platform, string> = {
    allegro: `✨ ${name} ✨

${baseDescription}

🎯 DLACZEGO WARTO?
• Wykonany z najwyższej jakości materiału ${material}
• ${materialBenefits[0]} i ${materialBenefits[1]}
• Precyzyjny wydruk 3D z dbałością o każdy detal
• ${categoryKeywords[0]} idealny na prezent

📐 SPECYFIKACJA:
• Materiał: ${material}
• Wymiary: ${dimText}
${color ? `• Kolor: ${color}` : ""}
${weight ? `• Waga: ${weight}g` : ""}
${printTime ? `• Czas realizacji: ${printTime}` : ""}

✅ GWARANCJA JAKOŚCI
Każdy produkt jest dokładnie sprawdzany przed wysyłką. Oferujemy pełne wsparcie i odpowiadamy na wszystkie pytania.

🚚 DOSTAWA
• Bezpieczne pakowanie
• Szybka realizacja zamówień
• Możliwość personalizacji

Masz pytania? Napisz do nas! 💬`,

    etsy: `Welcome to our 3D Print Studio! 🎨

${baseDescription}

This beautiful ${categoryKeywords[0]} is carefully crafted using premium ${material} filament and state-of-the-art 3D printing technology.

✨ FEATURES:
• Material: High-quality ${material}
• Dimensions: ${dimText}
${color ? `• Color: ${color}` : ""}
${weight ? `• Weight: ${weight}g` : ""}
• ${materialBenefits[0]}
• ${materialBenefits[1]}
• ${materialBenefits[2]}

🎁 PERFECT GIFT IDEA
Looking for a unique gift? This handmade ${categoryKeywords[0]} makes an excellent present for any occasion!

📦 SHIPPING & PACKAGING
We pack every item with extreme care to ensure it arrives in perfect condition. ${printTime ? `Processing time: ${printTime}` : ""}

💬 CUSTOM ORDERS
Want a different color or size? Contact us for custom orders!

Thank you for supporting small business! ⭐`,

    olx: `${name} - druk 3D ${material}

${baseDescription}

Materiał: ${material}
Wymiary: ${dimText}
${color ? `Kolor: ${color}` : ""}
${weight ? `Waga: ${weight}g` : ""}
${printTime ? `Czas realizacji: ${printTime}` : ""}

Wykonany z wysokiej jakości filamentu. Precyzyjny wydruk.

Możliwość personalizacji - pytaj o szczegóły.

Odbiór osobisty lub wysyłka.`,

    website: `<h2>${name}</h2>

<p>${baseDescription}</p>

<h3>Wybrane cechy</h3>
<ul>
<li>Wykonany z premium materiału ${material}</li>
<li>${materialBenefits[0]}</li>
<li>${materialBenefits[1]}</li>
<li>${materialBenefits[2]}</li>
</ul>

<h3>Specyfikacja techniczna</h3>
<table>
<tr><td>Materiał</td><td>${material}</td></tr>
<tr><td>Wymiary</td><td>${dimText}</td></tr>
${color ? `<tr><td>Kolor</td><td>${color}</td></tr>` : ""}
${weight ? `<tr><td>Waga</td><td>${weight}g</td></tr>` : ""}
${printTime ? `<tr><td>Czas realizacji</td><td>${printTime}</td></tr>` : ""}
</table>

<h3>Dlaczego nasze produkty?</h3>
<p>Każdy produkt jest drukowany z najwyższą precyzją i sprawdzany przed wysyłką. Oferujemy gwarancję jakości i pełne wsparcie klienta.</p>`,

    facebook: `🎉 ${name} 🎉

${baseDescription}

📌 Szczegóły:
• Materiał: ${material}
• Wymiary: ${dimText}
${color ? `• Kolor: ${color}` : ""}
${weight ? `• Waga: ${weight}g` : ""}

✅ ${materialBenefits[0]}
✅ ${materialBenefits[1]}
✅ ${materialBenefits[2]}

${printTime ? `⏱️ Czas realizacji: ${printTime}` : ""}

💬 Napisz do nas po więcej info!
📍 Lokalna sprzedaż + wysyłka

#druk3D #${category} #${material} #handmade #polskiprodukt`,
  };

  return descriptions[platform];
};

// Generate tags based on product data
const generateTags = (product: ProductData, platform: Platform): string[] => {
  const { name, material, category, color } = product;
  const categoryKeywords = getCategoryKeywords(category);

  const baseTags = [
    "druk 3D",
    "3D print",
    material,
    categoryKeywords[0],
    categoryKeywords[1],
    "handmade",
    "polski produkt",
  ];

  if (color) baseTags.push(color);
  if (name) {
    const nameWords = name.toLowerCase().split(" ");
    baseTags.push(...nameWords.filter((w) => w.length > 3).slice(0, 3));
  }

  // Platform-specific tags
  const platformTags: Record<Platform, string[]> = {
    allegro: [...baseTags, "prezent", "oryginalny", "personalizowany"],
    etsy: [...baseTags, "gift idea", "unique", "custom made", "birthday gift"],
    olx: [...baseTags.slice(0, 5)],
    website: [...baseTags, "premium", "wysoka jakość", "gwarancja"],
    facebook: [], // Facebook doesn't use tags
  };

  const maxTags = {
    allegro: 10,
    etsy: 13,
    olx: 5,
    website: 20,
    facebook: 0,
  }[platform];

  return platformTags[platform].slice(0, maxTags);
};

// Generate SEO keywords
const generateKeywords = (product: ProductData, platform: Platform): string[] => {
  const { name, material, category } = product;
  const categoryKeywords = getCategoryKeywords(category);

  const keywords = [
    "druk 3D",
    "3D print",
    material.toLowerCase(),
    categoryKeywords[0],
    categoryKeywords[1],
    "handmade",
    "polski produkt",
    "prezent",
    "unikalny",
    "personalizowany",
    name.toLowerCase(),
    `${material} druk 3D`,
    `produkt ${category}`,
    "custom 3D print",
    "wydruk 3D",
  ];

  return [...new Set(keywords)];
};

// Generate specifications
const generateSpecifications = (product: ProductData) => {
  const { material, dimensions, color, weight, printTime } = product;

  const specs = [
    { label: "Materiał", value: material },
    {
      label: "Wymiary",
      value:
        dimensions.length && dimensions.width && dimensions.height
          ? `${dimensions.length} x ${dimensions.width} x ${dimensions.height} mm`
          : "Na zamówienie",
    },
    { label: "Technologia", value: "Druk 3D FDM" },
  ];

  if (color) specs.push({ label: "Kolor", value: color });
  if (weight) specs.push({ label: "Waga", value: `${weight}g` });
  if (printTime) specs.push({ label: "Czas realizacji", value: printTime });

  return specs;
};

// Generate delivery terms
const generateDeliveryTerms = (platform: Platform): string => {
  const terms: Record<Platform, string> = {
    allegro:
      "Wysyłka w ciągu 1-2 dni roboczych. Bezpieczne pakowanie zabezpieczone folią bąbelkową. Dostępne metody: InPost, DPD, odbiór osobisty. Koszt wysyłki: od 12,99 zł.",
    etsy:
      "Processing time: 1-3 business days. We ship worldwide with tracked delivery. Carefully packaged in eco-friendly materials. Shipping costs calculated at checkout.",
    olx: "Odbiór osobisty lub wysyłka kurierem. Koszt wysyłki do ustalenia. Możliwość wysyłki za pobraniem.",
    website:
      "Darmowa dostawa przy zamówieniach powyżej 150 zł. Wysyłka w 24h. Bezpieczne pakowanie. Śledzenie przesyłki. Zwrot do 14 dni.",
    facebook:
      "Odbiór osobisty lub wysyłka. Wysyłka po przedpłacie na konto. Koszt wysyłki: 15 zł (InPaczkomat) lub 20 zł (kurier).",
  };

  return terms[platform];
};

// Generate return policy
const generateReturnPolicy = (platform: Platform): string => {
  const policies: Record<Platform, string> = {
    allegro:
      "Zgodnie z prawem, masz 14 dni na zwrot produktu bez podania przyczyny. Produkt musi być nieużywany i w oryginalnym opakowaniu. Zwrot kosztów w ciągu 14 dni od otrzymania zwrotu.",
    etsy:
      "We accept returns within 14 days of delivery. Item must be unused and in original packaging. Custom/personalized orders are non-refundable. Return shipping costs are buyer's responsibility.",
    olx: "Zwrot możliwy w ciągu 14 dni. Produkt nie może być używany. Koszt zwrotu pokrywa kupujący.",
    website:
      "14 dni na zwrot bez podania przyczyny. Produkt musi być w stanie nienaruszonym. Zwrot pełnej kwoty w ciągu 7 dni roboczych. Produkty personalizowane nie podlegają zwrotowi.",
    facebook:
      "Zwrot w ciągu 14 dni. Produkt nieużywany. Koszt wysyłki zwrotnej po stronie kupującego.",
  };

  return policies[platform];
};

// Generate SEO title
const generateSEOTitle = (product: ProductData, platform: Platform): string => {
  const { name, material, category } = product;
  const categoryLabel = getCategoryKeywords(category)[0];

  return `${name} | ${material} | ${capitalize(categoryLabel)} 3D Print | Kup Online`;
};

// Generate SEO description
const generateSEODescription = (product: ProductData, platform: Platform): string => {
  const { name, material, category } = product;
  const categoryKeywords = getCategoryKeywords(category);

  return `Kup ${name} wykonany z ${material}. Wysokiej jakości ${categoryKeywords[0]} z druku 3D. Szybka dostawa, bezpieczne pakowanie. Zamów teraz!`;
};

// Main content generation function
export const generateContent = (
  product: ProductData,
  platform: Platform
): GeneratedContent => {
  const description = generateDescription(product, platform);

  // Generate short description (first 2-3 sentences)
  const shortDesc = description
    .split(/[.!?]/)
    .slice(0, 2)
    .join(". ") + ".";

  return {
    title: generateTitle(product, platform),
    description,
    shortDescription: shortDesc,
    tags: generateTags(product, platform),
    keywords: generateKeywords(product, platform),
    specifications: generateSpecifications(product),
    deliveryTerms: generateDeliveryTerms(platform),
    returnPolicy: generateReturnPolicy(platform),
    seoTitle: generateSEOTitle(product, platform),
    seoDescription: generateSEODescription(product, platform),
  };
};

// Generate marketing texts
export const generateMarketingTexts = (
  product: ProductData,
  platform: Platform
): MarketingContent => {
  const { name, material, category } = product;
  const categoryKeywords = getCategoryKeywords(category);
  const materialBenefits = getMaterialBenefits(material);

  return {
    headlines: [
      `🎉 ${name} - Odkryj Jakość Druku 3D!`,
      `✨ Unikalny ${categoryKeywords[0]} z ${material} - Tylko u Nas!`,
      `🎁 Idealny Prezent: ${name} - Handmade z Pasją`,
      `🔥 ${categoryKeywords[0]} Premium - ${material} | Kup Teraz!`,
      `💎 ${name} - Rzemiosło XXI Wieku`,
      `🚀 ${categoryKeywords[0]} który Zmieni Twój Świat`,
    ],

    callToActions: [
      "🛒 Dodaj do koszyka i zamów teraz!",
      "💬 Napisz do nas po więcej info!",
      "⭐ Dodaj do ulubionych i kup później",
      "🎁 Zamów teraz - idealny na prezent!",
      "📦 Sprawdź dostępność i zamów!",
      "🔔 Kliknij i zobacz szczegóły!",
    ],

    benefits: [
      `✅ Wykonany z wysokiej jakości ${material} - ${materialBenefits[0]}`,
      `✅ Precyzyjny wydruk 3D z dbałością o każdy detal`,
      `✅ ${materialBenefits[1]} - produkt na lata`,
      `✅ Unikalny design - wyróżnij się z tłumu`,
      `✅ Idealny jako prezent dla bliskiej osoby`,
      `✅ Polski produkt - wspierasz lokalny biznes`,
      `✅ Możliwość personalizacji - stwórz coś wyjątkowego`,
      `✅ Gwarancja jakości - sprawdzamy każdy egzemplarz`,
    ],

    socialProof: [
      "⭐⭐⭐⭐⭐ 'Najlepsza jakość jaką widziałem!' - Anna K.",
      "⭐⭐⭐⭐⭐ 'Szybka dostawa, piękne wykonanie' - Marek W.",
      "⭐⭐⭐⭐⭐ 'Idealny prezent, polecam!' - Katarzyna S.",
      "🔥 Ponad 500 zadowolonych klientów!",
      "🏆 Top Rated Seller - 99% pozytywnych opinii",
      "📦 Wysłaliśmy już ponad 1000 produktów!",
    ],

    urgencyPhrases: [
      "⚡ Ostatnie sztuki w magazynie!",
      "🔥 Promocja tylko do końca tygodnia!",
      "⏰ Zamów w ciągu 24h - szybsza wysyłka!",
      "💎 Limitowana edycja - nie przegap!",
      "🎁 Darmowa dostawa przy zamówieniu 2 sztuk!",
      "⚠️ Tylko 3 sztuki dostępne!",
    ],

    uniqueSellingPoints: [
      `🎯 ${materialBenefits[0]} - jakość premium`,
      `🎯 Ręczna kontrola jakości każdego produktu`,
      `🎯 ${materialBenefits[2]} - inwestycja na lata`,
      `🎯 Unikalny design dostępny tylko u nas`,
      `🎯 Szybka realizacja - ${product.printTime || "1-2 dni robocze"}`,
    ],
  };
};
