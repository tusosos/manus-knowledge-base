"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  PenTool,
  Camera,
  DollarSign,
  Search,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  CheckCircle,
  AlertCircle,
  Star,
  TrendingUp,
  Eye,
  Heart,
} from "lucide-react";
import { cn } from "@/lib/utils";

type TipCategory = "all" | "writing" | "photography" | "pricing" | "seo";

interface Tip {
  id: string;
  title: string;
  content: string;
  category: Exclude<TipCategory, "all">;
  icon: React.ElementType;
  tips: string[];
  mistakes: string[];
  proTip?: string;
}

const tips: Tip[] = [
  {
    id: "writing-1",
    title: "Jak pisać oferty które się sprzedają",
    category: "writing",
    icon: PenTool,
    content:
      "Skuteczna oferta to nie tylko opis produktu - to historia, która przekonuje klienta do zakupu. Skup się na korzyściach, nie tylko cechach.",
    tips: [
      "Zacznij od mocnego headline - złap uwagę w pierwszych 3 sekundach",
      "Używaj słów 'Ty' i 'Twój' - personalizuj przekaz",
      "Opisuj korzyści, nie tylko funkcje (np. 'zaoszczędzisz czas' zamiast 'ma dużą pojemność')",
      "Dodaj storytelling - jak produkt rozwiązuje problem",
      "Używaj punktorów dla czytelności",
      "Zakończ silnym call-to-action",
      "Dodaj element pilności (ograniczona ilość, promocja)",
    ],
    mistakes: [
      "Zbyt długie, nudne opisy",
      "Brak formatowania - ściana tekstu",
      "Tylko sucha specyfikacja techniczna",
      "Brak informacji o rozmiarze/skali",
      "Niejasne zdjęcia lub ich brak",
    ],
    proTip:
      "Testuj różne wersje opisów (A/B testing) i śledź, które przynoszą lepsze wyniki.",
  },
  {
    id: "photography-1",
    title: "Jak fotografować produkty 3D",
    category: "photography",
    icon: Camera,
    content:
      "Zdjęcia to najważniejszy element oferty. Dla produktów 3D kluczowe jest pokazanie jakości wydruku, detali i skali.",
    tips: [
      "Używaj naturalnego światła lub softboxów - unikaj ostrych cieni",
      "Fotografuj na neutralnym tle (białe, szare, drewno)",
      "Zawsze pokazuj skalę - dodaj monetę, dłonię lub linijkę",
      "Zrób zdjęcia z różnych kątów (minimum 5-7 zdjęć)",
      "Zbliżenie na detale i teksturę warstw",
      "Pokaż produkt w użyciu/aranżacji",
      "Używaj trybu makro dla małych detali",
      "Zdjęcia 360° zwiększają zaufanie",
    ],
    mistakes: [
      "Słabe oświetlenie lub prześwietlenia",
      "Brak odniesienia do skali",
      "Nieczyste/nierówne tło",
      "Zbyt mało zdjęć",
      "Nieostre zdjęcia",
      "Filtry które zniekształcają kolory",
    ],
    proTip:
      "Zainwestuj w lightbox - nawet tani (50-100zł) znacznie poprawi jakość zdjęć.",
  },
  {
    id: "pricing-1",
    title: "Jak ustawiać ceny produktów 3D",
    category: "pricing",
    icon: DollarSign,
    content:
      "Wycena produktów 3D to sztuka balansu między kosztami a konkurencyjnością. Musisz uwzględnić czas, materiał, zużycie drukarki i marżę.",
    tips: [
      "Kalkuluj: materiał + czas druku + przygotowanie + pakowanie + marża",
      "Sprawdź ceny konkurencji na danej platformie",
      "Oferuj warianty cenowe (Basic/Premium/Deluxe)",
      "Dodaj koszt wysyłki w cenie lub podaj osobno",
      "Używaj psychologii cen - 49,99 zamiast 50 zł",
      "Oferuj zniżki przy większej ilości",
      "Podnieś cenę o 20-30% przed promocją",
      "Śledź marżę na każdym produkcie",
    ],
    mistakes: [
      "Zbyt niska cena - niezarobek i podejrzana jakość",
      "Nieuwzględnienie czasu przygotowania",
      "Brak kalkulacji zużycia drukarki",
      "Konkurencja tylko cenowa",
      "Nieaktualne ceny przy wzroście kosztów",
    ],
    proTip:
      "Użyj kalkulatora kosztów druku (np. 3DPrintCost) i dodaj 40-60% marży.",
  },
  {
    id: "seo-1",
    title: "SEO dla platform e-commerce",
    category: "seo",
    icon: Search,
    content:
      "SEO to klucz do organicznego ruchu. Każda platforma ma swoje algorytmy, ale podstawowe zasady są uniwersalne.",
    tips: [
      "Badaj słowa kluczowe - używaj Google Trends, Ubersuggest",
      "Umieść główne słowo kluczowe w tytule",
      "Używaj długiego ogona (long-tail keywords)",
      "Wypełnij wszystkie pola atrybutów",
      "Dodaj atrybuty materiału, koloru, rozmiaru",
      "Używaj tagów zgodnie z limitem platformy",
      "Regularnie aktualizuj oferty",
      "Zachęcaj do opinii - wpływają na ranking",
    ],
    mistakes: [
      "Keyword stuffing - nadmiar słów kluczowych",
      "Ignorowanie pól atrybutów",
      "Kopiowanie opisów konkurencji",
      "Brak unikalnych zdjęć",
      "Nieaktualne informacje",
    ],
    proTip:
      "Na Etsy używaj wszystkich 13 tagów - to najważniejszy czynnik SEO na tej platformie.",
  },
];

const categoryLabels: Record<TipCategory, { label: string; icon: React.ElementType; color: string }> = {
  all: { label: "Wszystkie", icon: Lightbulb, color: "text-amber-500" },
  writing: { label: "Pisanie ofert", icon: PenTool, color: "text-blue-500" },
  photography: { label: "Fotografia", icon: Camera, color: "text-purple-500" },
  pricing: { label: "Wycena", icon: DollarSign, color: "text-green-500" },
  seo: { label: "SEO", icon: Search, color: "text-orange-500" },
};

export function TipsSection() {
  const [activeCategory, setActiveCategory] = useState<TipCategory>("all");
  const [expandedTip, setExpandedTip] = useState<string | null>(null);

  const filteredTips =
    activeCategory === "all"
      ? tips
      : tips.filter((tip) => tip.category === activeCategory);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Category Filter */}
      <Card className="bg-gray-900/50 border-gray-800">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2">
            {(Object.keys(categoryLabels) as TipCategory[]).map((category) => {
              const { label, icon: Icon, color } = categoryLabels[category];
              const isActive = activeCategory === category;

              return (
                <Button
                  key={category}
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveCategory(category)}
                  className={cn(
                    "transition-all duration-200",
                    isActive
                      ? "bg-amber-500 hover:bg-amber-600 text-white"
                      : "border-gray-700 text-gray-400 hover:text-white hover:bg-gray-800"
                  )}
                >
                  <Icon className={cn("w-4 h-4 mr-2", isActive ? "text-white" : color)} />
                  {label}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Tips List */}
      <div className="space-y-4">
        <AnimatePresence mode="wait">
          {filteredTips.map((tip, index) => {
            const Icon = tip.icon;
            const isExpanded = expandedTip === tip.id;
            const categoryInfo = categoryLabels[tip.category];

            return (
              <motion.div
                key={tip.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={cn(
                    "bg-gray-900/50 border-gray-800 overflow-hidden transition-all duration-300",
                    isExpanded && "border-amber-500/50 shadow-lg shadow-amber-500/10"
                  )}
                >
                  <CardHeader
                    className="cursor-pointer hover:bg-gray-800/30 transition-colors"
                    onClick={() => setExpandedTip(isExpanded ? null : tip.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className={cn(
                            "w-12 h-12 rounded-xl flex items-center justify-center",
                            "bg-gradient-to-br",
                            tip.category === "writing" && "from-blue-500/20 to-cyan-500/20",
                            tip.category === "photography" && "from-purple-500/20 to-pink-500/20",
                            tip.category === "pricing" && "from-green-500/20 to-emerald-500/20",
                            tip.category === "seo" && "from-orange-500/20 to-amber-500/20"
                          )}
                        >
                          <Icon
                            className={cn(
                              "w-6 h-6",
                              categoryInfo.color
                            )}
                          />
                        </div>
                        <div>
                          <CardTitle className="text-white text-lg">
                            {tip.title}
                          </CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge
                              variant="secondary"
                              className={cn(
                                "text-xs border-0",
                                tip.category === "writing" && "bg-blue-500/20 text-blue-400",
                                tip.category === "photography" && "bg-purple-500/20 text-purple-400",
                                tip.category === "pricing" && "bg-green-500/20 text-green-400",
                                tip.category === "seo" && "bg-orange-500/20 text-orange-400"
                              )}
                            >
                              {categoryInfo.label}
                            </Badge>
                            <span className="text-gray-500 text-sm">
                              {tip.tips.length} wskazówek
                            </span>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-gray-400">
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5" />
                        ) : (
                          <ChevronDown className="w-5 h-5" />
                        )}
                      </Button>
                    </div>
                  </CardHeader>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <CardContent className="pt-0 space-y-6">
                          {/* Introduction */}
                          <p className="text-gray-300 leading-relaxed">
                            {tip.content}
                          </p>

                          {/* Tips */}
                          <div>
                            <h4 className="text-white font-medium flex items-center gap-2 mb-3">
                              <CheckCircle className="w-5 h-5 text-green-500" />
                              Co robić:
                            </h4>
                            <ul className="space-y-2">
                              {tip.tips.map((item, i) => (
                                <motion.li
                                  key={i}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: i * 0.05 }}
                                  className="flex items-start gap-3"
                                >
                                  <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <CheckCircle className="w-3 h-3 text-green-500" />
                                  </div>
                                  <span className="text-gray-300 text-sm">{item}</span>
                                </motion.li>
                              ))}
                            </ul>
                          </div>

                          {/* Mistakes */}
                          <div>
                            <h4 className="text-white font-medium flex items-center gap-2 mb-3">
                              <AlertCircle className="w-5 h-5 text-red-500" />
                              Czego unikać:
                            </h4>
                            <ul className="space-y-2">
                              {tip.mistakes.map((item, i) => (
                                <motion.li
                                  key={i}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: i * 0.05 }}
                                  className="flex items-start gap-3"
                                >
                                  <div className="w-5 h-5 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <AlertCircle className="w-3 h-3 text-red-500" />
                                  </div>
                                  <span className="text-gray-400 text-sm">{item}</span>
                                </motion.li>
                              ))}
                            </ul>
                          </div>

                          {/* Pro Tip */}
                          {tip.proTip && (
                            <div className="p-4 bg-gradient-to-r from-amber-500/10 to-orange-500/10 rounded-lg border border-amber-500/30">
                              <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center flex-shrink-0">
                                  <Star className="w-4 h-4 text-white" />
                                </div>
                                <div>
                                  <h4 className="text-amber-400 font-medium mb-1">
                                    Pro Tip
                                  </h4>
                                  <p className="text-gray-300 text-sm">{tip.proTip}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Quick Stats */}
      <Card className="bg-gray-900/50 border-gray-800 border-l-4 border-l-green-500">
        <CardContent className="p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Eye className="w-5 h-5 text-blue-500" />
              </div>
              <p className="text-2xl font-bold text-white">+40%</p>
              <p className="text-gray-400 text-sm">Więcej wyświetleń</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-green-500/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-2xl font-bold text-white">+25%</p>
              <p className="text-gray-400 text-sm">Wyższa konwersja</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Heart className="w-5 h-5 text-purple-500" />
              </div>
              <p className="text-2xl font-bold text-white">+60%</p>
              <p className="text-gray-400 text-sm">Więcej polubień</p>
            </div>
            <div className="text-center">
              <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-amber-500/20 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-amber-500" />
              </div>
              <p className="text-2xl font-bold text-white">+35%</p>
              <p className="text-gray-400 text-sm">Wyższa marża</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
