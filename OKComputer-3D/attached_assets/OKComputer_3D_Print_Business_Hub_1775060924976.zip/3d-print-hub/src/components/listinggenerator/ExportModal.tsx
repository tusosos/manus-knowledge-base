"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Download,
  FileText,
  Code,
  Copy,
  Check,
  X,
  FileJson,
  FileSpreadsheet,
  ShoppingCart,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProductData, GeneratedContent, MarketingContent, Platform } from "./types";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  productData: ProductData;
  generatedContent: GeneratedContent | null;
  marketingContent: MarketingContent | null;
  platform: Platform;
}

export function ExportModal({
  isOpen,
  onClose,
  productData,
  generatedContent,
  marketingContent,
  platform,
}: ExportModalProps) {
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("text");

  const handleCopy = async (text: string, format: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedFormat(format);
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const generatePlainText = () => {
    if (!generatedContent || !marketingContent) return "";

    return `=== OFERTA ${platform.toUpperCase()} ===

TYTUŁ:
${generatedContent.title}

OPIS:
${generatedContent.description}

SPECJALNE SŁOWA KLUCZOWE:
${generatedContent.keywords.join(", ")}

TAGI:
${generatedContent.tags.join(", ")}

SPECJYLACJA:
${generatedContent.specifications.map((s) => `- ${s.label}: ${s.value}`).join("\n")}

WARUNKI DOSTAWY:
${generatedContent.deliveryTerms}

POLITYKA ZWROTÓW:
${generatedContent.returnPolicy}

--- TEKSTY MARKETINGOWE ---

HEADLINES:
${marketingContent.headlines.map((h, i) => `${i + 1}. ${h}`).join("\n")}

CALL-TO-ACTION:
${marketingContent.callToActions.map((cta, i) => `${i + 1}. ${cta}`).join("\n")}

KORZYŚCI:
${marketingContent.benefits.map((b, i) => `- ${b}`).join("\n")}

UNIKALNE CECHY:
${marketingContent.uniqueSellingPoints.map((usp, i) => `${i + 1}. ${usp}`).join("\n")}
`;
  };

  const generateHTML = () => {
    if (!generatedContent || !marketingContent) return "";

    return `<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${generatedContent.seoTitle}</title>
    <meta name="description" content="${generatedContent.seoDescription}">
</head>
<body>
    <article class="product-listing">
        <header>
            <h1>${generatedContent.title}</h1>
        </header>
        
        <section class="description">
            ${generatedContent.description.split('\n').map(p => `<p>${p}</p>`).join('\n            ')}
        </section>
        
        <section class="specifications">
            <h2>Specyfikacja Techniczna</h2>
            <dl>
                ${generatedContent.specifications.map(s => `
                <dt>${s.label}</dt>
                <dd>${s.value}</dd>
                `).join('')}
            </dl>
        </section>
        
        <section class="delivery">
            <h2>Dostawa i Zwroty</h2>
            <p>${generatedContent.deliveryTerms}</p>
            <p>${generatedContent.returnPolicy}</p>
        </section>
        
        <section class="tags">
            <h2>Tagi</h2>
            ${generatedContent.tags.map(tag => `<span class="tag">${tag}</span>`).join(' ')}
        </section>
    </article>
</body>
</html>`;
  };

  const generateJSON = () => {
    const exportData = {
      platform,
      product: productData,
      content: generatedContent,
      marketing: marketingContent,
      exportedAt: new Date().toISOString(),
    };

    return JSON.stringify(exportData, null, 2);
  };

  const generateCSV = () => {
    if (!generatedContent) return "";

    const headers = ["Field", "Value"];
    const rows = [
      ["Platform", platform],
      ["Title", generatedContent.title],
      ["Description", generatedContent.description.replace(/\n/g, " ")],
      ["Short Description", generatedContent.shortDescription],
      ["SEO Title", generatedContent.seoTitle],
      ["SEO Description", generatedContent.seoDescription],
      ["Tags", generatedContent.tags.join(";")],
      ["Keywords", generatedContent.keywords.join(";")],
      ["Delivery Terms", generatedContent.deliveryTerms],
      ["Return Policy", generatedContent.returnPolicy],
      ...generatedContent.specifications.map((s) => [s.label, s.value]),
    ];

    return [headers.join(";"), ...rows.map((r) => r.join(";"))].join("\n");
  };

  const exportFormats = [
    {
      id: "text",
      label: "Tekst",
      icon: FileText,
      description: "Czysty tekst do wklejenia",
      content: generatePlainText(),
      extension: "txt",
    },
    {
      id: "html",
      label: "HTML",
      icon: Code,
      description: "Formatowana strona HTML",
      content: generateHTML(),
      extension: "html",
    },
    {
      id: "json",
      label: "JSON",
      icon: FileJson,
      description: "Dane w formacie JSON",
      content: generateJSON(),
      extension: "json",
    },
    {
      id: "csv",
      label: "CSV",
      icon: FileSpreadsheet,
      description: "Arkusz kalkulacyjny",
      content: generateCSV(),
      extension: "csv",
    },
  ];

  const handleDownload = (format: (typeof exportFormats)[0]) => {
    const blob = new Blob([format.content], {
      type:
        format.id === "json"
          ? "application/json"
          : format.id === "html"
          ? "text/html"
          : format.id === "csv"
          ? "text/csv"
          : "text/plain",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `oferta-${platform}-${productData.name || "produkt"}.${format.extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden bg-gray-900 border-gray-800">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Download className="w-5 h-5 text-amber-500" />
            Eksport Oferty
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Wybierz format eksportu dla swojej oferty na {platform}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid grid-cols-4 bg-gray-800/50">
            {exportFormats.map((format) => (
              <TabsTrigger
                key={format.id}
                value={format.id}
                className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
              >
                <format.icon className="w-4 h-4 mr-2" />
                {format.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {exportFormats.map((format) => (
            <TabsContent key={format.id} value={format.id} className="mt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-medium">{format.label}</h3>
                    <p className="text-gray-400 text-sm">{format.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy(format.content, format.id)}
                      className={cn(
                        "border-gray-700",
                        copiedFormat === format.id
                          ? "text-green-400 border-green-500/50"
                          : "text-gray-400 hover:text-amber-400"
                      )}
                    >
                      {copiedFormat === format.id ? (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Skopiowano
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Kopiuj
                        </>
                      )}
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleDownload(format)}
                      className="bg-amber-500 hover:bg-amber-600 text-white"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Pobierz .{format.extension}
                    </Button>
                  </div>
                </div>

                <div className="relative">
                  <pre
                    className={cn(
                      "p-4 rounded-lg bg-gray-800/50 text-sm overflow-auto max-h-[400px]",
                      format.id === "text" && "text-gray-300 whitespace-pre-wrap",
                      format.id === "html" && "text-blue-300",
                      format.id === "json" && "text-green-300",
                      format.id === "csv" && "text-orange-300"
                    )}
                  >
                    {format.content}
                  </pre>
                </div>

                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <ShoppingCart className="w-4 h-4" />
                  <span>
                    Gotowe do użycia na{" "}
                    <Badge variant="secondary" className="bg-gray-800 text-gray-400">
                      {platform}
                    </Badge>
                  </span>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
