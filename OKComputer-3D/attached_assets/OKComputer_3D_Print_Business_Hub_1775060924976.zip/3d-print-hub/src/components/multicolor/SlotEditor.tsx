'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, Droplets, Package, Scale, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { AMSSlot, FilamentColor, MaterialType, FILAMENT_COLORS, MATERIALS } from './types';

interface SlotEditorProps {
  slot: AMSSlot | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (slotId: number, color: FilamentColor | null, material: MaterialType, amount: number) => void;
  onClear: (slotId: number) => void;
}

export const SlotEditor: React.FC<SlotEditorProps> = ({
  slot,
  isOpen,
  onClose,
  onSave,
  onClear,
}) => {
  const [selectedColor, setSelectedColor] = useState<FilamentColor | null>(null);
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialType>('PLA');
  const [amount, setAmount] = useState<number>(1000);

  useEffect(() => {
    if (slot) {
      setSelectedColor(slot.color);
      setSelectedMaterial(slot.material);
      setAmount(slot.remainingAmount);
    }
  }, [slot]);

  const handleSave = () => {
    if (slot) {
      onSave(slot.id, selectedColor, selectedMaterial, amount);
      onClose();
    }
  };

  const handleClear = () => {
    if (slot) {
      onClear(slot.id);
      onClose();
    }
  };

  const handleColorSelect = (color: FilamentColor) => {
    setSelectedColor(color);
  };

  if (!slot) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-zinc-950 border-zinc-800 text-zinc-100">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500/20 to-amber-600/20 border border-amber-500/30 flex items-center justify-center">
              <Droplets className="w-4 h-4 text-amber-500" />
            </div>
            <span>Edit Slot {slot.id + 1}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Current Selection Preview */}
          <div className="flex items-center gap-4 p-4 bg-zinc-900/50 rounded-lg border border-zinc-800">
            <div 
              className="w-16 h-16 rounded-lg border-2 border-zinc-700 flex items-center justify-center"
              style={{
                background: selectedColor 
                  ? `linear-gradient(135deg, ${selectedColor.hex} 0%, ${selectedColor.hex}dd 100%)`
                  : '#18181b',
                borderColor: selectedColor ? selectedColor.hex : undefined,
              }}
            >
              {!selectedColor && <span className="text-zinc-600 text-2xl">?</span>}
            </div>
            <div className="flex-1">
              <p className="text-sm text-zinc-500">Selected Color</p>
              <p className="text-lg font-semibold text-zinc-100">
                {selectedColor?.name || 'No color selected'}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                  {selectedMaterial}
                </Badge>
                <Badge variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                  {amount}g
                </Badge>
              </div>
            </div>
          </div>

          {/* Color Selection */}
          <div className="space-y-3">
            <Label className="text-zinc-300 flex items-center gap-2">
              <Package className="w-4 h-4" />
              Select Color
            </Label>
            <ScrollArea className="h-48 rounded-lg border border-zinc-800 bg-zinc-900/30 p-3">
              <div className="grid grid-cols-5 gap-2">
                {FILAMENT_COLORS.map((color) => (
                  <motion.button
                    key={color.id}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleColorSelect(color)}
                    className={`
                      relative p-2 rounded-lg border-2 transition-all
                      ${selectedColor?.id === color.id 
                        ? 'border-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.3)]' 
                        : 'border-zinc-700 hover:border-zinc-600'
                      }
                    `}
                  >
                    <div 
                      className="w-full aspect-square rounded-md mb-1"
                      style={{ backgroundColor: color.hex }}
                    />
                    <p className="text-[10px] text-zinc-400 truncate">{color.name}</p>
                    {selectedColor?.id === color.id && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 rounded-full flex items-center justify-center"
                      >
                        <Check className="w-2.5 h-2.5 text-black" />
                      </motion.div>
                    )}
                  </motion.button>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Material Selection */}
          <div className="space-y-3">
            <Label className="text-zinc-300">Material Type</Label>
            <Select value={selectedMaterial} onValueChange={(v) => setSelectedMaterial(v as MaterialType)}>
              <SelectTrigger className="bg-zinc-900 border-zinc-700 text-zinc-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-700">
                {MATERIALS.map((material) => (
                  <SelectItem 
                    key={material} 
                    value={material}
                    className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                  >
                    <div className="flex items-center gap-2">
                      <div className={`
                        w-2 h-2 rounded-full
                        ${material === 'PLA' && 'bg-green-500'}
                        ${material === 'PETG' && 'bg-blue-500'}
                        ${material === 'ABS' && 'bg-red-500'}
                        ${material === 'TPU' && 'bg-purple-500'}
                        ${material === 'ASA' && 'bg-amber-500'}
                        ${material === 'PC' && 'bg-cyan-500'}
                        ${material === 'PA' && 'bg-pink-500'}
                        ${material === 'NYLON' && 'bg-indigo-500'}
                      `} />
                      {material}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Amount Selection */}
          <div className="space-y-3">
            <Label className="text-zinc-300 flex items-center gap-2">
              <Scale className="w-4 h-4" />
              Remaining Amount
            </Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[amount]}
                onValueChange={(v) => setAmount(v[0])}
                max={1000}
                min={0}
                step={10}
                className="flex-1"
              />
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-20 bg-zinc-900 border-zinc-700 text-zinc-100 text-center"
                  min={0}
                  max={1000}
                />
                <span className="text-zinc-500 text-sm">g</span>
              </div>
            </div>
            <div className="flex justify-between text-xs text-zinc-500">
              <span>0g</span>
              <span>500g</span>
              <span>1000g</span>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          {slot.color && (
            <Button
              variant="outline"
              onClick={handleClear}
              className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-400"
            >
              <X className="w-4 h-4 mr-2" />
              Clear Slot
            </Button>
          )}
          <Button
            variant="outline"
            onClick={onClose}
            className="border-zinc-700 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={!selectedColor}
            className="bg-amber-500 hover:bg-amber-600 text-black font-medium"
          >
            <Check className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SlotEditor;
