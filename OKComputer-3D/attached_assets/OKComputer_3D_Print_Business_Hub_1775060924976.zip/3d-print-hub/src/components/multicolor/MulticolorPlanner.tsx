'use client';

import React, { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Printer, 
  Save, 
  RotateCcw, 
  Download,
  Upload,
  Settings,
  Info
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';

import { AMSVisualization } from './AMSVisualization';
import { SlotEditor } from './SlotEditor';
import { ProjectPlanner } from './ProjectPlanner';
import { PurgeWasteCalculator } from './PurgeWasteCalculator';
import { ColorSuggestions } from './ColorSuggestions';
import { ModeToggle } from './ModeToggle';

import { 
  AMSSlot, 
  AMSMode, 
  MulticolorProject, 
  FilamentColor, 
  MaterialType,
  SAMPLE_PROJECTS,
  FILAMENT_COLORS,
} from './types';

// Initial AMS slots state
const createInitialSlots = (): AMSSlot[] => {
  return Array.from({ length: 8 }, (_, i) => ({
    id: i,
    color: i < 4 ? FILAMENT_COLORS[i] : null,
    material: 'PLA',
    remainingAmount: i < 4 ? 800 : 0,
    isActive: i === 0,
  }));
};

export const MulticolorPlanner: React.FC = () => {
  // State
  const [amsSlots, setAmsSlots] = useState<AMSSlot[]>(createInitialSlots());
  const [mode, setMode] = useState<AMSMode>('dual');
  const [editingSlot, setEditingSlot] = useState<AMSSlot | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<MulticolorProject | null>(null);
  const [colorSequence, setColorSequence] = useState<FilamentColor[]>([]);
  const [slotAssignments, setSlotAssignments] = useState<Map<number, FilamentColor>>(new Map());

  // Derived state
  const visibleSlots = useMemo(() => {
    return mode === 'single' ? amsSlots.slice(0, 4) : amsSlots;
  }, [amsSlots, mode]);

  const activeProjectColors = useMemo(() => {
    return selectedProject?.colorPalette.map(c => c.id) || [];
  }, [selectedProject]);

  // Handlers
  const handleSlotClick = useCallback((slotId: number) => {
    const slot = amsSlots.find(s => s.id === slotId);
    if (slot) {
      setEditingSlot(slot);
      setIsEditorOpen(true);
    }
  }, [amsSlots]);

  const handleSaveSlot = useCallback((
    slotId: number, 
    color: FilamentColor | null, 
    material: MaterialType, 
    amount: number
  ) => {
    setAmsSlots(prev => prev.map(slot => 
      slot.id === slotId 
        ? { ...slot, color, material, remainingAmount: amount }
        : slot
    ));
    toast.success(`Slot ${slotId + 1} updated successfully`);
  }, []);

  const handleClearSlot = useCallback((slotId: number) => {
    setAmsSlots(prev => prev.map(slot => 
      slot.id === slotId 
        ? { ...slot, color: null, remainingAmount: 0, isActive: false }
        : slot
    ));
    toast.info(`Slot ${slotId + 1} cleared`);
  }, []);

  const handleModeChange = useCallback((newMode: AMSMode) => {
    setMode(newMode);
    toast.info(`Switched to ${newMode === 'single' ? 'Single' : 'Dual'} AMS mode`);
  }, []);

  const handleProjectSelect = useCallback((project: MulticolorProject | null) => {
    setSelectedProject(project);
    if (project) {
      setColorSequence(project.colorPalette);
      toast.success(`Project "${project.name}" selected`);
    } else {
      setColorSequence([]);
      setSlotAssignments(new Map());
    }
  }, []);

  const handleAssignColors = useCallback((
    project: MulticolorProject, 
    assignments: Map<number, FilamentColor>
  ) => {
    setSlotAssignments(assignments);
    
    // Update active status for assigned slots
    setAmsSlots(prev => prev.map(slot => ({
      ...slot,
      isActive: assignments.has(slot.id),
    })));
  }, []);

  const handleApplyCombination = useCallback((colors: FilamentColor[]) => {
    // Find empty slots and fill them with the combination colors
    const emptySlots = amsSlots.filter(s => !s.color).map(s => s.id);
    const slotsToUpdate = Math.min(emptySlots.length, colors.length);
    
    if (slotsToUpdate === 0) {
      toast.warning('No empty slots available. Clear some slots first.');
      return;
    }

    setAmsSlots(prev => prev.map(slot => {
      const colorIndex = emptySlots.indexOf(slot.id);
      if (colorIndex !== -1 && colorIndex < colors.length) {
        return {
          ...slot,
          color: colors[colorIndex],
          material: 'PLA',
          remainingAmount: 1000,
        };
      }
      return slot;
    }));

    toast.success(`Applied ${slotsToUpdate} colors from combination`);
  }, [amsSlots]);

  const handleSaveConfiguration = useCallback(() => {
    const config = {
      mode,
      slots: amsSlots,
      timestamp: new Date().toISOString(),
    };
    localStorage.setItem('ams-config', JSON.stringify(config));
    toast.success('Configuration saved successfully');
  }, [mode, amsSlots]);

  const handleLoadConfiguration = useCallback(() => {
    const saved = localStorage.getItem('ams-config');
    if (saved) {
      try {
        const config = JSON.parse(saved);
        setMode(config.mode);
        setAmsSlots(config.slots);
        toast.success('Configuration loaded successfully');
      } catch {
        toast.error('Failed to load configuration');
      }
    } else {
      toast.info('No saved configuration found');
    }
  }, []);

  const handleReset = useCallback(() => {
    setAmsSlots(createInitialSlots());
    setSelectedProject(null);
    setColorSequence([]);
    setSlotAssignments(new Map());
    toast.info('Configuration reset to default');
  }, []);

  const handleExport = useCallback(() => {
    const config = {
      mode,
      slots: amsSlots,
      project: selectedProject,
      timestamp: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ams-config-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Configuration exported');
  }, [mode, amsSlots, selectedProject]);

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-black text-zinc-100 p-4 md:p-6">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
                <Printer className="w-7 h-7 text-black" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-zinc-100">
                  Multicolor Planner
                </h1>
                <p className="text-sm text-zinc-500">
                  Bambu Lab H2D • AMS Configuration
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSaveConfiguration}
                    className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Save configuration</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLoadConfiguration}
                    className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Load
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Load saved configuration</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleExport}
                    className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Export as JSON</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleReset}
                    className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Reset
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Reset to default</TooltipContent>
              </Tooltip>
            </div>
          </div>

          {/* Status Bar */}
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Badge variant="outline" className="border-zinc-700 text-zinc-400">
              <Settings className="w-3 h-3 mr-1" />
              {mode === 'dual' ? '8-Color' : '4-Color'} Mode
            </Badge>
            <Badge variant="outline" className="border-zinc-700 text-zinc-400">
              {amsSlots.filter(s => s.color).length} Slots Loaded
            </Badge>
            <Badge variant="outline" className="border-zinc-700 text-zinc-400">
              {amsSlots.reduce((acc, s) => acc + s.remainingAmount, 0)}g Total
            </Badge>
            {selectedProject && (
              <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                Project: {selectedProject.name}
              </Badge>
            )}
          </div>
        </motion.header>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - AMS & Mode */}
          <div className="lg:col-span-2 space-y-6">
            {/* AMS Mode Toggle */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <ModeToggle mode={mode} onModeChange={handleModeChange} />
            </motion.div>

            {/* AMS Visualization */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <AMSVisualization
                slots={amsSlots}
                mode={mode}
                onSlotClick={handleSlotClick}
                activeProjectColors={activeProjectColors}
              />
            </motion.div>

            {/* Project Planner */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <ProjectPlanner
                projects={SAMPLE_PROJECTS}
                amsSlots={amsSlots}
                onProjectSelect={handleProjectSelect}
                selectedProject={selectedProject}
                onAssignColors={handleAssignColors}
              />
            </motion.div>
          </div>

          {/* Right Column - Calculator & Suggestions */}
          <div className="space-y-6">
            {/* Purge Waste Calculator */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <PurgeWasteCalculator
                selectedProject={selectedProject}
                amsSlots={amsSlots}
                colorSequence={colorSequence}
              />
            </motion.div>

            {/* Color Suggestions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <ColorSuggestions
                onApplyCombination={handleApplyCombination}
                amsSlots={amsSlots}
              />
            </motion.div>
          </div>
        </div>

        {/* Info Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 pt-6 border-t border-zinc-800"
        >
          <div className="flex items-center justify-between text-sm text-zinc-500">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4" />
              <span>
                Compatible with Bambu Lab H2D and AMS units
              </span>
            </div>
            <div>
              3D Print Business Hub • Multicolor Planner v1.0
            </div>
          </div>
        </motion.footer>

        {/* Slot Editor Dialog */}
        <SlotEditor
          slot={editingSlot}
          isOpen={isEditorOpen}
          onClose={() => {
            setIsEditorOpen(false);
            setEditingSlot(null);
          }}
          onSave={handleSaveSlot}
          onClear={handleClearSlot}
        />
      </div>
    </TooltipProvider>
  );
};

export default MulticolorPlanner;
