'use client';

import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Trash2, 
  TrendingDown, 
  AlertTriangle, 
  Lightbulb,
  ArrowRight,
  RotateCcw,
  Calculator
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { MulticolorProject, AMSSlot, FilamentColor } from './types';

interface PurgeWasteCalculatorProps {
  selectedProject: MulticolorProject | null;
  amsSlots: AMSSlot[];
  colorSequence: FilamentColor[];
}

interface PurgeCalculation {
  totalWaste: number;
  colorChanges: number;
  purgePerChange: number;
  estimatedTime: number;
  wastePercentage: number;
  suggestions: string[];
  colorTransitions: { from: string; to: string; waste: number }[];
}

// Purge volumes in mm³ for different color transitions (approximate)
const PURGE_VOLUMES: Record<string, number> = {
  'light-to-dark': 100,
  'dark-to-light': 280,
  'similar': 50,
  'default': 150,
};

// Density of PLA in g/cm³
const FILAMENT_DENSITY = 1.24;

const getColorBrightness = (hex: string): number => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return (r * 299 + g * 587 + b * 114) / 1000;
};

const getPurgeVolume = (fromColor: FilamentColor, toColor: FilamentColor): number => {
  const fromBrightness = getColorBrightness(fromColor.hex);
  const toBrightness = getColorBrightness(toColor.hex);
  const brightnessDiff = Math.abs(fromBrightness - toBrightness);
  
  if (brightnessDiff < 50) return PURGE_VOLUMES.similar;
  if (fromBrightness > toBrightness) return PURGE_VOLUMES['dark-to-light'];
  return PURGE_VOLUMES['light-to-dark'];
};

const mm3ToGrams = (mm3: number): number => {
  return (mm3 / 1000) * FILAMENT_DENSITY;
};

export const PurgeWasteCalculator: React.FC<PurgeWasteCalculatorProps> = ({
  selectedProject,
  amsSlots,
  colorSequence,
}) => {
  const calculation = useMemo<PurgeCalculation | null>(() => {
    if (!selectedProject || colorSequence.length < 2) return null;

    const transitions: { from: string; to: string; waste: number }[] = [];
    let totalWasteMm3 = 0;

    for (let i = 0; i < colorSequence.length - 1; i++) {
      const fromColor = colorSequence[i];
      const toColor = colorSequence[i + 1];
      const purgeVolume = getPurgeVolume(fromColor, toColor);
      
      transitions.push({
        from: fromColor.name,
        to: toColor.name,
        waste: mm3ToGrams(purgeVolume),
      });
      
      totalWasteMm3 += purgeVolume;
    }

    const totalWaste = mm3ToGrams(totalWasteMm3);
    const wastePercentage = (totalWaste / selectedProject.filamentUsage) * 100;
    
    // Estimate time (purge takes ~10-30s per change depending on volume)
    const estimatedTime = transitions.length * 20;

    // Generate suggestions
    const suggestions: string[] = [];
    
    // Check for high waste
    if (wastePercentage > 20) {
      suggestions.push('Consider reducing the number of color changes');
    }
    
    // Check for dark-to-light transitions
    const darkToLightCount = transitions.filter(t => t.waste > 0.3).length;
    if (darkToLightCount > 0) {
      suggestions.push(`Reorder colors to minimize dark-to-light transitions (${darkToLightCount} found)`);
    }
    
    // Check for similar colors
    const similarTransitions = transitions.filter(t => t.waste < 0.1).length;
    if (similarTransitions > 0) {
      suggestions.push('Some color transitions are very similar - consider merging them');
    }
    
    // General optimization
    if (transitions.length > 5) {
      suggestions.push('Use "wipe into infill" feature to reduce waste');
    }
    
    if (suggestions.length === 0) {
      suggestions.push('Color sequence looks optimized!');
    }

    return {
      totalWaste,
      colorChanges: transitions.length,
      purgePerChange: totalWaste / transitions.length,
      estimatedTime,
      wastePercentage,
      suggestions,
      colorTransitions: transitions,
    };
  }, [selectedProject, colorSequence]);

  if (!selectedProject) {
    return (
      <Card className="bg-zinc-950 border-zinc-800 p-6">
        <div className="text-center py-8">
          <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center mx-auto mb-4">
            <Calculator className="w-8 h-8 text-zinc-600" />
          </div>
          <h3 className="text-lg font-medium text-zinc-400 mb-2">No Project Selected</h3>
          <p className="text-sm text-zinc-600">
            Select a project from the planner to calculate purge waste
          </p>
        </div>
      </Card>
    );
  }

  if (!calculation) {
    return (
      <Card className="bg-zinc-950 border-zinc-800 p-6">
        <div className="text-center py-8">
          <div className="w-16 h-16 rounded-full bg-zinc-900 flex items-center justify-center mx-auto mb-4">
            <RotateCcw className="w-8 h-8 text-zinc-600 animate-spin" />
          </div>
          <h3 className="text-lg font-medium text-zinc-400">Calculating...</h3>
        </div>
      </Card>
    );
  }

  const getWasteStatus = (percentage: number): { label: string; color: string } => {
    if (percentage < 10) return { label: 'Excellent', color: 'text-green-400' };
    if (percentage < 20) return { label: 'Good', color: 'text-amber-400' };
    return { label: 'High', color: 'text-red-400' };
  };

  const wasteStatus = getWasteStatus(calculation.wastePercentage);

  return (
    <TooltipProvider>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-zinc-100">Purge Waste Calculator</h3>
              <p className="text-xs text-zinc-500">
                For: {selectedProject.name}
              </p>
            </div>
          </div>
          <Badge 
            variant="outline" 
            className={`border-zinc-700 ${wasteStatus.color}`}
          >
            {wasteStatus.label}
          </Badge>
        </div>

        {/* Main Stats */}
        <Card className="bg-zinc-900/50 border-zinc-800 p-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-zinc-100">
                {calculation.totalWaste.toFixed(1)}g
              </p>
              <p className="text-xs text-zinc-500">Total Waste</p>
            </div>
            <div className="text-center border-x border-zinc-800">
              <p className="text-2xl font-bold text-zinc-100">
                {calculation.colorChanges}
              </p>
              <p className="text-xs text-zinc-500">Color Changes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-zinc-100">
                {calculation.estimatedTime}s
              </p>
              <p className="text-xs text-zinc-500">Extra Time</p>
            </div>
          </div>
        </Card>

        {/* Waste Percentage */}
        <Card className="bg-zinc-900/50 border-zinc-800 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-zinc-400">Waste Percentage</span>
            <span className={`text-sm font-medium ${wasteStatus.color}`}>
              {calculation.wastePercentage.toFixed(1)}%
            </span>
          </div>
          <Progress 
            value={Math.min(calculation.wastePercentage, 100)} 
            className="h-2"
          />
          <div className="flex justify-between mt-1 text-xs text-zinc-600">
            <span>0%</span>
            <span>Project: {selectedProject.filamentUsage}g</span>
            <span>50%</span>
          </div>
        </Card>

        {/* Color Transitions */}
        <Card className="bg-zinc-900/50 border-zinc-800 p-4">
          <h4 className="text-sm font-medium text-zinc-300 mb-3 flex items-center gap-2">
            <ArrowRight className="w-4 h-4" />
            Color Transitions
          </h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {calculation.colorTransitions.map((transition, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between py-2 px-3 rounded-lg bg-zinc-950/50"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-400">{transition.from}</span>
                  <ArrowRight className="w-3 h-3 text-zinc-600" />
                  <span className="text-xs text-zinc-400">{transition.to}</span>
                </div>
                <Tooltip>
                  <TooltipTrigger>
                    <Badge 
                      variant="outline" 
                      className={`
                        text-xs
                        ${transition.waste > 0.3 
                          ? 'border-red-500/30 text-red-400' 
                          : transition.waste < 0.1 
                            ? 'border-green-500/30 text-green-400'
                            : 'border-amber-500/30 text-amber-400'
                        }
                      `}
                    >
                      {transition.waste.toFixed(1)}g
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent className="bg-zinc-900 border-zinc-700">
                    <p className="text-xs text-zinc-300">
                      {transition.waste > 0.3 
                        ? 'High waste - dark to light transition' 
                        : transition.waste < 0.1 
                          ? 'Low waste - similar colors'
                          : 'Medium waste'
                      }
                    </p>
                  </TooltipContent>
                </Tooltip>
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Suggestions */}
        <Card className="bg-zinc-900/50 border-zinc-800 p-4">
          <h4 className="text-sm font-medium text-zinc-300 mb-3 flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            Optimization Suggestions
          </h4>
          <div className="space-y-2">
            {calculation.suggestions.map((suggestion, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-start gap-2 py-2"
              >
                {suggestion.includes('optimized') ? (
                  <TrendingDown className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
                )}
                <span className="text-sm text-zinc-400">{suggestion}</span>
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Cost Estimate */}
        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/30 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-zinc-400">Estimated Cost Impact</p>
              <p className="text-xs text-zinc-500">
                Based on average PLA price
              </p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-amber-400">
                ~€{(calculation.totalWaste * 0.025).toFixed(2)}
              </p>
              <p className="text-xs text-zinc-500">
                {calculation.totalWaste.toFixed(1)}g waste
              </p>
            </div>
          </div>
        </Card>
      </div>
    </TooltipProvider>
  );
};

export default PurgeWasteCalculator;
