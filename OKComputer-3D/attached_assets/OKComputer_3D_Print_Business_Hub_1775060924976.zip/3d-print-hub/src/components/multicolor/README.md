# Multicolor Planner for Bambu Lab H2D

Kompleksowe narzędzie do planowania wydruków wielokolorowych dla drukarki Bambu Lab H2D z systemem AMS (Automatic Material System).

## Funkcjonalności

### 1. Wizualizacja AMS
- 8 slotów w rzędzie (jak w rzeczywistym AMS)
- Podgląd koloru filamentu
- Typ materiału (PLA/PETG/ABS/TPU/ASA/PC/PA/NYLON)
- Pozostała ilość (g)
- Status aktywności (LED)
- Wskaźniki kolorów używanych w projekcie

### 2. Zarządzanie Slotami
- Kliknij slot aby edytować
- Paleta 25+ kolorów
- Wybór materiału
- Suwak ilości (0-1000g)
- Możliwość wyczyszczenia slotu

### 3. Planner Projektów
- Lista projektów multicolor
- Drag & drop do plannera
- Automatyczne przypisanie kolorów do slotów
- Podgląd wymaganych kolorów
- Kompatybilność z dostępnymi kolorami

### 4. Kalkulacja Purge Waste
- Obliczanie straty filamentu przy zmianach kolorów
- Szczegółowe przejścia między kolorami
- Szacowany czas dodatkowy
- Sugestie optymalizacji
- Szacowany koszt strat

### 5. Sugestie Kombinacji
- Popularne palety kolorów
- Sezonowe propozycje
- Dostępność w AMS
- Tagi i kategorie
- Możliwość zastosowania kombinacji

### 6. Tryb Single/Dual AMS
- Przełącznik 4/8 kolorów
- Wizualizacja dla obu trybów
- Opis funkcjonalności
- Zalecane ustawienia

## Komponenty

### AMSVisualization
```tsx
<AMSVisualization
  slots={amsSlots}
  mode="dual"
  onSlotClick={(slotId) => {}}
  activeProjectColors={['red', 'blue']}
/>
```

### SlotEditor
```tsx
<SlotEditor
  slot={editingSlot}
  isOpen={isEditorOpen}
  onClose={() => {}}
  onSave={(slotId, color, material, amount) => {}}
  onClear={(slotId) => {}}
/>
```

### ProjectPlanner
```tsx
<ProjectPlanner
  projects={SAMPLE_PROJECTS}
  amsSlots={amsSlots}
  onProjectSelect={(project) => {}}
  selectedProject={selectedProject}
  onAssignColors={(project, assignments) => {}}
/>
```

### PurgeWasteCalculator
```tsx
<PurgeWasteCalculator
  selectedProject={selectedProject}
  amsSlots={amsSlots}
  colorSequence={colorSequence}
/>
```

### ColorSuggestions
```tsx
<ColorSuggestions
  onApplyCombination={(colors) => {}}
  amsSlots={amsSlots}
/>
```

### ModeToggle
```tsx
<ModeToggle
  mode="dual"
  onModeChange={(mode) => {}}
/>
```

### MulticolorPlanner (Main)
```tsx
<MulticolorPlanner />
```

## Typy

```typescript
type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'ASA' | 'PC' | 'PA' | 'NYLON';

interface FilamentColor {
  id: string;
  name: string;
  hex: string;
  brand?: string;
}

interface AMSSlot {
  id: number;
  color: FilamentColor | null;
  material: MaterialType;
  remainingAmount: number;
  isActive: boolean;
}

interface MulticolorProject {
  id: string;
  name: string;
  description: string;
  requiredColors: number;
  colorPalette: FilamentColor[];
  estimatedPrintTime: number;
  filamentUsage: number;
  category: string;
  popularity: number;
}

type AMSMode = 'single' | 'dual';
```

## Kolory Dostępne

- Black, White, Gray, Silver
- Red, Dark Red, Orange, Amber, Yellow
- Lime, Green, Dark Green, Teal, Cyan
- Blue, Dark Blue, Indigo, Purple, Magenta
- Pink, Rose, Brown, Beige, Gold, Copper

## Materiały

- PLA (biodegradable, easy to print)
- PETG (durable, chemical resistant)
- ABS (heat resistant, strong)
- TPU (flexible, elastic)
- ASA (weather resistant)
- PC (polycarbonate, very strong)
- PA (polyamide, tough)
- NYLON (flexible, durable)

## Projektów Przykładowych

1. Dragon Multicolor (4 kolory, 8h)
2. Vase Art Deco (3 kolory, 6h)
3. Robot Keychain (6 kolorów, 4h)
4. Mandelbrot Lamp (2 kolory, 10h)
5. Pokemon Collection (5 kolorów, 12h)

## Kombinacje Kolorów

1. Classic Contrast (Black & White)
2. Ocean Breeze (Blue tones)
3. Autumn Forest (Warm tones)
4. Cyberpunk Neon (Neon on dark)
5. Christmas Spirit (Holiday colors)
6. Pastel Dreams (Soft pastels)
7. Industrial Metal (Metallic)
8. Sunset Gradient (Warm gradients)

## Użycie

```tsx
import { MulticolorPlanner } from '@/components/multicolor';

export default function Page() {
  return <MulticolorPlanner />;
}
```

## Wymagane Zależności

- React 18+
- TypeScript
- Tailwind CSS
- shadcn/ui (Card, Dialog, Select, Button, Tooltip, Badge, Progress, Slider, Tabs, ScrollArea)
- Framer Motion
- Lucide React
- Sonner (toast notifications)

## Styl

- Dark theme (domyślnie)
- Industrial aesthetic
- Amber accent color
- Subtelne animacje mechaniczne
- WCAG 2.1 AA accessibility
