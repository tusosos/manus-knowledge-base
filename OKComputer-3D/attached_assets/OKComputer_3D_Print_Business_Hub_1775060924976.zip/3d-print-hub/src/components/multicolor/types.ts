export type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'ASA' | 'PC' | 'PA' | 'NYLON';

export interface FilamentColor {
  id: string;
  name: string;
  hex: string;
  brand?: string;
}

export interface AMSSlot {
  id: number;
  color: FilamentColor | null;
  material: MaterialType;
  remainingAmount: number; // in grams
  isActive: boolean;
}

export interface MulticolorProject {
  id: string;
  name: string;
  description: string;
  requiredColors: number;
  colorPalette: FilamentColor[];
  estimatedPrintTime: number; // in minutes
  filamentUsage: number; // in grams
  imageUrl?: string;
  category: string;
  popularity: number; // 1-10
}

export interface PurgeCalculation {
  totalWaste: number;
  colorChanges: number;
  estimatedTime: number;
  suggestions: string[];
}

export interface ColorCombination {
  id: string;
  name: string;
  colors: FilamentColor[];
  description: string;
  season: 'all' | 'spring' | 'summer' | 'autumn' | 'winter' | 'holiday';
  popularity: number;
  tags: string[];
}

export type AMSMode = 'single' | 'dual';

export const MATERIALS: MaterialType[] = ['PLA', 'PETG', 'ABS', 'TPU', 'ASA', 'PC', 'PA', 'NYLON'];

export const FILAMENT_COLORS: FilamentColor[] = [
  { id: 'black', name: 'Black', hex: '#1a1a1a' },
  { id: 'white', name: 'White', hex: '#f5f5f5' },
  { id: 'gray', name: 'Gray', hex: '#6b7280' },
  { id: 'silver', name: 'Silver', hex: '#c0c0c0' },
  { id: 'red', name: 'Red', hex: '#dc2626' },
  { id: 'dark-red', name: 'Dark Red', hex: '#991b1b' },
  { id: 'orange', name: 'Orange', hex: '#f97316' },
  { id: 'amber', name: 'Amber', hex: '#f59e0b' },
  { id: 'yellow', name: 'Yellow', hex: '#fbbf24' },
  { id: 'lime', name: 'Lime', hex: '#84cc16' },
  { id: 'green', name: 'Green', hex: '#22c55e' },
  { id: 'dark-green', name: 'Dark Green', hex: '#166534' },
  { id: 'teal', name: 'Teal', hex: '#14b8a6' },
  { id: 'cyan', name: 'Cyan', hex: '#06b6d4' },
  { id: 'blue', name: 'Blue', hex: '#3b82f6' },
  { id: 'dark-blue', name: 'Dark Blue', hex: '#1e3a8a' },
  { id: 'indigo', name: 'Indigo', hex: '#6366f1' },
  { id: 'purple', name: 'Purple', hex: '#9333ea' },
  { id: 'magenta', name: 'Magenta', hex: '#d946ef' },
  { id: 'pink', name: 'Pink', hex: '#ec4899' },
  { id: 'rose', name: 'Rose', hex: '#fb7185' },
  { id: 'brown', name: 'Brown', hex: '#92400e' },
  { id: 'beige', name: 'Beige', hex: '#d4c4a8' },
  { id: 'gold', name: 'Gold', hex: '#ffd700' },
  { id: 'copper', name: 'Copper', hex: '#b87333' },
];

export const SAMPLE_PROJECTS: MulticolorProject[] = [
  {
    id: '1',
    name: 'Dragon Multicolor',
    description: 'Smok z gradientowymi skrzydłami i szczegółowymi łuskami',
    requiredColors: 4,
    colorPalette: [
      FILAMENT_COLORS[4], // Red
      FILAMENT_COLORS[10], // Green
      FILAMENT_COLORS[0], // Black
      FILAMENT_COLORS[1], // White
    ],
    estimatedPrintTime: 480,
    filamentUsage: 250,
    category: 'Figurki',
    popularity: 9,
  },
  {
    id: '2',
    name: 'Vase Art Deco',
    description: 'Wazon w stylu Art Deco z geometrycznym wzorem',
    requiredColors: 3,
    colorPalette: [
      FILAMENT_COLORS[1], // White
      FILAMENT_COLORS[3], // Silver
      FILAMENT_COLORS[14], // Blue
    ],
    estimatedPrintTime: 360,
    filamentUsage: 180,
    category: 'Dekoracje',
    popularity: 8,
  },
  {
    id: '3',
    name: 'Robot Keychain',
    description: 'Zestaw 8 breloków robotów w różnych kolorach',
    requiredColors: 6,
    colorPalette: [
      FILAMENT_COLORS[0], // Black
      FILAMENT_COLORS[1], // White
      FILAMENT_COLORS[4], // Red
      FILAMENT_COLORS[10], // Green
      FILAMENT_COLORS[14], // Blue
      FILAMENT_COLORS[16], // Yellow
    ],
    estimatedPrintTime: 240,
    filamentUsage: 120,
    category: 'Akcesoria',
    popularity: 7,
  },
  {
    id: '4',
    name: 'Mandelbrot Lamp',
    description: 'Lampa z fraktalnym wzorem Mandelbrota',
    requiredColors: 2,
    colorPalette: [
      FILAMENT_COLORS[1], // White
      FILAMENT_COLORS[14], // Blue
    ],
    estimatedPrintTime: 600,
    filamentUsage: 320,
    category: 'Oświetlenie',
    popularity: 6,
  },
  {
    id: '5',
    name: 'Pokemon Collection',
    description: 'Zestaw figurek Pokemonów (Pikachu, Charmander, Squirtle)',
    requiredColors: 5,
    colorPalette: [
      FILAMENT_COLORS[16], // Yellow
      FILAMENT_COLORS[4], // Red
      FILAMENT_COLORS[6], // Orange
      FILAMENT_COLORS[14], // Blue
      FILAMENT_COLORS[10], // Green
    ],
    estimatedPrintTime: 720,
    filamentUsage: 400,
    category: 'Figurki',
    popularity: 10,
  },
];

export const COLOR_COMBINATIONS: ColorCombination[] = [
  {
    id: '1',
    name: 'Classic Contrast',
    colors: [FILAMENT_COLORS[0], FILAMENT_COLORS[1]],
    description: 'Czasless black & white - zawsze się sprzedaje',
    season: 'all',
    popularity: 10,
    tags: ['minimalist', 'elegant', 'classic'],
  },
  {
    id: '2',
    name: 'Ocean Breeze',
    colors: [FILAMENT_COLORS[14], FILAMENT_COLORS[13], FILAMENT_COLORS[1]],
    description: 'Odcienie oceanu - idealne na lato',
    season: 'summer',
    popularity: 8,
    tags: ['fresh', 'calm', 'nature'],
  },
  {
    id: '3',
    name: 'Autumn Forest',
    colors: [FILAMENT_COLORS[6], FILAMENT_COLORS[21], FILAMENT_COLORS[4]],
    description: 'Ciepłe barwy jesieni',
    season: 'autumn',
    popularity: 9,
    tags: ['warm', 'cozy', 'seasonal'],
  },
  {
    id: '4',
    name: 'Cyberpunk Neon',
    colors: [FILAMENT_COLORS[0], FILAMENT_COLORS[17], FILAMENT_COLORS[18], FILAMENT_COLORS[13]],
    description: 'Neonowe akcenty na ciemnym tle',
    season: 'all',
    popularity: 9,
    tags: ['gaming', 'modern', 'tech'],
  },
  {
    id: '5',
    name: 'Christmas Spirit',
    colors: [FILAMENT_COLORS[10], FILAMENT_COLORS[4], FILAMENT_COLORS[1], FILAMENT_COLORS[16]],
    description: 'Klasyczne kolory świąteczne',
    season: 'holiday',
    popularity: 10,
    tags: ['festive', 'seasonal', 'popular'],
  },
  {
    id: '6',
    name: 'Pastel Dreams',
    colors: [FILAMENT_COLORS[19], FILAMENT_COLORS[20], FILAMENT_COLORS[17], FILAMENT_COLORS[1]],
    description: 'Delikatne pastele dla subtelnych projektów',
    season: 'spring',
    popularity: 7,
    tags: ['soft', 'feminine', 'gentle'],
  },
  {
    id: '7',
    name: 'Industrial Metal',
    colors: [FILAMENT_COLORS[2], FILAMENT_COLORS[3], FILAMENT_COLORS[0]],
    description: 'Metaliczne wykończenie w stylu industrialnym',
    season: 'all',
    popularity: 8,
    tags: ['modern', 'professional', 'sleek'],
  },
  {
    id: '8',
    name: 'Sunset Gradient',
    colors: [FILAMENT_COLORS[4], FILAMENT_COLORS[6], FILAMENT_COLORS[16]],
    description: 'Ciepłe przejścia jak przy zachodzie słońca',
    season: 'all',
    popularity: 8,
    tags: ['artistic', 'warm', 'gradient'],
  },
];
