'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  TrendingUp, 
  Calendar, 
  Tag,
  Check,
  Plus,
  Filter,
  ShoppingCart
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ColorCombination, COLOR_COMBINATIONS, FilamentColor } from './types';

interface ColorSuggestionsProps {
  onApplyCombination: (colors: FilamentColor[]) => void;
  amsSlots: { id: number; color: FilamentColor | null }[];
}

type SeasonFilter = 'all' | 'spring' | 'summer' | 'autumn' | 'winter' | 'holiday';

const seasonLabels: Record<SeasonFilter, string> = {
  all: 'All Seasons',
  spring: 'Spring',
  summer: 'Summer',
  autumn: 'Autumn',
  winter: 'Winter',
  holiday: 'Holiday',
};

const seasonIcons: Record<SeasonFilter, string> = {
  all: '🌈',
  spring: '🌸',
  summer: '☀️',
  autumn: '🍂',
  winter: '❄️',
  holiday: '🎄',
};

export const ColorSuggestions: React.FC<ColorSuggestionsProps> = ({
  onApplyCombination,
  amsSlots,
}) => {
  const [selectedSeason, setSelectedSeason] = useState<SeasonFilter>('all');
  const [expandedCombo, setExpandedCombo] = useState<string | null>(null);

  const filteredCombinations = COLOR_COMBINATIONS.filter(
    (combo) => selectedSeason === 'all' || combo.season === selectedSeason || combo.season === 'all'
  ).sort((a, b) => b.popularity - a.popularity);

  const getColorAvailability = (color: FilamentColor): boolean => {
    return amsSlots.some(slot => slot.color?.id === color.id);
  };

  const getCombinationAvailability = (combo: ColorCombination): {
    available: number;
    total: number;
    percentage: number;
  } => {
    const available = combo.colors.filter(color => getColorAvailability(color)).length;
    return {
      available,
      total: combo.colors.length,
      percentage: (available / combo.colors.length) * 100,
    };
  };

  return (
    <TooltipProvider>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-zinc-100">Color Combinations</h3>
              <p className="text-xs text-zinc-500">
                Popular & trending palettes
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-zinc-500" />
            <Select 
              value={selectedSeason} 
              onValueChange={(v) => setSelectedSeason(v as SeasonFilter)}
            >
              <SelectTrigger className="w-32 bg-zinc-900 border-zinc-700 text-zinc-100 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-700">
                {(Object.keys(seasonLabels) as SeasonFilter[]).map((season) => (
                  <SelectItem 
                    key={season} 
                    value={season}
                    className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                  >
                    <span className="flex items-center gap-2">
                      <span>{seasonIcons[season]}</span>
                      <span className="text-xs">{seasonLabels[season]}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Trending Badge */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <Badge variant="outline" className="border-green-500/30 text-green-400 whitespace-nowrap">
            <TrendingUp className="w-3 h-3 mr-1" />
            Best Sellers
          </Badge>
          <Badge variant="outline" className="border-amber-500/30 text-amber-400 whitespace-nowrap">
            <Calendar className="w-3 h-3 mr-1" />
            Seasonal
          </Badge>
          <Badge variant="outline" className="border-purple-500/30 text-purple-400 whitespace-nowrap">
            <Tag className="w-3 h-3 mr-1" />
            Trending
          </Badge>
        </div>

        {/* Combinations Grid */}
        <ScrollArea className="h-[500px] rounded-lg border border-zinc-800 bg-zinc-950/50">
          <div className="p-4 space-y-3">
            <AnimatePresence mode="popLayout">
              {filteredCombinations.map((combo, index) => {
                const availability = getCombinationAvailability(combo);
                const isExpanded = expandedCombo === combo.id;
                
                return (
                  <motion.div
                    key={combo.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: index * 0.05 }}
                    className={`
                      rounded-lg border overflow-hidden transition-all
                      ${isExpanded 
                        ? 'border-amber-500/50 bg-amber-500/5' 
                        : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'
                      }
                    `}
                  >
                    {/* Header Row */}
                    <div 
                      className="p-3 cursor-pointer"
                      onClick={() => setExpandedCombo(isExpanded ? null : combo.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {/* Color Preview */}
                          <div className="flex -space-x-2">
                            {combo.colors.map((color, i) => {
                              const isAvailable = getColorAvailability(color);
                              return (
                                <Tooltip key={i}>
                                  <TooltipTrigger>
                                    <div
                                      className={`
                                        w-8 h-8 rounded-full border-2 border-zinc-900
                                        ${!isAvailable && 'opacity-50 grayscale'}
                                      `}
                                      style={{ backgroundColor: color.hex }}
                                    />
                                  </TooltipTrigger>
                                  <TooltipContent className="bg-zinc-900 border-zinc-700">
                                    <p className="text-xs text-zinc-300">{color.name}</p>
                                    {!isAvailable && (
                                      <p className="text-xs text-red-400">Not in AMS</p>
                                    )}
                                  </TooltipContent>
                                </Tooltip>
                              );
                            })}
                          </div>
                          
                          <div>
                            <h4 className="font-medium text-zinc-200">{combo.name}</h4>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-xs text-zinc-500">
                                {seasonIcons[combo.season]} {seasonLabels[combo.season]}
                              </span>
                              <span className="text-zinc-700">•</span>
                              <span className="text-xs text-zinc-500">
                                {combo.popularity}/10 popularity
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {/* Availability Badge */}
                          <Tooltip>
                            <TooltipTrigger>
                              <Badge 
                                variant="outline" 
                                className={`
                                  text-xs
                                  ${availability.percentage === 100 
                                    ? 'border-green-500/30 text-green-400' 
                                    : availability.percentage >= 50 
                                      ? 'border-amber-500/30 text-amber-400'
                                      : 'border-red-500/30 text-red-400'
                                  }
                                `}
                              >
                                {availability.available}/{availability.total}
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent className="bg-zinc-900 border-zinc-700">
                              <p className="text-xs text-zinc-300">
                                {availability.available} of {availability.total} colors available
                              </p>
                            </TooltipContent>
                          </Tooltip>
                          
                          {/* Apply Button */}
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              onApplyCombination(combo.colors);
                            }}
                            disabled={availability.available === 0}
                            className="bg-amber-500 hover:bg-amber-600 text-black"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Expanded Details */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="border-t border-zinc-800"
                        >
                          <div className="p-3 space-y-3">
                            <p className="text-sm text-zinc-400">{combo.description}</p>
                            
                            {/* Tags */}
                            <div className="flex flex-wrap gap-1">
                              {combo.tags.map((tag, i) => (
                                <Badge 
                                  key={i}
                                  variant="outline" 
                                  className="border-zinc-700 text-zinc-500 text-xs"
                                >
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            
                            {/* Color Details */}
                            <div className="space-y-2">
                              <p className="text-xs text-zinc-500">Colors in this combination:</p>
                              <div className="grid grid-cols-2 gap-2">
                                {combo.colors.map((color, i) => {
                                  const isAvailable = getColorAvailability(color);
                                  return (
                                    <div 
                                      key={i}
                                      className={`
                                        flex items-center gap-2 p-2 rounded bg-zinc-950
                                        ${isAvailable ? 'border border-zinc-800' : 'border border-red-500/20'}
                                      `}
                                    >
                                      <div
                                        className="w-4 h-4 rounded"
                                        style={{ backgroundColor: color.hex }}
                                      />
                                      <span className="text-xs text-zinc-400 flex-1">{color.name}</span>
                                      {isAvailable ? (
                                        <Check className="w-3 h-3 text-green-500" />
                                      ) : (
                                        <Tooltip>
                                          <TooltipTrigger>
                                            <ShoppingCart className="w-3 h-3 text-amber-500" />
                                          </TooltipTrigger>
                                          <TooltipContent className="bg-zinc-900 border-zinc-700">
                                            <p className="text-xs text-zinc-300">Add to AMS</p>
                                          </TooltipContent>
                                        </Tooltip>
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </ScrollArea>

        {/* Quick Stats */}
        <Card className="bg-zinc-900/50 border-zinc-800 p-3">
          <div className="flex items-center justify-between text-xs text-zinc-500">
            <span>Showing {filteredCombinations.length} combinations</span>
            <span>
              {COLOR_COMBINATIONS.filter(c => c.popularity >= 8).length} highly rated
            </span>
          </div>
        </Card>
      </div>
    </TooltipProvider>
  );
};

export default ColorSuggestions;
