'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Layers, Grid2X2, Grid3X3 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AMSMode } from './types';

interface ModeToggleProps {
  mode: AMSMode;
  onModeChange: (mode: AMSMode) => void;
}

export const ModeToggle: React.FC<ModeToggleProps> = ({
  mode,
  onModeChange,
}) => {
  return (
    <Card className="bg-zinc-950 border-zinc-800 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center">
            <Layers className="w-5 h-5 text-amber-500" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-zinc-100">AMS Mode</h3>
            <p className="text-xs text-zinc-500">
              Select your AMS configuration
            </p>
          </div>
        </div>
        <Badge 
          variant="outline" 
          className="border-amber-500/30 text-amber-400"
        >
          H2D Compatible
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {/* Single AMS Mode */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onModeChange('single')}
          className={`
            relative p-4 rounded-xl border-2 transition-all duration-200
            ${mode === 'single' 
              ? 'border-amber-500 bg-amber-500/10' 
              : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'
            }
          `}
        >
          {/* Selection Indicator */}
          {mode === 'single' && (
            <motion.div
              layoutId="mode-indicator"
              className="absolute top-2 right-2 w-3 h-3 rounded-full bg-amber-500"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
            />
          )}

          <div className="flex flex-col items-center gap-3">
            {/* Visual Representation */}
            <div className={`
              w-16 h-12 rounded-lg border-2 flex items-center justify-center
              ${mode === 'single' ? 'border-amber-500/50' : 'border-zinc-700'}
            `}>
              <div className="grid grid-cols-4 gap-1 p-1">
                {[...Array(4)].map((_, i) => (
                  <div 
                    key={i}
                    className={`
                      w-2.5 h-6 rounded-sm
                      ${mode === 'single' 
                        ? 'bg-gradient-to-b from-amber-500/40 to-amber-600/40' 
                        : 'bg-zinc-800'
                      }
                    `}
                  />
                ))}
              </div>
            </div>

            <div className="text-center">
              <p className={`font-medium ${mode === 'single' ? 'text-amber-400' : 'text-zinc-400'}`}>
                Single AMS
              </p>
              <p className="text-xs text-zinc-500 mt-1">4 Colors</p>
            </div>

            <div className="flex items-center gap-1">
              <Grid2X2 className={`w-4 h-4 ${mode === 'single' ? 'text-amber-500' : 'text-zinc-600'}`} />
            </div>
          </div>
        </motion.button>

        {/* Dual AMS Mode */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onModeChange('dual')}
          className={`
            relative p-4 rounded-xl border-2 transition-all duration-200
            ${mode === 'dual' 
              ? 'border-amber-500 bg-amber-500/10' 
              : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'
            }
          `}
        >
          {/* Selection Indicator */}
          {mode === 'dual' && (
            <motion.div
              layoutId="mode-indicator"
              className="absolute top-2 right-2 w-3 h-3 rounded-full bg-amber-500"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
            />
          )}

          {/* Recommended Badge */}
          <div className="absolute -top-2 left-1/2 -translate-x-1/2">
            <Badge className="bg-green-500 text-black text-[10px] px-2 py-0">
              Recommended
            </Badge>
          </div>

          <div className="flex flex-col items-center gap-3">
            {/* Visual Representation */}
            <div className={`
              w-20 h-12 rounded-lg border-2 flex items-center justify-center
              ${mode === 'dual' ? 'border-amber-500/50' : 'border-zinc-700'}
            `}>
              <div className="grid grid-cols-8 gap-0.5 p-1">
                {[...Array(8)].map((_, i) => (
                  <div 
                    key={i}
                    className={`
                      w-1.5 h-6 rounded-sm
                      ${mode === 'dual' 
                        ? 'bg-gradient-to-b from-amber-500/40 to-amber-600/40' 
                        : 'bg-zinc-800'
                      }
                    `}
                  />
                ))}
              </div>
            </div>

            <div className="text-center">
              <p className={`font-medium ${mode === 'dual' ? 'text-amber-400' : 'text-zinc-400'}`}>
                Dual AMS
              </p>
              <p className="text-xs text-zinc-500 mt-1">8 Colors</p>
            </div>

            <div className="flex items-center gap-1">
              <Grid3X3 className={`w-4 h-4 ${mode === 'dual' ? 'text-amber-500' : 'text-zinc-600'}`} />
            </div>
          </div>
        </motion.button>
      </div>

      {/* Mode Description */}
      <div className="mt-4 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800">
        <p className="text-sm text-zinc-400">
          {mode === 'single' ? (
            <>
              <span className="text-amber-400 font-medium">Single AMS</span> mode uses 4 filament slots. 
              Perfect for simple multicolor prints with fewer color changes. 
              Compatible with basic AMS unit.
            </>
          ) : (
            <>
              <span className="text-amber-400 font-medium">Dual AMS</span> mode uses all 8 filament slots. 
              Ideal for complex multicolor projects with many color transitions. 
              Requires two AMS units connected to your H2D.
            </>
          )}
        </p>
      </div>

      {/* Features List */}
      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
        <div className={`flex items-center gap-2 ${mode === 'single' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'single' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          4 active filaments
        </div>
        <div className={`flex items-center gap-2 ${mode === 'dual' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'dual' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          8 active filaments
        </div>
        <div className={`flex items-center gap-2 ${mode === 'single' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'single' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          Basic multicolor
        </div>
        <div className={`flex items-center gap-2 ${mode === 'dual' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'dual' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          Advanced multicolor
        </div>
        <div className={`flex items-center gap-2 ${mode === 'single' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'single' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          Lower purge waste
        </div>
        <div className={`flex items-center gap-2 ${mode === 'dual' ? 'text-zinc-300' : 'text-zinc-600'}`}>
          <div className={`w-1.5 h-1.5 rounded-full ${mode === 'dual' ? 'bg-amber-500' : 'bg-zinc-700'}`} />
          More color options
        </div>
      </div>
    </Card>
  );
};

export default ModeToggle;
