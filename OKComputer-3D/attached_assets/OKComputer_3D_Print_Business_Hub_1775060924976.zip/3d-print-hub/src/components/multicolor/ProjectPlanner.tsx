'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FolderOpen, 
  Clock, 
  Scale, 
  Palette, 
  GripVertical,
  Check,
  AlertCircle,
  ArrowRight,
  Sparkles,
  Trash2
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { MulticolorProject, AMSSlot, FilamentColor } from './types';
import { SAMPLE_PROJECTS } from './types';

interface ProjectPlannerProps {
  projects: MulticolorProject[];
  amsSlots: AMSSlot[];
  onProjectSelect: (project: MulticolorProject | null) => void;
  selectedProject: MulticolorProject | null;
  onAssignColors: (project: MulticolorProject, slotAssignments: Map<number, FilamentColor>) => void;
}

interface DragItem {
  project: MulticolorProject;
}

export const ProjectPlanner: React.FC<ProjectPlannerProps> = ({
  projects,
  amsSlots,
  onProjectSelect,
  selectedProject,
  onAssignColors,
}) => {
  const [draggedProject, setDraggedProject] = useState<MulticolorProject | null>(null);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [slotAssignments, setSlotAssignments] = useState<Map<number, FilamentColor>>(new Map());

  const handleDragStart = (project: MulticolorProject) => {
    setDraggedProject(project);
  };

  const handleDragEnd = () => {
    setDraggedProject(null);
    setIsDraggingOver(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDrop = (e: React.DragEvent, project: MulticolorProject) => {
    e.preventDefault();
    setIsDraggingOver(false);
    onProjectSelect(project);
    
    // Auto-assign colors to available slots
    const assignments = new Map<number, FilamentColor>();
    const availableSlots = amsSlots.filter(s => s.color);
    
    project.colorPalette.forEach((color, index) => {
      const matchingSlot = availableSlots.find(s => s.color?.id === color.id);
      if (matchingSlot) {
        assignments.set(matchingSlot.id, color);
      } else {
        // Find first available slot with different color
        const freeSlot = availableSlots.find(s => !assignments.has(s.id));
        if (freeSlot) {
          assignments.set(freeSlot.id, color);
        }
      }
    });
    
    setSlotAssignments(assignments);
    onAssignColors(project, assignments);
  };

  const formatTime = (minutes: number): string => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  const getProjectCompatibility = (project: MulticolorProject): {
    compatible: boolean;
    missingColors: number;
    availableSlots: number;
  } => {
    const availableColors = amsSlots.filter(s => s.color).map(s => s.color?.id);
    const requiredColors = project.colorPalette.map(c => c.id);
    const matchedColors = requiredColors.filter(id => availableColors.includes(id));
    const missingColors = requiredColors.length - matchedColors.length;
    
    return {
      compatible: missingColors === 0,
      missingColors,
      availableSlots: amsSlots.filter(s => s.color).length,
    };
  };

  return (
    <TooltipProvider>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center">
              <FolderOpen className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-zinc-100">Project Planner</h3>
              <p className="text-xs text-zinc-500">
                {projects.length} multicolor projects available
              </p>
            </div>
          </div>
          {selectedProject && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onProjectSelect(null)}
              className="border-zinc-700 text-zinc-400 hover:bg-zinc-800"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Selection
            </Button>
          )}
        </div>

        {/* Selected Project Display */}
        <AnimatePresence>
          {selectedProject && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/5 border-amber-500/30 p-4">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-zinc-100">{selectedProject.name}</h4>
                      <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                        Selected
                      </Badge>
                    </div>
                    <p className="text-sm text-zinc-400 mb-2">{selectedProject.description}</p>
                    <div className="flex items-center gap-4 text-xs text-zinc-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTime(selectedProject.estimatedPrintTime)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Scale className="w-3 h-3" />
                        {selectedProject.filamentUsage}g
                      </span>
                      <span className="flex items-center gap-1">
                        <Palette className="w-3 h-3" />
                        {selectedProject.requiredColors} colors
                      </span>
                    </div>
                  </div>
                </div>

                {/* Required Colors */}
                <div className="mt-4 pt-4 border-t border-amber-500/20">
                  <p className="text-xs text-zinc-500 mb-2">Required Colors:</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.colorPalette.map((color, index) => {
                      const isAvailable = amsSlots.some(s => s.color?.id === color.id);
                      return (
                        <motion.div
                          key={color.id}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className={`
                            flex items-center gap-2 px-3 py-1.5 rounded-full border
                            ${isAvailable 
                              ? 'border-green-500/30 bg-green-500/10' 
                              : 'border-red-500/30 bg-red-500/10'
                            }
                          `}
                        >
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span className={`text-xs ${isAvailable ? 'text-green-400' : 'text-red-400'}`}>
                            {color.name}
                          </span>
                          {isAvailable ? (
                            <Check className="w-3 h-3 text-green-500" />
                          ) : (
                            <AlertCircle className="w-3 h-3 text-red-500" />
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                </div>

                {/* Slot Assignments */}
                {slotAssignments.size > 0 && (
                  <div className="mt-4 pt-4 border-t border-amber-500/20">
                    <p className="text-xs text-zinc-500 mb-2">Color Assignments:</p>
                    <div className="flex flex-wrap gap-2">
                      {Array.from(slotAssignments.entries()).map(([slotId, color]) => (
                        <div 
                          key={slotId}
                          className="flex items-center gap-2 px-2 py-1 rounded bg-zinc-900 border border-zinc-700"
                        >
                          <span className="text-xs text-zinc-500">Slot {slotId + 1}</span>
                          <ArrowRight className="w-3 h-3 text-zinc-600" />
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span className="text-xs text-zinc-300">{color.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Projects List */}
        <ScrollArea className="h-[400px] rounded-lg border border-zinc-800 bg-zinc-950/50">
          <div className="p-4 space-y-3">
            {projects.map((project, index) => {
              const compatibility = getProjectCompatibility(project);
              const isSelected = selectedProject?.id === project.id;
              
              return (
                <motion.div
                  key={project.id}
                  draggable
                  onDragStart={() => handleDragStart(project)}
                  onDragEnd={handleDragEnd}
                  onClick={() => onProjectSelect(isSelected ? null : project)}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.01 }}
                  className={`
                    cursor-pointer rounded-lg border p-3 transition-all
                    ${isSelected 
                      ? 'border-amber-500 bg-amber-500/10' 
                      : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700 hover:bg-zinc-900'
                    }
                  `}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1 text-zinc-600">
                      <GripVertical className="w-4 h-4" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium text-zinc-200">{project.name}</h4>
                        <div className="flex items-center gap-2">
                          {!compatibility.compatible && (
                            <Tooltip>
                              <TooltipTrigger>
                                <Badge variant="outline" className="border-red-500/30 text-red-400 text-xs">
                                  <AlertCircle className="w-3 h-3 mr-1" />
                                  {compatibility.missingColors} missing
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent className="bg-zinc-900 border-zinc-700">
                                <p className="text-xs text-zinc-300">
                                  {compatibility.missingColors} colors not available in AMS
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          )}
                          <Badge variant="outline" className="border-zinc-700 text-zinc-500 text-xs">
                            {project.category}
                          </Badge>
                        </div>
                      </div>
                      
                      <p className="text-sm text-zinc-500 mb-2 line-clamp-1">
                        {project.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-xs text-zinc-500">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatTime(project.estimatedPrintTime)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Scale className="w-3 h-3" />
                            {project.filamentUsage}g
                          </span>
                          <span className="flex items-center gap-1">
                            <Palette className="w-3 h-3" />
                            {project.requiredColors} colors
                          </span>
                        </div>
                        
                        {/* Color Preview */}
                        <div className="flex -space-x-1">
                          {project.colorPalette.slice(0, 4).map((color, i) => (
                            <div
                              key={i}
                              className="w-5 h-5 rounded-full border-2 border-zinc-900"
                              style={{ backgroundColor: color.hex }}
                              title={color.name}
                            />
                          ))}
                          {project.colorPalette.length > 4 && (
                            <div className="w-5 h-5 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center">
                              <span className="text-[8px] text-zinc-400">
                                +{project.colorPalette.length - 4}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </ScrollArea>

        {/* Drop Zone Hint */}
        <motion.div
          animate={{
            borderColor: isDraggingOver ? 'rgba(245, 158, 11, 0.5)' : 'rgba(63, 63, 70, 1)',
            backgroundColor: isDraggingOver ? 'rgba(245, 158, 11, 0.05)' : 'transparent',
          }}
          className="p-4 rounded-lg border-2 border-dashed border-zinc-700 text-center"
        >
          <p className="text-sm text-zinc-500">
            Drag a project here or click to select
          </p>
        </motion.div>
      </div>
    </TooltipProvider>
  );
};

export default ProjectPlanner;
