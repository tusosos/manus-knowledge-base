'use client';

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Edit2, Droplets, AlertTriangle, Check } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { AMSSlot, AMSMode, MaterialType } from './types';

interface AMSVisualizationProps {
  slots: AMSSlot[];
  mode: AMSMode;
  onSlotClick: (slotId: number) => void;
  activeProjectColors?: string[];
}

const materialColors: Record<MaterialType, string> = {
  PLA: 'bg-green-500/20 text-green-400 border-green-500/30',
  PETG: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  ABS: 'bg-red-500/20 text-red-400 border-red-500/30',
  TPU: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  ASA: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  PC: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  PA: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  NYLON: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
};

const getMaterialShortName = (material: MaterialType): string => {
  return material;
};

const getAmountStatus = (amount: number): { status: 'ok' | 'low' | 'critical'; color: string } => {
  if (amount > 200) return { status: 'ok', color: 'text-green-400' };
  if (amount > 100) return { status: 'low', color: 'text-amber-400' };
  return { status: 'critical', color: 'text-red-400' };
};

export const AMSVisualization: React.FC<AMSVisualizationProps> = ({
  slots,
  mode,
  onSlotClick,
  activeProjectColors = [],
}) => {
  const visibleSlots = mode === 'single' ? slots.slice(0, 4) : slots;
  const isColorUsedInProject = (colorId: string | undefined) => {
    if (!colorId || activeProjectColors.length === 0) return false;
    return activeProjectColors.includes(colorId);
  };

  return (
    <TooltipProvider>
      <div className="w-full">
        {/* AMS Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700 flex items-center justify-center">
              <Droplets className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-zinc-100">AMS Unit</h3>
              <p className="text-xs text-zinc-500">
                {mode === 'dual' ? '8-Color System' : '4-Color System'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-zinc-700 text-zinc-400">
              {slots.filter(s => s.color).length}/{visibleSlots.length} Loaded
            </Badge>
            <Badge variant="outline" className="border-amber-500/30 text-amber-400">
              Bambu Lab H2D
            </Badge>
          </div>
        </div>

        {/* AMS Body - Industrial Design */}
        <Card className="relative bg-gradient-to-b from-zinc-900 via-zinc-950 to-black border-zinc-800 p-6 overflow-hidden">
          {/* Industrial texture overlay */}
          <div className="absolute inset-0 opacity-5 pointer-events-none"
               style={{
                 backgroundImage: `repeating-linear-gradient(
                   0deg,
                   transparent,
                   transparent 2px,
                   rgba(255,255,255,0.03) 2px,
                   rgba(255,255,255,0.03) 4px
                 )`
               }}
          />
          
          {/* Corner accents */}
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-amber-500/30 rounded-tl-lg" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-amber-500/30 rounded-tr-lg" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-amber-500/30 rounded-bl-lg" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-amber-500/30 rounded-br-lg" />

          {/* Status LEDs */}
          <div className="flex justify-center gap-2 mb-6">
            {visibleSlots.map((slot, index) => (
              <motion.div
                key={`led-${slot.id}`}
                className={`w-2 h-2 rounded-full ${
                  slot.color 
                    ? slot.isActive 
                      ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' 
                      : 'bg-zinc-600'
                    : 'bg-zinc-800'
                }`}
                animate={slot.isActive ? {
                  opacity: [1, 0.5, 1],
                } : {}}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                  delay: index * 0.1,
                }}
              />
            ))}
          </div>

          {/* Slots Grid */}
          <div className={`grid gap-3 ${
            mode === 'single' 
              ? 'grid-cols-4' 
              : 'grid-cols-4 md:grid-cols-8'
          }`}>
            <AnimatePresence mode="popLayout">
              {visibleSlots.map((slot, index) => {
                const amountStatus = getAmountStatus(slot.remainingAmount);
                const isProjectColor = isColorUsedInProject(slot.color?.id);
                
                return (
                  <motion.div
                    key={slot.id}
                    layout
                    initial={{ opacity: 0, scale: 0.8, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: -20 }}
                    transition={{
                      duration: 0.3,
                      delay: index * 0.05,
                      type: 'spring',
                      stiffness: 300,
                      damping: 25,
                    }}
                  >
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <motion.div
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => onSlotClick(slot.id)}
                          className={`
                            relative cursor-pointer rounded-xl overflow-hidden
                            border-2 transition-all duration-200
                            ${slot.color 
                              ? isProjectColor 
                                ? 'border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)]' 
                                : 'border-zinc-700 hover:border-zinc-600'
                              : 'border-dashed border-zinc-800 hover:border-zinc-700'
                            }
                          `}
                        >
                          {/* Slot Number */}
                          <div className="absolute top-1 left-1 z-10">
                            <span className="text-[10px] font-mono text-zinc-500 bg-black/50 px-1.5 py-0.5 rounded">
                              {slot.id + 1}
                            </span>
                          </div>

                          {/* Project Color Indicator */}
                          {isProjectColor && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="absolute top-1 right-1 z-10"
                            >
                              <div className="w-4 h-4 bg-amber-500 rounded-full flex items-center justify-center">
                                <Check className="w-2.5 h-2.5 text-black" />
                              </div>
                            </motion.div>
                          )}

                          {/* Filament Visual */}
                          <div 
                            className="h-24 relative"
                            style={{
                              background: slot.color 
                                ? `linear-gradient(135deg, ${slot.color.hex} 0%, ${slot.color.hex}dd 50%, ${slot.color.hex} 100%)`
                                : 'linear-gradient(135deg, #18181b 0%, #09090b 100%)',
                            }}
                          >
                            {/* Filament texture */}
                            {slot.color && (
                              <div 
                                className="absolute inset-0 opacity-30"
                                style={{
                                  backgroundImage: `repeating-linear-gradient(
                                    45deg,
                                    transparent,
                                    transparent 3px,
                                    rgba(0,0,0,0.1) 3px,
                                    rgba(0,0,0,0.1) 6px
                                  )`
                                }}
                              />
                            )}
                            
                            {/* Empty slot placeholder */}
                            {!slot.color && (
                              <div className="absolute inset-0 flex items-center justify-center">
                                <div className="w-12 h-12 rounded-full border-2 border-dashed border-zinc-700 flex items-center justify-center">
                                  <span className="text-zinc-600 text-xs">+</span>
                                </div>
                              </div>
                            )}

                            {/* Edit overlay */}
                            <motion.div
                              initial={{ opacity: 0 }}
                              whileHover={{ opacity: 1 }}
                              className="absolute inset-0 bg-black/60 flex items-center justify-center"
                            >
                              <Edit2 className="w-5 h-5 text-white" />
                            </motion.div>
                          </div>

                          {/* Slot Info */}
                          <div className="bg-zinc-950 p-2 space-y-1">
                            {slot.color ? (
                              <>
                                <p className="text-xs font-medium text-zinc-200 truncate">
                                  {slot.color.name}
                                </p>
                                <div className="flex items-center justify-between">
                                  <Badge 
                                    variant="outline" 
                                    className={`text-[9px] px-1 py-0 ${materialColors[slot.material]}`}
                                  >
                                    {getMaterialShortName(slot.material)}
                                  </Badge>
                                  <div className="flex items-center gap-1">
                                    {amountStatus.status === 'critical' && (
                                      <AlertTriangle className="w-3 h-3 text-red-500" />
                                    )}
                                    <span className={`text-[10px] font-mono ${amountStatus.color}`}>
                                      {slot.remainingAmount}g
                                    </span>
                                  </div>
                                </div>
                              </>
                            ) : (
                              <p className="text-xs text-zinc-600 text-center">Empty</p>
                            )}
                          </div>
                        </motion.div>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="bg-zinc-900 border-zinc-700">
                        {slot.color ? (
                          <div className="space-y-1">
                            <p className="font-medium text-zinc-100">{slot.color.name}</p>
                            <p className="text-xs text-zinc-400">Material: {slot.material}</p>
                            <p className="text-xs text-zinc-400">Remaining: {slot.remainingAmount}g</p>
                            {isProjectColor && (
                              <p className="text-xs text-amber-400">Used in current project</p>
                            )}
                          </div>
                        ) : (
                          <p className="text-zinc-400">Click to add filament</p>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* Bottom Info Bar */}
          <div className="mt-6 pt-4 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                Active
              </span>
              <span className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                Project Color
              </span>
              <span className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-zinc-600" />
                Loaded
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span>Total Capacity:</span>
              <span className="text-zinc-300 font-mono">
                {slots.reduce((acc, s) => acc + s.remainingAmount, 0)}g
              </span>
            </div>
          </div>
        </Card>
      </div>
    </TooltipProvider>
  );
};

export default AMSVisualization;
