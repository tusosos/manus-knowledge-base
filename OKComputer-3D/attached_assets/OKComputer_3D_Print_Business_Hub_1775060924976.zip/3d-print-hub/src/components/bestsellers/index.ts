// Main Module
export { BestsellersModule } from "./BestsellersModule";

// Components
export { ProductCard } from "./ProductCard";
export { CategoryFilter } from "./CategoryFilter";
export { MulticolorPremium } from "./MulticolorPremium";
export { Trends2026 } from "./Trends2026";
export { SalesPlatforms } from "./SalesPlatforms";
export { TipsSection } from "./TipsSection";

// Data & Types
export {
  products,
  categories,
  multicolorPremium,
  trends2026,
  salesPlatforms,
  photographyTips,
  descriptionTips,
  pricingTips,
} from "./data";

export type { Product, Category, CategoryInfo } from "./data";
