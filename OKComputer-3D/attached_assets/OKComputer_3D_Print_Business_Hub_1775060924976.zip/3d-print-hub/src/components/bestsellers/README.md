# Bestsellers Module - 3D Print Business Hub

Moduł bestsellerów dla biznesu druku 3D - TOP 23 produkty które najlepiej się sprzedają.

## Funkcjonalności

### 1. TOP 23 Produktów
- Nazwa produktu
- Kategoria
- Sugerowana cena sprzedaży
- Szacowany koszt wydruku
- Marża (% i zł)
- Linki do modeli (MakerWorld, Printables, Cults3D, Thingiverse)
- Ikona multicolor (dla H2D)

### 2. Kategorie Produktów
| Kategoria | Marża | Ikonka |
|-----------|-------|--------|
| Fidget Toys / Smoki | 400% | Dragon |
| Biżuteria 3D | 500% | Gem |
| Litofany | 400% | Image |
| Organizery | 200% | LayoutGrid |
| Miniatury | 500% | Users |
| Etui na Telefon | 300% | Smartphone |
| Dekoracje Świąteczne | 200% | TreePine |
| Articulated Toys | 400% | ToyBrick |
| Cosplay Props | 300% | Sword |
| Narzędzia i Gadżety | 250% | Wrench |

### 3. Sekcja Multicolor Premium
- Produkty idealne dla H2D + AMS
- 8-kolorowe wydruki
- Wysoka marża premium

### 4. Trendy 2026
- Multicolor Revolution
- Articulated Toys Boom
- Personalizacja Masowa
- Miniatures Gaming

### 5. Platformy Sprzedaży
- Etsy
- Allegro
- OLX
- Amazon Handmade
- Własna strona

### 6. Porady
- Jak fotografować produkty
- Jak pisać opisy
- Jak ustawiać ceny

## Użycie

```tsx
import { BestsellersModule } from "@/components/bestsellers";

export default function Page() {
  return <BestsellersModule />;
}
```

## Struktura Plików

```
bestsellers/
├── BestsellersModule.tsx    # Główny komponent modułu
├── ProductCard.tsx          # Karta produktu
├── CategoryFilter.tsx       # Filtrowanie kategorii
├── MulticolorPremium.tsx    # Sekcja multicolor
├── Trends2026.tsx           # Trendy na 2026
├── SalesPlatforms.tsx       # Platformy sprzedaży
├── TipsSection.tsx          # Sekcja porad
├── data.ts                  # Dane produktów i typy
├── index.ts                 # Eksporty
└── README.md                # Dokumentacja
```

## Wymagane Zależności

```bash
npm install lucide-react
```

## Wymagane Komponenty shadcn/ui

```bash
npx shadcn add card badge button tabs table input tooltip
```

## Dane Produktów

Produkty są zdefiniowane w `data.ts` i zawierają:
- 23 bestsellerowe produkty
- Realistyczne ceny i koszty
- Linki do modeli 3D
- Wskazówki do druku

## Licencja

MIT - Darmowe użycie w projektach komercyjnych i niekomercyjnych.
