"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Product } from "./data";
import {
  ExternalLink,
  Clock,
  Weight,
  TrendingUp,
  Zap,
  Palette,
  Wrench,
  Lightbulb,
  Star,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-500/20 text-green-400 border-green-500/30";
      case "medium":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case "hard":
        return "bg-red-500/20 text-red-400 border-red-500/30";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "Łatwy";
      case "medium":
        return "Średni";
      case "hard":
        return "Trudny";
      default:
        return difficulty;
    }
  };

  const getPopularityStars = (popularity: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`w-3 h-3 ${
            i < popularity / 2
              ? "fill-amber-400 text-amber-400"
              : "fill-gray-700 text-gray-700"
          }`}
        />
      ));
  };

  return (
    <Card className="group bg-zinc-900/80 border-zinc-800 hover:border-amber-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/10 overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-lg text-zinc-100 truncate group-hover:text-amber-400 transition-colors">
              {product.name}
            </h3>
            <p className="text-sm text-zinc-500">{product.categoryName}</p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge
              variant="outline"
              className={`text-xs ${getDifficultyColor(product.difficulty)}`}
            >
              {getDifficultyLabel(product.difficulty)}
            </Badge>
            {product.multicolor && (
              <Badge
                variant="outline"
                className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30 text-xs"
              >
                <Palette className="w-3 h-3 mr-1" />
                {product.colors}K
              </Badge>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 mt-2">
          {getPopularityStars(product.popularity)}
          <span className="text-xs text-zinc-500 ml-1">
            Popularność: {product.popularity}/10
          </span>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Price Section */}
        <div className="grid grid-cols-3 gap-2 p-3 bg-zinc-950/50 rounded-lg">
          <div className="text-center">
            <p className="text-xs text-zinc-500 mb-1">Cena</p>
            <p className="text-lg font-bold text-emerald-400">
              {product.sellingPrice} zł
            </p>
          </div>
          <div className="text-center border-x border-zinc-800">
            <p className="text-xs text-zinc-500 mb-1">Koszt</p>
            <p className="text-lg font-semibold text-zinc-300">
              {product.printCost} zł
            </p>
          </div>
          <div className="text-center">
            <p className="text-xs text-zinc-500 mb-1">Zysk</p>
            <p className="text-lg font-bold text-amber-400">
              {product.marginPLN} zł
            </p>
          </div>
        </div>

        {/* Margin Badge */}
        <div className="flex items-center justify-center">
          <Badge
            variant="outline"
            className="bg-amber-500/10 text-amber-400 border-amber-500/30 px-4 py-1"
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Marża: {product.marginPercent}%
          </Badge>
        </div>

        {/* Print Details */}
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center gap-2 text-zinc-400">
            <Clock className="w-4 h-4 text-zinc-500" />
            <span>{product.printTime}</span>
          </div>
          <div className="flex items-center gap-2 text-zinc-400">
            <Weight className="w-4 h-4 text-zinc-500" />
            <span>{product.filamentWeight}</span>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-zinc-400 line-clamp-2">
          {product.description}
        </p>

        {/* Tips */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-start gap-2 p-2 bg-amber-500/5 rounded border border-amber-500/20 cursor-help">
                <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-zinc-400 line-clamp-2">
                  {product.tips}
                </p>
              </div>
            </TooltipTrigger>
            <TooltipContent
              side="bottom"
              className="max-w-xs bg-zinc-900 border-zinc-700"
            >
              <p className="text-sm text-zinc-300">{product.tips}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Links */}
        <div className="pt-2 border-t border-zinc-800">
          <p className="text-xs text-zinc-500 mb-2 flex items-center gap-1">
            <ExternalLink className="w-3 h-3" />
            Modele 3D:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {product.links.makerworld && (
              <a
                href={product.links.makerworld}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-orange-500/20 hover:text-orange-400 hover:border-orange-500/50"
                >
                  <Zap className="w-3 h-3 mr-1" />
                  MakerWorld
                </Button>
              </a>
            )}
            {product.links.printables && (
              <a
                href={product.links.printables}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-orange-500/20 hover:text-orange-400 hover:border-orange-500/50"
                >
                  <Wrench className="w-3 h-3 mr-1" />
                  Printables
                </Button>
              </a>
            )}
            {product.links.cults3d && (
              <a
                href={product.links.cults3d}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-purple-500/20 hover:text-purple-400 hover:border-purple-500/50"
                >
                  <Star className="w-3 h-3 mr-1" />
                  Cults3D
                </Button>
              </a>
            )}
            {product.links.thingiverse && (
              <a
                href={product.links.thingiverse}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-blue-500/20 hover:text-blue-400 hover:border-blue-500/50"
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Thingiverse
                </Button>
              </a>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
