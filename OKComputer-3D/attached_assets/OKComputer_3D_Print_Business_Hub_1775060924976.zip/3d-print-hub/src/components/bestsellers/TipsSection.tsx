"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  photographyTips,
  descriptionTips,
  pricingTips,
} from "./data";
import {
  Camera,
  FileText,
  Calculator,
  Sun,
  Square,
  Image,
  CheckCircle2,
  Lightbulb,
  TrendingUp,
  DollarSign,
} from "lucide-react";

const photographyIconMap: Record<string, React.ElementType> = {
  Sun,
  Square,
  Camera,
  Image,
};

export function TipsSection() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-500/10 rounded-lg">
          <Lightbulb className="w-6 h-6 text-blue-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-zinc-100">
            Porady Eksperta
          </h2>
          <p className="text-zinc-500">
            Jak skutecznie sprzedawać produkty z druku 3D
          </p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="photography" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-zinc-900/80 border border-zinc-800">
          <TabsTrigger
            value="photography"
            className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
          >
            <Camera className="w-4 h-4 mr-2" />
            Fotografia
          </TabsTrigger>
          <TabsTrigger
            value="description"
            className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
          >
            <FileText className="w-4 h-4 mr-2" />
            Opisy
          </TabsTrigger>
          <TabsTrigger
            value="pricing"
            className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
          >
            <Calculator className="w-4 h-4 mr-2" />
            Ceny
          </TabsTrigger>
        </TabsList>

        {/* Photography Tips */}
        <TabsContent value="photography" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {photographyTips.map((tip, index) => {
              const Icon = photographyIconMap[tip.icon] || Camera;
              return (
                <Card
                  key={index}
                  className="bg-zinc-900/80 border-zinc-800 hover:border-amber-500/50 transition-all duration-300"
                >
                  <CardContent className="p-5">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-amber-500/10 rounded-lg">
                        <Icon className="w-5 h-5 text-amber-400" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-zinc-100 mb-1">
                          {tip.title}
                        </h3>
                        <p className="text-sm text-zinc-400">
                          {tip.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Card className="mt-4 bg-gradient-to-r from-amber-500/10 via-zinc-900 to-zinc-900 border-amber-500/30">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-amber-500/20 rounded-lg">
                  <CheckCircle2 className="w-5 h-5 text-amber-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-zinc-100 mb-2">
                    Checklist Zdjęć Produktowych
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {[
                      "Zdjęcie główne na białym tle",
                      "Zdjęcie z perspektywy 45°",
                      "Zbliżenie na detale",
                      "Produkt w użyciu (lifestyle)",
                      "Zdjęcie pokazujące skalę (w dłoni)",
                      "Opcje kolorystyczne",
                      "Opakowanie/pakowanie",
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 text-sm text-zinc-400"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Description Tips */}
        <TabsContent value="description" className="mt-4">
          <div className="space-y-4">
            {descriptionTips.map((tip, index) => (
              <Card
                key={index}
                className="bg-zinc-900/80 border-zinc-800 hover:border-amber-500/50 transition-all duration-300"
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="p-2 bg-blue-500/10 rounded-lg">
                      <FileText className="w-5 h-5 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-zinc-100 mb-1">
                        {tip.title}
                      </h3>
                      <p className="text-sm text-zinc-400 mb-2">
                        {tip.description}
                      </p>
                      <Badge
                        variant="outline"
                        className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                      >
                        {tip.example}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-4 bg-gradient-to-r from-blue-500/10 via-zinc-900 to-zinc-900 border-blue-500/30">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-blue-500/20 rounded-lg">
                  <Lightbulb className="w-5 h-5 text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-zinc-100 mb-2">
                    Szablon Opisu Produktu
                  </h3>
                  <div className="p-3 bg-zinc-950/50 rounded-lg font-mono text-sm text-zinc-400 space-y-1">
                    <p className="text-amber-400 font-bold">
                      🔥 3D Printed Crystal Dragon - Articulated Fidget Toy
                    </p>
                    <p className="text-zinc-500">
                      #fidgettoy #3dprinted #dragon #gift
                    </p>
                    <p className="text-zinc-300 mt-2">
                      Rozładowuj stres z naszym magicznym smokiem!
                    </p>
                    <p className="text-zinc-400">
                      Ten articulowany smok to idealna zabawka antystresowa dla
                      dorosłych i dzieci.
                    </p>
                    <p className="text-emerald-400 mt-2">✨ Specyfikacja:</p>
                    <p className="text-zinc-500">
                      • Wymiary: 30cm długości
                      <br />• Materiał: PLA Silk (eko-friendly)
                      <br />• Kolory: Do wyboru 10+ wariantów
                      <br />• Czas druku: 8-10h
                    </p>
                    <p className="text-amber-400 mt-2">
                      🎁 Idealny prezent na każdą okazję!
                    </p>
                    <p className="text-purple-400 mt-2">
                      📦 Wysyłka w 24h | Zwrot do 14 dni
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pricing Tips */}
        <TabsContent value="pricing" className="mt-4">
          <div className="space-y-4">
            {pricingTips.map((tip, index) => (
              <Card
                key={index}
                className="bg-zinc-900/80 border-zinc-800 hover:border-amber-500/50 transition-all duration-300"
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="p-2 bg-emerald-500/10 rounded-lg">
                      {index === 0 ? (
                        <Calculator className="w-5 h-5 text-emerald-400" />
                      ) : index === 1 ? (
                        <TrendingUp className="w-5 h-5 text-emerald-400" />
                      ) : index === 2 ? (
                        <DollarSign className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-zinc-100 mb-1">
                        {tip.title}
                      </h3>
                      {"formula" in tip ? (
                        <>
                          <p className="text-sm text-zinc-400 mb-2">
                            {tip.formula}
                          </p>
                          <Badge
                            variant="outline"
                            className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                          >
                            {tip.example}
                          </Badge>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-zinc-400 mb-2">
                            {tip.description}
                          </p>
                          <Badge
                            variant="outline"
                            className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                          >
                            {tip.example}
                          </Badge>
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-4 bg-gradient-to-r from-emerald-500/10 via-zinc-900 to-zinc-900 border-emerald-500/30">
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-emerald-500/20 rounded-lg">
                  <Calculator className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-zinc-100 mb-2">
                    Kalkulator Ceny - Przykład
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-zinc-950/50 rounded-lg">
                      <p className="text-sm text-zinc-500 mb-2">
                        Crystal Dragon:
                      </p>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between text-zinc-400">
                          <span>Koszt filamentu (120g):</span>
                          <span>12 zł</span>
                        </div>
                        <div className="flex justify-between text-zinc-400">
                          <span>Prąd (10h × 0.5zł):</span>
                          <span>5 zł</span>
                        </div>
                        <div className="flex justify-between text-zinc-400">
                          <span>Amortyzacja drukarki:</span>
                          <span>1 zł</span>
                        </div>
                        <div className="border-t border-zinc-800 pt-1 flex justify-between text-zinc-300 font-medium">
                          <span>Całkowity koszt:</span>
                          <span>18 zł</span>
                        </div>
                        <div className="flex justify-between text-emerald-400">
                          <span>Marża 400%:</span>
                          <span>+71 zł</span>
                        </div>
                        <div className="border-t border-zinc-800 pt-1 flex justify-between text-amber-400 font-bold">
                          <span>Cena sprzedaży:</span>
                          <span>89 zł</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 bg-zinc-950/50 rounded-lg">
                      <p className="text-sm text-zinc-500 mb-2">
                        Wskazówki:
                      </p>
                      <ul className="space-y-1 text-sm text-zinc-400">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                          Uwzględnij czas obsługi zamówienia
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                          Dodaj koszt opakowania i wysyłki
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                          Prowizje platform też kosztują
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                          Rezerwuj 10% na reklamacje
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
