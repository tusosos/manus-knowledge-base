"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Category, CategoryInfo, categories } from "./data";
import {
  Dragon,
  Gem,
  Image,
  LayoutGrid,
  Users,
  Smartphone,
  TreePine,
  ToyBrick,
  Sword,
  Wrench,
  Layers,
} from "lucide-react";

interface CategoryFilterProps {
  selectedCategory: Category | "all";
  onCategoryChange: (category: Category | "all") => void;
  productCounts: Record<string, number>;
}

const iconMap: Record<string, React.ElementType> = {
  Dragon,
  Gem,
  Image,
  LayoutGrid,
  Users,
  Smartphone,
  TreePine,
  ToyBrick,
  Sword,
  Wrench,
};

export function CategoryFilter({
  selectedCategory,
  onCategoryChange,
  productCounts,
}: CategoryFilterProps) {
  const getCategoryIcon = (iconName: string) => {
    const Icon = iconMap[iconName] || Layers;
    return <Icon className="w-4 h-4" />;
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedCategory === "all" ? "default" : "outline"}
          size="sm"
          onClick={() => onCategoryChange("all")}
          className={`
            ${
              selectedCategory === "all"
                ? "bg-amber-500 hover:bg-amber-600 text-zinc-950"
                : "bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:bg-zinc-700 hover:text-zinc-100"
            }
          `}
        >
          <Layers className="w-4 h-4 mr-2" />
          Wszystkie
          <Badge
            variant="secondary"
            className={`ml-2 text-xs ${
              selectedCategory === "all"
                ? "bg-zinc-950/20 text-zinc-100"
                : "bg-zinc-700 text-zinc-300"
            }`}
          >
            {Object.values(productCounts).reduce((a, b) => a + b, 0)}
          </Badge>
        </Button>

        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            size="sm"
            onClick={() => onCategoryChange(category.id)}
            className={`
              ${
                selectedCategory === category.id
                  ? "bg-amber-500 hover:bg-amber-600 text-zinc-950"
                  : "bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:bg-zinc-700 hover:text-zinc-100"
              }
            `}
          >
            {getCategoryIcon(category.icon)}
            <span className="ml-2">{category.name}</span>
            <Badge
              variant="secondary"
              className={`ml-2 text-xs ${
                selectedCategory === category.id
                  ? "bg-zinc-950/20 text-zinc-100"
                  : "bg-zinc-700 text-zinc-300"
              }`}
            >
              {productCounts[category.id] || 0}
            </Badge>
          </Button>
        ))}
      </div>

      {/* Category Info Card */}
      {selectedCategory !== "all" && (
        <div className="p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg">
          {categories
            .filter((c) => c.id === selectedCategory)
            .map((category) => (
              <div key={category.id} className="flex items-start gap-4">
                <div className="p-3 bg-amber-500/10 rounded-lg">
                  {getCategoryIcon(category.icon)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold text-zinc-100">
                      {category.name}
                    </h4>
                    <Badge
                      variant="outline"
                      className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                    >
                      Marża: {category.margin}%
                    </Badge>
                  </div>
                  <p className="text-sm text-zinc-400">
                    {category.description}
                  </p>
                </div>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}
