"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trends2026 } from "./data";
import {
  Palette,
  ToyBrick,
  UserCog,
  Dice5,
  TrendingUp,
  ArrowUpRight,
  Sparkles,
} from "lucide-react";

const iconMap: Record<string, React.ElementType> = {
  Palette,
  ToyBrick,
  UserCog,
  Dice5,
};

export function Trends2026() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-amber-500/10 rounded-lg">
          <TrendingUp className="w-6 h-6 text-amber-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-zinc-100">
            Trendy 2026
          </h2>
          <p className="text-zinc-500">
            Co będzie sprzedawać się najlepiej w nadchodzącym roku
          </p>
        </div>
      </div>

      {/* Trends Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {trends2026.map((trend, index) => {
          const Icon = iconMap[trend.icon] || Sparkles;
          return (
            <Card
              key={index}
              className="group bg-zinc-900/80 border-zinc-800 hover:border-amber-500/50 transition-all duration-300 overflow-hidden"
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-amber-500/10 rounded-lg group-hover:bg-amber-500/20 transition-colors">
                    <Icon className="w-6 h-6 text-amber-400" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold text-zinc-100 group-hover:text-amber-400 transition-colors">
                        {trend.title}
                      </h3>
                      <ArrowUpRight className="w-4 h-4 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <p className="text-sm text-zinc-400 mb-3">
                      {trend.description}
                    </p>
                    <Badge
                      variant="outline"
                      className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                    >
                      <TrendingUp className="w-3 h-3 mr-1" />
                      {trend.impact}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Summary Card */}
      <Card className="bg-gradient-to-r from-amber-500/10 via-zinc-900 to-zinc-900 border-amber-500/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-amber-500/20 rounded-lg">
              <Sparkles className="w-6 h-6 text-amber-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-zinc-100 mb-2">
                Podsumowanie Trendów
              </h3>
              <p className="text-sm text-zinc-400 mb-4">
                Rok 2026 to przełom dla druku 3D. Multicolor staje się
                standardem, a personalizacja to już nie luksus, ale oczekiwanie
                klientów. Inwestycja w drukarkę wielomateriałową (H2D + AMS)
                zwróci się w ciągu 3-6 miesięcy przy odpowiednim podejściu do
                sprzedaży.
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                >
                  Multicolor
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                >
                  Personalizacja
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                >
                  Articulated
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                >
                  Miniatures
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                >
                  Gaming
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
