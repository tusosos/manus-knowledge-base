export type Category =
  | "fidget"
  | "jewelry"
  | "lithophane"
  | "organizer"
  | "miniature"
  | "phone-case"
  | "decoration"
  | "articulated"
  | "cosplay"
  | "gadget";

export interface Product {
  id: number;
  name: string;
  category: Category;
  categoryName: string;
  sellingPrice: number;
  printCost: number;
  marginPercent: number;
  marginPLN: number;
  printTime: string;
  filamentWeight: string;
  multicolor: boolean;
  colors?: number;
  difficulty: "easy" | "medium" | "hard";
  popularity: number; // 1-10
  links: {
    makerworld?: string;
    printables?: string;
    cults3d?: string;
    thingiverse?: string;
  };
  description: string;
  tips: string;
}

export interface CategoryInfo {
  id: Category;
  name: string;
  margin: number;
  icon: string;
  description: string;
}

export const categories: CategoryInfo[] = [
  {
    id: "fidget",
    name: "Fidget Toys / Smoki",
    margin: 400,
    icon: "Dragon",
    description: "Nieskończona popularność - smoki, węże, zwierzęta articulowane",
  },
  {
    id: "jewelry",
    name: "Biżuteria 3D",
    margin: 500,
    icon: "Gem",
    description: "Kolczyki, naszyjniki, bransoletki z niskimi kosztami produkcji",
  },
  {
    id: "lithophane",
    name: "Litofany",
    margin: 400,
    icon: "Image",
    description: "Personalizowane zdjęcia 3D - idealny prezent",
  },
  {
    id: "organizer",
    name: "Organizery",
    margin: 200,
    icon: "LayoutGrid",
    description: "Pudełka, wsporniki, systemy przechowywania",
  },
  {
    id: "miniature",
    name: "Miniatury",
    margin: 500,
    icon: "Users",
    description: "Figurki do gier RPG, kolekcjonerskie, dioramy",
  },
  {
    id: "phone-case",
    name: "Etui na Telefon",
    margin: 300,
    icon: "Smartphone",
    description: "Personalizowane obudowy z unikalnymi wzorami",
  },
  {
    id: "decoration",
    name: "Dekoracje Świąteczne",
    margin: 200,
    icon: "TreePine",
    description: "Sezonowe ozdoby - święta, Halloween, Wielkanoc",
  },
  {
    id: "articulated",
    name: "Articulated Toys",
    margin: 400,
    icon: "ToyBrick",
    description: "Ruchome zabawki bez potrzeby składania",
  },
  {
    id: "cosplay",
    name: "Cosplay Props",
    margin: 300,
    icon: "Sword",
    description: "Miecze, zbroje, akcesoria do kostiumów",
  },
  {
    id: "gadget",
    name: "Narzędzia i Gadżety",
    margin: 250,
    icon: "Wrench",
    description: "Praktyczne przedmioty użytkowe do domu i warsztatu",
  },
];

export const products: Product[] = [
  // FIDGET TOYS / SMOKI
  {
    id: 1,
    name: "Crystal Dragon",
    category: "fidget",
    categoryName: "Fidget Toys / Smoki",
    sellingPrice: 89,
    printCost: 18,
    marginPercent: 394,
    marginPLN: 71,
    printTime: "8-10h",
    filamentWeight: "120g",
    multicolor: true,
    colors: 4,
    difficulty: "medium",
    popularity: 10,
    links: {
      makerworld: "https://makerworld.com/en/models/10001",
      printables: "https://printables.com/model/10001",
      cults3d: "https://cults3d.com/en/3d-model/art/crystal-dragon",
    },
    description: "Najpopularniejszy smok 3D wszech czasów. Articulowany, ruchomy, hipnotyzujący.",
    tips: "Drukuj z 0.16mm layer height dla lepszej jakości. Użyj silk filamentu.",
  },
  {
    id: 2,
    name: "Articulated Snake",
    category: "fidget",
    categoryName: "Fidget Toys / Smoki",
    sellingPrice: 45,
    printCost: 9,
    marginPercent: 400,
    marginPLN: 36,
    printTime: "4-5h",
    filamentWeight: "60g",
    multicolor: true,
    colors: 3,
    difficulty: "easy",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/20001",
      printables: "https://printables.com/model/20001",
    },
    description: "Wąż z realistycznym ruchem. Idealny do zabawy i stresu.",
    tips: "Drukuj w pozycji płaskiej, bez supportów. Rainbow filament = hit sprzedaży.",
  },
  {
    id: 3,
    name: "Flexi Cat",
    category: "fidget",
    categoryName: "Fidget Toys / Smoki",
    sellingPrice: 55,
    printCost: 11,
    marginPercent: 400,
    marginPLN: 44,
    printTime: "5-6h",
    filamentWeight: "75g",
    multicolor: false,
    difficulty: "easy",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/30001",
      cults3d: "https://cults3d.com/en/3d-model/art/flexi-cat",
    },
    description: "Słodki, ruchomy kotek. Ulubieniec dzieci i dorosłych.",
    tips: "Pastelowe kolory sprzedają się najlepiej. Dodaj dzwoneczek!",
  },

  // BIŻUTERIA 3D
  {
    id: 4,
    name: "Geometric Earrings Set",
    category: "jewelry",
    categoryName: "Biżuteria 3D",
    sellingPrice: 69,
    printCost: 12,
    marginPercent: 475,
    marginPLN: 57,
    printTime: "2-3h",
    filamentWeight: "25g",
    multicolor: false,
    difficulty: "easy",
    popularity: 8,
    links: {
      printables: "https://printables.com/model/40001",
      thingiverse: "https://thingiverse.com/thing:40001",
    },
    description: "Zestaw 5 par kolczyków w stylu geometrycznym. Lekkie i eleganckie.",
    tips: "Użyj PLA silk lub PETG. Pakuj w ozdobne pudełko +30zł wartości.",
  },
  {
    id: 5,
    name: "Flower Pendant Necklace",
    category: "jewelry",
    categoryName: "Biżuteria 3D",
    sellingPrice: 79,
    printCost: 14,
    marginPercent: 464,
    marginPLN: 65,
    printTime: "3-4h",
    filamentWeight: "30g",
    multicolor: true,
    colors: 2,
    difficulty: "medium",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/50001",
      cults3d: "https://cults3d.com/en/3d-model/jewelry/flower-pendant",
    },
    description: "Delikatny wisior w kształcie kwiatu. Personalizowany kolor.",
    tips: "Dodaj łańcuszek ze stali nierdzewnej. Kwiaty to zawsze hit.",
  },
  {
    id: 6,
    name: "Minimalist Bracelet",
    category: "jewelry",
    categoryName: "Biżuteria 3D",
    sellingPrice: 59,
    printCost: 10,
    marginPercent: 490,
    marginPLN: 49,
    printTime: "2-3h",
    filamentWeight: "20g",
    multicolor: false,
    difficulty: "easy",
    popularity: 7,
    links: {
      printables: "https://printables.com/model/60001",
    },
    description: "Nowoczesna bransoletka z możliwością regulacji.",
    tips: "TPU dla elastyczności lub PLA dla sztywności. Pomiar nadgarstka kluczowy.",
  },

  // LITOFANY
  {
    id: 7,
    name: "Personalized Lithophane Frame",
    category: "lithophane",
    categoryName: "Litofany",
    sellingPrice: 129,
    printCost: 26,
    marginPercent: 396,
    marginPLN: 103,
    printTime: "12-14h",
    filamentWeight: "180g",
    multicolor: false,
    difficulty: "medium",
    popularity: 10,
    links: {
      makerworld: "https://makerworld.com/en/models/70001",
      cults3d: "https://cults3d.com/en/3d-model/art/lithophane-frame",
    },
    description: "Zdjęcie 3D w eleganckiej ramce z podświetleniem LED.",
    tips: "Użyj białego PLA. Konwersja zdjęcia w ItsLitho lub Cura. LED z tyłu = magia!",
  },
  {
    id: 8,
    name: "Lithophane Lamp",
    category: "lithophane",
    categoryName: "Litofany",
    sellingPrice: 199,
    printCost: 40,
    marginPercent: 398,
    marginPLN: 159,
    printTime: "18-20h",
    filamentWeight: "280g",
    multicolor: false,
    difficulty: "hard",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/80001",
      printables: "https://printables.com/model/80001",
    },
    description: "Lampka nocna ze zdjęciem 3D. Prezent marzenie.",
    tips: "Drukuj 3-4 panele litofanowe. Dodaj gotową bazę lampy z USB.",
  },

  // ORGANIZERY
  {
    id: 9,
    name: "Desk Organizer Pro",
    category: "organizer",
    categoryName: "Organizery",
    sellingPrice: 149,
    printCost: 50,
    marginPercent: 198,
    marginPLN: 99,
    printTime: "15-18h",
    filamentWeight: "350g",
    multicolor: true,
    colors: 2,
    difficulty: "medium",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/90001",
      printables: "https://printables.com/model/90001",
      cults3d: "https://cults3d.com/en/3d-model/home/desk-organizer",
    },
    description: "Kompletny organizer biurkowy z szufladkami i przegródkami.",
    tips: "Drukuj w częściach dla większych wymiarów. Magnesy do szufladek = premium.",
  },
  {
    id: 10,
    name: "Gridfinity Modular System",
    category: "organizer",
    categoryName: "Organizery",
    sellingPrice: 89,
    printCost: 30,
    marginPercent: 197,
    marginPLN: 59,
    printTime: "10-12h",
    filamentWeight: "200g",
    multicolor: false,
    difficulty: "easy",
    popularity: 9,
    links: {
      printables: "https://printables.com/model/100001",
      thingiverse: "https://thingiverse.com/thing:100001",
    },
    description: "Modułowy system organizacji - kompatybilny z Gridfinity.",
    tips: "Sprzedawaj zestawy startowe. Klienci dokupują dodatkowe moduły.",
  },

  // MINIATURY
  {
    id: 11,
    name: "D&D Character Set (5 pcs)",
    category: "miniature",
    categoryName: "Miniatury",
    sellingPrice: 199,
    printCost: 35,
    marginPercent: 469,
    marginPLN: 164,
    printTime: "20-24h",
    filamentWeight: "150g",
    multicolor: true,
    colors: 8,
    difficulty: "hard",
    popularity: 10,
    links: {
      makerworld: "https://makerworld.com/en/models/110001",
      cults3d: "https://cults3d.com/en/3d-model/game/dd-characters",
    },
    description: "Zestaw 5 postaci do D&D z detalami wielokolorowymi.",
    tips: "H2D + AMS = game changer. Malowanie niepotrzebne przy 8 kolorach!",
  },
  {
    id: 12,
    name: "Dragon Miniature",
    category: "miniature",
    categoryName: "Miniatury",
    sellingPrice: 149,
    printCost: 25,
    marginPercent: 496,
    marginPLN: 124,
    printTime: "14-16h",
    filamentWeight: "100g",
    multicolor: true,
    colors: 6,
    difficulty: "hard",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/120001",
      printables: "https://printables.com/model/120001",
    },
    description: "Epicka miniatura smoka do gier i kolekcji.",
    tips: "Supporty kluczowe! Użyj soluble supports lub ręczne usuwanie.",
  },

  // ETUI NA TELEFON
  {
    id: 13,
    name: "iPhone 15 Pro Case Custom",
    category: "phone-case",
    categoryName: "Etui na Telefon",
    sellingPrice: 99,
    printCost: 25,
    marginPercent: 296,
    marginPLN: 74,
    printTime: "8-10h",
    filamentWeight: "80g",
    multicolor: true,
    colors: 4,
    difficulty: "medium",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/130001",
      printables: "https://printables.com/model/130001",
    },
    description: "Personalizowane etui z teksturą i wielokolorowym wzorem.",
    tips: "TPU lub TPU+PC composite. Dokładne wymiary z Apple specs.",
  },
  {
    id: 14,
    name: "Samsung Galaxy Card Holder Case",
    category: "phone-case",
    categoryName: "Etui na Telefon",
    sellingPrice: 119,
    printCost: 30,
    marginPercent: 297,
    marginPLN: 89,
    printTime: "10-12h",
    filamentWeight: "100g",
    multicolor: false,
    difficulty: "medium",
    popularity: 7,
    links: {
      printables: "https://printables.com/model/140001",
      cults3d: "https://cults3d.com/en/3d-model/gadget/phone-card-case",
    },
    description: "Etui z wbudowanym portfelem na karty.",
    tips: "Testuj kliknięcie karty - powinno być pewne ale nie za ciasne.",
  },

  // DEKORACJE ŚWIĄTECZNE
  {
    id: 15,
    name: "Christmas Ornament Set (12 pcs)",
    category: "decoration",
    categoryName: "Dekoracje Świąteczne",
    sellingPrice: 89,
    printCost: 30,
    marginPercent: 197,
    marginPLN: 59,
    printTime: "12-15h",
    filamentWeight: "200g",
    multicolor: true,
    colors: 4,
    difficulty: "easy",
    popularity: 10,
    links: {
      makerworld: "https://makerworld.com/en/models/150001",
      printables: "https://printables.com/model/150001",
    },
    description: "Zestaw 12 ozdób choinkowych w różnych wzorach.",
    tips: "Sezonowy hit! Zacznij drukować w październiku. Glitter filament = premium.",
  },
  {
    id: 16,
    name: "Halloween Pumpkin Light",
    category: "decoration",
    categoryName: "Dekoracje Świąteczne",
    sellingPrice: 69,
    printCost: 22,
    marginPercent: 214,
    marginPLN: 47,
    printTime: "8-10h",
    filamentWeight: "150g",
    multicolor: true,
    colors: 2,
    difficulty: "medium",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/160001",
      cults3d: "https://cults3d.com/en/3d-model/home/halloween-pumpkin",
    },
    description: "Podświetlana dynia z przerażającymi wzorami.",
    tips: "Pomarańczowy + czarny PLA. LED tealight w środku.",
  },

  // ARTICULATED TOYS
  {
    id: 17,
    name: "Articulated Shark",
    category: "articulated",
    categoryName: "Articulated Toys",
    sellingPrice: 79,
    printCost: 16,
    marginPercent: 394,
    marginPLN: 63,
    printTime: "6-8h",
    filamentWeight: "100g",
    multicolor: true,
    colors: 3,
    difficulty: "medium",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/170001",
      printables: "https://printables.com/model/170001",
    },
    description: "Realistyczny rekin z ruchomym ciałem i szczęką.",
    tips: "Szary + biały brzuch. Szczęka na zawiasie = WOW efekt!",
  },
  {
    id: 18,
    name: "Flexi Unicorn",
    category: "articulated",
    categoryName: "Articulated Toys",
    sellingPrice: 69,
    printCost: 14,
    marginPercent: 393,
    marginPLN: 55,
    printTime: "5-7h",
    filamentWeight: "85g",
    multicolor: true,
    colors: 4,
    difficulty: "medium",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/180001",
      cults3d: "https://cults3d.com/en/3d-model/art/flexi-unicorn",
    },
    description: "Magiczny jednorożec z ruchomą grzywą i ogonem.",
    tips: "Pastelowe kolory + tęczowa grzywa. Dzieci uwielbiają!",
  },

  // COSPLAY PROPS
  {
    id: 19,
    name: "LED Katana Prop",
    category: "cosplay",
    categoryName: "Cosplay Props",
    sellingPrice: 249,
    printCost: 65,
    marginPercent: 283,
    marginPLN: 184,
    printTime: "25-30h",
    filamentWeight: "400g",
    multicolor: true,
    colors: 3,
    difficulty: "hard",
    popularity: 9,
    links: {
      makerworld: "https://makerworld.com/en/models/190001",
      printables: "https://printables.com/model/190001",
    },
    description: "Podświetlany miecz katana z efektownym LED.",
    tips: "Przewody LED w środku. Złóż w częściach dla transportu.",
  },
  {
    id: 20,
    name: "Mandalorian Helmet",
    category: "cosplay",
    categoryName: "Cosplay Props",
    sellingPrice: 399,
    printCost: 100,
    marginPercent: 299,
    marginPLN: 299,
    printTime: "40-50h",
    filamentWeight: "600g",
    multicolor: false,
    difficulty: "hard",
    popularity: 10,
    links: {
      makerworld: "https://makerworld.com/en/models/200001",
      cults3d: "https://cults3d.com/en/3d-model/cosplay/mandalorian-helmet",
    },
    description: "Pełnowymiarowy hełm Mandalorianina. Ikona cosplayu.",
    links: {
      makerworld: "https://makerworld.com/en/models/200001",
      cults3d: "https://cults3d.com/en/3d-model/cosplay/mandalorian-helmet",
    },
    tips: "Drukuj w sekcjach. Szlifowanie i malowanie kluczowe. Padding w środku.",
  },

  // NARZĘDZIA I GADŻETY
  {
    id: 21,
    name: "Universal Phone Stand",
    category: "gadget",
    categoryName: "Narzędzia i Gadżety",
    sellingPrice: 49,
    printCost: 14,
    marginPercent: 250,
    marginPLN: 35,
    printTime: "4-5h",
    filamentWeight: "60g",
    multicolor: false,
    difficulty: "easy",
    popularity: 8,
    links: {
      printables: "https://printables.com/model/210001",
      thingiverse: "https://thingiverse.com/thing:210001",
    },
    description: "Uniwersalna podstawka pod telefon - regulowany kąt.",
    tips: "Testuj stabilność z różnymi telefonami. Gumowe nóżki = premium.",
  },
  {
    id: 22,
    name: "Cable Organizer Set",
    category: "gadget",
    categoryName: "Narzędzia i Gadżety",
    sellingPrice: 59,
    printCost: 17,
    marginPercent: 247,
    marginPLN: 42,
    printTime: "5-6h",
    filamentWeight: "70g",
    multicolor: true,
    colors: 3,
    difficulty: "easy",
    popularity: 7,
    links: {
      makerworld: "https://makerworld.com/en/models/220001",
      printables: "https://printables.com/model/220001",
    },
    description: "Zestaw organizerów na kable - 10 sztuk różnych rozmiarów.",
    tips: "Kolorowe kodowanie rozmiarów. Magnesy lub rzepy do zamykania.",
  },
  {
    id: 23,
    name: "Wall Mount Headphone Stand",
    category: "gadget",
    categoryName: "Narzędzia i Gadżety",
    sellingPrice: 69,
    printCost: 20,
    marginPercent: 245,
    marginPLN: 49,
    printTime: "6-8h",
    filamentWeight: "90g",
    multicolor: false,
    difficulty: "easy",
    popularity: 8,
    links: {
      makerworld: "https://makerworld.com/en/models/230001",
      printables: "https://printables.com/model/230001",
      cults3d: "https://cults3d.com/en/3d-model/home/headphone-stand",
    },
    description: "Elegancki uchwyt na słuchawki - montaż na ścianę.",
    tips: "Dodaj śruby i kołki do zestawu. Gaming aesthetic = wyższa cena.",
  },
];

export const multicolorPremium: Product[] = products.filter(
  (p) => p.multicolor && (p.colors || 0) >= 4
);

export const trends2026 = [
  {
    title: "Multicolor Revolution",
    description: "H2D + AMS zmieniają zasady gry. 8-kolorowe wydruki bez malowania.",
    impact: "+150% marży na produktach premium",
    icon: "Palette",
  },
  {
    title: "Articulated Toys Boom",
    description: "Ruchome zabawki bez składania to nowy standard.",
    impact: "Najpopularniejsza kategoria na TikToku",
    icon: "ToyBrick",
  },
  {
    title: "Personalizacja Masowa",
    description: "Klienci chcą produktów z ich imieniem, zdjęciem, kolorem.",
    impact: "+200% wartości przy personalizacji",
    icon: "UserCog",
  },
  {
    title: "Miniatures Gaming",
    description: "Wzrost popularności gier RPG i kolekcjonerskich figurek.",
    impact: "Najwyższe marże w branży",
    icon: "Dice5",
  },
];

export const salesPlatforms = [
  {
    name: "Etsy",
    url: "https://etsy.com",
    commission: "6.5% + opłaty",
    audience: "Globalna, kreatywna",
    bestFor: "Biżuteria, personalizacja",
    difficulty: "Średnia",
    potential: "Bardzo Wysoka",
  },
  {
    name: "Allegro",
    url: "https://allegro.pl",
    commission: "10-15%",
    audience: "Polska",
    bestFor: "Wszystkie kategorie",
    difficulty: "Niska",
    potential: "Wysoka",
  },
  {
    name: "OLX",
    url: "https://olx.pl",
    commission: "0% (płatne promowanie)",
    audience: "Polska, lokalna",
    bestFor: "Szybka sprzedaż lokalna",
    difficulty: "Bardzo niska",
    potential: "Średnia",
  },
  {
    name: "Amazon Handmade",
    url: "https://amazon.com/handmade",
    commission: "15%",
    audience: "Globalna",
    bestFor: "Produkty premium",
    difficulty: "Wysoka",
    potential: "Bardzo Wysoka",
  },
  {
    name: "Własna Strona",
    url: "Shopify/WooCommerce",
    commission: "0% (koszty hostingu)",
    audience: "Twoi klienci",
    bestFor: "Budowanie marki",
    difficulty: "Wysoka",
    potential: "Najwyższa",
  },
];

export const photographyTips = [
  {
    title: "Oświetlenie",
    description: "Użyj naturalnego światła lub softboxów. Unikaj cieni.",
    icon: "Sun",
  },
  {
    title: "Tło",
    description: "Neutralne, jednolite tło - białe, szare lub drewniane.",
    icon: "Square",
  },
  {
    title: "Kąty",
    description: "Pokazuj produkt z 3-4 perspektyw. Detale = zaufanie.",
    icon: "Camera",
  },
  {
    title: "Kontekst",
    description: "Pokaż produkt w użyciu - na biurku, w dłoni, w domu.",
    icon: "Image",
  },
];

export const descriptionTips = [
  {
    title: "Tytuł z kluczowymi słowami",
    description: "3D Printed Crystal Dragon | Articulated Fidget Toy | Multicolor | Gift",
    example: "✅ DOBRZE",
  },
  {
    title: "Pierwszy akapit - hook",
    description: "Zacznij od korzyści: 'Rozładowuj stres z naszym magicznym smokiem!'",
    example: "✅ DOBRZE",
  },
  {
    title: "Specyfikacja techniczna",
    description: "Wymiary, materiał, czas druku, kolory - wszystko dokładnie.",
    example: "✅ DOBRZE",
  },
  {
    title: "Call to Action",
    description: "'Dodaj do koszyka i ciesz się unikalną zabawką już za 3 dni!'",
    example: "✅ DOBRZE",
  },
];

export const pricingTips = [
  {
    title: "Koszt + Marża + Czas",
    formula: "Cena = (Koszt materiału × 2) + (Czas druku × stawka godzinowa) + Marża",
    example: "Koszt 18zł × 2 + 10h × 5zł + 100% = 89zł",
  },
  {
    title: "Badaj Konkurencję",
    description: "Sprawdź podobne produkty na Etsy/Allegro. Bądź w średniej.",
    example: "Jeśli konkurencja sprzedaje za 80-100zł, ustaw 89zł",
  },
  {
    title: "Psychologia Cen",
    description: "Używaj końcówek .99 lub .90. 89zł wygląda lepiej niż 90zł.",
    example: "89zł > 90zł w percepcji klienta",
  },
  {
    title: "Wartość Dodana",
    description: "Pakowanie prezentowe +20zł, Ekspresowa wysyłka +15zł",
    example: "Zwiększ wartość koszyka o 30-50%",
  },
];
