"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { multicolorPremium } from "./data";
import {
  Palette,
  Sparkles,
  TrendingUp,
  Clock,
  Weight,
  ExternalLink,
  Zap,
  Star,
  Info,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export function MulticolorPremium() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-purple-900/50 via-zinc-900 to-pink-900/50 border border-purple-500/30 p-6">
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-pink-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg">
              <Palette className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                Multicolor Premium
              </h2>
              <p className="text-purple-300">
                Produkty idealne dla H2D + AMS
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-4 mt-4">
            <Badge
              variant="outline"
              className="bg-purple-500/10 text-purple-300 border-purple-500/30 px-3 py-1"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              8-kolorowe wydruki
            </Badge>
            <Badge
              variant="outline"
              className="bg-pink-500/10 text-pink-300 border-pink-500/30 px-3 py-1"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Wysoka marża premium
            </Badge>
            <Badge
              variant="outline"
              className="bg-amber-500/10 text-amber-300 border-amber-500/30 px-3 py-1"
            >
              <Zap className="w-4 h-4 mr-2" />
              Bez malowania
            </Badge>
          </div>

          <div className="mt-4 p-3 bg-zinc-950/50 rounded-lg border border-purple-500/20">
            <div className="flex items-start gap-2">
              <Info className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-zinc-400">
                Produkty multicolor to przyszłość druku 3D. Dzięki drukarkom
                wielomateriałowym jak Bambu Lab H2D z AMS, możesz tworzyć
                kolorowe produkty bez czasochłonnego malowania. To oznacza
                wyższą jakość, szybszą produkcję i znacznie wyższe marże!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {multicolorPremium.map((product) => (
          <Card
            key={product.id}
            className="group bg-zinc-900/80 border-zinc-800 hover:border-purple-500/50 transition-all duration-300 overflow-hidden"
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-lg text-zinc-100 truncate group-hover:text-purple-400 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-zinc-500">
                    {product.categoryName}
                  </p>
                </div>
                <Badge
                  variant="outline"
                  className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30"
                >
                  <Palette className="w-3 h-3 mr-1" />
                  {product.colors}K
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Price Section */}
              <div className="grid grid-cols-3 gap-2 p-3 bg-zinc-950/50 rounded-lg">
                <div className="text-center">
                  <p className="text-xs text-zinc-500 mb-1">Cena</p>
                  <p className="text-lg font-bold text-emerald-400">
                    {product.sellingPrice} zł
                  </p>
                </div>
                <div className="text-center border-x border-zinc-800">
                  <p className="text-xs text-zinc-500 mb-1">Koszt</p>
                  <p className="text-lg font-semibold text-zinc-300">
                    {product.printCost} zł
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-zinc-500 mb-1">Zysk</p>
                  <p className="text-lg font-bold text-purple-400">
                    {product.marginPLN} zł
                  </p>
                </div>
              </div>

              {/* Margin Badge */}
              <div className="flex items-center justify-center">
                <Badge
                  variant="outline"
                  className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-purple-400 border-purple-500/30 px-4 py-1"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Marża: {product.marginPercent}%
                </Badge>
              </div>

              {/* Print Details */}
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center gap-2 text-zinc-400">
                  <Clock className="w-4 h-4 text-zinc-500" />
                  <span>{product.printTime}</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-400">
                  <Weight className="w-4 h-4 text-zinc-500" />
                  <span>{product.filamentWeight}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-zinc-400 line-clamp-2">
                {product.description}
              </p>

              {/* Links */}
              <div className="pt-2 border-t border-zinc-800">
                <p className="text-xs text-zinc-500 mb-2 flex items-center gap-1">
                  <ExternalLink className="w-3 h-3" />
                  Modele 3D:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {product.links.makerworld && (
                    <a
                      href={product.links.makerworld}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-orange-500/20 hover:text-orange-400 hover:border-orange-500/50"
                      >
                        <Zap className="w-3 h-3 mr-1" />
                        MakerWorld
                      </Button>
                    </a>
                  )}
                  {product.links.printables && (
                    <a
                      href={product.links.printables}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-orange-500/20 hover:text-orange-400 hover:border-orange-500/50"
                      >
                        <Star className="w-3 h-3 mr-1" />
                        Printables
                      </Button>
                    </a>
                  )}
                  {product.links.cults3d && (
                    <a
                      href={product.links.cults3d}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-purple-500/20 hover:text-purple-400 hover:border-purple-500/50"
                      >
                        <Sparkles className="w-3 h-3 mr-1" />
                        Cults3D
                      </Button>
                    </a>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* H2D + AMS Info */}
      <Card className="bg-gradient-to-r from-zinc-900 to-zinc-900/50 border-zinc-800">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-purple-500/10 rounded-lg">
              <Zap className="w-6 h-6 text-purple-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-zinc-100 mb-2">
                Dlaczego H2D + AMS?
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-3 bg-zinc-950/50 rounded-lg">
                  <p className="font-medium text-purple-400 mb-1">
                    8 Kolorów Jednocześnie
                  </p>
                  <p className="text-sm text-zinc-400">
                    Drukuj z 8 różnych filamentów w jednym wydruku bez
                    przerywania.
                  </p>
                </div>
                <div className="p-3 bg-zinc-950/50 rounded-lg">
                  <p className="font-medium text-pink-400 mb-1">
                    Automatyczna Zmiana
                  </p>
                  <p className="text-sm text-zinc-400">
                    AMS automatycznie przełącza kolory - zero interwencji.
                  </p>
                </div>
                <div className="p-3 bg-zinc-950/50 rounded-lg">
                  <p className="font-medium text-amber-400 mb-1">
                    Wyższa Marża
                  </p>
                  <p className="text-sm text-zinc-400">
                    Produkty multicolor sprzedają się za 50-100% więcej.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
