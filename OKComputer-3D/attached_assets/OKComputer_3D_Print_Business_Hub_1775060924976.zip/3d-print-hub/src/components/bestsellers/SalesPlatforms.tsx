"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { salesPlatforms } from "./data";
import {
  ExternalLink,
  Users,
  Target,
  BarChart3,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Globe,
  ShoppingBag,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function SalesPlatforms() {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Bardzo niska":
        return "bg-green-500/20 text-green-400 border-green-500/30";
      case "Niska":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30";
      case "Średnia":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case "Wysoka":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30";
      case "Bardzo Wysoka":
        return "bg-purple-500/20 text-purple-400 border-purple-500/30";
      default:
        return "bg-zinc-500/20 text-zinc-400";
    }
  };

  const getPotentialColor = (potential: string) => {
    switch (potential) {
      case "Średnia":
        return "text-yellow-400";
      case "Wysoka":
        return "text-emerald-400";
      case "Bardzo Wysoka":
        return "text-purple-400";
      case "Najwyższa":
        return "text-amber-400";
      default:
        return "text-zinc-400";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-emerald-500/10 rounded-lg">
          <ShoppingBag className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-zinc-100">
            Platformy Sprzedaży
          </h2>
          <p className="text-zinc-500">
            Gdzie sprzedawać produkty z druku 3D
          </p>
        </div>
      </div>

      {/* Platforms Table */}
      <Card className="bg-zinc-900/80 border-zinc-800 overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-zinc-800 hover:bg-transparent">
                <TableHead className="text-zinc-400">Platforma</TableHead>
                <TableHead className="text-zinc-400">Prowizja</TableHead>
                <TableHead className="text-zinc-400">Grupa docelowa</TableHead>
                <TableHead className="text-zinc-400">Idealne dla</TableHead>
                <TableHead className="text-zinc-400">Trudność</TableHead>
                <TableHead className="text-zinc-400">Potencjał</TableHead>
                <TableHead className="text-zinc-400 text-right">
                  Akcja
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {salesPlatforms.map((platform, index) => (
                <TableRow
                  key={index}
                  className="border-zinc-800 hover:bg-zinc-800/50"
                >
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-zinc-500" />
                      <span className="font-medium text-zinc-100">
                        {platform.name}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className="bg-zinc-800/50 text-zinc-300 border-zinc-700"
                    >
                      {platform.commission}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-sm text-zinc-400">
                      <Users className="w-3 h-3" />
                      {platform.audience}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 text-sm text-zinc-400">
                      <Target className="w-3 h-3" />
                      {platform.bestFor}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={getDifficultyColor(platform.difficulty)}
                    >
                      {platform.difficulty}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div
                      className={`flex items-center gap-1 font-medium ${getPotentialColor(
                        platform.potential
                      )}`}
                    >
                      <TrendingUp className="w-4 h-4" />
                      {platform.potential}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <a
                      href={platform.url}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs bg-zinc-800/50 border-zinc-700 hover:bg-emerald-500/20 hover:text-emerald-400 hover:border-emerald-500/50"
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Odwiedź
                      </Button>
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Tips Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-zinc-900/80 border-zinc-800">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-zinc-100">
                Zacznij od Allegro
              </h3>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-zinc-400">
              Najniższy próg wejścia dla polskich sprzedających. Duża baza
              klientów i znajoma platforma. Idealne na start.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/80 border-zinc-800">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-amber-400" />
              <h3 className="font-semibold text-zinc-100">
                Rozszerz na Etsy
              </h3>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-zinc-400">
              Globalny zasięg i klienteli szukająca unikalnych, ręcznie
              robionych produktów. Wyższe ceny i marże.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/80 border-zinc-800">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-purple-400" />
              <h3 className="font-semibold text-zinc-100">
                Własna Strona = Cel
              </h3>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-zinc-400">
              Ostateczny cel - własna marka i zero prowizji. Wymaga czasu i
              inwestycji w marketing, ale daje największą kontrolę.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Strategy Card */}
      <Card className="bg-gradient-to-r from-emerald-500/10 via-zinc-900 to-zinc-900 border-emerald-500/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-emerald-500/20 rounded-lg">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-zinc-100 mb-2">
                Rekomendowana Strategia
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-zinc-400">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">
                    1
                  </span>
                  <span>
                    <strong className="text-zinc-300">Miesiąc 1-2:</strong>{" "}
                    Start na Allegro - testuj produkty i ceny
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-400">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">
                    2
                  </span>
                  <span>
                    <strong className="text-zinc-300">Miesiąc 3-4:</strong>{" "}
                    Dodaj Etsy - globalna ekspansja
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-400">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">
                    3
                  </span>
                  <span>
                    <strong className="text-zinc-300">Miesiąc 6+:</strong>{" "}
                    Rozważ własną stronę (Shopify/WooCommerce)
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-400">
                  <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">
                    4
                  </span>
                  <span>
                    <strong className="text-zinc-300">Rok 2+:</strong>{" "}
                    Amazon Handmade dla skalowania
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
