"use client";

import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { products, Category } from "./data";
import { ProductCard } from "./ProductCard";
import { CategoryFilter } from "./CategoryFilter";
import { MulticolorPremium } from "./MulticolorPremium";
import { Trends2026 } from "./Trends2026";
import { SalesPlatforms } from "./SalesPlatforms";
import { TipsSection } from "./TipsSection";
import {
  TrendingUp,
  Search,
  Package,
  Palette,
  BarChart3,
  Store,
  Lightbulb,
  Sparkles,
  Filter,
} from "lucide-react";

export function BestsellersModule() {
  const [selectedCategory, setSelectedCategory] = useState<Category | "all">(
    "all"
  );
  const [searchQuery, setSearchQuery] = useState("");

  // Calculate product counts per category
  const productCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    products.forEach((product) => {
      counts[product.category] = (counts[product.category] || 0) + 1;
    });
    return counts;
  }, []);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        selectedCategory === "all" || product.category === selectedCategory;
      const matchesSearch =
        searchQuery === "" ||
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.categoryName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  // Calculate statistics
  const stats = useMemo(() => {
    const totalProducts = products.length;
    const multicolorProducts = products.filter((p) => p.multicolor).length;
    const avgMargin = Math.round(
      products.reduce((acc, p) => acc + p.marginPercent, 0) / totalProducts
    );
    const totalPotentialProfit = products.reduce(
      (acc, p) => acc + p.marginPLN,
      0
    );

    return {
      totalProducts,
      multicolorProducts,
      avgMargin,
      totalPotentialProfit,
    };
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950">
      {/* Header */}
      <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-amber-500/10 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-amber-400" />
                </div>
                <h1 className="text-3xl font-bold text-zinc-100">
                  Bestsellery 3D
                </h1>
              </div>
              <p className="text-zinc-500 max-w-2xl">
                TOP 23 produktów które najlepiej się sprzedają w druku 3D.
                Gotowe kalkulacje cen, linki do modeli i porady eksperta.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge
                variant="outline"
                className="bg-amber-500/10 text-amber-400 border-amber-500/30 px-3 py-1"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                3D Print Business Hub
              </Badge>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Package className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-zinc-100">
                      {stats.totalProducts}
                    </p>
                    <p className="text-xs text-zinc-500">Produktów</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Palette className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-zinc-100">
                      {stats.multicolorProducts}
                    </p>
                    <p className="text-xs text-zinc-500">Multicolor</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/10 rounded-lg">
                    <BarChart3 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-zinc-100">
                      {stats.avgMargin}%
                    </p>
                    <p className="text-xs text-zinc-500">Śr. Marża</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900/50 border-zinc-800">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-amber-500/10 rounded-lg">
                    <TrendingUp className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-zinc-100">
                      {stats.totalPotentialProfit} zł
                    </p>
                    <p className="text-xs text-zinc-500">Suma Zysków</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="products" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-zinc-900/80 border border-zinc-800 mb-6">
            <TabsTrigger
              value="products"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Package className="w-4 h-4 mr-2" />
              Produkty
            </TabsTrigger>
            <TabsTrigger
              value="multicolor"
              className="data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <Palette className="w-4 h-4 mr-2" />
              Multicolor
            </TabsTrigger>
            <TabsTrigger
              value="trends"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Trendy 2026
            </TabsTrigger>
            <TabsTrigger
              value="platforms"
              className="data-[state=active]:bg-emerald-500 data-[state=active]:text-zinc-950"
            >
              <Store className="w-4 h-4 mr-2" />
              Platformy
            </TabsTrigger>
            <TabsTrigger
              value="tips"
              className="data-[state=active]:bg-blue-500 data-[state=active]:text-white"
            >
              <Lightbulb className="w-4 h-4 mr-2" />
              Porady
            </TabsTrigger>
          </TabsList>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <Input
                  placeholder="Szukaj produktów..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-500"
                />
              </div>
            </div>

            {/* Category Filter */}
            <CategoryFilter
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
              productCounts={productCounts}
            />

            {/* Results Count */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-zinc-500" />
                <p className="text-sm text-zinc-500">
                  Znaleziono{" "}
                  <span className="text-amber-400 font-medium">
                    {filteredProducts.length}
                  </span>{" "}
                  produktów
                </p>
              </div>
              {selectedCategory !== "all" && (
                <Badge
                  variant="outline"
                  className="bg-zinc-800/50 text-zinc-300 border-zinc-700 cursor-pointer hover:bg-zinc-700"
                  onClick={() => setSelectedCategory("all")}
                >
                  Wyczyść filtr ×
                </Badge>
              )}
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <Card className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-12 text-center">
                  <Package className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-zinc-400 mb-2">
                    Nie znaleziono produktów
                  </h3>
                  <p className="text-sm text-zinc-500">
                    Spróbuj zmienić kryteria wyszukiwania lub wyczyść filtry
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Multicolor Tab */}
          <TabsContent value="multicolor">
            <MulticolorPremium />
          </TabsContent>

          {/* Trends Tab */}
          <TabsContent value="trends">
            <Trends2026 />
          </TabsContent>

          {/* Platforms Tab */}
          <TabsContent value="platforms">
            <SalesPlatforms />
          </TabsContent>

          {/* Tips Tab */}
          <TabsContent value="tips">
            <TipsSection />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
