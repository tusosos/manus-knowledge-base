"use client";

import { motion } from "framer-motion";
import {
  Package,
  AlertTriangle,
  ShoppingCart,
  TrendingDown,
  MoreHorizontal,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface FilamentItem {
  id: string;
  name: string;
  color: string;
  colorHex: string;
  weight: number;
  maxWeight: number;
  type: string;
}

interface InventoryAlertsProps {
  items?: FilamentItem[];
  threshold?: number;
  delay?: number;
}

const defaultItems: FilamentItem[] = [
  {
    id: "1",
    name: "PLA Premium",
    color: "Czerwony",
    colorHex: "#ef4444",
    weight: 125,
    maxWeight: 1000,
    type: "PLA",
  },
  {
    id: "2",
    name: "PETG Eco",
    color: "Czarny",
    colorHex: "#1f2937",
    weight: 85,
    maxWeight: 1000,
    type: "PETG",
  },
  {
    id: "3",
    name: "ABS Pro",
    color: "Biały",
    colorHex: "#f9fafb",
    weight: 45,
    maxWeight: 1000,
    type: "ABS",
  },
  {
    id: "4",
    name: "TPU Flexible",
    color: "Niebieski",
    colorHex: "#3b82f6",
    weight: 156,
    maxWeight: 500,
    type: "TPU",
  },
  {
    id: "5",
    name: "PLA Silk",
    color: "Złoty",
    colorHex: "#fbbf24",
    weight: 67,
    maxWeight: 1000,
    type: "PLA",
  },
];

export function InventoryAlerts({
  items = defaultItems,
  threshold = 200,
  delay = 0,
}: InventoryAlertsProps) {
  const lowStockItems = items.filter((item) => item.weight < threshold);
  const criticalItems = items.filter((item) => item.weight < threshold / 2);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  Alerty Magazynu
                </CardTitle>
                <p className="text-xs text-gray-500">
                  {lowStockItems.length} filamentów poniżej {threshold}g
                </p>
              </div>
            </div>
            <button className="p-2 rounded-lg hover:bg-[#2a2a2a] transition-colors">
              <MoreHorizontal className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </CardHeader>

        <CardContent>
          {/* Alert banner */}
          {criticalItems.length > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: delay * 0.1 + 0.1 }}
              className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
            >
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-red-400" />
                <span className="text-sm text-red-400">
                  <strong>{criticalItems.length}</strong> filamentów wymaga
                  natychmiastowej zamówienia!
                </span>
              </div>
            </motion.div>
          )}

          {/* Items list */}
          <div className="space-y-3">
            {lowStockItems.map((item, index) => {
              const percentage = Math.round((item.weight / item.maxWeight) * 100);
              const isCritical = item.weight < threshold / 2;

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.3,
                    delay: delay * 0.1 + index * 0.05,
                  }}
                  className="group"
                >
                  <div className="p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-red-500/30 transition-all duration-300">
                    <div className="flex items-center gap-3">
                      {/* Color indicator */}
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 border-2 border-[#2a2a2a]"
                        style={{ backgroundColor: `${item.colorHex}20` }}
                      >
                        <div
                          className="w-5 h-5 rounded-full border-2 border-[#1a1a1a]"
                          style={{ backgroundColor: item.colorHex }}
                        />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-white font-medium text-sm">
                              {item.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {item.color} • {item.type}
                            </p>
                          </div>
                          <div className="text-right">
                            <p
                              className={`font-['JetBrains_Mono'] font-bold ${
                                isCritical ? "text-red-400" : "text-[#fbbf24]"
                              }`}
                            >
                              {item.weight}g
                            </p>
                            <p className="text-xs text-gray-500">
                              z {item.maxWeight}g
                            </p>
                          </div>
                        </div>

                        {/* Progress bar */}
                        <div className="mt-2">
                          <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                            <motion.div
                              className={`h-full rounded-full ${
                                isCritical
                                  ? "bg-red-500"
                                  : percentage < 20
                                  ? "bg-[#fbbf24]"
                                  : "bg-yellow-500"
                              }`}
                              initial={{ width: 0 }}
                              animate={{ width: `${percentage}%` }}
                              transition={{
                                duration: 0.6,
                                delay: delay * 0.1 + index * 0.05 + 0.2,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Action buttons */}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay * 0.1 + 0.3 }}
              className="flex items-center justify-center gap-2 py-2.5 text-sm text-white bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 rounded-lg transition-all duration-300 font-medium"
            >
              <ShoppingCart className="w-4 h-4" />
              Zamów brakujące
            </motion.button>
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay * 0.1 + 0.35 }}
              className="flex items-center justify-center gap-2 py-2.5 text-sm text-[#fbbf24] hover:text-[#f59e0b] border border-[#2a2a2a] hover:border-[#fbbf24]/50 rounded-lg transition-all duration-300 font-medium"
            >
              <Package className="w-4 h-4" />
              Zarządzaj magazynem
            </motion.button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
