# Dashboard Components - 3D Print Business Hub

Kompleksowy zestaw komponentów dashboardu dla aplikacji do zarządzania biznesem druku 3D.

## 📁 Struktura

```
dashboard/
├── KPICard.tsx          # Karty KPI z trendami i progress bar
├── PrinterStatus.tsx    # Status drukarki H2D z temperaturą
├── KanbanSummary.tsx    # Podsumowanie zadań Kanban
├── ProjectsStatus.tsx   # Pipeline projektów
├── RecentPrints.tsx     # Lista ostatnich wydruków
├── RecentQuotes.tsx     # Lista ostatnich wycen
├── InventoryAlerts.tsx  # Alerty magazynu filamentów
├── MainDashboard.tsx    # Główny komponent dashboardu
└── index.ts             # Eksporty
```

## 🎨 Design System

### Kolory
- **Background**: `#0a0a0a` (główny), `#1a1a1a` (karty)
- **Akcenty**: `#fbbf24` (amber)
- **Bordery**: `#2a2a2a`
- **Statusy**: 
  - Green: `#22c55e` (sukces)
  - Red: `#ef4444` (błąd/krytyczne)
  - Blue: `#3b82f6` (info)
  - Gray: `#6b7280` (neutralne)

### Fonty
- **Liczby**: `JetBrains Mono`
- **Tekst**: `Inter`

## 🧩 Komponenty

### KPICard
```tsx
<KPICard
  title="Przychód miesięczny"
  value="24,580"
  suffix="zł"
  icon={DollarSign}
  trend={12.5}
  trendLabel="vs. poprzedni miesiąc"
  progress={78} // opcjonalnie
/>
```

### PrinterStatus
```tsx
<PrinterStatus
  printerName="H2D Printer"
  state="printing" // 'online' | 'offline' | 'printing' | 'error'
  currentPrint="Nazwa wydruku"
  estimatedTime="2h 15min"
  progress={67}
  temperature={{ nozzle: 210, bed: 60 }}
/>
```

### KanbanSummary
```tsx
<KanbanSummary
  columns={[
    { id: "todo", title: "Do zrobienia", count: 12, ... },
    { id: "in-progress", title: "W trakcie", count: 5, ... },
    { id: "done", title: "Gotowe", count: 28, ... },
  ]}
/>
```

### ProjectsStatus
```tsx
<ProjectsStatus
  stages={[
    { id: "idea", title: "Pomysł", count: 8, color: "#6b7280" },
    { id: "prototype", title: "Prototyp", count: 5, color: "#fbbf24" },
    { id: "testing", title: "Testowany", count: 3, color: "#3b82f6" },
    { id: "ready", title: "Gotowy", count: 12, color: "#22c55e" },
  ]}
/>
```

### RecentPrints
```tsx
<RecentPrints
  prints={[
    { id: "1", name: "...", duration: "4h 30min", status: "completed", ... },
  ]}
/>
```

### RecentQuotes
```tsx
<RecentQuotes
  quotes={[
    { id: "1", client: "...", amount: 1250, status: "pending", ... },
  ]}
/>
```

### InventoryAlerts
```tsx
<InventoryAlerts
  items={[
    { id: "1", name: "PLA Premium", color: "Czerwony", weight: 125, ... },
  ]}
  threshold={200}
/>
```

## 🚀 Użycie

```tsx
import { MainDashboard } from "@/components/dashboard";

export default function Page() {
  return <MainDashboard />;
}
```

## 📦 Zależności

- `framer-motion` - animacje
- `lucide-react` - ikony
- `@/components/ui/*` - shadcn/ui komponenty
