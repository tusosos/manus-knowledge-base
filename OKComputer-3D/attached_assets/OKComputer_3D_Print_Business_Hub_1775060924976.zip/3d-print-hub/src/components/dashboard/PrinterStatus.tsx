"use client";

import { motion } from "framer-motion";
import {
  Printer,
  Clock,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type PrinterState = "online" | "offline" | "printing" | "error";

interface PrinterStatusProps {
  printerName?: string;
  state?: PrinterState;
  currentPrint?: string;
  estimatedTime?: string;
  progress?: number;
  temperature?: {
    nozzle: number;
    bed: number;
  };
  delay?: number;
}

const stateConfig: Record<
  PrinterState,
  { label: string; color: string; icon: typeof CheckCircle2 }
> = {
  online: {
    label: "Online",
    color: "bg-green-500",
    icon: CheckCircle2,
  },
  offline: {
    label: "Offline",
    color: "bg-gray-500",
    icon: AlertCircle,
  },
  printing: {
    label: "Drukowanie",
    color: "bg-[#fbbf24]",
    icon: Loader2,
  },
  error: {
    label: "Błąd",
    color: "bg-red-500",
    icon: AlertCircle,
  },
};

export function PrinterStatus({
  printerName = "H2D Printer",
  state = "printing",
  currentPrint = "Uchwyt na słuchawki v2",
  estimatedTime = "2h 15min",
  progress = 67,
  temperature = { nozzle: 210, bed: 60 },
  delay = 0,
}: PrinterStatusProps) {
  const config = stateConfig[state];
  const StatusIcon = config.icon;
  const isPrinting = state === "printing";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a] overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#2a2a2a] flex items-center justify-center">
                <Printer className="w-5 h-5 text-[#fbbf24]" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  {printerName}
                </CardTitle>
                <p className="text-xs text-gray-500">Bambu Lab H2D</p>
              </div>
            </div>
            <Badge
              variant="secondary"
              className={`${config.color}/10 text-${
                config.color.split("-")[1]
              }-400 border-0 flex items-center gap-1.5`}
            >
              <span className={`w-2 h-2 rounded-full ${config.color} ${isPrinting ? "animate-pulse" : ""}`} />
              {config.label}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Current Print Info */}
          {isPrinting && (
            <>
              <div className="bg-[#0a0a0a] rounded-lg p-4 border border-[#2a2a2a]">
                <div className="flex items-start gap-3">
                  <FileText className="w-4 h-4 text-[#fbbf24] mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-500 mb-1">Aktualny wydruk</p>
                    <p className="text-white font-medium truncate">
                      {currentPrint}
                    </p>
                  </div>
                </div>
              </div>

              {/* Progress Section */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2 text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Pozostało: {estimatedTime}</span>
                  </div>
                  <span className="text-[#fbbf24] font-['JetBrains_Mono'] font-bold">
                    {progress}%
                  </span>
                </div>
                <div className="h-3 bg-[#2a2a2a] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#fbbf24] via-[#f59e0b] to-[#fbbf24] rounded-full relative"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 1, delay: delay * 0.1 + 0.3 }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse" />
                  </motion.div>
                </div>
              </div>

              {/* Temperature */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#0a0a0a] rounded-lg p-3 border border-[#2a2a2a]">
                  <p className="text-xs text-gray-500 mb-1">Dysza</p>
                  <p className="text-white font-['JetBrains_Mono'] text-lg">
                    {temperature.nozzle}°C
                  </p>
                </div>
                <div className="bg-[#0a0a0a] rounded-lg p-3 border border-[#2a2a2a]">
                  <p className="text-xs text-gray-500 mb-1">Stół</p>
                  <p className="text-white font-['JetBrains_Mono'] text-lg">
                    {temperature.bed}°C
                  </p>
                </div>
              </div>
            </>
          )}

          {/* Offline State */}
          {state === "offline" && (
            <div className="text-center py-8">
              <AlertCircle className="w-12 h-12 text-gray-500 mx-auto mb-3" />
              <p className="text-gray-400">Drukarka offline</p>
              <p className="text-sm text-gray-600 mt-1">
                Sprawdź połączenie z siecią
              </p>
            </div>
          )}

          {/* Online/Idle State */}
          {state === "online" && (
            <div className="text-center py-8">
              <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-3" />
              <p className="text-white font-medium">Gotowa do pracy</p>
              <p className="text-sm text-gray-500 mt-1">
                Ostatni wydruk: 2h temu
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
