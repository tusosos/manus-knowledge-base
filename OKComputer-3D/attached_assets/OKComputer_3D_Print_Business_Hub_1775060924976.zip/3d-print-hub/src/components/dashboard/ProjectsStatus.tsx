"use client";

import { motion } from "framer-motion";
import {
  Lightbulb,
  Hammer,
  FlaskConical,
  Rocket,
  FolderKanban,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ProjectStage {
  id: string;
  title: string;
  count: number;
  icon: typeof Lightbulb;
  color: string;
}

interface ProjectsStatusProps {
  stages?: ProjectStage[];
  delay?: number;
}

const defaultStages: ProjectStage[] = [
  {
    id: "idea",
    title: "Pomysł",
    count: 8,
    icon: Lightbulb,
    color: "#6b7280",
  },
  {
    id: "prototype",
    title: "Prototyp",
    count: 5,
    icon: Hammer,
    color: "#fbbf24",
  },
  {
    id: "testing",
    title: "Testowany",
    count: 3,
    icon: FlaskConical,
    color: "#3b82f6",
  },
  {
    id: "ready",
    title: "Gotowy",
    count: 12,
    icon: Rocket,
    color: "#22c55e",
  },
];

export function ProjectsStatus({
  stages = defaultStages,
  delay = 0,
}: ProjectsStatusProps) {
  const totalProjects = stages.reduce((sum, stage) => sum + stage.count, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#2a2a2a] flex items-center justify-center">
                <FolderKanban className="w-5 h-5 text-[#fbbf24]" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  Projekty
                </CardTitle>
                <p className="text-xs text-gray-500">
                  {totalProjects} projektów łącznie
                </p>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          {/* Pipeline visualization */}
          <div className="relative">
            {/* Connection line */}
            <div className="absolute top-6 left-8 right-8 h-0.5 bg-[#2a2a2a] hidden sm:block" />

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stages.map((stage, index) => {
                const Icon = stage.icon;
                const isLast = index === stages.length - 1;

                return (
                  <motion.div
                    key={stage.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      duration: 0.3,
                      delay: delay * 0.1 + index * 0.08,
                    }}
                    className="relative"
                  >
                    <div className="flex flex-col items-center text-center group cursor-pointer">
                      {/* Icon circle */}
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-300 z-10 relative"
                        style={{
                          backgroundColor: `${stage.color}15`,
                          borderColor: stage.color,
                        }}
                      >
                        <Icon
                          className="w-5 h-5 transition-transform group-hover:scale-110"
                          style={{ color: stage.color }}
                        />
                      </div>

                      {/* Count badge */}
                      <Badge
                        className="mt-3 mb-1 font-['JetBrains_Mono'] text-sm px-2 py-0.5"
                        style={{
                          backgroundColor: `${stage.color}20`,
                          color: stage.color,
                          borderColor: `${stage.color}40`,
                        }}
                        variant="outline"
                      >
                        {stage.count}
                      </Badge>

                      {/* Title */}
                      <span className="text-xs text-gray-400 group-hover:text-white transition-colors">
                        {stage.title}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Summary stats */}
          <div className="mt-6 pt-4 border-t border-[#2a2a2a]">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#0a0a0a] rounded-lg p-3 border border-[#2a2a2a]">
                <p className="text-xs text-gray-500 mb-1">W produkcji</p>
                <p className="text-white font-['JetBrains_Mono'] text-lg">
                  {stages
                    .filter((s) => s.id === "prototype" || s.id === "testing")
                    .reduce((sum, s) => sum + s.count, 0)}
                </p>
              </div>
              <div className="bg-[#0a0a0a] rounded-lg p-3 border border-[#2a2a2a]">
                <p className="text-xs text-gray-500 mb-1">Ukończone</p>
                <p className="text-green-400 font-['JetBrains_Mono'] text-lg">
                  {stages.find((s) => s.id === "ready")?.count || 0}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
