"use client";

import { motion } from "framer-motion";
import { ClipboardList, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface KanbanColumn {
  id: string;
  title: string;
  count: number;
  color: string;
  bgColor: string;
  icon: typeof ClipboardList;
}

interface KanbanSummaryProps {
  columns?: KanbanColumn[];
  delay?: number;
}

const defaultColumns: KanbanColumn[] = [
  {
    id: "todo",
    title: "Do zrobienia",
    count: 12,
    color: "text-gray-400",
    bgColor: "bg-gray-500/10",
    icon: ClipboardList,
  },
  {
    id: "in-progress",
    title: "W trakcie",
    count: 5,
    color: "text-[#fbbf24]",
    bgColor: "bg-[#fbbf24]/10",
    icon: Clock,
  },
  {
    id: "done",
    title: "Gotowe",
    count: 28,
    color: "text-green-400",
    bgColor: "bg-green-500/10",
    icon: CheckCircle2,
  },
];

export function KanbanSummary({
  columns = defaultColumns,
  delay = 0,
}: KanbanSummaryProps) {
  const totalTasks = columns.reduce((sum, col) => sum + col.count, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#2a2a2a] flex items-center justify-center">
                <ClipboardList className="w-5 h-5 text-[#fbbf24]" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  Zadania
                </CardTitle>
                <p className="text-xs text-gray-500">
                  {totalTasks} zadań łącznie
                </p>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-3">
            {columns.map((column, index) => {
              const Icon = column.icon;
              const percentage = Math.round((column.count / totalTasks) * 100);

              return (
                <motion.div
                  key={column.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: delay * 0.1 + index * 0.1 }}
                  className="group"
                >
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/30 transition-all duration-300 cursor-pointer">
                    {/* Icon */}
                    <div
                      className={`w-10 h-10 rounded-lg ${column.bgColor} flex items-center justify-center flex-shrink-0`}
                    >
                      <Icon className={`w-5 h-5 ${column.color}`} />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-300 font-medium">
                          {column.title}
                        </span>
                        <span
                          className={`text-lg font-bold font-['JetBrains_Mono'] ${column.color}`}
                        >
                          {column.count}
                        </span>
                      </div>

                      {/* Progress bar */}
                      <div className="h-1.5 bg-[#2a2a2a] rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full rounded-full ${
                            column.id === "todo"
                              ? "bg-gray-500"
                              : column.id === "in-progress"
                              ? "bg-[#fbbf24]"
                              : "bg-green-500"
                          }`}
                          initial={{ width: 0 }}
                          animate={{ width: `${percentage}%` }}
                          transition={{
                            duration: 0.6,
                            delay: delay * 0.1 + index * 0.1 + 0.2,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Quick stats */}
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <AlertCircle className="w-3 h-3" />
              <span>3 zadania wymagają uwagi</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
