"use client";

import { motion } from "framer-motion";
import {
  DollarSign,
  ShoppingCart,
  Users,
  Clock,
  Bell,
  Settings,
  Search,
  Menu,
} from "lucide-react";
import { KPICard } from "./KPICard";
import { PrinterStatus } from "./PrinterStatus";
import { KanbanSummary } from "./KanbanSummary";
import { ProjectsStatus } from "./ProjectsStatus";
import { RecentPrints } from "./RecentPrints";
import { RecentQuotes } from "./RecentQuotes";
import { InventoryAlerts } from "./InventoryAlerts";

// KPI Data
const kpiData = [
  {
    title: "Przychód miesięczny",
    value: "24,580",
    suffix: "zł",
    icon: DollarSign,
    trend: 12.5,
    trendLabel: "vs. poprzedni miesiąc",
  },
  {
    title: "Liczba zamówień",
    value: "48",
    suffix: "szt",
    icon: ShoppingCart,
    trend: 8.3,
    trendLabel: "vs. poprzedni miesiąc",
  },
  {
    title: "Liczba klientów",
    value: "127",
    suffix: "osób",
    icon: Users,
    trend: 15.2,
    trendLabel: "vs. poprzedni miesiąc",
  },
  {
    title: "Godziny druku",
    value: "342",
    suffix: "h",
    icon: Clock,
    progress: 78,
  },
];

// Printer Data
const printerData = {
  printerName: "H2D Printer",
  state: "printing" as const,
  currentPrint: "Uchwyt na słuchawki v2",
  estimatedTime: "2h 15min",
  progress: 67,
  temperature: {
    nozzle: 210,
    bed: 60,
  },
};

// Kanban Data
const kanbanData = {
  columns: [
    {
      id: "todo",
      title: "Do zrobienia",
      count: 12,
      color: "text-gray-400",
      bgColor: "bg-gray-500/10",
      icon: ShoppingCart,
    },
    {
      id: "in-progress",
      title: "W trakcie",
      count: 5,
      color: "text-[#fbbf24]",
      bgColor: "bg-[#fbbf24]/10",
      icon: Clock,
    },
    {
      id: "done",
      title: "Gotowe",
      count: 28,
      color: "text-green-400",
      bgColor: "bg-green-500/10",
      icon: Users,
    },
  ],
};

// Projects Data
const projectsData = {
  stages: [
    { id: "idea", title: "Pomysł", count: 8, icon: DollarSign, color: "#6b7280" },
    { id: "prototype", title: "Prototyp", count: 5, icon: Clock, color: "#fbbf24" },
    { id: "testing", title: "Testowany", count: 3, icon: Bell, color: "#3b82f6" },
    { id: "ready", title: "Gotowy", count: 12, icon: Settings, color: "#22c55e" },
  ],
};

// Recent Prints Data
const recentPrintsData = {
  prints: [
    {
      id: "1",
      name: "Uchwyt na słuchawki v2",
      duration: "4h 30min",
      status: "completed" as const,
      date: "Dzisiaj, 14:30",
      material: "PLA",
    },
    {
      id: "2",
      name: "Obudowa Raspberry Pi",
      duration: "2h 15min",
      status: "completed" as const,
      date: "Dzisiaj, 10:15",
      material: "PETG",
    },
    {
      id: "3",
      name: "Wspornik półki",
      duration: "5h 45min",
      status: "failed" as const,
      date: "Wczoraj, 18:20",
      material: "PLA",
    },
    {
      id: "4",
      name: "Klucz nasadowy 10mm",
      duration: "1h 20min",
      status: "completed" as const,
      date: "Wczoraj, 15:00",
      material: "ABS",
    },
    {
      id: "5",
      name: "Stojak na długopisy",
      duration: "3h 10min",
      status: "completed" as const,
      date: "Wczoraj, 11:30",
      material: "PLA",
    },
  ],
};

// Recent Quotes Data
const recentQuotesData = {
  quotes: [
    {
      id: "1",
      client: "TechStart Sp. z o.o.",
      amount: 1250.0,
      status: "pending" as const,
      date: "Dzisiaj, 09:15",
      items: 3,
    },
    {
      id: "2",
      client: "Jan Kowalski",
      amount: 340.5,
      status: "accepted" as const,
      date: "Wczoraj, 16:45",
      items: 2,
    },
    {
      id: "3",
      client: "Design Studio",
      amount: 2890.0,
      status: "pending" as const,
      date: "Wczoraj, 11:20",
      items: 8,
    },
    {
      id: "4",
      client: "Marek Nowak",
      amount: 125.0,
      status: "rejected" as const,
      date: "2 dni temu",
      items: 1,
    },
    {
      id: "5",
      client: "Prototyp Labs",
      amount: 5675.0,
      status: "accepted" as const,
      date: "3 dni temu",
      items: 15,
    },
  ],
};

// Inventory Alerts Data
const inventoryData = {
  items: [
    {
      id: "1",
      name: "PLA Premium",
      color: "Czerwony",
      colorHex: "#ef4444",
      weight: 125,
      maxWeight: 1000,
      type: "PLA",
    },
    {
      id: "2",
      name: "PETG Eco",
      color: "Czarny",
      colorHex: "#1f2937",
      weight: 85,
      maxWeight: 1000,
      type: "PETG",
    },
    {
      id: "3",
      name: "ABS Pro",
      color: "Biały",
      colorHex: "#f9fafb",
      weight: 45,
      maxWeight: 1000,
      type: "ABS",
    },
    {
      id: "4",
      name: "TPU Flexible",
      color: "Niebieski",
      colorHex: "#3b82f6",
      weight: 156,
      maxWeight: 500,
      type: "TPU",
    },
    {
      id: "5",
      name: "PLA Silk",
      color: "Złoty",
      colorHex: "#fbbf24",
      weight: 67,
      maxWeight: 1000,
      type: "PLA",
    },
  ],
  threshold: 200,
};

export function MainDashboard() {
  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="sticky top-0 z-50 bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-[#2a2a2a]"
      >
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left side */}
            <div className="flex items-center gap-4">
              <button className="p-2 rounded-lg hover:bg-[#1a1a1a] transition-colors lg:hidden">
                <Menu className="w-5 h-5 text-gray-400" />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] flex items-center justify-center">
                  <span className="text-[#0a0a0a] font-bold text-lg">3D</span>
                </div>
                <div className="hidden sm:block">
                  <h1 className="text-white font-semibold">
                    3D Print Business Hub
                  </h1>
                  <p className="text-xs text-gray-500">Dashboard</p>
                </div>
              </div>
            </div>

            {/* Right side */}
            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="hidden md:flex items-center bg-[#1a1a1a] rounded-lg px-3 py-2 border border-[#2a2a2a]">
                <Search className="w-4 h-4 text-gray-500 mr-2" />
                <input
                  type="text"
                  placeholder="Szukaj..."
                  className="bg-transparent text-sm text-white placeholder-gray-500 outline-none w-48"
                />
              </div>

              {/* Notifications */}
              <button className="relative p-2 rounded-lg hover:bg-[#1a1a1a] transition-colors">
                <Bell className="w-5 h-5 text-gray-400" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
              </button>

              {/* Settings */}
              <button className="p-2 rounded-lg hover:bg-[#1a1a1a] transition-colors">
                <Settings className="w-5 h-5 text-gray-400" />
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Dashboard
          </h2>
          <p className="text-gray-400">
            Przegląd Twojego biznesu druku 3D w czasie rzeczywistym
          </p>
        </motion.div>

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {kpiData.map((kpi, index) => (
            <KPICard
              key={kpi.title}
              title={kpi.title}
              value={kpi.value}
              suffix={kpi.suffix}
              icon={kpi.icon}
              trend={kpi.trend}
              trendLabel={kpi.trendLabel}
              progress={kpi.progress}
              delay={index}
            />
          ))}
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Printer Status - takes 1 column */}
          <PrinterStatus {...printerData} delay={4} />

          {/* Kanban Summary - takes 1 column */}
          <KanbanSummary {...kanbanData} delay={5} />

          {/* Projects Status - takes 1 column */}
          <ProjectsStatus {...projectsData} delay={6} />
        </div>

        {/* Secondary Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Recent Prints */}
          <RecentPrints {...recentPrintsData} delay={7} />

          {/* Recent Quotes */}
          <RecentQuotes {...recentQuotesData} delay={8} />
        </div>

        {/* Inventory Alerts - Full width */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <InventoryAlerts {...inventoryData} delay={9} />
          </div>

          {/* Quick Actions Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 1 }}
          >
            <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6 h-full">
              <h3 className="text-white font-semibold mb-4">Szybkie Akcje</h3>
              <div className="space-y-3">
                <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/50 transition-all duration-300 group">
                  <div className="w-10 h-10 rounded-lg bg-[#fbbf24]/10 flex items-center justify-center group-hover:bg-[#fbbf24]/20 transition-colors">
                    <ShoppingCart className="w-5 h-5 text-[#fbbf24]" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Nowe zamówienie</p>
                    <p className="text-xs text-gray-500">
                      Dodaj nowe zamówienie klienta
                    </p>
                  </div>
                </button>

                <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/50 transition-all duration-300 group">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
                    <DollarSign className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Nowa wycena</p>
                    <p className="text-xs text-gray-500">
                      Przygotuj wycenę dla klienta
                    </p>
                  </div>
                </button>

                <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/50 transition-all duration-300 group">
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center group-hover:bg-green-500/20 transition-colors">
                    <Clock className="w-5 h-5 text-green-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Rozpocznij wydruk</p>
                    <p className="text-xs text-gray-500">
                      Dodaj zadanie do kolejki
                    </p>
                  </div>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 1.1 }}
        className="border-t border-[#2a2a2a] mt-12"
      >
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              © 2024 3D Print Business Hub. Wszelkie prawa zastrzeżone.
            </p>
            <div className="flex items-center gap-4">
              <span className="text-xs text-gray-500">
                Status systemu:{" "}
                <span className="text-green-400">Operacyjny</span>
              </span>
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </div>
          </div>
        </div>
      </motion.footer>
    </div>
  );
}
