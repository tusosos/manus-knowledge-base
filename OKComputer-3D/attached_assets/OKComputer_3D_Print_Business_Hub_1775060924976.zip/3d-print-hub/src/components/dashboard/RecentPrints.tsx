"use client";

import { motion } from "framer-motion";
import {
  Printer,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  MoreHorizontal,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

type PrintStatus = "completed" | "failed" | "printing" | "queued";

interface PrintJob {
  id: string;
  name: string;
  duration: string;
  status: PrintStatus;
  date: string;
  material?: string;
}

interface RecentPrintsProps {
  prints?: PrintJob[];
  delay?: number;
}

const defaultPrints: PrintJob[] = [
  {
    id: "1",
    name: "Uchwyt na słuchawki v2",
    duration: "4h 30min",
    status: "completed",
    date: "Dzisiaj, 14:30",
    material: "PLA",
  },
  {
    id: "2",
    name: "Obudowa Raspberry Pi",
    duration: "2h 15min",
    status: "completed",
    date: "Dzisiaj, 10:15",
    material: "PETG",
  },
  {
    id: "3",
    name: "Wspornik półki",
    duration: "5h 45min",
    status: "failed",
    date: "Wczoraj, 18:20",
    material: "PLA",
  },
  {
    id: "4",
    name: "Klucz nasadowy 10mm",
    duration: "1h 20min",
    status: "completed",
    date: "Wczoraj, 15:00",
    material: "ABS",
  },
  {
    id: "5",
    name: "Stojak na długopisy",
    duration: "3h 10min",
    status: "completed",
    date: "Wczoraj, 11:30",
    material: "PLA",
  },
];

const statusConfig: Record<
  PrintStatus,
  { label: string; color: string; icon: typeof CheckCircle2 }
> = {
  completed: {
    label: "Ukończony",
    color: "bg-green-500/10 text-green-400 border-green-500/20",
    icon: CheckCircle2,
  },
  failed: {
    label: "Błąd",
    color: "bg-red-500/10 text-red-400 border-red-500/20",
    icon: XCircle,
  },
  printing: {
    label: "Drukowanie",
    color: "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/20",
    icon: Printer,
  },
  queued: {
    label: "W kolejce",
    color: "bg-gray-500/10 text-gray-400 border-gray-500/20",
    icon: Clock,
  },
};

export function RecentPrints({
  prints = defaultPrints,
  delay = 0,
}: RecentPrintsProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#2a2a2a] flex items-center justify-center">
                <Printer className="w-5 h-5 text-[#fbbf24]" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  Ostatnie Wydruki
                </CardTitle>
                <p className="text-xs text-gray-500">
                  {prints.length} ostatnich zadań
                </p>
              </div>
            </div>
            <button className="p-2 rounded-lg hover:bg-[#2a2a2a] transition-colors">
              <MoreHorizontal className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-2">
            {prints.map((print, index) => {
              const config = statusConfig[print.status];
              const StatusIcon = config.icon;

              return (
                <motion.div
                  key={print.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.3,
                    delay: delay * 0.1 + index * 0.05,
                  }}
                  className="group"
                >
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/30 transition-all duration-300 cursor-pointer">
                    {/* Status icon */}
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        print.status === "completed"
                          ? "bg-green-500/10"
                          : print.status === "failed"
                          ? "bg-red-500/10"
                          : print.status === "printing"
                          ? "bg-[#fbbf24]/10"
                          : "bg-gray-500/10"
                      }`}
                    >
                      <StatusIcon
                        className={`w-5 h-5 ${
                          print.status === "completed"
                            ? "text-green-400"
                            : print.status === "failed"
                            ? "text-red-400"
                            : print.status === "printing"
                            ? "text-[#fbbf24]"
                            : "text-gray-400"
                        }`}
                      />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-white font-medium truncate group-hover:text-[#fbbf24] transition-colors">
                          {print.name}
                        </p>
                        <Badge
                          variant="outline"
                          className={`text-xs ${config.color} flex-shrink-0 ml-2`}
                        >
                          {config.label}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {print.duration}
                        </span>
                        {print.material && (
                          <span className="flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-[#fbbf24]" />
                            {print.material}
                          </span>
                        )}
                        <span>{print.date}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* View all link */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: delay * 0.1 + 0.3 }}
            className="w-full mt-4 py-2.5 text-sm text-[#fbbf24] hover:text-[#f59e0b] border border-[#2a2a2a] hover:border-[#fbbf24]/50 rounded-lg transition-all duration-300 font-medium"
          >
            Zobacz wszystkie wydruki
          </motion.button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
