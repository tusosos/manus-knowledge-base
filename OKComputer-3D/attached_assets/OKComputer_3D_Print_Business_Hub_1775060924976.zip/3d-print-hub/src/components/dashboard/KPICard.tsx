"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface KPICardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: number;
  trendLabel?: string;
  progress?: number;
  suffix?: string;
  delay?: number;
}

export function KPICard({
  title,
  value,
  icon: Icon,
  trend,
  trendLabel,
  progress,
  suffix,
  delay = 0,
}: KPICardProps) {
  const isPositiveTrend = trend && trend > 0;
  const isNegativeTrend = trend && trend < 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a] hover:border-[#fbbf24]/30 transition-all duration-300 group">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <p className="text-sm text-gray-400 font-[Inter] mb-2">{title}</p>
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold text-white font-['JetBrains_Mono'] tracking-tight">
                  {value}
                </span>
                {suffix && (
                  <span className="text-lg text-gray-400 font-['JetBrains_Mono']">
                    {suffix}
                  </span>
                )}
              </div>

              {/* Trend indicator */}
              {trend !== undefined && (
                <div className="flex items-center gap-2 mt-3">
                  <div
                    className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      isPositiveTrend
                        ? "bg-green-500/10 text-green-400"
                        : isNegativeTrend
                        ? "bg-red-500/10 text-red-400"
                        : "bg-gray-500/10 text-gray-400"
                    }`}
                  >
                    {isPositiveTrend && <TrendingUp className="w-3 h-3" />}
                    {isNegativeTrend && <TrendingDown className="w-3 h-3" />}
                    <span className="font-['JetBrains_Mono']">
                      {isPositiveTrend ? "+" : ""}
                      {trend}%
                    </span>
                  </div>
                  {trendLabel && (
                    <span className="text-xs text-gray-500">{trendLabel}</span>
                  )}
                </div>
              )}

              {/* Progress bar */}
              {progress !== undefined && (
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-500">Wykorzystanie</span>
                    <span className="text-[#fbbf24] font-['JetBrains_Mono']">
                      {progress}%
                    </span>
                  </div>
                  <div className="h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-[#fbbf24] to-[#f59e0b] rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      transition={{ duration: 0.8, delay: delay * 0.1 + 0.3 }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Icon */}
            <div className="w-12 h-12 rounded-xl bg-[#2a2a2a] flex items-center justify-center group-hover:bg-[#fbbf24]/10 transition-colors duration-300">
              <Icon className="w-6 h-6 text-[#fbbf24]" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
