"use client";

import { motion } from "framer-motion";
import {
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  Hourglass,
  MoreHorizontal,
  User,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

type QuoteStatus = "pending" | "accepted" | "rejected" | "expired";

interface Quote {
  id: string;
  client: string;
  amount: number;
  status: QuoteStatus;
  date: string;
  items?: number;
}

interface RecentQuotesProps {
  quotes?: Quote[];
  delay?: number;
}

const defaultQuotes: Quote[] = [
  {
    id: "1",
    client: "TechStart Sp. z o.o.",
    amount: 1250.0,
    status: "pending",
    date: "Dzisiaj, 09:15",
    items: 3,
  },
  {
    id: "2",
    client: "Jan Kowalski",
    amount: 340.5,
    status: "accepted",
    date: "Wczoraj, 16:45",
    items: 2,
  },
  {
    id: "3",
    client: "Design Studio",
    amount: 2890.0,
    status: "pending",
    date: "Wczoraj, 11:20",
    items: 8,
  },
  {
    id: "4",
    client: "Marek Nowak",
    amount: 125.0,
    status: "rejected",
    date: "2 dni temu",
    items: 1,
  },
  {
    id: "5",
    client: "Prototyp Labs",
    amount: 5675.0,
    status: "accepted",
    date: "3 dni temu",
    items: 15,
  },
];

const statusConfig: Record<
  QuoteStatus,
  { label: string; color: string; icon: typeof CheckCircle2 }
> = {
  pending: {
    label: "Oczekuje",
    color: "bg-[#fbbf24]/10 text-[#fbbf24] border-[#fbbf24]/20",
    icon: Hourglass,
  },
  accepted: {
    label: "Zaakceptowana",
    color: "bg-green-500/10 text-green-400 border-green-500/20",
    icon: CheckCircle2,
  },
  rejected: {
    label: "Odrzucona",
    color: "bg-red-500/10 text-red-400 border-red-500/20",
    icon: XCircle,
  },
  expired: {
    label: "Wygasła",
    color: "bg-gray-500/10 text-gray-400 border-gray-500/20",
    icon: Clock,
  },
};

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("pl-PL", {
    style: "currency",
    currency: "PLN",
    minimumFractionDigits: 2,
  }).format(amount);
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

export function RecentQuotes({
  quotes = defaultQuotes,
  delay = 0,
}: RecentQuotesProps) {
  const totalValue = quotes.reduce((sum, q) => sum + q.amount, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay * 0.1 }}
    >
      <Card className="bg-[#1a1a1a] border-[#2a2a2a]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#2a2a2a] flex items-center justify-center">
                <FileText className="w-5 h-5 text-[#fbbf24]" />
              </div>
              <div>
                <CardTitle className="text-white text-lg font-semibold">
                  Ostatnie Wyceny
                </CardTitle>
                <p className="text-xs text-gray-500">
                  {quotes.length} ostatnich wycen
                </p>
              </div>
            </div>
            <button className="p-2 rounded-lg hover:bg-[#2a2a2a] transition-colors">
              <MoreHorizontal className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </CardHeader>

        <CardContent>
          <div className="space-y-2">
            {quotes.map((quote, index) => {
              const config = statusConfig[quote.status];
              const StatusIcon = config.icon;

              return (
                <motion.div
                  key={quote.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.3,
                    delay: delay * 0.1 + index * 0.05,
                  }}
                  className="group"
                >
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0a] border border-[#2a2a2a] hover:border-[#fbbf24]/30 transition-all duration-300 cursor-pointer">
                    {/* Avatar */}
                    <Avatar className="w-10 h-10 flex-shrink-0 border-2 border-[#2a2a2a]">
                      <AvatarFallback className="bg-[#2a2a2a] text-[#fbbf24] text-sm font-medium">
                        {getInitials(quote.client)}
                      </AvatarFallback>
                    </Avatar>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-white font-medium truncate group-hover:text-[#fbbf24] transition-colors">
                          {quote.client}
                        </p>
                        <span className="text-[#fbbf24] font-['JetBrains_Mono'] font-bold text-sm flex-shrink-0 ml-2">
                          {formatCurrency(quote.amount)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex items-center gap-3 text-xs text-gray-500">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {quote.date}
                          </span>
                          {quote.items && (
                            <span>{quote.items} pozycji</span>
                          )}
                        </div>
                        <Badge
                          variant="outline"
                          className={`text-xs ${config.color}`}
                        >
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {config.label}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Summary */}
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Wartość wycen</span>
              <span className="text-white font-['JetBrains_Mono'] font-bold">
                {formatCurrency(totalValue)}
              </span>
            </div>
          </div>

          {/* View all link */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: delay * 0.1 + 0.3 }}
            className="w-full mt-4 py-2.5 text-sm text-[#fbbf24] hover:text-[#f59e0b] border border-[#2a2a2a] hover:border-[#fbbf24]/50 rounded-lg transition-all duration-300 font-medium"
          >
            Zobacz wszystkie wyceny
          </motion.button>
        </CardContent>
      </Card>
    </motion.div>
  );
}
