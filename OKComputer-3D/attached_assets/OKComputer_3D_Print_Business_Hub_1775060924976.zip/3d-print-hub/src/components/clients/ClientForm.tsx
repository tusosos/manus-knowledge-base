'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import type { Client, ClientStatus } from './types';
import { statusLabels } from './types';

interface ClientFormProps {
  client?: Client | null;
  onSubmit: (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    status: ClientStatus;
    address: {
      street: string;
      city: string;
      postalCode: string;
      country: string;
    };
  }) => void;
  onCancel: () => void;
}

export function ClientForm({ client, onSubmit, onCancel }: ClientFormProps) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    status: 'new' as ClientStatus,
    address: {
      street: '',
      city: '',
      postalCode: '',
      country: 'Polska',
    },
  });

  useEffect(() => {
    if (client) {
      setFormData({
        firstName: client.firstName,
        lastName: client.lastName,
        email: client.email,
        phone: client.phone,
        status: client.status,
        address: { ...client.address },
      });
    }
  }, [client]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const updateAddress = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      address: { ...prev.address, [field]: value },
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-zinc-100">Dane podstawowe</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="firstName" className="text-zinc-300">
              Imię
            </Label>
            <Input
              id="firstName"
              value={formData.firstName}
              onChange={(e) => updateField('firstName', e.target.value)}
              placeholder="Jan"
              required
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName" className="text-zinc-300">
              Nazwisko
            </Label>
            <Input
              id="lastName"
              value={formData.lastName}
              onChange={(e) => updateField('lastName', e.target.value)}
              placeholder="Kowalski"
              required
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-zinc-300">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => updateField('email', e.target.value)}
              placeholder="jan.kowalski@example.com"
              required
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone" className="text-zinc-300">
              Telefon
            </Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => updateField('phone', e.target.value)}
              placeholder="+48 123 456 789"
              required
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status" className="text-zinc-300">
            Status
          </Label>
          <Select
            value={formData.status}
            onValueChange={(value) => updateField('status', value as ClientStatus)}
          >
            <SelectTrigger className="bg-zinc-900/50 border-zinc-800 text-zinc-100">
              <SelectValue placeholder="Wybierz status" />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-800">
              <SelectItem value="new" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
                {statusLabels.new}
              </SelectItem>
              <SelectItem value="regular" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
                {statusLabels.regular}
              </SelectItem>
              <SelectItem value="vip" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
                {statusLabels.vip}
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Separator className="bg-zinc-800" />

      <div className="space-y-4">
        <h3 className="text-sm font-medium text-zinc-100">Adres dostawy</h3>
        <div className="space-y-2">
          <Label htmlFor="street" className="text-zinc-300">
            Ulica i numer
          </Label>
          <Input
            id="street"
            value={formData.address.street}
            onChange={(e) => updateAddress('street', e.target.value)}
            placeholder="ul. Przykładowa 15"
            className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="city" className="text-zinc-300">
              Miasto
            </Label>
            <Input
              id="city"
              value={formData.address.city}
              onChange={(e) => updateAddress('city', e.target.value)}
              placeholder="Warszawa"
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="postalCode" className="text-zinc-300">
              Kod pocztowy
            </Label>
            <Input
              id="postalCode"
              value={formData.address.postalCode}
              onChange={(e) => updateAddress('postalCode', e.target.value)}
              placeholder="00-001"
              className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="country" className="text-zinc-300">
            Kraj
          </Label>
          <Input
            id="country"
            value={formData.address.country}
            onChange={(e) => updateAddress('country', e.target.value)}
            placeholder="Polska"
            className="bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100"
        >
          Anuluj
        </Button>
        <Button
          type="submit"
          className="bg-amber-500 hover:bg-amber-600 text-zinc-950"
        >
          {client ? 'Zapisz zmiany' : 'Dodaj klienta'}
        </Button>
      </div>
    </form>
  );
}
