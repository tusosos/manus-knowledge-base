'use client';

import { useState } from 'react';
import { Palette, Box, Layers, Plus, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import type { Preferences } from './types';

interface ClientPreferencesProps {
  preferences: Preferences;
  onUpdate?: (preferences: Partial<Preferences>) => void;
  readOnly?: boolean;
}

const commonMaterials = ['PLA', 'ABS', 'PETG', 'TPU', 'Nylon', 'Resin', 'ASA', 'PC'];
const commonColors = ['Czarny', 'Biały', 'Szary', 'Czerwony', 'Niebieski', 'Zielony', 'Żółty', 'Przezroczysty'];
const commonStyles = ['Funkcjonalne', 'Dekoracyjne', 'Architektoniczne', 'Przemysłowe', 'Artystyczne', 'Prototypy'];

export function ClientPreferences({
  preferences,
  onUpdate,
  readOnly = false,
}: ClientPreferencesProps) {
  const [newMaterial, setNewMaterial] = useState('');
  const [newColor, setNewColor] = useState('');
  const [newStyle, setNewStyle] = useState('');

  const addItem = (type: 'favoriteMaterials' | 'preferredColors' | 'projectStyles', value: string) => {
    if (!value.trim() || !onUpdate) return;
    const current = preferences[type];
    if (current.includes(value.trim())) return;
    onUpdate({ [type]: [...current, value.trim()] });
  };

  const removeItem = (type: 'favoriteMaterials' | 'preferredColors' | 'projectStyles', value: string) => {
    if (!onUpdate) return;
    const current = preferences[type];
    onUpdate({ [type]: current.filter((item) => item !== value) });
  };

  const renderSection = (
    title: string,
    icon: React.ReactNode,
    items: string[],
    type: 'favoriteMaterials' | 'preferredColors' | 'projectStyles',
    placeholder: string,
    newValue: string,
    setNewValue: (value: string) => void,
    suggestions: string[]
  ) => (
    <Card className="bg-zinc-900/50 border-zinc-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium text-zinc-100 flex items-center gap-2">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        {/* Lista elementów */}
        <div className="flex flex-wrap gap-2">
          {items.length === 0 ? (
            <p className="text-sm text-zinc-500 italic">Brak preferencji</p>
          ) : (
            items.map((item) => (
              <Badge
                key={item}
                variant="secondary"
                className="bg-zinc-800 text-zinc-300 hover:bg-zinc-700 flex items-center gap-1"
              >
                {item}
                {!readOnly && (
                  <button
                    onClick={() => removeItem(type, item)}
                    className="ml-1 hover:text-red-400"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </Badge>
            ))
          )}
        </div>

        {/* Dodawanie nowego elementu */}
        {!readOnly && (
          <>
            <div className="flex gap-2">
              <Input
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder={placeholder}
                className="flex-1 bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600 text-sm"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addItem(type, newValue);
                    setNewValue('');
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => {
                  addItem(type, newValue);
                  setNewValue('');
                }}
                className="border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {/* Sugestie */}
            <div className="flex flex-wrap gap-1">
              {suggestions
                .filter((s) => !items.includes(s))
                .slice(0, 5)
                .map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => addItem(type, suggestion)}
                    className="text-xs px-2 py-1 rounded-full bg-zinc-800/50 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300 transition-colors"
                  >
                    + {suggestion}
                  </button>
                ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      {renderSection(
        'Ulubione materiały',
        <Box className="h-4 w-4 text-amber-500" />,
        preferences.favoriteMaterials,
        'favoriteMaterials',
        'Dodaj materiał...',
        newMaterial,
        setNewMaterial,
        commonMaterials
      )}

      {renderSection(
        'Preferowane kolory',
        <Palette className="h-4 w-4 text-purple-500" />,
        preferences.preferredColors,
        'preferredColors',
        'Dodaj kolor...',
        newColor,
        setNewColor,
        commonColors
      )}

      {renderSection(
        'Style projektów',
        <Layers className="h-4 w-4 text-blue-500" />,
        preferences.projectStyles,
        'projectStyles',
        'Dodaj styl...',
        newStyle,
        setNewStyle,
        commonStyles
      )}
    </div>
  );
}
