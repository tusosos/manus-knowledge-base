'use client';

import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { ClientFilter, ClientStatus } from './types';
import { statusLabels } from './types';

interface ClientFiltersProps {
  filter: ClientFilter;
  onFilterChange: (filter: ClientFilter) => void;
}

export function ClientFilters({ filter, onFilterChange }: ClientFiltersProps) {
  const handleSearchChange = (value: string) => {
    onFilterChange({ ...filter, search: value });
  };

  const handleStatusChange = (value: ClientStatus | 'all') => {
    onFilterChange({ ...filter, status: value });
  };

  const handleClear = () => {
    onFilterChange({ search: '', status: 'all' });
  };

  const hasActiveFilters = filter.search !== '' || filter.status !== 'all';

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
      <div className="relative flex-1 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
        <Input
          placeholder="Szukaj po imieniu, emailu lub telefonie..."
          value={filter.search}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="pl-10 bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-500"
        />
        {filter.search && (
          <button
            onClick={() => handleSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-zinc-500" />
        <Select
          value={filter.status}
          onValueChange={(value) => handleStatusChange(value as ClientStatus | 'all')}
        >
          <SelectTrigger className="w-[160px] bg-zinc-900/50 border-zinc-800 text-zinc-100">
            <SelectValue placeholder="Wszystkie statusy" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
              Wszystkie statusy
            </SelectItem>
            <SelectItem value="new" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
              {statusLabels.new}
            </SelectItem>
            <SelectItem value="regular" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
              {statusLabels.regular}
            </SelectItem>
            <SelectItem value="vip" className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100">
              {statusLabels.vip}
            </SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClear}
            className="text-zinc-400 hover:text-zinc-100"
          >
            <X className="h-4 w-4 mr-1" />
            Wyczyść
          </Button>
        )}
      </div>
    </div>
  );
}
