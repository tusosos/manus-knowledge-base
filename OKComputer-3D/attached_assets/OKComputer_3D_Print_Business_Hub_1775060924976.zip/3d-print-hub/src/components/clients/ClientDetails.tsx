'use client';

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Mail,
  Phone,
  MapPin,
  Calendar,
  User,
  Package,
  MessageSquare,
  Heart,
} from 'lucide-react';
import { ClientAvatar } from './ClientAvatar';
import { ClientStatusBadge } from './ClientStatusBadge';
import { ClientOrders } from './ClientOrders';
import { ClientPreferences } from './ClientPreferences';
import { ClientCommunication } from './ClientCommunication';
import type { Client } from './types';

interface ClientDetailsProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddNote?: (content: string) => void;
  onUpdatePreferences?: (preferences: Client['preferences']) => void;
}

export function ClientDetails({
  client,
  open,
  onOpenChange,
  onAddNote,
  onUpdatePreferences,
}: ClientDetailsProps) {
  if (!client) return null;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl bg-zinc-950 border-zinc-800 p-0">
        <ScrollArea className="h-full">
          <div className="p-6">
            {/* Nagłówek */}
            <SheetHeader className="space-y-6">
              <div className="flex items-start gap-4">
                <ClientAvatar
                  firstName={client.firstName}
                  lastName={client.lastName}
                  status={client.status}
                  size="lg"
                />
                <div className="flex-1 min-w-0">
                  <SheetTitle className="text-xl font-semibold text-zinc-100">
                    {client.firstName} {client.lastName}
                  </SheetTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <ClientStatusBadge status={client.status} />
                    <Badge
                      variant="outline"
                      className="bg-zinc-900/50 text-zinc-500 border-zinc-800"
                    >
                      <Calendar className="h-3 w-3 mr-1" />
                      Od {new Date(client.createdAt).toLocaleDateString('pl-PL')}
                    </Badge>
                  </div>
                </div>
              </div>
            </SheetHeader>

            <Separator className="my-6 bg-zinc-800" />

            {/* Dane kontaktowe */}
            <div className="space-y-4 mb-6">
              <h3 className="text-sm font-medium text-zinc-100 flex items-center gap-2">
                <User className="h-4 w-4 text-zinc-500" />
                Dane kontaktowe
              </h3>
              <div className="grid gap-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-zinc-900/50">
                  <Mail className="h-4 w-4 text-zinc-500" />
                  <div>
                    <p className="text-xs text-zinc-500">Email</p>
                    <p className="text-sm text-zinc-100">{client.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-zinc-900/50">
                  <Phone className="h-4 w-4 text-zinc-500" />
                  <div>
                    <p className="text-xs text-zinc-500">Telefon</p>
                    <p className="text-sm text-zinc-100">{client.phone}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Adres */}
            <div className="space-y-4 mb-6">
              <h3 className="text-sm font-medium text-zinc-100 flex items-center gap-2">
                <MapPin className="h-4 w-4 text-zinc-500" />
                Adres dostawy
              </h3>
              <div className="p-3 rounded-lg bg-zinc-900/50">
                <p className="text-sm text-zinc-100">{client.address.street}</p>
                <p className="text-sm text-zinc-400">
                  {client.address.postalCode} {client.address.city}
                </p>
                <p className="text-sm text-zinc-400">{client.address.country}</p>
              </div>
            </div>

            <Separator className="my-6 bg-zinc-800" />

            {/* Zakładki */}
            <Tabs defaultValue="orders" className="w-full">
              <TabsList className="w-full grid grid-cols-3 bg-zinc-900/50 p-1">
                <TabsTrigger
                  value="orders"
                  className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-500"
                >
                  <Package className="h-4 w-4 mr-2" />
                  Zamówienia
                </TabsTrigger>
                <TabsTrigger
                  value="preferences"
                  className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-500"
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Preferencje
                </TabsTrigger>
                <TabsTrigger
                  value="communication"
                  className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100 text-zinc-500"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Notatki
                </TabsTrigger>
              </TabsList>

              <TabsContent value="orders" className="mt-4">
                <ClientOrders orders={client.orders} />
              </TabsContent>

              <TabsContent value="preferences" className="mt-4">
                <ClientPreferences
                  preferences={client.preferences}
                  onUpdate={onUpdatePreferences}
                />
              </TabsContent>

              <TabsContent value="communication" className="mt-4">
                <ClientCommunication
                  notes={client.notes}
                  lastContactDate={client.lastContactDate}
                  onAddNote={onAddNote}
                />
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
