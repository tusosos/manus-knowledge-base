// Types
export type {
  Client,
  ClientStatus,
  ClientFilter,
  Address,
  Order,
  Preferences,
  Note,
} from './types';

// Constants
export {
  statusLabels,
  statusColors,
  orderStatusLabels,
  orderStatusColors,
} from './types';

// Hooks
export { useClients } from './useClients';

// Components
export { ClientAvatar } from './ClientAvatar';
export { ClientStatusBadge } from './ClientStatusBadge';
export { ClientFilters } from './ClientFilters';
export { ClientsTable } from './ClientsTable';
export { ClientForm } from './ClientForm';
export { ClientDialog } from './ClientDialog';
export { ClientDetails } from './ClientDetails';
export { ClientOrders } from './ClientOrders';
export { ClientPreferences } from './ClientPreferences';
export { ClientCommunication } from './ClientCommunication';
export { ClientStats } from './ClientStats';
export { DeleteConfirmDialog } from './DeleteConfirmDialog';
export { ClientsPage } from './ClientsPage';
