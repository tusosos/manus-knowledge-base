'use client';

import { useState, useCallback, useMemo } from 'react';
import type { Client, ClientFilter, ClientStatus, Note, Order, Preferences } from './types';

// Mock data dla demonstracji
const mockClients: Client[] = [
  {
    id: '1',
    firstName: 'Jan',
    lastName: 'Kowalski',
    email: 'jan.kowalski@example.com',
    phone: '+48 123 456 789',
    status: 'vip',
    address: {
      street: 'ul. Przykładowa 15',
      city: 'Warszawa',
      postalCode: '00-001',
      country: 'Polska',
    },
    notes: [
      {
        id: 'n1',
        date: '2024-01-15T10:30:00',
        content: 'Klient zainteresowany dużymi projektami. Preferuje szybką realizację.',
        author: 'Administrator',
      },
    ],
    orders: [
      {
        id: 'o1',
        date: '2024-01-10',
        amount: 1250.00,
        status: 'completed',
        description: 'Model architektoniczny budynku',
      },
      {
        id: 'o2',
        date: '2024-01-20',
        amount: 890.50,
        status: 'in_progress',
        description: 'Elementy dekoracyjne do biura',
      },
    ],
    preferences: {
      favoriteMaterials: ['PLA', 'PETG', 'ABS'],
      preferredColors: ['Czarny', 'Biały', 'Szary'],
      projectStyles: ['Architektoniczne', 'Funkcjonalne'],
    },
    createdAt: '2023-12-01T08:00:00',
    lastContactDate: '2024-01-15T10:30:00',
  },
  {
    id: '2',
    firstName: 'Anna',
    lastName: 'Nowak',
    email: 'anna.nowak@example.com',
    phone: '+48 987 654 321',
    status: 'regular',
    address: {
      street: 'ul. Testowa 42',
      city: 'Kraków',
      postalCode: '30-001',
      country: 'Polska',
    },
    notes: [
      {
        id: 'n2',
        date: '2024-01-18T14:15:00',
        content: 'Regularnie zamawia drobne elementy. Zadowolona z jakości.',
        author: 'Administrator',
      },
    ],
    orders: [
      {
        id: 'o3',
        date: '2024-01-05',
        amount: 245.00,
        status: 'completed',
        description: 'Uchwyty do szuflad',
      },
      {
        id: 'o4',
        date: '2024-01-12',
        amount: 180.00,
        status: 'completed',
        description: 'Organizer biurkowy',
      },
      {
        id: 'o5',
        date: '2024-01-25',
        amount: 320.00,
        status: 'pending',
        description: 'Wieszaki na klucze',
      },
    ],
    preferences: {
      favoriteMaterials: ['PLA'],
      preferredColors: ['Biały', 'Pastelowe'],
      projectStyles: ['Praktyczne', 'Dekoracyjne'],
    },
    createdAt: '2023-11-15T09:00:00',
    lastContactDate: '2024-01-18T14:15:00',
  },
  {
    id: '3',
    firstName: 'Piotr',
    lastName: 'Wiśniewski',
    email: 'piotr.wisniewski@example.com',
    phone: '+48 555 666 777',
    status: 'new',
    address: {
      street: 'ul. Nowa 7',
      city: 'Wrocław',
      postalCode: '50-001',
      country: 'Polska',
    },
    notes: [],
    orders: [],
    preferences: {
      favoriteMaterials: [],
      preferredColors: [],
      projectStyles: [],
    },
    createdAt: '2024-01-20T11:00:00',
  },
  {
    id: '4',
    firstName: 'Maria',
    lastName: 'Lewandowska',
    email: 'maria.lewandowska@example.com',
    phone: '+48 111 222 333',
    status: 'regular',
    address: {
      street: 'ul. Długa 23',
      city: 'Gdańsk',
      postalCode: '80-001',
      country: 'Polska',
    },
    notes: [
      {
        id: 'n3',
        date: '2024-01-10T09:00:00',
        content: 'Projektantka wnętrz. Często zamawia prototypy.',
        author: 'Administrator',
      },
    ],
    orders: [
      {
        id: 'o6',
        date: '2024-01-08',
        amount: 567.00,
        status: 'completed',
        description: 'Lampy dekoracyjne',
      },
    ],
    preferences: {
      favoriteMaterials: ['PLA', 'Resin'],
      preferredColors: ['Złoty', 'Srebrny', 'Czarny'],
      projectStyles: ['Dekoracyjne', 'Ekskluzywne'],
    },
    createdAt: '2023-12-10T10:00:00',
    lastContactDate: '2024-01-10T09:00:00',
  },
  {
    id: '5',
    firstName: 'Tomasz',
    lastName: 'Zieliński',
    email: 'tomasz.zielinski@example.com',
    phone: '+48 444 555 666',
    status: 'vip',
    address: {
      street: 'ul. Krótka 5',
      city: 'Poznań',
      postalCode: '60-001',
      country: 'Polska',
    },
    notes: [
      {
        id: 'n4',
        date: '2024-01-22T16:45:00',
        content: 'Właściciel firmy. Duże zamówienia, krótkie terminy.',
        author: 'Administrator',
      },
      {
        id: 'n5',
        date: '2024-01-25T11:20:00',
        content: 'Zapytał o możliwość druku wielkoformatowego.',
        author: 'Administrator',
      },
    ],
    orders: [
      {
        id: 'o7',
        date: '2024-01-15',
        amount: 2100.00,
        status: 'completed',
        description: 'Elementy maszynowe - seria 50 szt.',
      },
      {
        id: 'o8',
        date: '2024-01-22',
        amount: 3400.00,
        status: 'in_progress',
        description: 'Obudowy urządzeń - seria 100 szt.',
      },
      {
        id: 'o9',
        date: '2024-01-28',
        amount: 1500.00,
        status: 'pending',
        description: 'Wsporniki montażowe',
      },
    ],
    preferences: {
      favoriteMaterials: ['ABS', 'PETG', 'Nylon'],
      preferredColors: ['Czarny', 'Szary przemysłowy'],
      projectStyles: ['Przemysłowe', 'Funkcjonalne'],
    },
    createdAt: '2023-10-01T08:00:00',
    lastContactDate: '2024-01-25T11:20:00',
  },
];

export function useClients() {
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [filter, setFilter] = useState<ClientFilter>({
    search: '',
    status: 'all',
  });

  // Filtrowanie klientów
  const filteredClients = useMemo(() => {
    return clients.filter((client) => {
      const matchesSearch =
        filter.search === '' ||
        `${client.firstName} ${client.lastName}`
          .toLowerCase()
          .includes(filter.search.toLowerCase()) ||
        client.email.toLowerCase().includes(filter.search.toLowerCase()) ||
        client.phone.includes(filter.search);

      const matchesStatus =
        filter.status === 'all' || client.status === filter.status;

      return matchesSearch && matchesStatus;
    });
  }, [clients, filter]);

  // Dodanie klienta
  const addClient = useCallback((clientData: Omit<Client, 'id' | 'createdAt' | 'orders' | 'notes'>) => {
    const newClient: Client = {
      ...clientData,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString(),
      orders: [],
      notes: [],
    };
    setClients((prev) => [...prev, newClient]);
    return newClient;
  }, []);

  // Aktualizacja klienta
  const updateClient = useCallback((id: string, updates: Partial<Client>) => {
    setClients((prev) =>
      prev.map((client) =>
        client.id === id ? { ...client, ...updates } : client
      )
    );
  }, []);

  // Usunięcie klienta
  const deleteClient = useCallback((id: string) => {
    setClients((prev) => prev.filter((client) => client.id !== id));
  }, []);

  // Dodanie notatki
  const addNote = useCallback((clientId: string, content: string, author: string = 'Administrator') => {
    const newNote: Note = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      content,
      author,
    };
    setClients((prev) =>
      prev.map((client) =>
        client.id === clientId
          ? {
              ...client,
              notes: [newNote, ...client.notes],
              lastContactDate: newNote.date,
            }
          : client
      )
    );
    return newNote;
  }, []);

  // Dodanie zamówienia
  const addOrder = useCallback((clientId: string, order: Omit<Order, 'id'>) => {
    const newOrder: Order = {
      ...order,
      id: Math.random().toString(36).substr(2, 9),
    };
    setClients((prev) =>
      prev.map((client) =>
        client.id === clientId
          ? { ...client, orders: [newOrder, ...client.orders] }
          : client
      )
    );
    return newOrder;
  }, []);

  // Aktualizacja preferencji
  const updatePreferences = useCallback(
    (clientId: string, preferences: Partial<Preferences>) => {
      setClients((prev) =>
        prev.map((client) =>
          client.id === clientId
            ? {
                ...client,
                preferences: { ...client.preferences, ...preferences },
              }
            : client
        )
      );
    },
    []
  );

  // Pobranie klienta po ID
  const getClientById = useCallback(
    (id: string) => {
      return clients.find((client) => client.id === id);
    },
    [clients]
  );

  // Obliczenie całkowitej kwoty zamówień klienta
  const getTotalOrderAmount = useCallback((clientId: string) => {
    const client = clients.find((c) => c.id === clientId);
    if (!client) return 0;
    return client.orders.reduce((sum, order) => sum + order.amount, 0);
  }, [clients]);

  // Statystyki
  const stats = useMemo(() => {
    return {
      total: clients.length,
      new: clients.filter((c) => c.status === 'new').length,
      regular: clients.filter((c) => c.status === 'regular').length,
      vip: clients.filter((c) => c.status === 'vip').length,
      totalRevenue: clients.reduce(
        (sum, client) =>
          sum + client.orders.reduce((orderSum, order) => orderSum + order.amount, 0),
        0
      ),
    };
  }, [clients]);

  return {
    clients: filteredClients,
    allClients: clients,
    filter,
    setFilter,
    stats,
    addClient,
    updateClient,
    deleteClient,
    addNote,
    addOrder,
    updatePreferences,
    getClientById,
    getTotalOrderAmount,
  };
}
