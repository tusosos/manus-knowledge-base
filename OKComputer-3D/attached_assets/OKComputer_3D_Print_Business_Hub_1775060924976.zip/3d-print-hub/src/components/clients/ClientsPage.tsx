'use client';

import { useState } from 'react';
import { Plus, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ClientStats } from './ClientStats';
import { ClientFilters } from './ClientFilters';
import { ClientsTable } from './ClientsTable';
import { ClientDetails } from './ClientDetails';
import { ClientDialog } from './ClientDialog';
import { DeleteConfirmDialog } from './DeleteConfirmDialog';
import { useClients } from './useClients';
import type { Client, ClientStatus } from './types';

export function ClientsPage() {
  const {
    clients,
    filter,
    setFilter,
    stats,
    addClient,
    updateClient,
    deleteClient,
    addNote,
    updatePreferences,
    getClientById,
  } = useClients();

  // Stany dla dialogów
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  // Obsługa podglądu klienta
  const handleView = (client: Client) => {
    setSelectedClient(client);
    setDetailsOpen(true);
  };

  // Obsługa edycji klienta
  const handleEdit = (client: Client) => {
    setSelectedClient(client);
    setDialogOpen(true);
  };

  // Obsługa dodawania nowego klienta
  const handleAdd = () => {
    setSelectedClient(null);
    setDialogOpen(true);
  };

  // Obsługa usuwania klienta
  const handleDelete = (client: Client) => {
    setSelectedClient(client);
    setDeleteDialogOpen(true);
  };

  // Potwierdzenie usunięcia
  const handleConfirmDelete = () => {
    if (selectedClient) {
      deleteClient(selectedClient.id);
      setDeleteDialogOpen(false);
      setSelectedClient(null);
    }
  };

  // Zapisanie klienta (dodanie lub aktualizacja)
  const handleSave = (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    status: ClientStatus;
    address: {
      street: string;
      city: string;
      postalCode: string;
      country: string;
    };
  }) => {
    if (selectedClient) {
      updateClient(selectedClient.id, data);
    } else {
      addClient(data);
    }
  };

  // Dodanie notatki
  const handleAddNote = (content: string) => {
    if (selectedClient) {
      addNote(selectedClient.id, content);
      // Odświeżenie danych klienta
      const updated = getClientById(selectedClient.id);
      if (updated) {
        setSelectedClient(updated);
      }
    }
  };

  // Aktualizacja preferencji
  const handleUpdatePreferences = (preferences: Client['preferences']) => {
    if (selectedClient) {
      updatePreferences(selectedClient.id, preferences);
      // Odświeżenie danych klienta
      const updated = getClientById(selectedClient.id);
      if (updated) {
        setSelectedClient(updated);
      }
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Nagłówek */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-zinc-100 flex items-center gap-2">
            <Users className="h-6 w-6 text-amber-500" />
            Baza Klientów
          </h1>
          <p className="text-zinc-500 mt-1">
            Zarządzaj klientami i ich zamówieniami
          </p>
        </div>
        <Button
          onClick={handleAdd}
          className="bg-amber-500 hover:bg-amber-600 text-zinc-950"
        >
          <Plus className="h-4 w-4 mr-2" />
          Dodaj klienta
        </Button>
      </div>

      {/* Statystyki */}
      <ClientStats
        total={stats.total}
        new={stats.new}
        regular={stats.regular}
        vip={stats.vip}
        totalRevenue={stats.totalRevenue}
      />

      {/* Główna zawartość */}
      <Card className="bg-zinc-950 border-zinc-800">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-medium text-zinc-100">
            Lista klientów
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-4">
          {/* Filtry */}
          <ClientFilters filter={filter} onFilterChange={setFilter} />

          {/* Tabela */}
          <ClientsTable
            clients={clients}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />

          {/* Podsumowanie */}
          <div className="flex items-center justify-between text-sm text-zinc-500 pt-4 border-t border-zinc-800">
            <p>
              Wyświetlanie {clients.length} z {stats.total} klientów
            </p>
            {filter.search || filter.status !== 'all' ? (
              <p>Aktywne filtry</p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* Szczegóły klienta (Drawer) */}
      <ClientDetails
        client={selectedClient}
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        onAddNote={handleAddNote}
        onUpdatePreferences={handleUpdatePreferences}
      />

      {/* Dialog dodawania/edycji */}
      <ClientDialog
        client={selectedClient}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSubmit={handleSave}
      />

      {/* Dialog potwierdzenia usunięcia */}
      <DeleteConfirmDialog
        client={selectedClient}
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}
