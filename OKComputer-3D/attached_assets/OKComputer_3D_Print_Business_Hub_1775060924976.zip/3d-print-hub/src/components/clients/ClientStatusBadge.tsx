'use client';

import { Badge } from '@/components/ui/badge';
import type { ClientStatus } from './types';
import { statusLabels, statusColors } from './types';

interface ClientStatusBadgeProps {
  status: ClientStatus;
}

export function ClientStatusBadge({ status }: ClientStatusBadgeProps) {
  return (
    <Badge
      variant="outline"
      className={`${statusColors[status]} font-medium capitalize`}
    >
      {statusLabels[status]}
    </Badge>
  );
}
