'use client';

import { Package, Calendar, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import type { Order } from './types';
import { orderStatusLabels, orderStatusColors } from './types';

interface ClientOrdersProps {
  orders: Order[];
}

export function ClientOrders({ orders }: ClientOrdersProps) {
  const totalAmount = orders.reduce((sum, order) => sum + order.amount, 0);
  const completedOrders = orders.filter((o) => o.status === 'completed').length;
  const pendingOrders = orders.filter((o) => o.status === 'pending').length;
  const inProgressOrders = orders.filter((o) => o.status === 'in_progress').length;

  if (orders.length === 0) {
    return (
      <div className="space-y-4">
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="h-12 w-12 rounded-full bg-zinc-800/50 flex items-center justify-center mb-3">
                <Package className="h-6 w-6 text-zinc-500" />
              </div>
              <p className="text-zinc-400 font-medium">Brak zamówień</p>
              <p className="text-sm text-zinc-500 mt-1">
                Klient nie złożył jeszcze żadnych zamówień.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Statystyki zamówień */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-zinc-500" />
              <span className="text-xs text-zinc-400">Wszystkie</span>
            </div>
            <p className="text-2xl font-bold text-zinc-100 mt-1">{orders.length}</p>
          </CardContent>
        </Card>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-500" />
              <span className="text-xs text-zinc-400">Zakończone</span>
            </div>
            <p className="text-2xl font-bold text-zinc-100 mt-1">{completedOrders}</p>
          </CardContent>
        </Card>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-blue-500" />
              <span className="text-xs text-zinc-400">W realizacji</span>
            </div>
            <p className="text-2xl font-bold text-zinc-100 mt-1">{inProgressOrders}</p>
          </CardContent>
        </Card>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-yellow-500" />
              <span className="text-xs text-zinc-400">Oczekujące</span>
            </div>
            <p className="text-2xl font-bold text-zinc-100 mt-1">{pendingOrders}</p>
          </CardContent>
        </Card>
      </div>

      {/* Całkowita kwota */}
      <Card className="bg-gradient-to-r from-amber-500/10 to-amber-600/5 border-amber-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-zinc-400">Całkowita wartość zamówień</p>
              <p className="text-3xl font-bold text-amber-400 mt-1">
                {totalAmount.toLocaleString('pl-PL', {
                  style: 'currency',
                  currency: 'PLN',
                })}
              </p>
            </div>
            <div className="h-12 w-12 rounded-full bg-amber-500/20 flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-amber-500" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista zamówień */}
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-zinc-100">
            Historia zamówień
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            {orders
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((order, index) => (
                <div key={order.id}>
                  {index > 0 && <Separator className="bg-zinc-800 my-3" />}
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-zinc-100">
                        {order.description}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-zinc-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(order.date).toLocaleDateString('pl-PL')}
                        </span>
                        <span>ID: {order.id}</span>
                      </div>
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-sm font-medium text-zinc-100">
                        {order.amount.toLocaleString('pl-PL', {
                          style: 'currency',
                          currency: 'PLN',
                        })}
                      </p>
                      <Badge
                        variant="outline"
                        className={`${orderStatusColors[order.status]} text-xs`}
                      >
                        {orderStatusLabels[order.status]}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
