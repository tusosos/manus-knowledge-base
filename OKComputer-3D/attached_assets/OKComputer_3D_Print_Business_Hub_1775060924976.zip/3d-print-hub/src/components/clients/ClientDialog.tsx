'use client';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ClientForm } from './ClientForm';
import type { Client, ClientStatus } from './types';

interface ClientDialogProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    status: ClientStatus;
    address: {
      street: string;
      city: string;
      postalCode: string;
      country: string;
    };
  }) => void;
}

export function ClientDialog({
  client,
  open,
  onOpenChange,
  onSubmit,
}: ClientDialogProps) {
  const handleSubmit = (data: Parameters<typeof onSubmit>[0]) => {
    onSubmit(data);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-zinc-950 border-zinc-800">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-zinc-100">
            {client ? 'Edytuj klienta' : 'Dodaj nowego klienta'}
          </DialogTitle>
        </DialogHeader>
        <ClientForm
          client={client}
          onSubmit={handleSubmit}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  );
}
