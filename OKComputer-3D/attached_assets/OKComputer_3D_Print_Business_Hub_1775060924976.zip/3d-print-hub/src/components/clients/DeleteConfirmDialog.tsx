'use client';

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { AlertTriangle } from 'lucide-react';
import type { Client } from './types';

interface DeleteConfirmDialogProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

export function DeleteConfirmDialog({
  client,
  open,
  onOpenChange,
  onConfirm,
}: DeleteConfirmDialogProps) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-zinc-950 border-zinc-800">
        <AlertDialogHeader>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
              <AlertTriangle className="h-5 w-5 text-red-500" />
            </div>
            <div>
              <AlertDialogTitle className="text-zinc-100">
                Usunąć klienta?
              </AlertDialogTitle>
              <AlertDialogDescription className="text-zinc-500">
                Tej akcji nie można cofnąć.
              </AlertDialogDescription>
            </div>
          </div>
        </AlertDialogHeader>

        {client && (
          <div className="my-4 p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
            <p className="text-sm text-zinc-400">
              Klient: <span className="text-zinc-100 font-medium">{client.firstName} {client.lastName}</span>
            </p>
            <p className="text-sm text-zinc-400 mt-1">
              Email: <span className="text-zinc-100">{client.email}</span>
            </p>
            {client.orders.length > 0 && (
              <p className="text-sm text-red-400 mt-2">
                Uwaga: Klient ma {client.orders.length} zamówień w systemie.
              </p>
            )}
          </div>
        )}

        <AlertDialogFooter>
          <AlertDialogCancel className="bg-zinc-900 border-zinc-800 text-zinc-100 hover:bg-zinc-800 hover:text-zinc-100">
            Anuluj
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-red-500 hover:bg-red-600 text-white"
          >
            Usuń klienta
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
