'use client';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { ClientStatus } from './types';

interface ClientAvatarProps {
  firstName: string;
  lastName: string;
  status?: ClientStatus;
  size?: 'sm' | 'md' | 'lg';
}

const statusRingColors: Record<ClientStatus, string> = {
  new: 'ring-blue-500/50',
  regular: 'ring-amber-500/50',
  vip: 'ring-purple-500/50',
};

const sizeClasses = {
  sm: 'h-8 w-8 text-xs',
  md: 'h-10 w-10 text-sm',
  lg: 'h-16 w-16 text-lg',
};

export function ClientAvatar({
  firstName,
  lastName,
  status,
  size = 'md',
}: ClientAvatarProps) {
  const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();

  // Generowanie koloru na podstawie inicjałów
  const hue =
    ((firstName.charCodeAt(0) + lastName.charCodeAt(0)) % 360) * 0.7 + 180;
  const backgroundColor = `hsl(${hue}, 60%, 35%)`;

  return (
    <Avatar
      className={`${sizeClasses[size]} ${status ? `ring-2 ${statusRingColors[status]}` : ''}`}
    >
      <AvatarFallback
        className="font-medium text-white"
        style={{ backgroundColor }}
      >
        {initials}
      </AvatarFallback>
    </Avatar>
  );
}
