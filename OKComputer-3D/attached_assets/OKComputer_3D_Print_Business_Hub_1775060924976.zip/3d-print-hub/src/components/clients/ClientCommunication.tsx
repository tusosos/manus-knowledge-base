'use client';

import { useState } from 'react';
import { MessageSquare, Calendar, User, Send, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Note } from './types';

interface ClientCommunicationProps {
  notes: Note[];
  lastContactDate?: string;
  onAddNote?: (content: string) => void;
}

export function ClientCommunication({
  notes,
  lastContactDate,
  onAddNote,
}: ClientCommunicationProps) {
  const [newNote, setNewNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!newNote.trim() || !onAddNote) return;
    setIsSubmitting(true);
    await onAddNote(newNote.trim());
    setNewNote('');
    setIsSubmitting(false);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      if (diffInHours < 1) {
        return 'Przed chwilą';
      }
      return `${Math.floor(diffInHours)} godz. temu`;
    }
    if (diffInHours < 48) {
      return 'Wczoraj';
    }
    return date.toLocaleDateString('pl-PL', {
      day: 'numeric',
      month: 'short',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
    });
  };

  return (
    <div className="space-y-4">
      {/* Ostatni kontakt */}
      {lastContactDate && (
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-zinc-400">Ostatni kontakt</p>
                <p className="text-lg font-medium text-zinc-100">
                  {formatDate(lastContactDate)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dodawanie notatki */}
      {onAddNote && (
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-zinc-100 flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-amber-500" />
              Dodaj notatkę
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <Textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Wpisz treść notatki..."
              className="min-h-[100px] bg-zinc-900/50 border-zinc-800 text-zinc-100 placeholder:text-zinc-600 resize-none"
            />
            <div className="flex justify-end">
              <Button
                onClick={handleSubmit}
                disabled={!newNote.trim() || isSubmitting}
                className="bg-amber-500 hover:bg-amber-600 text-zinc-950 disabled:opacity-50"
              >
                <Send className="h-4 w-4 mr-2" />
                Dodaj notatkę
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Historia notatek */}
      <Card className="bg-zinc-900/50 border-zinc-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-zinc-100 flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-zinc-500" />
            Historia komunikacji
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {notes.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="h-12 w-12 rounded-full bg-zinc-800/50 flex items-center justify-center mb-3">
                <MessageSquare className="h-6 w-6 text-zinc-500" />
              </div>
              <p className="text-zinc-400 font-medium">Brak notatek</p>
              <p className="text-sm text-zinc-500 mt-1">
                Nie dodano jeszcze żadnych notatek dla tego klienta.
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {notes
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((note, index) => (
                    <div key={note.id}>
                      {index > 0 && <Separator className="bg-zinc-800 my-4" />}
                      <div className="flex gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-zinc-800 text-zinc-400 text-xs">
                            {note.author
                              .split(' ')
                              .map((n) => n[0])
                              .join('')
                              .toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <User className="h-3 w-3 text-zinc-500" />
                              <span className="text-sm font-medium text-zinc-300">
                                {note.author}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-xs text-zinc-500">
                              <Calendar className="h-3 w-3" />
                              {formatDate(note.date)}
                            </div>
                          </div>
                          <p className="text-sm text-zinc-400 leading-relaxed">
                            {note.content}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
