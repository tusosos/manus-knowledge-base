'use client';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Eye, Edit, Trash2, Mail, Phone } from 'lucide-react';
import { ClientAvatar } from './ClientAvatar';
import { ClientStatusBadge } from './ClientStatusBadge';
import type { Client } from './types';

interface ClientsTableProps {
  clients: Client[];
  onView: (client: Client) => void;
  onEdit: (client: Client) => void;
  onDelete: (client: Client) => void;
}

export function ClientsTable({ clients, onView, onEdit, onDelete }: ClientsTableProps) {
  if (clients.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="h-16 w-16 rounded-full bg-zinc-800/50 flex items-center justify-center mb-4">
          <Mail className="h-8 w-8 text-zinc-500" />
        </div>
        <h3 className="text-lg font-medium text-zinc-100 mb-2">
          Nie znaleziono klientów
        </h3>
        <p className="text-sm text-zinc-500 max-w-sm">
          Spróbuj zmienić kryteria wyszukiwania lub filtry, aby znaleźć klientów.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-md border border-zinc-800 overflow-hidden">
      <Table>
        <TableHeader className="bg-zinc-900/50">
          <TableRow className="border-zinc-800 hover:bg-transparent">
            <TableHead className="text-zinc-400 font-medium">Klient</TableHead>
            <TableHead className="text-zinc-400 font-medium">Kontakt</TableHead>
            <TableHead className="text-zinc-400 font-medium">Status</TableHead>
            <TableHead className="text-zinc-400 font-medium">Zamówienia</TableHead>
            <TableHead className="text-zinc-400 font-medium text-right">Akcje</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {clients.map((client) => (
            <TableRow
              key={client.id}
              className="border-zinc-800 hover:bg-zinc-900/30 cursor-pointer"
              onClick={() => onView(client)}
            >
              <TableCell>
                <div className="flex items-center gap-3">
                  <ClientAvatar
                    firstName={client.firstName}
                    lastName={client.lastName}
                    status={client.status}
                    size="sm"
                  />
                  <div>
                    <p className="font-medium text-zinc-100">
                      {client.firstName} {client.lastName}
                    </p>
                    <p className="text-xs text-zinc-500">
                      Od {new Date(client.createdAt).toLocaleDateString('pl-PL')}
                    </p>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-zinc-400">
                    <Mail className="h-3.5 w-3.5" />
                    <span className="truncate max-w-[180px]">{client.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-zinc-400">
                    <Phone className="h-3.5 w-3.5" />
                    <span>{client.phone}</span>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <ClientStatusBadge status={client.status} />
              </TableCell>
              <TableCell>
                <div className="text-sm">
                  <span className="text-zinc-100 font-medium">
                    {client.orders.length}
                  </span>
                  <span className="text-zinc-500 ml-1">
                    ({client.orders
                      .reduce((sum, o) => sum + o.amount, 0)
                      .toLocaleString('pl-PL', { style: 'currency', currency: 'PLN' })}
                    )
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-zinc-400 hover:text-zinc-100"
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="end"
                    className="w-48 bg-zinc-900 border-zinc-800"
                  >
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onView(client);
                      }}
                      className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Szczegóły
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit(client);
                      }}
                      className="text-zinc-100 focus:bg-zinc-800 focus:text-zinc-100"
                    >
                      <Edit className="h-4 w-4 mr-2" />
                      Edytuj
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-zinc-800" />
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(client);
                      }}
                      className="text-red-400 focus:bg-zinc-800 focus:text-red-400"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Usuń
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
