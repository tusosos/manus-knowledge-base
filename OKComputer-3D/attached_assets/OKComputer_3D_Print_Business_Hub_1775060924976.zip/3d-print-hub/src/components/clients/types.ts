export type ClientStatus = 'new' | 'regular' | 'vip';

export interface Address {
  street: string;
  city: string;
  postalCode: string;
  country: string;
}

export interface Order {
  id: string;
  date: string;
  amount: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  description: string;
}

export interface Preferences {
  favoriteMaterials: string[];
  preferredColors: string[];
  projectStyles: string[];
}

export interface Note {
  id: string;
  date: string;
  content: string;
  author: string;
}

export interface Client {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  status: ClientStatus;
  address: Address;
  notes: Note[];
  orders: Order[];
  preferences: Preferences;
  createdAt: string;
  lastContactDate?: string;
  avatar?: string;
}

export interface ClientFilter {
  search: string;
  status: ClientStatus | 'all';
}

export const statusLabels: Record<ClientStatus, string> = {
  new: 'Nowy',
  regular: 'Stały',
  vip: 'VIP',
};

export const statusColors: Record<ClientStatus, string> = {
  new: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  regular: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  vip: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
};

export const orderStatusLabels: Record<Order['status'], string> = {
  pending: 'Oczekujące',
  in_progress: 'W realizacji',
  completed: 'Zakończone',
  cancelled: 'Anulowane',
};

export const orderStatusColors: Record<Order['status'], string> = {
  pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  in_progress: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  completed: 'bg-green-500/10 text-green-400 border-green-500/20',
  cancelled: 'bg-red-500/10 text-red-400 border-red-500/20',
};
