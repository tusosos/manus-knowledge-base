'use client';

import { Users, UserPlus, Crown, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface ClientStatsProps {
  total: number;
  new: number;
  regular: number;
  vip: number;
  totalRevenue: number;
}

export function ClientStats({ total, new: newCount, regular, vip, totalRevenue }: ClientStatsProps) {
  const stats = [
    {
      label: 'Wszyscy klienci',
      value: total,
      icon: Users,
      color: 'text-zinc-100',
      bgColor: 'bg-zinc-800/50',
    },
    {
      label: 'Nowi',
      value: newCount,
      icon: UserPlus,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
    },
    {
      label: 'Stali',
      value: regular,
      icon: TrendingUp,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
    },
    {
      label: 'VIP',
      value: vip,
      icon: Crown,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
    },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label} className="bg-zinc-900/50 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-zinc-100">{stat.value}</p>
                  <p className="text-xs text-zinc-500">{stat.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-amber-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-zinc-400">Całkowity przychód od klientów</p>
              <p className="text-3xl font-bold text-amber-400 mt-1">
                {totalRevenue.toLocaleString('pl-PL', {
                  style: 'currency',
                  currency: 'PLN',
                })}
              </p>
            </div>
            <div className="h-14 w-14 rounded-full bg-amber-500/20 flex items-center justify-center">
              <TrendingUp className="h-7 w-7 text-amber-500" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
