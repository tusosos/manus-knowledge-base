'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Shield, 
  AlertTriangle, 
  Lightbulb, 
  AlertOctagon,
  TrendingUp,
  TrendingDown,
  Target,
  Zap
} from 'lucide-react';
import { SWOT_DATA } from './constants';
import type { SWOTItem } from './types';

const priorityColors = {
  high: 'bg-red-500/20 text-red-400 border-red-500/50',
  medium: 'bg-amber-500/20 text-amber-400 border-amber-500/50',
  low: 'bg-blue-500/20 text-blue-400 border-blue-500/50'
};

const priorityLabels = {
  high: 'Wysoki',
  medium: 'Średni',
  low: 'Niski'
};

interface SWOTCardProps {
  title: string;
  icon: React.ReactNode;
  items: SWOTItem[];
  bgColor: string;
  borderColor: string;
  iconColor: string;
}

function SWOTCard({ title, icon, items, bgColor, borderColor, iconColor }: SWOTCardProps) {
  return (
    <Card className={`${bgColor} ${borderColor} border-2 h-full`}>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${iconColor}`}>
            {icon}
          </div>
          <CardTitle className="text-white text-lg">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {items.map((item) => (
            <div 
              key={item.id}
              className="bg-slate-900/50 rounded-lg p-3 border border-slate-700/50"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="text-slate-300 text-sm">{item.text}</p>
                <Badge 
                  variant="outline" 
                  className={`text-xs whitespace-nowrap ${priorityColors[item.priority]}`}
                >
                  {priorityLabels[item.priority]}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function SWOTAnalysis() {
  const { strengths, weaknesses, opportunities, threats } = SWOT_DATA;

  // Count priorities
  const countPriorities = (items: SWOTItem[]) => ({
    high: items.filter(i => i.priority === 'high').length,
    medium: items.filter(i => i.priority === 'medium').length,
    low: items.filter(i => i.priority === 'low').length
  });

  const sCounts = countPriorities(strengths);
  const wCounts = countPriorities(weaknesses);
  const oCounts = countPriorities(opportunities);
  const tCounts = countPriorities(threats);

  return (
    <div className="space-y-6">
      {/* SWOT Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <SWOTCard
          title="Mocne Strony (Strengths)"
          icon={<Shield className="h-5 w-5" />}
          items={strengths}
          bgColor="bg-emerald-900/20"
          borderColor="border-emerald-800"
          iconColor="bg-emerald-500/20 text-emerald-400"
        />
        <SWOTCard
          title="Słabe Strony (Weaknesses)"
          icon={<AlertTriangle className="h-5 w-5" />}
          items={weaknesses}
          bgColor="bg-red-900/20"
          borderColor="border-red-800"
          iconColor="bg-red-500/20 text-red-400"
        />
        <SWOTCard
          title="Szanse (Opportunities)"
          icon={<Lightbulb className="h-5 w-5" />}
          items={opportunities}
          bgColor="bg-blue-900/20"
          borderColor="border-blue-800"
          iconColor="bg-blue-500/20 text-blue-400"
        />
        <SWOTCard
          title="Zagrożenia (Threats)"
          icon={<AlertOctagon className="h-5 w-5" />}
          items={threats}
          bgColor="bg-amber-900/20"
          borderColor="border-amber-800"
          iconColor="bg-amber-500/20 text-amber-400"
        />
      </div>

      {/* Priority Summary */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="h-5 w-5 text-purple-400" />
            Podsumowanie Priorytetów
          </CardTitle>
          <CardDescription className="text-slate-400">
            Rozkład elementów SWOT według priorytetów
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Strengths Summary */}
            <div className="bg-emerald-900/20 rounded-lg p-4 border border-emerald-800">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="h-4 w-4 text-emerald-400" />
                <span className="text-emerald-400 font-medium">Mocne Strony</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Wysoki</span>
                  <span className="text-red-400 font-medium">{sCounts.high}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Średni</span>
                  <span className="text-amber-400 font-medium">{sCounts.medium}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Niski</span>
                  <span className="text-blue-400 font-medium">{sCounts.low}</span>
                </div>
              </div>
            </div>

            {/* Weaknesses Summary */}
            <div className="bg-red-900/20 rounded-lg p-4 border border-red-800">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="h-4 w-4 text-red-400" />
                <span className="text-red-400 font-medium">Słabe Strony</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Wysoki</span>
                  <span className="text-red-400 font-medium">{wCounts.high}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Średni</span>
                  <span className="text-amber-400 font-medium">{wCounts.medium}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Niski</span>
                  <span className="text-blue-400 font-medium">{wCounts.low}</span>
                </div>
              </div>
            </div>

            {/* Opportunities Summary */}
            <div className="bg-blue-900/20 rounded-lg p-4 border border-blue-800">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="h-4 w-4 text-blue-400" />
                <span className="text-blue-400 font-medium">Szanse</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Wysoki</span>
                  <span className="text-red-400 font-medium">{oCounts.high}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Średni</span>
                  <span className="text-amber-400 font-medium">{oCounts.medium}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Niski</span>
                  <span className="text-blue-400 font-medium">{oCounts.low}</span>
                </div>
              </div>
            </div>

            {/* Threats Summary */}
            <div className="bg-amber-900/20 rounded-lg p-4 border border-amber-800">
              <div className="flex items-center gap-2 mb-3">
                <AlertOctagon className="h-4 w-4 text-amber-400" />
                <span className="text-amber-400 font-medium">Zagrożenia</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Wysoki</span>
                  <span className="text-red-400 font-medium">{tCounts.high}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Średni</span>
                  <span className="text-amber-400 font-medium">{tCounts.medium}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Niski</span>
                  <span className="text-blue-400 font-medium">{tCounts.low}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Strategic Recommendations */}
      <Card className="bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-purple-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-purple-400" />
            Rekomendacje Strategiczne
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* SO Strategy */}
            <div className="space-y-3">
              <h4 className="text-emerald-400 font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Strategia SO (Strengths + Opportunities)
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">→</span>
                  Wykorzystaj szybki czas realizacji do obsługi rosnącego rynku prototypowania
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">→</span>
                  Rozwijaj współpracę ze startupami technologicznymi
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">→</span>
                  Wejdź na rynek medyczny (ortotyka) z wysoką jakością druku
                </li>
              </ul>
            </div>

            {/* WO Strategy */}
            <div className="space-y-3">
              <h4 className="text-blue-400 font-medium flex items-center gap-2">
                <Lightbulb className="h-4 w-4" />
                Strategia WO (Weaknesses + Opportunities)
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 mt-1">→</span>
                  Zdobądź certyfikaty dla segmentu medycznego
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 mt-1">→</span>
                  Rozwijaj umiejętności CAD poprzez szkolenia
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-500 mt-1">→</span>
                  Zdywersyfikuj dostawców filamentu
                </li>
              </ul>
            </div>

            {/* ST Strategy */}
            <div className="space-y-3">
              <h4 className="text-amber-400 font-medium flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Strategia ST (Strengths + Threats)
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">→</span>
                  Konkuruj jakością, nie ceną
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">→</span>
                  Buduj lojalność klientów poprzez elastyczność
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">→</span>
                  Twórz bariery wejścia poprzez specjalizację
                </li>
              </ul>
            </div>

            {/* WT Strategy */}
            <div className="space-y-3">
              <h4 className="text-red-400 font-medium flex items-center gap-2">
                <TrendingDown className="h-4 w-4" />
                Strategia WT (Weaknesses + Threats)
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">→</span>
                  Zabezpiecz zapasy materiałów na wypadek wzrostu cen
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">→</span>
                  Rozważ outsourcing projektów CAD
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-1">→</span>
                  Planuj stopniową rozbudowę pojemności produkcyjnej
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
