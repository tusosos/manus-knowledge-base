'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line,
  ComposedChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  Calendar, 
  Target, 
  DollarSign,
  Download,
  FileText
} from 'lucide-react';
import { REVENUE_FORECAST, formatCurrency } from './constants';

interface ForecastPeriod {
  label: string;
  months: number[];
}

const FORECAST_PERIODS: ForecastPeriod[] = [
  { label: '3 miesiące', months: [1, 2, 3] },
  { label: '6 miesięcy', months: [1, 2, 3, 4, 5, 6] },
  { label: '12 miesięcy', months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] }
];

export function RevenueForecast() {
  const [selectedPeriod, setSelectedPeriod] = useState<number>(12);

  const getFilteredData = () => {
    const period = FORECAST_PERIODS.find(p => p.months.length === selectedPeriod);
    if (!period) return REVENUE_FORECAST;
    return REVENUE_FORECAST.filter(d => period.months.includes(d.month));
  };

  const filteredData = getFilteredData();
  const lastMonth = filteredData[filteredData.length - 1];
  const firstMonth = filteredData[0];
  
  const totalRevenue = filteredData.reduce((sum, d) => sum + d.revenue, 0);
  const totalCosts = filteredData.reduce((sum, d) => sum + d.costs, 0);
  const totalProfit = filteredData.reduce((sum, d) => sum + d.profit, 0);
  const avgMonthlyRevenue = totalRevenue / filteredData.length;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3 shadow-lg">
          <p className="text-white font-medium mb-2">Miesiąc {label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4">
            <p className="text-xs text-slate-400">Przychód całkowity</p>
            <p className="text-lg font-bold text-emerald-400 mt-1">
              {formatCurrency(totalRevenue)}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4">
            <p className="text-xs text-slate-400">Koszty całkowite</p>
            <p className="text-lg font-bold text-red-400 mt-1">
              {formatCurrency(totalCosts)}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4">
            <p className="text-xs text-slate-400">Zysk całkowity</p>
            <p className={`text-lg font-bold mt-1 ${totalProfit >= 0 ? 'text-blue-400' : 'text-red-400'}`}>
              {formatCurrency(totalProfit)}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-4">
            <p className="text-xs text-slate-400">Śr. przychód/mies.</p>
            <p className="text-lg font-bold text-purple-400 mt-1">
              {formatCurrency(avgMonthlyRevenue)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Period Selector */}
      <div className="flex flex-wrap gap-2">
        {FORECAST_PERIODS.map((period) => (
          <Button
            key={period.months.length}
            variant={selectedPeriod === period.months.length ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedPeriod(period.months.length)}
            className={selectedPeriod === period.months.length 
              ? 'bg-blue-600 hover:bg-blue-700' 
              : 'border-slate-700 text-slate-300 hover:bg-slate-800'
            }
          >
            <Calendar className="h-4 w-4 mr-2" />
            {period.label}
          </Button>
        ))}
      </div>

      {/* Charts */}
      <Tabs defaultValue="bar" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800">
          <TabsTrigger value="bar" className="data-[state=active]:bg-slate-700">
            <TrendingUp className="h-4 w-4 mr-2" />
            Słupkowy
          </TabsTrigger>
          <TabsTrigger value="line" className="data-[state=active]:bg-slate-700">
            <Target className="h-4 w-4 mr-2" />
            Liniowy
          </TabsTrigger>
          <TabsTrigger value="combined" className="data-[state=active]:bg-slate-700">
            <DollarSign className="h-4 w-4 mr-2" />
            Złożony
          </TabsTrigger>
        </TabsList>

        <TabsContent value="bar">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Prognoza Przychodów i Kosztów</CardTitle>
              <CardDescription className="text-slate-400">
                Porównanie przychodów, kosztów i zysków miesięcznych
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis 
                      dataKey="month" 
                      stroke="#94a3b8"
                      tickFormatter={(value) => `M${value}`}
                    />
                    <YAxis 
                      stroke="#94a3b8"
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar 
                      dataKey="revenue" 
                      name="Przychód" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar 
                      dataKey="costs" 
                      name="Koszty" 
                      fill="#ef4444" 
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar 
                      dataKey="profit" 
                      name="Zysk" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="line">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Trend Zysków Skumulowanych</CardTitle>
              <CardDescription className="text-slate-400">
                Wizualizacja kumulatywnego zysku w czasie
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis 
                      dataKey="month" 
                      stroke="#94a3b8"
                      tickFormatter={(value) => `M${value}`}
                    />
                    <YAxis 
                      stroke="#94a3b8"
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="cumulativeProfit" 
                      name="Zysk skumulowany" 
                      stroke="#8b5cf6" 
                      strokeWidth={3}
                      dot={{ fill: '#8b5cf6', strokeWidth: 2 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="revenue" 
                      name="Przychód" 
                      stroke="#10b981" 
                      strokeWidth={2}
                      strokeDasharray="5 5"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="combined">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Analiza Złożona</CardTitle>
              <CardDescription className="text-slate-400">
                Przychody (słupki) vs Zysk skumulowany (linia)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis 
                      dataKey="month" 
                      stroke="#94a3b8"
                      tickFormatter={(value) => `M${value}`}
                    />
                    <YAxis 
                      yAxisId="left"
                      stroke="#94a3b8"
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    />
                    <YAxis 
                      yAxisId="right"
                      orientation="right"
                      stroke="#8b5cf6"
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar 
                      yAxisId="left"
                      dataKey="revenue" 
                      name="Przychód" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]}
                    />
                    <Bar 
                      yAxisId="left"
                      dataKey="costs" 
                      name="Koszty" 
                      fill="#ef4444" 
                      radius={[4, 4, 0, 0]}
                    />
                    <Line 
                      yAxisId="right"
                      type="monotone" 
                      dataKey="cumulativeProfit" 
                      name="Zysk skumulowany" 
                      stroke="#8b5cf6" 
                      strokeWidth={3}
                      dot={{ fill: '#8b5cf6', strokeWidth: 2 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Monthly Details Table */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-white">Szczegóły Miesięczne</CardTitle>
            <CardDescription className="text-slate-400">
              Pełna tabela prognoz finansowych
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" className="border-slate-700 text-slate-300">
            <Download className="h-4 w-4 mr-2" />
            Eksport CSV
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Miesiąc</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Przychód</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Koszty</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Zysk</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Zysk skum.</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((data) => (
                  <tr key={data.month} className="border-b border-slate-800 hover:bg-slate-800/50">
                    <td className="py-3 px-4 text-white font-medium">
                      Miesiąc {data.month}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-400">
                      {formatCurrency(data.revenue)}
                    </td>
                    <td className="py-3 px-4 text-right text-red-400">
                      {formatCurrency(data.costs)}
                    </td>
                    <td className={`py-3 px-4 text-right font-medium ${
                      data.profit >= 0 ? 'text-blue-400' : 'text-red-400'
                    }`}>
                      {formatCurrency(data.profit)}
                    </td>
                    <td className={`py-3 px-4 text-right font-medium ${
                      data.cumulativeProfit >= 0 ? 'text-purple-400' : 'text-red-400'
                    }`}>
                      {formatCurrency(data.cumulativeProfit)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {data.profit >= 0 ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-emerald-900/50 text-emerald-400">
                          Zysk
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-red-900/50 text-red-400">
                          Strata
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Key Milestones */}
      <Card className="bg-gradient-to-r from-emerald-900/30 to-blue-900/30 border-emerald-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="h-5 w-5 text-emerald-400" />
            Kluczowe Kamienie Milowe
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-800/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Pierwszy zysk</p>
              <p className="text-xl font-bold text-emerald-400 mt-1">Miesiąc 3</p>
              <p className="text-xs text-slate-500 mt-1">
                Zysk: {formatCurrency(REVENUE_FORECAST[2].profit)}
              </p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Zwrot inwestycji</p>
              <p className="text-xl font-bold text-blue-400 mt-1">Miesiąc 4</p>
              <p className="text-xs text-slate-500 mt-1">
                Zysk skumulowany dodatni
              </p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-4">
              <p className="text-sm text-slate-400">Cel roczny</p>
              <p className="text-xl font-bold text-purple-400 mt-1">Miesiąc 12</p>
              <p className="text-xs text-slate-500 mt-1">
                Zysk skumulowany: {formatCurrency(REVENUE_FORECAST[11].cumulativeProfit)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
