'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Target, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  Users,
  Settings,
  Heart,
  Calendar,
  CheckCircle2,
  Clock,
  Edit2,
  Save
} from 'lucide-react';
import { KPI_TARGETS, formatCurrency } from './constants';
import type { KPITarget } from './types';

const categoryIcons: Record<string, React.ReactNode> = {
  financial: <DollarSign className="h-4 w-4" />,
  operational: <Settings className="h-4 w-4" />,
  marketing: <Users className="h-4 w-4" />,
  customer: <Heart className="h-4 w-4" />
};

const categoryLabels: Record<string, string> = {
  financial: 'Finansowe',
  operational: 'Operacyjne',
  marketing: 'Marketing',
  customer: 'Klienci'
};

const categoryColors: Record<string, string> = {
  financial: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50',
  operational: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
  marketing: 'bg-purple-500/20 text-purple-400 border-purple-500/50',
  customer: 'bg-pink-500/20 text-pink-400 border-pink-500/50'
};

export function KPITargets() {
  const [kpis, setKpis] = useState<KPITarget[]>(KPI_TARGETS);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleUpdateKPI = (id: string, field: 'target' | 'current', value: number) => {
    setKpis(prev => prev.map(kpi => 
      kpi.id === id ? { ...kpi, [field]: value } : kpi
    ));
  };

  const getProgress = (current: number, target: number) => {
    if (target === 0) return 0;
    return Math.min((current / target) * 100, 100);
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-emerald-500';
    if (progress >= 50) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const kpisByCategory = kpis.reduce((acc, kpi) => {
    if (!acc[kpi.category]) acc[kpi.category] = [];
    acc[kpi.category].push(kpi);
    return acc;
  }, {} as Record<string, KPITarget[]>);

  const totalProgress = kpis.reduce((sum, kpi) => sum + getProgress(kpi.current, kpi.target), 0) / kpis.length;

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-slate-400">Postęp Celów Roku 1</p>
              <p className="text-3xl font-bold text-white mt-1">
                {totalProgress.toFixed(1)}%
              </p>
            </div>
            <div className="p-4 bg-blue-500/20 rounded-full">
              <Target className="h-8 w-8 text-blue-400" />
            </div>
          </div>
          <Progress 
            value={totalProgress} 
            className="h-3 bg-slate-700"
          />
          <p className="text-sm text-slate-400 mt-3">
            {kpis.filter(k => k.current >= k.target).length} z {kpis.length} celów osiągniętych
          </p>
        </CardContent>
      </Card>

      {/* KPIs by Category */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-slate-800">
          <TabsTrigger value="all" className="data-[state=active]:bg-slate-700">
            Wszystkie
          </TabsTrigger>
          <TabsTrigger value="financial" className="data-[state=active]:bg-slate-700">
            <DollarSign className="h-4 w-4 mr-1" />
            Finanse
          </TabsTrigger>
          <TabsTrigger value="operational" className="data-[state=active]:bg-slate-700">
            <Settings className="h-4 w-4 mr-1" />
            Operacje
          </TabsTrigger>
          <TabsTrigger value="marketing" className="data-[state=active]:bg-slate-700">
            <Users className="h-4 w-4 mr-1" />
            Marketing
          </TabsTrigger>
          <TabsTrigger value="customer" className="data-[state=active]:bg-slate-700">
            <Heart className="h-4 w-4 mr-1" />
            Klienci
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {kpis.map((kpi) => {
              const progress = getProgress(kpi.current, kpi.target);
              const isAchieved = kpi.current >= kpi.target;

              return (
                <Card key={kpi.id} className="bg-slate-900 border-slate-800">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${categoryColors[kpi.category]}`}>
                          {categoryIcons[kpi.category]}
                        </div>
                        <div>
                          <p className="text-white font-medium">{kpi.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className={`text-xs ${categoryColors[kpi.category]}`}>
                              {categoryLabels[kpi.category]}
                            </Badge>
                            <span className="text-xs text-slate-500 flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {kpi.deadline}
                            </span>
                          </div>
                        </div>
                      </div>
                      {isAchieved && (
                        <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                      )}
                    </div>

                    {editingId === kpi.id ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-xs text-slate-400">Cel</label>
                            <Input
                              type="number"
                              value={kpi.target}
                              onChange={(e) => handleUpdateKPI(kpi.id, 'target', Number(e.target.value))}
                              className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-slate-400">Aktualnie</label>
                            <Input
                              type="number"
                              value={kpi.current}
                              onChange={(e) => handleUpdateKPI(kpi.id, 'current', Number(e.target.value))}
                              className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                          </div>
                        </div>
                        <Button 
                          size="sm"
                          onClick={() => setEditingId(null)}
                          className="w-full bg-blue-600 hover:bg-blue-700"
                        >
                          <Save className="h-4 w-4 mr-2" />
                          Zapisz
                        </Button>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-baseline gap-2">
                            <span className="text-2xl font-bold text-white">
                              {kpi.unit === 'PLN' ? formatCurrency(kpi.current) : kpi.current}
                            </span>
                            <span className="text-slate-400">/ {kpi.unit === 'PLN' ? formatCurrency(kpi.target) : kpi.target} {kpi.unit}</span>
                          </div>
                          <span className={`text-sm font-medium ${
                            progress >= 80 ? 'text-emerald-400' : 
                            progress >= 50 ? 'text-amber-400' : 'text-red-400'
                          }`}>
                            {progress.toFixed(0)}%
                          </span>
                        </div>

                        <Progress 
                          value={progress} 
                          className="h-2 bg-slate-700"
                        />

                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-2 text-sm">
                            {kpi.current >= kpi.target ? (
                              <TrendingUp className="h-4 w-4 text-emerald-500" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-500" />
                            )}
                            <span className={kpi.current >= kpi.target ? 'text-emerald-400' : 'text-red-400'}>
                              {kpi.current >= kpi.target ? 'Cel osiągnięty' : `Brakuje ${kpi.target - kpi.current} ${kpi.unit}`}
                            </span>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => setEditingId(kpi.id)}
                            className="text-slate-400 hover:text-white"
                          >
                            <Edit2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {Object.entries(kpisByCategory).map(([category, categoryKpis]) => (
          <TabsContent key={category} value={category} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categoryKpis.map((kpi) => {
                const progress = getProgress(kpi.current, kpi.target);
                const isAchieved = kpi.current >= kpi.target;

                return (
                  <Card key={kpi.id} className="bg-slate-900 border-slate-800">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${categoryColors[kpi.category]}`}>
                            {categoryIcons[kpi.category]}
                          </div>
                          <div>
                            <p className="text-white font-medium">{kpi.name}</p>
                            <span className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                              <Calendar className="h-3 w-3" />
                              {kpi.deadline}
                            </span>
                          </div>
                        </div>
                        {isAchieved && (
                          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        )}
                      </div>

                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-white">
                            {kpi.unit === 'PLN' ? formatCurrency(kpi.current) : kpi.current}
                          </span>
                          <span className="text-slate-400">/ {kpi.unit === 'PLN' ? formatCurrency(kpi.target) : kpi.target} {kpi.unit}</span>
                        </div>
                        <span className={`text-sm font-medium ${
                          progress >= 80 ? 'text-emerald-400' : 
                          progress >= 50 ? 'text-amber-400' : 'text-red-400'
                        }`}>
                          {progress.toFixed(0)}%
                        </span>
                      </div>

                      <Progress 
                        value={progress} 
                        className="h-2 bg-slate-700"
                      />
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Summary by Category */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="h-5 w-5 text-amber-400" />
            Podsumowanie Kategorii
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(kpisByCategory).map(([category, categoryKpis]) => {
              const categoryProgress = categoryKpis.reduce((sum, kpi) => 
                sum + getProgress(kpi.current, kpi.target), 0
              ) / categoryKpis.length;

              return (
                <div key={category} className="bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1.5 rounded ${categoryColors[category]}`}>
                      {categoryIcons[category]}
                    </div>
                    <span className="text-slate-300 text-sm">{categoryLabels[category]}</span>
                  </div>
                  <p className="text-2xl font-bold text-white">
                    {categoryProgress.toFixed(0)}%
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {categoryKpis.filter(k => k.current >= k.target).length} / {categoryKpis.length} celów
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Year 1 Goals Summary */}
      <Card className="bg-gradient-to-r from-emerald-900/30 to-blue-900/30 border-emerald-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="h-5 w-5 text-emerald-400" />
            Cele na Pierwszy Rok - Podsumowanie
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-slate-800/50 rounded-lg">
              <p className="text-sm text-slate-400">Przychód roczny</p>
              <p className="text-xl font-bold text-emerald-400 mt-1">
                {formatCurrency(35000 * 12)}
              </p>
              <p className="text-xs text-slate-500 mt-1">Cel: 35k PLN/mies.</p>
            </div>
            <div className="text-center p-4 bg-slate-800/50 rounded-lg">
              <p className="text-sm text-slate-400">Zamówienia rocznie</p>
              <p className="text-xl font-bold text-blue-400 mt-1">1,800</p>
              <p className="text-xs text-slate-500 mt-1">Cel: 150/mies.</p>
            </div>
            <div className="text-center p-4 bg-slate-800/50 rounded-lg">
              <p className="text-sm text-slate-400">Nowi klienci</p>
              <p className="text-xl font-bold text-purple-400 mt-1">240</p>
              <p className="text-xs text-slate-500 mt-1">Cel: 20/mies.</p>
            </div>
            <div className="text-center p-4 bg-slate-800/50 rounded-lg">
              <p className="text-sm text-slate-400">Zadowolenie</p>
              <p className="text-xl font-bold text-pink-400 mt-1">95%</p>
              <p className="text-xs text-slate-500 mt-1">Cel: 95%</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
