'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  DollarSign, 
  Calculator, 
  BarChart3, 
  Target, 
  Shield,
  Lightbulb,
  Zap,
  FileText,
  Download,
  Printer,
  Calendar,
  ArrowRight
} from 'lucide-react';

import { MarketAnalysis } from './MarketAnalysis';
import { RevenueModel } from './RevenueModel';
import { CostCalculator } from './CostCalculator';
import { RevenueForecast } from './RevenueForecast';
import { BreakEvenAnalysis } from './BreakEvenAnalysis';
import { SWOTAnalysis } from './SWOTAnalysis';
import { KPITargets } from './KPITargets';
import { INITIAL_INVESTMENT, REVENUE_FORECAST, formatCurrency } from './constants';

export function BusinessPlan() {
  const [activeTab, setActiveTab] = useState('overview');

  // Calculate summary metrics
  const totalInvestment = INITIAL_INVESTMENT.total;
  const yearEndProfit = REVENUE_FORECAST[REVENUE_FORECAST.length - 1].cumulativeProfit;
  const breakEvenMonth = REVENUE_FORECAST.findIndex(m => m.cumulativeProfit >= 0) + 1;
  const avgMonthlyRevenue = REVENUE_FORECAST.reduce((sum, m) => sum + m.revenue, 0) / 12;

  const exportToPDF = () => {
    // This would trigger PDF generation
    alert('Eksport do PDF - funkcja w przygotowaniu');
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 bg-blue-600 rounded-xl">
                <Printer className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">3D Print Business Hub</h1>
                <p className="text-slate-400">Kompleksowy Biznesplan</p>
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={exportToPDF}
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <Download className="h-4 w-4 mr-2" />
              Eksport PDF
            </Button>
            <Button 
              onClick={() => window.print()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Printer className="h-4 w-4 mr-2" />
              Drukuj
            </Button>
          </div>
        </div>

        {/* Executive Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-4">
              <p className="text-xs text-slate-400">Inwestycja początkowa</p>
              <p className="text-xl font-bold text-white mt-1">
                {formatCurrency(totalInvestment)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-4">
              <p className="text-xs text-slate-400">Zysk rok 1</p>
              <p className="text-xl font-bold text-emerald-400 mt-1">
                {formatCurrency(yearEndProfit)}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-4">
              <p className="text-xs text-slate-400">Break-even</p>
              <p className="text-xl font-bold text-blue-400 mt-1">
                Miesiąc {breakEvenMonth}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-4">
              <p className="text-xs text-slate-400">Śr. przychód/mies.</p>
              <p className="text-xl font-bold text-purple-400 mt-1">
                {formatCurrency(avgMonthlyRevenue)}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content Tabs */}
      <div className="max-w-7xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 md:grid-cols-8 bg-slate-900 border border-slate-800 p-1">
            <TabsTrigger 
              value="overview" 
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <FileText className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Przegląd</span>
            </TabsTrigger>
            <TabsTrigger 
              value="market"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <TrendingUp className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Rynek</span>
            </TabsTrigger>
            <TabsTrigger 
              value="revenue"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <DollarSign className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Przychody</span>
            </TabsTrigger>
            <TabsTrigger 
              value="costs"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <Calculator className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Koszty</span>
            </TabsTrigger>
            <TabsTrigger 
              value="forecast"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <BarChart3 className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Prognoza</span>
            </TabsTrigger>
            <TabsTrigger 
              value="breakeven"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <Target className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">Break-even</span>
            </TabsTrigger>
            <TabsTrigger 
              value="swot"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <Shield className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">SWOT</span>
            </TabsTrigger>
            <TabsTrigger 
              value="kpi"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-400"
            >
              <Zap className="h-4 w-4 mr-1 md:mr-2" />
              <span className="hidden md:inline">KPI</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6">
            <div className="space-y-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Executive Summary</CardTitle>
                  <CardDescription className="text-slate-400">
                    3D Print Business Hub - Profesjonalne usługi druku 3D
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                        <Lightbulb className="h-5 w-5 text-yellow-400" />
                        Opis Biznesu
                      </h3>
                      <p className="text-slate-300 leading-relaxed">
                        3D Print Business Hub to nowoczesne przedsiębiorstwo oferujące kompleksowe 
                        usługi druku 3D dla klientów B2B i B2C. Specjalizujemy się w prototypowaniu, 
                        produkcji małoseryjnej oraz projektach customowych. Dzięki zaawansowanemu 
                        parkowi maszynowemu i doświadczeniu zespołu, realizujemy projekty z 
                        najwyższą jakością i w konkurencyjnych cenach.
                      </p>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
                        <Target className="h-5 w-5 text-blue-400" />
                        Cele Strategiczne
                      </h3>
                      <ul className="space-y-2 text-slate-300">
                        <li className="flex items-start gap-2">
                          <ArrowRight className="h-4 w-4 text-blue-400 mt-1" />
                          Osiągnięcie przychodu 35,000 PLN miesięcznie do końca roku 1
                        </li>
                        <li className="flex items-start gap-2">
                          <ArrowRight className="h-4 w-4 text-blue-400 mt-1" />
                          Zbudowanie bazy 200+ stałych klientów
                        </li>
                        <li className="flex items-start gap-2">
                          <ArrowRight className="h-4 w-4 text-blue-400 mt-1" />
                          Rozszerzenie oferty o druk metali w roku 2
                        </li>
                        <li className="flex items-start gap-2">
                          <ArrowRight className="h-4 w-4 text-blue-400 mt-1" />
                          Osiągnięcie 95% zadowolenia klientów
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="border-t border-slate-800 pt-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Inwestycja Początkowa</h3>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                        <p className="text-sm text-slate-400">Drukarki 3D</p>
                        <p className="text-lg font-bold text-white mt-1">
                          {formatCurrency(INITIAL_INVESTMENT.printers)}
                        </p>
                      </div>
                      <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                        <p className="text-sm text-slate-400">Wyposażenie</p>
                        <p className="text-lg font-bold text-white mt-1">
                          {formatCurrency(INITIAL_INVESTMENT.equipment)}
                        </p>
                      </div>
                      <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                        <p className="text-sm text-slate-400">Oprogramowanie</p>
                        <p className="text-lg font-bold text-white mt-1">
                          {formatCurrency(INITIAL_INVESTMENT.software)}
                        </p>
                      </div>
                      <div className="bg-slate-800/50 rounded-lg p-4 text-center">
                        <p className="text-sm text-slate-400">Marketing</p>
                        <p className="text-lg font-bold text-white mt-1">
                          {formatCurrency(INITIAL_INVESTMENT.marketing)}
                        </p>
                      </div>
                      <div className="bg-slate-800/50 rounded-lg p-4 text-center border-2 border-blue-600">
                        <p className="text-sm text-slate-400">Suma</p>
                        <p className="text-lg font-bold text-blue-400 mt-1">
                          {formatCurrency(INITIAL_INVESTMENT.total)}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-slate-800 pt-6">
                    <h3 className="text-lg font-semibold text-white mb-4">Kluczowe Wskaźniki</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-4">
                        <div className="p-2 bg-emerald-500/20 rounded-lg">
                          <TrendingUp className="h-5 w-5 text-emerald-400" />
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Wzrost rynku</p>
                          <p className="text-lg font-bold text-emerald-400">+5.6%</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-4">
                        <div className="p-2 bg-blue-500/20 rounded-lg">
                          <Calendar className="h-5 w-5 text-blue-400" />
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Czas zwrotu</p>
                          <p className="text-lg font-bold text-blue-400">4 mies.</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-4">
                        <div className="p-2 bg-purple-500/20 rounded-lg">
                          <DollarSign className="h-5 w-5 text-purple-400" />
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Marża</p>
                          <p className="text-lg font-bold text-purple-400">55%</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-4">
                        <div className="p-2 bg-amber-500/20 rounded-lg">
                          <Target className="h-5 w-5 text-amber-400" />
                        </div>
                        <div>
                          <p className="text-sm text-slate-400">Zamówień BE</p>
                          <p className="text-lg font-bold text-amber-400">20/mc</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Navigation */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { id: 'market', label: 'Analiza Rynku', icon: TrendingUp, color: 'bg-emerald-600' },
                  { id: 'revenue', label: 'Model Przychodów', icon: DollarSign, color: 'bg-blue-600' },
                  { id: 'costs', label: 'Kalkulacja Kosztów', icon: Calculator, color: 'bg-red-600' },
                  { id: 'forecast', label: 'Prognoza', icon: BarChart3, color: 'bg-purple-600' },
                ].map((item) => (
                  <Button
                    key={item.id}
                    variant="outline"
                    onClick={() => setActiveTab(item.id)}
                    className="h-auto py-4 border-slate-700 hover:bg-slate-800 flex flex-col items-center gap-2"
                  >
                    <div className={`p-2 ${item.color} rounded-lg`}>
                      <item.icon className="h-5 w-5 text-white" />
                    </div>
                    <span className="text-slate-300">{item.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Market Analysis Tab */}
          <TabsContent value="market" className="mt-6">
            <MarketAnalysis />
          </TabsContent>

          {/* Revenue Model Tab */}
          <TabsContent value="revenue" className="mt-6">
            <RevenueModel />
          </TabsContent>

          {/* Costs Tab */}
          <TabsContent value="costs" className="mt-6">
            <CostCalculator />
          </TabsContent>

          {/* Forecast Tab */}
          <TabsContent value="forecast" className="mt-6">
            <RevenueForecast />
          </TabsContent>

          {/* Break-even Tab */}
          <TabsContent value="breakeven" className="mt-6">
            <BreakEvenAnalysis />
          </TabsContent>

          {/* SWOT Tab */}
          <TabsContent value="swot" className="mt-6">
            <SWOTAnalysis />
          </TabsContent>

          {/* KPI Tab */}
          <TabsContent value="kpi" className="mt-6">
            <KPITargets />
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-slate-800">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
          <p>© 2024 3D Print Business Hub - Biznesplan</p>
          <div className="flex items-center gap-4">
            <span>Dane: AMPOWER Report 2026</span>
            <span>•</span>
            <span>Waluta: PLN</span>
            <span>•</span>
            <span>Ostatnia aktualizacja: {new Date().toLocaleDateString('pl-PL')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
