// Types for 3D Print Business Hub Business Plan Module

export interface MarketData {
  year: number;
  marketSize: number; // in billions USD
  growthRate: number; // percentage
  polandMarketSize: number; // in millions PLN
}

export interface RevenueStream {
  id: string;
  name: string;
  description: string;
  avgOrderValue: number;
  monthlyOrders: number;
  margin: number;
  monthlyRevenue: number;
}

export interface FixedCost {
  id: string;
  name: string;
  monthlyAmount: number;
  category: 'rent' | 'insurance' | 'tax' | 'software' | 'other';
}

export interface VariableCost {
  id: string;
  name: string;
  unitCost: number;
  monthlyUnits: number;
  monthlyCost: number;
  category: 'materials' | 'energy' | 'maintenance' | 'other';
}

export interface MonthlyForecast {
  month: number;
  revenue: number;
  costs: number;
  profit: number;
  cumulativeProfit: number;
}

export interface SWOTItem {
  id: string;
  text: string;
  priority: 'high' | 'medium' | 'low';
}

export interface SWOTAnalysis {
  strengths: SWOTItem[];
  weaknesses: SWOTItem[];
  opportunities: SWOTItem[];
  threats: SWOTItem[];
}

export interface KPITarget {
  id: string;
  name: string;
  target: number;
  current: number;
  unit: string;
  deadline: string;
  category: 'financial' | 'operational' | 'marketing' | 'customer';
}

export interface BreakEvenData {
  fixedCosts: number;
  variableCostPerUnit: number;
  pricePerUnit: number;
  breakEvenUnits: number;
  breakEvenRevenue: number;
  marginPerUnit: number;
}

export interface TrendData {
  name: string;
  value: number;
  growth: number;
  description: string;
}
