'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Home, 
  Shield, 
  Receipt, 
  Laptop, 
  Package, 
  Zap, 
  Wrench,
  Box,
  Calculator,
  TrendingDown,
  AlertCircle
} from 'lucide-react';
import { FIXED_COSTS, VARIABLE_COSTS, formatCurrency } from './constants';
import type { FixedCost, VariableCost } from './types';

const categoryIcons: Record<string, React.ReactNode> = {
  rent: <Home className="h-4 w-4" />,
  insurance: <Shield className="h-4 w-4" />,
  tax: <Receipt className="h-4 w-4" />,
  software: <Laptop className="h-4 w-4" />,
  materials: <Package className="h-4 w-4" />,
  energy: <Zap className="h-4 w-4" />,
  maintenance: <Wrench className="h-4 w-4" />,
  other: <Box className="h-4 w-4" />
};

const categoryLabels: Record<string, string> = {
  rent: 'Czynsz',
  insurance: 'Ubezpieczenie',
  tax: 'Podatki i ZUS',
  software: 'Oprogramowanie',
  materials: 'Materiały',
  energy: 'Energia',
  maintenance: 'Konserwacja',
  other: 'Inne'
};

export function CostCalculator() {
  const [fixedCosts, setFixedCosts] = useState<FixedCost[]>(FIXED_COSTS);
  const [variableCosts, setVariableCosts] = useState<VariableCost[]>(VARIABLE_COSTS);
  const [editingFixed, setEditingFixed] = useState<string | null>(null);
  const [editingVariable, setEditingVariable] = useState<string | null>(null);

  const totalFixedCosts = fixedCosts.reduce((sum, c) => sum + c.monthlyAmount, 0);
  const totalVariableCosts = variableCosts.reduce((sum, c) => sum + c.monthlyCost, 0);
  const totalCosts = totalFixedCosts + totalVariableCosts;

  const handleUpdateFixedCost = (id: string, amount: number) => {
    setFixedCosts(prev => prev.map(cost => 
      cost.id === id ? { ...cost, monthlyAmount: amount } : cost
    ));
  };

  const handleUpdateVariableCost = (id: string, field: 'unitCost' | 'monthlyUnits', value: number) => {
    setVariableCosts(prev => prev.map(cost => {
      if (cost.id === id) {
        const updated = { ...cost, [field]: value };
        updated.monthlyCost = updated.unitCost * updated.monthlyUnits;
        return updated;
      }
      return cost;
    }));
  };

  const fixedByCategory = fixedCosts.reduce((acc, cost) => {
    acc[cost.category] = (acc[cost.category] || 0) + cost.monthlyAmount;
    return acc;
  }, {} as Record<string, number>);

  const variableByCategory = variableCosts.reduce((acc, cost) => {
    acc[cost.category] = (acc[cost.category] || 0) + cost.monthlyCost;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Koszty Stałe</p>
                <p className="text-2xl font-bold text-red-400 mt-1">
                  {formatCurrency(totalFixedCosts)}
                </p>
              </div>
              <Home className="h-8 w-8 text-red-500" />
            </div>
            <p className="text-xs text-slate-500 mt-2">miesięcznie</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Koszty Zmienne</p>
                <p className="text-2xl font-bold text-amber-400 mt-1">
                  {formatCurrency(totalVariableCosts)}
                </p>
              </div>
              <Package className="h-8 w-8 text-amber-500" />
            </div>
            <p className="text-xs text-slate-500 mt-2">miesięcznie</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Koszty Całkowite</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(totalCosts)}
                </p>
              </div>
              <Calculator className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-xs text-slate-500 mt-2">miesięcznie</p>
          </CardContent>
        </Card>
      </div>

      {/* Cost Details Tabs */}
      <Tabs defaultValue="fixed" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-slate-800">
          <TabsTrigger value="fixed" className="data-[state=active]:bg-slate-700">
            <Home className="h-4 w-4 mr-2" />
            Koszty Stałe
          </TabsTrigger>
          <TabsTrigger value="variable" className="data-[state=active]:bg-slate-700">
            <Package className="h-4 w-4 mr-2" />
            Koszty Zmienne
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fixed" className="space-y-4">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Szczegóły Kosztów Stałych</CardTitle>
              <CardDescription className="text-slate-400">
                Koszty niezależne od wolumenu produkcji
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {fixedCosts.map((cost) => (
                  <div 
                    key={cost.id}
                    className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-700 rounded-lg text-slate-400">
                        {categoryIcons[cost.category]}
                      </div>
                      <div>
                        <p className="text-white font-medium">{cost.name}</p>
                        <p className="text-xs text-slate-500">{categoryLabels[cost.category]}</p>
                      </div>
                    </div>
                    {editingFixed === cost.id ? (
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          value={cost.monthlyAmount}
                          onChange={(e) => handleUpdateFixedCost(cost.id, Number(e.target.value))}
                          className="w-24 bg-slate-800 border-slate-700 text-white"
                        />
                        <Button 
                          size="sm"
                          onClick={() => setEditingFixed(null)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          OK
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <span className="text-red-400 font-medium">
                          {formatCurrency(cost.monthlyAmount)}
                        </span>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setEditingFixed(cost.id)}
                          className="text-slate-400 hover:text-white"
                        >
                          Edytuj
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Category Summary */}
              <div className="mt-6 pt-4 border-t border-slate-800">
                <h4 className="text-sm text-slate-400 mb-3">Podsumowanie według kategorii</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {Object.entries(fixedByCategory).map(([category, amount]) => (
                    <div key={category} className="bg-slate-800 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        {categoryIcons[category]}
                        <span className="text-xs text-slate-400">{categoryLabels[category]}</span>
                      </div>
                      <p className="text-white font-medium">{formatCurrency(amount)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="variable" className="space-y-4">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white">Szczegóły Kosztów Zmiennych</CardTitle>
              <CardDescription className="text-slate-400">
                Koszty zależne od wolumenu produkcji
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {variableCosts.map((cost) => (
                  <div 
                    key={cost.id}
                    className="p-3 bg-slate-800/50 rounded-lg"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-700 rounded-lg text-slate-400">
                          {categoryIcons[cost.category]}
                        </div>
                        <div>
                          <p className="text-white font-medium">{cost.name}</p>
                          <p className="text-xs text-slate-500">{categoryLabels[cost.category]}</p>
                        </div>
                      </div>
                      <span className="text-amber-400 font-bold text-lg">
                        {formatCurrency(cost.monthlyCost)}
                      </span>
                    </div>
                    
                    {editingVariable === cost.id ? (
                      <div className="grid grid-cols-2 gap-3 mt-3">
                        <div>
                          <Label className="text-xs text-slate-400">Koszt jednostkowy</Label>
                          <Input
                            type="number"
                            value={cost.unitCost}
                            onChange={(e) => handleUpdateVariableCost(cost.id, 'unitCost', Number(e.target.value))}
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-slate-400">Jednostek/miesiąc</Label>
                          <Input
                            type="number"
                            value={cost.monthlyUnits}
                            onChange={(e) => handleUpdateVariableCost(cost.id, 'monthlyUnits', Number(e.target.value))}
                            className="bg-slate-800 border-slate-700 text-white mt-1"
                          />
                        </div>
                        <Button 
                          onClick={() => setEditingVariable(null)}
                          className="col-span-2 bg-blue-600 hover:bg-blue-700"
                        >
                          Zapisz
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex gap-4 text-sm text-slate-400">
                          <span>{formatCurrency(cost.unitCost)} / szt.</span>
                          <span>×</span>
                          <span>{cost.monthlyUnits} szt./mies.</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setEditingVariable(cost.id)}
                          className="text-slate-400 hover:text-white"
                        >
                          Edytuj
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Category Summary */}
              <div className="mt-6 pt-4 border-t border-slate-800">
                <h4 className="text-sm text-slate-400 mb-3">Podsumowanie według kategorii</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {Object.entries(variableByCategory).map(([category, amount]) => (
                    <div key={category} className="bg-slate-800 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        {categoryIcons[category]}
                        <span className="text-xs text-slate-400">{categoryLabels[category]}</span>
                      </div>
                      <p className="text-white font-medium">{formatCurrency(amount)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Cost Breakdown Visualization */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-red-400" />
            Struktura Kosztów
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">Koszty stałe</span>
                <span className="text-slate-400">
                  {formatCurrency(totalFixedCosts)} ({((totalFixedCosts / totalCosts) * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-red-500 rounded-full transition-all duration-500"
                  style={{ width: `${(totalFixedCosts / totalCosts) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">Koszty zmienne</span>
                <span className="text-slate-400">
                  {formatCurrency(totalVariableCosts)} ({((totalVariableCosts / totalCosts) * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500 rounded-full transition-all duration-500"
                  style={{ width: `${(totalVariableCosts / totalCosts) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Warning */}
      <Card className="bg-amber-900/20 border-amber-800">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-400 mt-0.5" />
            <div>
              <p className="text-amber-400 font-medium">Ważne</p>
              <p className="text-sm text-slate-400 mt-1">
                Powyższe kalkulacje nie uwzględniają amortyzacji sprzętu (drukarki 3D, 
                komputery) oraz podatku dochodowego. Zaleca się uwzględnienie 15-20% 
                dodatkowego buforu na nieprzewidziane wydatki.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
