'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { 
  Printer, 
  Palette, 
  Boxes, 
  Lightbulb, 
  Users,
  Calculator,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { REVENUE_STREAMS, formatCurrency } from './constants';
import type { RevenueStream } from './types';

const iconMap: Record<string, React.ReactNode> = {
  'print-on-demand': <Printer className="h-5 w-5" />,
  'custom-projects': <Palette className="h-5 w-5" />,
  'small-batch': <Boxes className="h-5 w-5" />,
  'prototyping': <Lightbulb className="h-5 w-5" />,
  'consulting': <Users className="h-5 w-5" />
};

export function RevenueModel() {
  const [streams, setStreams] = useState<RevenueStream[]>(REVENUE_STREAMS);
  const [editingId, setEditingId] = useState<string | null>(null);

  const totalMonthlyRevenue = streams.reduce((sum, s) => sum + s.monthlyRevenue, 0);
  const totalMonthlyOrders = streams.reduce((sum, s) => sum + s.monthlyOrders, 0);
  const weightedMargin = streams.reduce((sum, s) => sum + (s.margin * s.monthlyRevenue), 0) / totalMonthlyRevenue;

  const handleUpdateStream = (id: string, field: keyof RevenueStream, value: number) => {
    setStreams(prev => prev.map(stream => {
      if (stream.id === id) {
        const updated = { ...stream, [field]: value };
        // Recalculate monthly revenue
        if (field === 'avgOrderValue' || field === 'monthlyOrders') {
          updated.monthlyRevenue = updated.avgOrderValue * updated.monthlyOrders;
        }
        return updated;
      }
      return stream;
    }));
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Przychód Miesięczny</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  {formatCurrency(totalMonthlyRevenue)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Zamówienia Miesięcznie</p>
                <p className="text-2xl font-bold text-blue-400 mt-1">
                  {totalMonthlyOrders}
                </p>
              </div>
              <Calculator className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Średnia Marża</p>
                <p className="text-2xl font-bold text-purple-400 mt-1">
                  {(weightedMargin * 100).toFixed(0)}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Streams */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {streams.map((stream) => (
          <Card key={stream.id} className="bg-slate-900 border-slate-800">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-900/50 rounded-lg text-blue-400">
                    {iconMap[stream.id]}
                  </div>
                  <div>
                    <CardTitle className="text-white text-lg">{stream.name}</CardTitle>
                    <CardDescription className="text-slate-400 text-sm">
                      {stream.description}
                    </CardDescription>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-emerald-400">
                    {formatCurrency(stream.monthlyRevenue)}
                  </p>
                  <p className="text-xs text-slate-500">miesięcznie</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {editingId === stream.id ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-400 text-sm">Śr. wartość zamówienia</Label>
                      <Input
                        type="number"
                        value={stream.avgOrderValue}
                        onChange={(e) => handleUpdateStream(stream.id, 'avgOrderValue', Number(e.target.value))}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-400 text-sm">Zamówień/miesiąc</Label>
                      <Input
                        type="number"
                        value={stream.monthlyOrders}
                        onChange={(e) => handleUpdateStream(stream.id, 'monthlyOrders', Number(e.target.value))}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => setEditingId(null)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Zapisz
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="bg-slate-800/50 rounded-lg p-3">
                      <p className="text-slate-400">Śr. zamówienie</p>
                      <p className="text-white font-medium">{formatCurrency(stream.avgOrderValue)}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3">
                      <p className="text-slate-400">Zamówień/mc</p>
                      <p className="text-white font-medium">{stream.monthlyOrders}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg p-3">
                      <p className="text-slate-400">Marża</p>
                      <p className="text-emerald-400 font-medium">{(stream.margin * 100).toFixed(0)}%</p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setEditingId(stream.id)}
                    className="border-slate-700 text-slate-300 hover:bg-slate-800"
                  >
                    Edytuj
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Distribution */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white">Dystrybucja Przychodów</CardTitle>
          <CardDescription className="text-slate-400">
            Udział poszczególnych źródeł w całkowitym przychodzie
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {streams.map((stream) => {
              const percentage = (stream.monthlyRevenue / totalMonthlyRevenue) * 100;
              return (
                <div key={stream.id} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-300">{stream.name}</span>
                    <span className="text-slate-400">
                      {formatCurrency(stream.monthlyRevenue)} ({percentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all duration-500"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="mt-6 pt-4 border-t border-slate-800">
            <div className="flex justify-between items-center">
              <span className="text-white font-medium">Suma</span>
              <span className="text-emerald-400 font-bold text-lg">
                {formatCurrency(totalMonthlyRevenue)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Annual Projection */}
      <Card className="bg-gradient-to-r from-emerald-900/30 to-blue-900/30 border-emerald-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-emerald-400" />
            Prognoza Roczna
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-sm text-slate-400">Przychód roczny</p>
              <p className="text-xl font-bold text-emerald-400">
                {formatCurrency(totalMonthlyRevenue * 12)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-slate-400">Zamówień rocznie</p>
              <p className="text-xl font-bold text-blue-400">
                {totalMonthlyOrders * 12}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-slate-400">Śr. wartość zam.</p>
              <p className="text-xl font-bold text-purple-400">
                {formatCurrency(totalMonthlyRevenue / totalMonthlyOrders)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-slate-400">Szacowana marża</p>
              <p className="text-xl font-bold text-amber-400">
                {formatCurrency(totalMonthlyRevenue * weightedMargin * 12)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
