// 3D Print Business Hub - Business Plan Module
// Export all components and types

export { BusinessPlan } from './BusinessPlan';
export { MarketAnalysis } from './MarketAnalysis';
export { RevenueModel } from './RevenueModel';
export { CostCalculator } from './CostCalculator';
export { RevenueForecast } from './RevenueForecast';
export { BreakEvenAnalysis } from './BreakEvenAnalysis';
export { SWOTAnalysis } from './SWOTAnalysis';
export { KPITargets } from './KPITargets';

// Export types
export type {
  MarketData,
  RevenueStream,
  FixedCost,
  VariableCost,
  MonthlyForecast,
  SWOTItem,
  SWOTAnalysis as SWOTAnalysisType,
  KPITarget,
  BreakEvenData,
  TrendData
} from './types';

// Export constants and utilities
export {
  AMPOWER_DATA,
  POLAND_TRENDS,
  REVENUE_STREAMS,
  FIXED_COSTS,
  VARIABLE_COSTS,
  SWOT_DATA,
  KPI_TARGETS,
  REVENUE_FORECAST,
  BREAK_EVEN_DATA,
  INITIAL_INVESTMENT,
  formatCurrency,
  formatPercentage
} from './constants';
