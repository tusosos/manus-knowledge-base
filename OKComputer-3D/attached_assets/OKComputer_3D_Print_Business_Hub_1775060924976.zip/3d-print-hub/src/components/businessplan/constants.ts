// Constants and Data for 3D Print Business Hub Business Plan

import { MarketData, RevenueStream, FixedCost, VariableCost, SWOTAnalysis, KPITarget, MonthlyForecast } from './types';

// AMPOWER 2026 Market Data
export const AMPOWER_DATA: MarketData[] = [
  { year: 2021, marketSize: 12.5, growthRate: 18.2, polandMarketSize: 180 },
  { year: 2022, marketSize: 14.8, growthRate: 18.4, polandMarketSize: 215 },
  { year: 2023, marketSize: 17.2, growthRate: 16.2, polandMarketSize: 255 },
  { year: 2024, marketSize: 19.8, growthRate: 15.1, polandMarketSize: 300 },
  { year: 2025, marketSize: 22.5, growthRate: 13.6, polandMarketSize: 350 },
  { year: 2026, marketSize: 23.8, growthRate: 5.6, polandMarketSize: 380 },
];

// Poland 3D Printing Trends
export const POLAND_TRENDS = [
  {
    name: 'Przemysł 4.0',
    value: 68,
    growth: 24,
    description: 'Wzrost zainteresowania drukiem 3D w przemyśle'
  },
  {
    name: 'Prototypowanie',
    value: 82,
    growth: 15,
    description: 'Główne zastosowanie wśród polskich firm'
  },
  {
    name: 'Edukacja',
    value: 45,
    growth: 35,
    description: 'Rosnące zainteresowanie w szkołach i uczelniach'
  },
  {
    name: 'Medycyna',
    value: 28,
    growth: 42,
    description: 'Najszybciej rosnący segment'
  },
  {
    name: 'Architektura',
    value: 35,
    growth: 18,
    description: 'Modele architektoniczne i wizualizacje'
  }
];

// Revenue Streams
export const REVENUE_STREAMS: RevenueStream[] = [
  {
    id: 'print-on-demand',
    name: 'Print-on-Demand',
    description: 'Druk pojedynczych elementów na zamówienie klienta',
    avgOrderValue: 150,
    monthlyOrders: 40,
    margin: 0.55,
    monthlyRevenue: 6000
  },
  {
    id: 'custom-projects',
    name: 'Projekty Custom',
    description: 'Indywidualne projekty z projektowaniem CAD',
    avgOrderValue: 800,
    monthlyOrders: 8,
    margin: 0.65,
    monthlyRevenue: 6400
  },
  {
    id: 'small-batch',
    name: 'Small Batch Production',
    description: 'Małe serie produkcyjne (10-100 szt.)',
    avgOrderValue: 2500,
    monthlyOrders: 3,
    margin: 0.50,
    monthlyRevenue: 7500
  },
  {
    id: 'prototyping',
    name: 'Prototypowanie',
    description: 'Szybkie prototypy dla startupów i firm',
    avgOrderValue: 500,
    monthlyOrders: 12,
    margin: 0.60,
    monthlyRevenue: 6000
  },
  {
    id: 'consulting',
    name: 'Konsulting 3D',
    description: 'Doradztwo w zakresie druku 3D',
    avgOrderValue: 300,
    monthlyOrders: 6,
    margin: 0.80,
    monthlyRevenue: 1800
  }
];

// Fixed Costs (Monthly in PLN)
export const FIXED_COSTS: FixedCost[] = [
  { id: 'rent', name: 'Czynsz lokalu', monthlyAmount: 2500, category: 'rent' },
  { id: 'insurance', name: 'Ubezpieczenie', monthlyAmount: 400, category: 'insurance' },
  { id: ' zus', name: 'ZUS (mały)', monthlyAmount: 1500, category: 'tax' },
  { id: 'software-cad', name: 'Oprogramowanie CAD', monthlyAmount: 500, category: 'software' },
  { id: 'software-slicer', name: 'Slicery Premium', monthlyAmount: 150, category: 'software' },
  { id: 'accounting', name: 'Księgowość', monthlyAmount: 400, category: 'other' },
  { id: 'internet', name: 'Internet i telefon', monthlyAmount: 200, category: 'other' },
  { id: 'marketing', name: 'Marketing stały', monthlyAmount: 800, category: 'other' }
];

// Variable Costs (Monthly in PLN)
export const VARIABLE_COSTS: VariableCost[] = [
  { id: 'filament-pla', name: 'Filament PLA', unitCost: 80, monthlyUnits: 15, monthlyCost: 1200, category: 'materials' },
  { id: 'filament-petg', name: 'Filament PETG', unitCost: 90, monthlyUnits: 8, monthlyCost: 720, category: 'materials' },
  { id: 'filament-abs', name: 'Filament ABS/ASA', unitCost: 100, monthlyUnits: 4, monthlyCost: 400, category: 'materials' },
  { id: 'resin', name: 'Żywica LCD/DLP', unitCost: 200, monthlyUnits: 3, monthlyCost: 600, category: 'materials' },
  { id: 'energy', name: 'Energia elektryczna', unitCost: 1.2, monthlyUnits: 800, monthlyCost: 960, category: 'energy' },
  { id: 'nozzles', name: 'Dysze i części', unitCost: 50, monthlyUnits: 6, monthlyCost: 300, category: 'maintenance' },
  { id: 'bed-adhesion', name: 'Kleje i taśmy', unitCost: 40, monthlyUnits: 4, monthlyCost: 160, category: 'materials' },
  { id: 'packaging', name: 'Opakowania', unitCost: 15, monthlyUnits: 70, monthlyCost: 1050, category: 'other' }
];

// SWOT Analysis
export const SWOT_DATA: SWOTAnalysis = {
  strengths: [
    { id: 's1', text: 'Szybki czas realizacji zamówień (24-48h)', priority: 'high' },
    { id: 's2', text: 'Wysoka jakość druku (0.1mm warstwa)', priority: 'high' },
    { id: 's3', text: 'Elastyczność w projektach custom', priority: 'high' },
    { id: 's4', text: 'Znajomość rynku lokalnego', priority: 'medium' },
    { id: 's5', text: 'Niskie koszty operacyjne', priority: 'medium' }
  ],
  weaknesses: [
    { id: 'w1', text: 'Ograniczona pojemność produkcyjna', priority: 'high' },
    { id: 'w2', text: 'Brak certyfikatów branżowych', priority: 'medium' },
    { id: 'w3', text: 'Zależność od dostawców filamentu', priority: 'medium' },
    { id: 'w4', text: 'Wysokie zużycie energii', priority: 'low' },
    { id: 'w5', text: 'Ograniczona znajomość CAD', priority: 'medium' }
  ],
  opportunities: [
    { id: 'o1', text: 'Wzrost rynku druku 3D (+5.6% rocznie)', priority: 'high' },
    { id: 'o2', text: 'Rosnące zainteresowanie Przemysłem 4.0', priority: 'high' },
    { id: 'o3', text: 'Współpraca z startupami technologicznymi', priority: 'high' },
    { id: 'o4', text: 'Edukacja i warsztaty 3D', priority: 'medium' },
    { id: 'o5', text: 'Segment medyczny (ortotyka)', priority: 'medium' }
  ],
  threats: [
    { id: 't1', text: 'Rosnąca konkurencja cenowa', priority: 'high' },
    { id: 't2', text: 'Wahania cen materiałów', priority: 'medium' },
    { id: 't3', text: 'Drukarki 3D w cenach konsumenckich', priority: 'medium' },
    { id: 't4', text: 'Zmiany w przepisach BHP', priority: 'low' },
    { id: 't5', text: 'Kryzys gospodarczy', priority: 'medium' }
  ]
};

// KPI Targets for First Year
export const KPI_TARGETS: KPITarget[] = [
  {
    id: 'kpi1',
    name: 'Miesięczny przychód',
    target: 35000,
    current: 0,
    unit: 'PLN',
    deadline: 'Miesiąc 12',
    category: 'financial'
  },
  {
    id: 'kpi2',
    name: 'Liczba zamówień',
    target: 150,
    current: 0,
    unit: 'szt.',
    deadline: 'Miesiąc 12',
    category: 'operational'
  },
  {
    id: 'kpi3',
    name: 'Średnia wartość zamówienia',
    target: 450,
    current: 0,
    unit: 'PLN',
    deadline: 'Miesiąc 12',
    category: 'financial'
  },
  {
    id: 'kpi4',
    name: 'Zadowolenie klientów',
    target: 95,
    current: 0,
    unit: '%',
    deadline: 'Miesiąc 12',
    category: 'customer'
  },
  {
    id: 'kpi5',
    name: 'Współczynnik zwrotów',
    target: 2,
    current: 0,
    unit: '%',
    deadline: 'Miesiąc 12',
    category: 'operational'
  },
  {
    id: 'kpi6',
    name: 'Nowi klienci miesięcznie',
    target: 20,
    current: 0,
    unit: 'os.',
    deadline: 'Miesiąc 12',
    category: 'marketing'
  },
  {
    id: 'kpi7',
    name: 'Marża brutto',
    target: 55,
    current: 0,
    unit: '%',
    deadline: 'Miesiąc 12',
    category: 'financial'
  },
  {
    id: 'kpi8',
    name: 'Czas realizacji',
    target: 48,
    current: 0,
    unit: 'h',
    deadline: 'Miesiąc 12',
    category: 'operational'
  }
];

// Revenue Forecast (12 months)
export const REVENUE_FORECAST: MonthlyForecast[] = [
  { month: 1, revenue: 8000, costs: 12000, profit: -4000, cumulativeProfit: -4000 },
  { month: 2, revenue: 12000, costs: 12500, profit: -500, cumulativeProfit: -4500 },
  { month: 3, revenue: 16000, costs: 13000, profit: 3000, cumulativeProfit: -1500 },
  { month: 4, revenue: 19000, costs: 13200, profit: 5800, cumulativeProfit: 4300 },
  { month: 5, revenue: 22000, costs: 13500, profit: 8500, cumulativeProfit: 12800 },
  { month: 6, revenue: 25000, costs: 13800, profit: 11200, cumulativeProfit: 24000 },
  { month: 7, revenue: 27000, costs: 14000, profit: 13000, cumulativeProfit: 37000 },
  { month: 8, revenue: 29000, costs: 14200, profit: 14800, cumulativeProfit: 51800 },
  { month: 9, revenue: 31000, costs: 14500, profit: 16500, cumulativeProfit: 68300 },
  { month: 10, revenue: 33000, costs: 14800, profit: 18200, cumulativeProfit: 86500 },
  { month: 11, revenue: 34000, costs: 15000, profit: 19000, cumulativeProfit: 105500 },
  { month: 12, revenue: 35000, costs: 15200, profit: 19800, cumulativeProfit: 125300 }
];

// Break-even calculation constants
export const BREAK_EVEN_DATA = {
  fixedCosts: 6450,
  variableCostPerUnit: 65,
  pricePerUnit: 380,
  breakEvenUnits: 20,
  breakEvenRevenue: 7600,
  marginPerUnit: 315
};

// Investment needed
export const INITIAL_INVESTMENT = {
  printers: 15000,
  equipment: 8000,
  software: 3000,
  marketing: 5000,
  workingCapital: 10000,
  total: 41000
};

// Format currency
export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(value);
};

// Format percentage
export const formatPercentage = (value: number): string => {
  return `${value.toFixed(1)}%`;
};
