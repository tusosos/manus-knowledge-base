# 3D Print Business Hub - Moduł Biznesplanu

Kompleksowy moduł biznesplanu dla firmy oferującej usługi druku 3D.

## 📁 Struktura Plików

```
businessplan/
├── types.ts              # Definicje typów TypeScript
├── constants.ts          # Dane rynkowe, koszty, prognozy
├── index.ts              # Eksporty modułu
├── BusinessPlan.tsx      # Główny komponent (wrapper)
├── MarketAnalysis.tsx    # Analiza rynku (AMPOWER 2026)
├── RevenueModel.tsx      # Modele przychodów
├── CostCalculator.tsx    # Kalkulacja kosztów
├── RevenueForecast.tsx   # Prognozy finansowe z wykresami
├── BreakEvenAnalysis.tsx # Analiza break-even
├── SWOTAnalysis.tsx      # Analiza SWOT
└── KPITargets.tsx        # Cele i KPI
```

## 🚀 Użycie

```tsx
import { BusinessPlan } from './components/businessplan';

function App() {
  return <BusinessPlan />;
}
```

## 📊 Funkcjonalności

### 1. Analiza Rynku
- Dane AMPOWER Report 2026 (wzrost 5.6%)
- Trendy w Polsce (Przemysł 4.0, Medycyna, Edukacja)
- Prognozy wielkości rynku

### 2. Model Przychodów
- Print-on-Demand
- Projekty Custom
- Small Batch Production
- Prototypowanie
- Konsulting 3D

### 3. Kalkulacja Kosztów
- Koszty stałe: czynsz, ZUS, ubezpieczenie, oprogramowanie
- Koszty zmienne: materiały, energia, amortyzacja
- Podział na kategorie

### 4. Prognoza Przychodów
- Okresy: 3, 6, 12 miesięcy
- Wykresy: słupkowy, liniowy, złożony
- Tabela szczegółowa

### 5. Break-even Analysis
- Punkt równowagi (ilość i przychód)
- Interaktywny kalkulator
- Scenariusze: pesymistyczny, realistyczny, optymistyczny

### 6. SWOT Analysis
- Macierz 2x2
- Priorytety (wysoki/średni/niski)
- Strategie: SO, WO, ST, WT

### 7. KPI Targets
- Cele finansowe, operacyjne, marketingowe
- Śledzenie postępów
- Podział na kategorie

## 💰 Kluczowe Dane

| Wskaźnik | Wartość |
|----------|---------|
| Inwestycja początkowa | 41,000 PLN |
| Przychód miesięczny (cel) | 35,000 PLN |
| Koszty stałe miesięczne | 6,450 PLN |
| Koszty zmienne miesięczne | 5,390 PLN |
| Break-even | 20 zamówień/mies. |
| Zwrot inwestycji | Miesiąc 4 |

## 🎨 UI/UX

- **Dark theme** - profesjonalny wygląd
- **shadcn/ui** - Card, Tabs, Table, Progress, Badge
- **Recharts** - wykresy słupkowe, liniowe, złożone
- **Responsive** - działa na desktop i mobile
- **Interaktywne** - edycja danych w locie

## 📈 Wykresy

- BarChart - przychody vs koszty
- LineChart - zysk skumulowany
- ComposedChart - analiza złożona
- AreaChart - break-even

## 🔧 Technologie

- React 18+
- TypeScript
- Tailwind CSS
- shadcn/ui components
- Recharts
- Lucide React icons

## 📝 Licencja

MIT - 3D Print Business Hub
