'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Globe, MapPin, Zap, Target } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { 
  AMPOWER_DATA, 
  POLAND_TRENDS, 
  formatCurrency, 
  formatPercentage 
} from './constants';

export function MarketAnalysis() {
  const latestData = AMPOWER_DATA[AMPOWER_DATA.length - 1];
  const previousData = AMPOWER_DATA[AMPOWER_DATA.length - 2];
  const growthChange = latestData.growthRate - previousData.growthRate;

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Rynek Globalny 2026</p>
                <p className="text-2xl font-bold text-white mt-1">
                  ${latestData.marketSize.toFixed(1)}B
                </p>
              </div>
              <Globe className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Wzrost (AMPOWER)</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  +{latestData.growthRate}%
                </p>
              </div>
              {growthChange >= 0 ? (
                <TrendingUp className="h-8 w-8 text-emerald-500" />
              ) : (
                <TrendingDown className="h-8 w-8 text-amber-500" />
              )}
            </div>
            <p className="text-xs text-slate-500 mt-2">
              {growthChange >= 0 ? '+' : ''}{growthChange.toFixed(1)}% vs rok poprzedni
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Rynek Polski 2026</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(latestData.polandMarketSize * 1000000).replace('PLN', '')}M
                </p>
              </div>
              <MapPin className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Prognoza CAGR</p>
                <p className="text-2xl font-bold text-purple-400 mt-1">15.2%</p>
              </div>
              <Target className="h-8 w-8 text-purple-500" />
            </div>
            <p className="text-xs text-slate-500 mt-2">2024-2030</p>
          </CardContent>
        </Card>
      </div>

      {/* AMPOWER Data Table */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-500" />
            Dane AMPOWER Report 2026
          </CardTitle>
          <CardDescription className="text-slate-400">
            Globalny rynek druku 3D - historia i prognozy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Rok</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Rynek Globalny</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Wzrost r/r</th>
                  <th className="text-right py-3 px-4 text-slate-400 font-medium">Rynek Polski</th>
                  <th className="text-center py-3 px-4 text-slate-400 font-medium">Trend</th>
                </tr>
              </thead>
              <tbody>
                {AMPOWER_DATA.map((data, index) => (
                  <tr 
                    key={data.year} 
                    className={`border-b border-slate-800 ${
                      index === AMPOWER_DATA.length - 1 ? 'bg-blue-900/20' : ''
                    }`}
                  >
                    <td className="py-3 px-4 text-white font-medium">
                      {data.year}
                      {index === AMPOWER_DATA.length - 1 && (
                        <span className="ml-2 text-xs bg-blue-600 text-white px-2 py-0.5 rounded">
                          PROGNOZA
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      ${data.marketSize.toFixed(1)} mld
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className={`${
                        data.growthRate >= 10 ? 'text-emerald-400' : 
                        data.growthRate >= 5 ? 'text-amber-400' : 'text-red-400'
                      }`}>
                        {formatPercentage(data.growthRate)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-slate-300">
                      {formatCurrency(data.polandMarketSize * 1000000)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex justify-center">
                        {index > 0 && (
                          data.marketSize > AMPOWER_DATA[index - 1].marketSize ? (
                            <TrendingUp className="h-4 w-4 text-emerald-500" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-500" />
                          )
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Poland Trends */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Trendy w Polsce - Segmenty Rynku
          </CardTitle>
          <CardDescription className="text-slate-400">
            Najważniejsze kierunki rozwoju druku 3D w Polsce
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {POLAND_TRENDS.map((trend) => (
              <div 
                key={trend.name}
                className="bg-slate-800/50 rounded-lg p-4 border border-slate-700"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-white font-medium">{trend.name}</h4>
                  <span className="text-emerald-400 text-sm font-medium">
                    +{trend.growth}%
                  </span>
                </div>
                <div className="mb-3">
                  <Progress 
                    value={trend.value} 
                    className="h-2 bg-slate-700"
                  />
                </div>
                <p className="text-sm text-slate-400">{trend.description}</p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-xs text-slate-500">Udział:</span>
                  <span className="text-sm text-slate-300">{trend.value}%</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Key Insights */}
      <Card className="bg-gradient-to-r from-blue-900/30 to-purple-900/30 border-blue-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Target className="h-5 w-5 text-blue-400" />
            Kluczowe Wnioski
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="text-emerald-400 font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Pozytywne sygnały
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">•</span>
                  Rynek druku 3D rośnie stabilnie, mimo spowolnienia do 5.6% w 2026
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">•</span>
                  Polski rynek wyceniany na ~380M PLN w 2026
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">•</span>
                  Segment medyczny rośnie najszybciej (+42%)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-1">•</span>
                  Przemysł 4.0 napędza zainteresowanie prototypowaniem
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-amber-400 font-medium flex items-center gap-2">
                <TrendingDown className="h-4 w-4" />
                Wyzwania
              </h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  Spowolnienie wzrostu globalnego (z 18% do 5.6%)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  Rosnąca konkurencja na rynku polskim
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  Wysokie ceny materiałów i energii
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-1">•</span>
                  Konieczność certyfikacji dla segmentu medycznego
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
