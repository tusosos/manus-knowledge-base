'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart
} from 'recharts';
import { 
  Target, 
  TrendingUp, 
  Calculator, 
  AlertCircle,
  CheckCircle2,
  DollarSign,
  Package
} from 'lucide-react';
import { BREAK_EVEN_DATA, formatCurrency } from './constants';

interface BreakEvenPoint {
  units: number;
  revenue: number;
  costs: number;
  profit: number;
}

export function BreakEvenAnalysis() {
  const [fixedCosts, setFixedCosts] = useState(BREAK_EVEN_DATA.fixedCosts);
  const [variableCostPerUnit, setVariableCostPerUnit] = useState(BREAK_EVEN_DATA.variableCostPerUnit);
  const [pricePerUnit, setPricePerUnit] = useState(BREAK_EVEN_DATA.pricePerUnit);

  // Calculate break-even
  const marginPerUnit = pricePerUnit - variableCostPerUnit;
  const breakEvenUnits = Math.ceil(fixedCosts / marginPerUnit);
  const breakEvenRevenue = breakEvenUnits * pricePerUnit;

  // Generate chart data
  const generateChartData = (): BreakEvenPoint[] => {
    const data: BreakEvenPoint[] = [];
    const maxUnits = Math.max(breakEvenUnits * 2, 50);
    
    for (let units = 0; units <= maxUnits; units += 5) {
      const revenue = units * pricePerUnit;
      const costs = fixedCosts + (units * variableCostPerUnit);
      data.push({
        units,
        revenue,
        costs,
        profit: revenue - costs
      });
    }
    return data;
  };

  const chartData = generateChartData();

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3 shadow-lg">
          <p className="text-white font-medium mb-2">{label} zamówień</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Break-even Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Break-even (ilość)</p>
                <p className="text-2xl font-bold text-emerald-400 mt-1">
                  {breakEvenUnits} zam.
                </p>
              </div>
              <Package className="h-8 w-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Break-even (przychód)</p>
                <p className="text-2xl font-bold text-blue-400 mt-1">
                  {formatCurrency(breakEvenRevenue)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Marża / zamówienie</p>
                <p className="text-2xl font-bold text-purple-400 mt-1">
                  {formatCurrency(marginPerUnit)}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Status</p>
                <div className="flex items-center gap-2 mt-1">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                  <p className="text-lg font-bold text-emerald-400">Osiągalny</p>
                </div>
              </div>
              <Target className="h-8 w-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Calculator Inputs */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calculator className="h-5 w-5 text-blue-400" />
            Kalkulator Break-even
          </CardTitle>
          <CardDescription className="text-slate-400">
            Dostosuj parametry, aby zobaczyć wpływ na punkt równowagi
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <Label className="text-slate-400">Koszty stałe (miesięcznie)</Label>
              <Input
                type="number"
                value={fixedCosts}
                onChange={(e) => setFixedCosts(Number(e.target.value))}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Czynsz, ZUS, ubezpieczenie, oprogramowanie
              </p>
            </div>
            <div>
              <Label className="text-slate-400">Koszt zmienny / zamówienie</Label>
              <Input
                type="number"
                value={variableCostPerUnit}
                onChange={(e) => setVariableCostPerUnit(Number(e.target.value))}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Materiały, energia, opakowania
              </p>
            </div>
            <div>
              <Label className="text-slate-400">Cena sprzedaży / zamówienie</Label>
              <Input
                type="number"
                value={pricePerUnit}
                onChange={(e) => setPricePerUnit(Number(e.target.value))}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Średnia wartość zamówienia
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Break-even Chart */}
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white">Wykres Break-even</CardTitle>
          <CardDescription className="text-slate-400">
            Punkt przecięcia przychodów i kosztów
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="units" 
                  stroke="#94a3b8"
                  label={{ value: 'Liczba zamówień', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                />
                <YAxis 
                  stroke="#94a3b8"
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                  label={{ value: 'PLN', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                
                <ReferenceLine 
                  x={breakEvenUnits} 
                  stroke="#f59e0b" 
                  strokeDasharray="3 3"
                  label={{ value: `BE: ${breakEvenUnits}`, fill: '#f59e0b', position: 'top' }}
                />
                
                <Area
                  type="monotone"
                  dataKey="revenue"
                  name="Przychód"
                  fill="#10b981"
                  fillOpacity={0.3}
                  stroke="#10b981"
                  strokeWidth={2}
                />
                
                <Area
                  type="monotone"
                  dataKey="costs"
                  name="Koszty całkowite"
                  fill="#ef4444"
                  fillOpacity={0.3}
                  stroke="#ef4444"
                  strokeWidth={2}
                />
                
                <Line 
                  type="monotone" 
                  dataKey="profit" 
                  name="Zysk" 
                  stroke="#8b5cf6" 
                  strokeWidth={3}
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          
          {/* Break-even Point Indicator */}
          <div className="mt-6 flex items-center justify-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-emerald-500 rounded" />
              <span className="text-sm text-slate-400">Przychód</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded" />
              <span className="text-sm text-slate-400">Koszty</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-1 bg-purple-500" />
              <span className="text-sm text-slate-400">Zysk</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-0 border-t-2 border-dashed border-amber-500" />
              <span className="text-sm text-slate-400">Punkt równowagi</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Scenarios */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white text-lg">Scenariusz Pesymistyczny</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Cena / zamówienie</span>
                <span className="text-white">{formatCurrency(pricePerUnit * 0.85)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Zamówień / miesiąc</span>
                <span className="text-white">{Math.ceil(breakEvenUnits / 0.85)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Przychód BE</span>
                <span className="text-red-400">{formatCurrency(breakEvenRevenue / 0.85)}</span>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={85} className="h-2 bg-slate-700" />
              <p className="text-xs text-slate-500 mt-1">-15% ceny</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white text-lg">Scenariusz Realistyczny</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Cena / zamówienie</span>
                <span className="text-white">{formatCurrency(pricePerUnit)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Zamówień / miesiąc</span>
                <span className="text-white">{breakEvenUnits}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Przychód BE</span>
                <span className="text-emerald-400">{formatCurrency(breakEvenRevenue)}</span>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={100} className="h-2 bg-slate-700" />
              <p className="text-xs text-slate-500 mt-1">Bazowy</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white text-lg">Scenariusz Optymistyczny</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Cena / zamówienie</span>
                <span className="text-white">{formatCurrency(pricePerUnit * 1.15)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Zamówień / miesiąc</span>
                <span className="text-white">{Math.ceil(breakEvenUnits / 1.15)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Przychód BE</span>
                <span className="text-emerald-400">{formatCurrency(breakEvenRevenue / 1.15)}</span>
              </div>
            </div>
            <div className="mt-4">
              <Progress value={115} className="h-2 bg-slate-700" />
              <p className="text-xs text-slate-500 mt-1">+15% ceny</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card className="bg-blue-900/20 border-blue-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-blue-400" />
            Rekomendacje
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-emerald-400 font-medium mb-2">Aby osiągnąć break-even:</h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5" />
                  Realizuj minimum {breakEvenUnits} zamówień miesięcznie
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5" />
                  Utrzymuj średnią wartość zamówienia na poziomie {formatCurrency(pricePerUnit)}
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5" />
                  Kontroluj koszty zmienne poniżej {formatCurrency(variableCostPerUnit)} / zam.
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-amber-400 font-medium mb-2">Strategia na start:</h4>
              <ul className="space-y-2 text-sm text-slate-300">
                <li className="flex items-start gap-2">
                  <Target className="h-4 w-4 text-amber-500 mt-0.5" />
                  Cel: 25-30 zamówień w pierwszym miesiącu
                </li>
                <li className="flex items-start gap-2">
                  <Target className="h-4 w-4 text-amber-500 mt-0.5" />
                  Priorytet: Print-on-demand i prototypowanie
                </li>
                <li className="flex items-start gap-2">
                  <Target className="h-4 w-4 text-amber-500 mt-0.5" />
                  Buduj bazę stałych klientów B2B
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
