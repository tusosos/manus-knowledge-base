// Types for Printer Profile Component

export interface PrinterSpecs {
  model: string;
  manufacturer: string;
  maxNozzleTemp: number;
  maxBedTemp: number;
  buildVolume: {
    x: number;
    y: number;
    z: number;
  };
  nozzleCount: number;
  amsUnits: number;
  maxColors: number;
  maxSpeed: number;
  features: string[];
}

export interface MaterialSettings {
  material: string;
  nozzleTemp: string;
  bedTemp: string;
  speed: string;
  infill: string;
  supports: boolean;
  cooling: string;
  retraction: string;
}

export interface CalibrationEntry {
  id: string;
  date: string;
  type: 'flow' | 'pressure' | 'temperature' | 'speed' | 'full';
  flowRate: number;
  pressureAdvance: number;
  notes: string;
  performedBy: string;
}

export interface MaintenanceEntry {
  id: string;
  date: string;
  type: string;
  description: string;
  partsReplaced: string[];
  cost: number;
  performedBy: string;
  nextDue?: string;
}

export interface PartWear {
  name: string;
  lifespan: number;
  used: number;
  remaining: number;
  lastReplaced: string;
  status: 'good' | 'warning' | 'critical';
}

export interface PrinterStats {
  totalPrintTime: number; // in hours
  totalFilamentUsed: number; // in kg
  completedPrints: number;
  failedPrints: number;
  successRate: number;
  averagePrintTime: number;
  monthlyStats: MonthlyStat[];
}

export interface MonthlyStat {
  month: string;
  prints: number;
  filamentUsed: number;
  successRate: number;
}

export interface OnlineStatus {
  isOnline: boolean;
  currentJob?: {
    name: string;
    progress: number;
    elapsed: string;
    remaining: string;
    layer: string;
  };
  temperatures: {
    nozzle: {
      current: number;
      target: number;
    };
    bed: {
      current: number;
      target: number;
    };
  };
  chamberTemp?: number;
  fanSpeed: number;
}

export interface MaintenanceChecklist {
  daily: ChecklistItem[];
  weekly: ChecklistItem[];
  monthly: ChecklistItem[];
}

export interface ChecklistItem {
  id: string;
  task: string;
  completed: boolean;
  lastCompleted?: string;
}
