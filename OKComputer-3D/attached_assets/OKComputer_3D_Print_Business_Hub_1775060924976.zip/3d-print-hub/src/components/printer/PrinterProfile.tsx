'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Thermometer,
  Box,
  Zap,
  Layers,
  Settings,
  Wrench,
  BarChart3,
  Wifi,
  WifiOff,
  Clock,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  TrendingUp,
  Calendar,
  User,
  FileText,
  RotateCw,
  Gauge,
  Wind,
  Ruler,
  Palette,
  Cpu,
  Eye,
  Printer,
  Droplets,
  ChevronRight,
} from 'lucide-react';
import {
  printerSpecs,
  materialSettings,
  calibrationHistory,
  maintenanceHistory,
  partWear,
  printerStats,
  onlineStatus,
  maintenanceChecklist,
} from './mockData';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from 'recharts';

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3 },
  },
};

// Helper functions
const getStatusColor = (status: 'good' | 'warning' | 'critical') => {
  switch (status) {
    case 'good':
      return 'bg-emerald-500';
    case 'warning':
      return 'bg-amber-500';
    case 'critical':
      return 'bg-red-500';
  }
};

const getStatusBadge = (status: 'good' | 'warning' | 'critical') => {
  switch (status) {
    case 'good':
      return (
        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3 mr-1" />
          Good
        </Badge>
      );
    case 'warning':
      return (
        <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
          <AlertTriangle className="w-3 h-3 mr-1" />
          Warning
        </Badge>
      );
    case 'critical':
      return (
        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
          <AlertCircle className="w-3 h-3 mr-1" />
          Critical
        </Badge>
      );
  }
};

const getCalibrationTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    flow: 'Flow Rate',
    pressure: 'Pressure Advance',
    temperature: 'Temperature',
    speed: 'Speed',
    full: 'Full Calibration',
  };
  return labels[type] || type;
};

// Technical Specs Section
const TechnicalSpecs: React.FC = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 flex items-center gap-2">
              <Printer className="w-5 h-5 text-amber-500" />
              {printerSpecs.manufacturer} {printerSpecs.model}
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Professional dual-extruder 3D printer with AMS support
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-zinc-950/50 p-4 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Thermometer className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Max Nozzle</span>
                </div>
                <p className="text-2xl font-bold text-zinc-100">
                  {printerSpecs.maxNozzleTemp}°C
                </p>
              </div>
              <div className="bg-zinc-950/50 p-4 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Box className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Build Volume</span>
                </div>
                <p className="text-lg font-bold text-zinc-100">
                  {printerSpecs.buildVolume.x}×{printerSpecs.buildVolume.y}×
                  {printerSpecs.buildVolume.z}mm
                </p>
              </div>
              <div className="bg-zinc-950/50 p-4 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Zap className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Max Speed</span>
                </div>
                <p className="text-2xl font-bold text-zinc-100">
                  {printerSpecs.maxSpeed}mm/s
                </p>
              </div>
              <div className="bg-zinc-950/50 p-4 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Palette className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Max Colors</span>
                </div>
                <p className="text-2xl font-bold text-zinc-100">
                  {printerSpecs.maxColors}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Key Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {printerSpecs.features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center gap-3 p-3 bg-zinc-950/50 rounded-lg border border-zinc-800"
                >
                  <div className="w-2 h-2 rounded-full bg-amber-500" />
                  <span className="text-zinc-300 text-sm">{feature}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Hardware Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-xs text-zinc-500">Nozzle Count</p>
                  <p className="text-zinc-100 font-medium">{printerSpecs.nozzleCount} (Dual)</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center">
                  <Layers className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-xs text-zinc-500">AMS Units</p>
                  <p className="text-zinc-100 font-medium">{printerSpecs.amsUnits}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center">
                  <Thermometer className="w-5 h-5 text-zinc-400" />
                </div>
                <div>
                  <p className="text-xs text-zinc-500">Max Bed Temp</p>
                  <p className="text-zinc-100 font-medium">{printerSpecs.maxBedTemp}°C</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Print Parameters Section
const PrintParameters: React.FC = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-500" />
              Material Print Settings
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Default parameters optimized for Bambu Lab H2D
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow className="border-zinc-800 hover:bg-transparent">
                    <TableHead className="text-zinc-400">Material</TableHead>
                    <TableHead className="text-zinc-400">Nozzle Temp</TableHead>
                    <TableHead className="text-zinc-400">Bed Temp</TableHead>
                    <TableHead className="text-zinc-400">Speed</TableHead>
                    <TableHead className="text-zinc-400">Infill</TableHead>
                    <TableHead className="text-zinc-400">Supports</TableHead>
                    <TableHead className="text-zinc-400">Cooling</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {materialSettings.map((material, index) => (
                    <TableRow
                      key={index}
                      className="border-zinc-800 hover:bg-zinc-800/50"
                    >
                      <TableCell className="font-medium text-zinc-100">
                        {material.material}
                      </TableCell>
                      <TableCell className="text-zinc-300">
                        <span className="flex items-center gap-1">
                          <Thermometer className="w-3 h-3 text-red-400" />
                          {material.nozzleTemp}
                        </span>
                      </TableCell>
                      <TableCell className="text-zinc-300">
                        <span className="flex items-center gap-1">
                          <Box className="w-3 h-3 text-orange-400" />
                          {material.bedTemp}
                        </span>
                      </TableCell>
                      <TableCell className="text-zinc-300">
                        <span className="flex items-center gap-1">
                          <Zap className="w-3 h-3 text-amber-400" />
                          {material.speed}
                        </span>
                      </TableCell>
                      <TableCell className="text-zinc-300">
                        <span className="flex items-center gap-1">
                          <Grid3x3 className="w-3 h-3 text-blue-400" />
                          {material.infill}
                        </span>
                      </TableCell>
                      <TableCell>
                        {material.supports ? (
                          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                            Yes
                          </Badge>
                        ) : (
                          <Badge className="bg-zinc-700 text-zinc-400">No</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-zinc-300">
                        <span className="flex items-center gap-1">
                          <Wind className="w-3 h-3 text-cyan-400" />
                          {material.cooling}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Retraction Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {materialSettings.slice(0, 4).map((material, index) => (
                <div
                  key={index}
                  className="p-3 bg-zinc-950/50 rounded-lg border border-zinc-800"
                >
                  <p className="text-xs text-zinc-500 mb-1">{material.material}</p>
                  <p className="text-zinc-100 font-mono text-sm">{material.retraction}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Calibration Section
const Calibration: React.FC = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 flex items-center gap-2">
              <Gauge className="w-5 h-5 text-amber-500" />
              Calibration History
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Last calibration: {calibrationHistory[0].date} by {calibrationHistory[0].performedBy}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {calibrationHistory.map((entry, index) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge
                          variant="outline"
                          className="border-amber-500/30 text-amber-400"
                        >
                          {getCalibrationTypeLabel(entry.type)}
                        </Badge>
                        <span className="text-sm text-zinc-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {entry.date}
                        </span>
                        <span className="text-sm text-zinc-500 flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {entry.performedBy}
                        </span>
                      </div>
                      <p className="text-zinc-300 text-sm mb-3">{entry.notes}</p>
                      <div className="flex gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-zinc-500">Flow Rate:</span>
                          <span className="text-sm font-mono text-zinc-100">
                            {entry.flowRate.toFixed(3)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-zinc-500">Pressure Advance:</span>
                          <span className="text-sm font-mono text-zinc-100">
                            {entry.pressureAdvance.toFixed(4)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Current Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <p className="text-xs text-zinc-500 mb-1">Flow Rate</p>
                <p className="text-2xl font-mono font-bold text-amber-400">
                  {calibrationHistory[0].flowRate.toFixed(3)}
                </p>
              </div>
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <p className="text-xs text-zinc-500 mb-1">Pressure Advance</p>
                <p className="text-2xl font-mono font-bold text-amber-400">
                  {calibrationHistory[0].pressureAdvance.toFixed(4)}
                </p>
              </div>
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <p className="text-xs text-zinc-500 mb-1">Retraction Distance</p>
                <p className="text-2xl font-mono font-bold text-zinc-100">0.8mm</p>
              </div>
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <p className="text-xs text-zinc-500 mb-1">Retraction Speed</p>
                <p className="text-2xl font-mono font-bold text-zinc-100">40mm/s</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Maintenance Section
const Maintenance: React.FC = () => {
  const [checklist, setChecklist] = useState(maintenanceChecklist);

  const toggleChecklistItem = (category: 'daily' | 'weekly' | 'monthly', id: string) => {
    setChecklist((prev) => ({
      ...prev,
      [category]: prev[category].map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-amber-500" />
              Maintenance History
            </CardTitle>
            <CardDescription className="text-zinc-500">
              Service records and part replacements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {maintenanceHistory.map((entry, index) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge
                          className={
                            entry.type === 'Preventive'
                              ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                              : entry.type === 'Repair'
                              ? 'bg-red-500/20 text-red-400 border-red-500/30'
                              : 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                          }
                        >
                          {entry.type}
                        </Badge>
                        <span className="text-sm text-zinc-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {entry.date}
                        </span>
                        {entry.nextDue && (
                          <span className="text-sm text-zinc-500 flex items-center gap-1">
                            <RotateCw className="w-3 h-3" />
                            Next: {entry.nextDue}
                          </span>
                        )}
                      </div>
                      <p className="text-zinc-300 text-sm mb-2">{entry.description}</p>
                      {entry.partsReplaced.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-2">
                          {entry.partsReplaced.map((part, i) => (
                            <Badge
                              key={i}
                              variant="outline"
                              className="border-zinc-700 text-zinc-400 text-xs"
                            >
                              {part}
                            </Badge>
                          ))}
                        </div>
                      )}
                      <div className="flex items-center gap-4 text-sm">
                        <span className="text-zinc-500 flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {entry.performedBy}
                        </span>
                        <span className="text-zinc-500">Cost: ${entry.cost.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div variants={itemVariants}>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-lg">Part Wear Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {partWear.map((part, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-zinc-300">{part.name}</span>
                        {getStatusBadge(part.status)}
                      </div>
                      <span className="text-xs text-zinc-500">
                        {part.used}/{part.lifespan}h
                      </span>
                    </div>
                    <div className="relative h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(part.used / part.lifespan) * 100}%` }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        className={`absolute h-full rounded-full ${getStatusColor(
                          part.status
                        )}`}
                      />
                    </div>
                    <p className="text-xs text-zinc-500">
                      Last replaced: {part.lastReplaced} • {part.remaining}h remaining
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-lg">Maintenance Checklist</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-zinc-400 mb-2 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Daily
                    </h4>
                    <div className="space-y-2">
                      {checklist.daily.map((item) => (
                        <label
                          key={item.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-800/50 cursor-pointer"
                        >
                          <Checkbox
                            checked={item.completed}
                            onCheckedChange={() => toggleChecklistItem('daily', item.id)}
                          />
                          <span
                            className={`text-sm ${
                              item.completed ? 'text-zinc-500 line-through' : 'text-zinc-300'
                            }`}
                          >
                            {item.task}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <Separator className="bg-zinc-800" />
                  <div>
                    <h4 className="text-sm font-medium text-zinc-400 mb-2 flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Weekly
                    </h4>
                    <div className="space-y-2">
                      {checklist.weekly.map((item) => (
                        <label
                          key={item.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-800/50 cursor-pointer"
                        >
                          <Checkbox
                            checked={item.completed}
                            onCheckedChange={() => toggleChecklistItem('weekly', item.id)}
                          />
                          <span
                            className={`text-sm ${
                              item.completed ? 'text-zinc-500 line-through' : 'text-zinc-300'
                            }`}
                          >
                            {item.task}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <Separator className="bg-zinc-800" />
                  <div>
                    <h4 className="text-sm font-medium text-zinc-400 mb-2 flex items-center gap-2">
                      <RotateCw className="w-4 h-4" />
                      Monthly
                    </h4>
                    <div className="space-y-2">
                      {checklist.monthly.map((item) => (
                        <label
                          key={item.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-800/50 cursor-pointer"
                        >
                          <Checkbox
                            checked={item.completed}
                            onCheckedChange={() => toggleChecklistItem('monthly', item.id)}
                          />
                          <span
                            className={`text-sm ${
                              item.completed ? 'text-zinc-500 line-through' : 'text-zinc-300'
                            }`}
                          >
                            {item.task}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
};

// Statistics Section
const Statistics: React.FC = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-500 mb-2">
                <Clock className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Total Print Time</span>
              </div>
              <p className="text-2xl font-bold text-zinc-100">
                {Math.floor(printerStats.totalPrintTime / 24)}d{' '}
                {printerStats.totalPrintTime % 24}h
              </p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-500 mb-2">
                <Droplets className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Filament Used</span>
              </div>
              <p className="text-2xl font-bold text-zinc-100">
                {printerStats.totalFilamentUsed.toFixed(1)} kg
              </p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-500 mb-2">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Completed Prints</span>
              </div>
              <p className="text-2xl font-bold text-zinc-100">
                {printerStats.completedPrints}
              </p>
            </CardContent>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-zinc-500 mb-2">
                <TrendingUp className="w-4 h-4" />
                <span className="text-xs uppercase tracking-wider">Success Rate</span>
              </div>
              <p className="text-2xl font-bold text-emerald-400">
                {printerStats.successRate}%
              </p>
            </CardContent>
          </Card>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div variants={itemVariants}>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-lg">Monthly Print Volume</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={printerStats.monthlyStats}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                    <XAxis dataKey="month" stroke="#71717a" fontSize={12} />
                    <YAxis stroke="#71717a" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#18181b',
                        border: '1px solid #27272a',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: '#a1a1aa' }}
                    />
                    <Bar dataKey="prints" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-zinc-100 text-lg">Filament Usage (kg)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={printerStats.monthlyStats}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                    <XAxis dataKey="month" stroke="#71717a" fontSize={12} />
                    <YAxis stroke="#71717a" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#18181b',
                        border: '1px solid #27272a',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: '#a1a1aa' }}
                    />
                    <Area
                      type="monotone"
                      dataKey="filamentUsed"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Success Rate Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={printerStats.monthlyStats}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="month" stroke="#71717a" fontSize={12} />
                  <YAxis stroke="#71717a" fontSize={12} domain={[90, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#18181b',
                      border: '1px solid #27272a',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#a1a1aa' }}
                    formatter={(value: number) => [`${value}%`, 'Success Rate']}
                  />
                  <Line
                    type="monotone"
                    dataKey="successRate"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ fill: '#10b981', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Online Status Section
const OnlineStatus: React.FC = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-4"
    >
      <motion.div variants={itemVariants}>
        <Card
          className={`border ${
            onlineStatus.isOnline
              ? 'bg-emerald-950/20 border-emerald-500/30'
              : 'bg-red-950/20 border-red-500/30'
          }`}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    onlineStatus.isOnline ? 'bg-emerald-500/20' : 'bg-red-500/20'
                  }`}
                >
                  {onlineStatus.isOnline ? (
                    <Wifi className="w-6 h-6 text-emerald-400" />
                  ) : (
                    <WifiOff className="w-6 h-6 text-red-400" />
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-zinc-100">
                    {onlineStatus.isOnline ? 'Printer Online' : 'Printer Offline'}
                  </h3>
                  <p className="text-zinc-500">
                    {onlineStatus.isOnline
                      ? 'Connected and ready'
                      : 'Connection lost - check network'}
                  </p>
                </div>
              </div>
              <Badge
                className={
                  onlineStatus.isOnline
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    : 'bg-red-500/20 text-red-400 border-red-500/30'
                }
              >
                {onlineStatus.isOnline ? 'Active' : 'Disconnected'}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {onlineStatus.isOnline && onlineStatus.currentJob && (
        <motion.div variants={itemVariants}>
          <Card className="bg-zinc-900/50 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-zinc-100 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-500" />
                Current Print Job
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-medium text-zinc-100">
                      {onlineStatus.currentJob.name}
                    </p>
                    <p className="text-sm text-zinc-500">
                      Layer {onlineStatus.currentJob.layer}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-amber-400">
                      {onlineStatus.currentJob.progress}%
                    </p>
                    <p className="text-sm text-zinc-500">
                      {onlineStatus.currentJob.remaining} remaining
                    </p>
                  </div>
                </div>
                <Progress value={onlineStatus.currentJob.progress} className="h-3" />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-zinc-500 flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    Elapsed: {onlineStatus.currentJob.elapsed}
                  </span>
                  <span className="text-zinc-500">
                    ETA: {new Date(Date.now() + parseInt(onlineStatus.currentJob.remaining) * 60000).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">Temperatures</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Thermometer className="w-4 h-4 text-red-400" />
                  <span className="text-xs uppercase tracking-wider">Nozzle</span>
                </div>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold text-zinc-100">
                    {onlineStatus.temperatures.nozzle.current}°C
                  </span>
                  <span className="text-sm text-zinc-500 mb-1">
                    / {onlineStatus.temperatures.nozzle.target}°C
                  </span>
                </div>
              </div>
              <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-500 mb-2">
                  <Box className="w-4 h-4 text-orange-400" />
                  <span className="text-xs uppercase tracking-wider">Bed</span>
                </div>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold text-zinc-100">
                    {onlineStatus.temperatures.bed.current}°C
                  </span>
                  <span className="text-sm text-zinc-500 mb-1">
                    / {onlineStatus.temperatures.bed.target}°C
                  </span>
                </div>
              </div>
              {onlineStatus.chamberTemp && (
                <div className="p-4 bg-zinc-950/50 rounded-lg border border-zinc-800">
                  <div className="flex items-center gap-2 text-zinc-500 mb-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span className="text-xs uppercase tracking-wider">Chamber</span>
                  </div>
                  <div className="flex items-end gap-2">
                    <span className="text-3xl font-bold text-zinc-100">
                      {onlineStatus.chamberTemp}°C
                    </span>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="bg-zinc-900/50 border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100 text-lg">System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3 p-3 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <Wind className="w-5 h-5 text-cyan-400" />
                <div>
                  <p className="text-xs text-zinc-500">Fan Speed</p>
                  <p className="text-zinc-100 font-medium">{onlineStatus.fanSpeed}%</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <Eye className="w-5 h-5 text-purple-400" />
                <div>
                  <p className="text-xs text-zinc-500">Camera</p>
                  <p className="text-zinc-100 font-medium">Active</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <Ruler className="w-5 h-5 text-emerald-400" />
                <div>
                  <p className="text-xs text-zinc-500">Position</p>
                  <p className="text-zinc-100 font-medium">X:142 Y:203</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-zinc-950/50 rounded-lg border border-zinc-800">
                <Zap className="w-5 h-5 text-amber-400" />
                <div>
                  <p className="text-xs text-zinc-500">Power</p>
                  <p className="text-zinc-100 font-medium">245W</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

// Missing import for Grid3x3
const Grid3x3: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <rect width="18" height="18" x="3" y="3" rx="2" />
    <path d="M3 9h18" />
    <path d="M3 15h18" />
    <path d="M9 3v18" />
    <path d="M15 3v18" />
  </svg>
);

// Main Printer Profile Component
const PrinterProfile: React.FC = () => {
  const [activeTab, setActiveTab] = useState('specs');

  return (
    <div className="min-h-screen bg-zinc-950 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2 mb-2">
            <span className="text-zinc-500 text-sm">3D Print Business Hub</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
            <span className="text-zinc-400 text-sm">Printers</span>
            <ChevronRight className="w-4 h-4 text-zinc-600" />
            <span className="text-amber-400 text-sm">H2D-001</span>
          </div>
          <h1 className="text-3xl font-bold text-zinc-100 flex items-center gap-3">
            <Printer className="w-8 h-8 text-amber-500" />
            Bambu Lab H2D
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <Wifi className="w-3 h-3 mr-1" />
              Online
            </Badge>
          </h1>
          <p className="text-zinc-500 mt-1">Professional dual-extruder 3D printer</p>
        </motion.div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-zinc-900 border border-zinc-800 p-1 flex flex-wrap gap-1">
            <TabsTrigger
              value="specs"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Settings className="w-4 h-4 mr-2" />
              Specs
            </TabsTrigger>
            <TabsTrigger
              value="parameters"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Layers className="w-4 h-4 mr-2" />
              Parameters
            </TabsTrigger>
            <TabsTrigger
              value="calibration"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Gauge className="w-4 h-4 mr-2" />
              Calibration
            </TabsTrigger>
            <TabsTrigger
              value="maintenance"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Wrench className="w-4 h-4 mr-2" />
              Maintenance
            </TabsTrigger>
            <TabsTrigger
              value="statistics"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Statistics
            </TabsTrigger>
            <TabsTrigger
              value="status"
              className="data-[state=active]:bg-amber-500 data-[state=active]:text-zinc-950"
            >
              <Wifi className="w-4 h-4 mr-2" />
              Live Status
            </TabsTrigger>
          </TabsList>

          <TabsContent value="specs">
            <TechnicalSpecs />
          </TabsContent>
          <TabsContent value="parameters">
            <PrintParameters />
          </TabsContent>
          <TabsContent value="calibration">
            <Calibration />
          </TabsContent>
          <TabsContent value="maintenance">
            <Maintenance />
          </TabsContent>
          <TabsContent value="statistics">
            <Statistics />
          </TabsContent>
          <TabsContent value="status">
            <OnlineStatus />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PrinterProfile;
