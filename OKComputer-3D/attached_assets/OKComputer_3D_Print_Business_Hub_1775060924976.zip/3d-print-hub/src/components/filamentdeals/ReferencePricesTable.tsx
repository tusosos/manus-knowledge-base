import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Clock } from 'lucide-react';
import type { ReferencePrice, MaterialType } from './types';

interface ReferencePricesTableProps {
  prices: ReferencePrice[];
}

const materialColors: Record<MaterialType, string> = {
  PLA: 'bg-green-500/20 text-green-400 border-green-500/30',
  PETG: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  ABS: 'bg-red-500/20 text-red-400 border-red-500/30',
  TPU: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  PA: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  PC: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
};

const TrendIcon: React.FC<{ trend: 'up' | 'down' | 'stable'; value: number }> = ({ trend, value }) => {
  if (trend === 'up') {
    return (
      <div className="flex items-center gap-1 text-red-400">
        <TrendingUp className="h-4 w-4" />
        <span className="text-xs font-medium">+{value.toFixed(1)}%</span>
      </div>
    );
  }
  if (trend === 'down') {
    return (
      <div className="flex items-center gap-1 text-green-400">
        <TrendingDown className="h-4 w-4" />
        <span className="text-xs font-medium">-{value.toFixed(1)}%</span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1 text-zinc-500">
      <Minus className="h-4 w-4" />
      <span className="text-xs font-medium">{value.toFixed(1)}%</span>
    </div>
  );
};

export const ReferencePricesTable: React.FC<ReferencePricesTableProps> = ({ prices }) => {
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 overflow-hidden">
      <div className="p-4 border-b border-zinc-800">
        <h3 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
          Ceny Referencyjne
          <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-400 border-amber-500/30">
            PLN/kg
          </Badge>
        </h3>
        <p className="text-sm text-zinc-500 mt-1">
          Aktualne ceny rynkowe dla popularnych materiałów 3D
        </p>
      </div>
      
      <Table>
        <TableHeader>
          <TableRow className="border-zinc-800 hover:bg-transparent">
            <TableHead className="text-zinc-400 font-medium">Materiał</TableHead>
            <TableHead className="text-zinc-400 font-medium text-right">Cena/kg</TableHead>
            <TableHead className="text-zinc-400 font-medium text-center">Trend (7d)</TableHead>
            <TableHead className="text-zinc-400 font-medium text-right">
              <span className="flex items-center justify-end gap-1">
                <Clock className="h-3.5 w-3.5" />
                Aktualizacja
              </span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {prices.map((price) => (
            <TableRow 
              key={price.material} 
              className="border-zinc-800/50 hover:bg-zinc-900/50 transition-colors"
            >
              <TableCell>
                <Badge 
                  variant="outline" 
                  className={`font-semibold ${materialColors[price.material]}`}
                >
                  {price.material}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <span className="text-lg font-bold text-zinc-100">
                  {price.pricePerKg.toFixed(2)}
                </span>
                <span className="text-sm text-zinc-500 ml-1">zł</span>
              </TableCell>
              <TableCell className="text-center">
                <TrendIcon trend={price.trend} value={price.trendValue} />
              </TableCell>
              <TableCell className="text-right text-zinc-500 text-sm">
                {price.lastUpdated}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default ReferencePricesTable;
