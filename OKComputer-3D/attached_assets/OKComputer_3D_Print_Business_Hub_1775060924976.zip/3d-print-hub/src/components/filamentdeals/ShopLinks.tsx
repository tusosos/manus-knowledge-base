import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, MapPin, Globe, ShoppingCart } from 'lucide-react';
import type { Shop } from './types';

interface ShopLinksProps {
  polishShops: Shop[];
  chineseShops: Shop[];
}

const ShopCard: React.FC<{ shop: Shop; variant: 'poland' | 'china' }> = ({ shop, variant }) => {
  const isPoland = variant === 'poland';
  
  return (
    <a
      href={shop.url}
      target="_blank"
      rel="noopener noreferrer"
      className="group block"
    >
      <div className={`
        relative p-4 rounded-lg border transition-all duration-300
        ${isPoland 
          ? 'bg-zinc-900/50 border-zinc-800 hover:border-amber-500/50 hover:bg-zinc-900' 
          : 'bg-zinc-900/30 border-zinc-800/50 hover:border-red-500/50 hover:bg-zinc-900/50'
        }
      `}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`
              w-10 h-10 rounded-lg flex items-center justify-center
              ${isPoland ? 'bg-amber-500/10' : 'bg-red-500/10'}
            `}>
              <ShoppingCart className={`h-5 w-5 ${isPoland ? 'text-amber-500' : 'text-red-500'}`} />
            </div>
            <div>
              <h4 className="font-medium text-zinc-200 group-hover:text-white transition-colors">
                {shop.name}
              </h4>
              <div className="flex items-center gap-1.5 mt-0.5">
                <MapPin className="h-3 w-3 text-zinc-500" />
                <span className="text-xs text-zinc-500">
                  {isPoland ? 'Polska' : 'Chiny'}
                </span>
              </div>
            </div>
          </div>
          <ExternalLink className="h-4 w-4 text-zinc-600 group-hover:text-zinc-400 transition-colors" />
        </div>
      </div>
    </a>
  );
};

export const ShopLinks: React.FC<ShopLinksProps> = ({ polishShops, chineseShops }) => {
  return (
    <div className="space-y-6">
      {/* Polish Shops */}
      <Card className="bg-zinc-950/50 border-zinc-800">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <MapPin className="h-4 w-4 text-amber-500" />
              </div>
              Polskie Sklepy
            </CardTitle>
            <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30">
              {polishShops.length} sklepów
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {polishShops.map((shop) => (
              <ShopCard key={shop.id} shop={shop} variant="poland" />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Chinese Shops */}
      <Card className="bg-zinc-950/50 border-zinc-800">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
                <Globe className="h-4 w-4 text-red-500" />
              </div>
              Chińskie Platformy
            </CardTitle>
            <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30">
              {chineseShops.length} platform
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {chineseShops.map((shop) => (
              <ShopCard key={shop.id} shop={shop} variant="china" />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ShopLinks;
