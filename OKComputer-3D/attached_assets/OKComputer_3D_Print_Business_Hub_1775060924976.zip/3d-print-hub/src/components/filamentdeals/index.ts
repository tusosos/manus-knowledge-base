// Filament Deals Module - 3D Print Business Hub
// Module for tracking filament prices, promotions, and price alerts

export { FilamentDeals } from './FilamentDeals';
export { ReferencePricesTable } from './ReferencePricesTable';
export { ShopLinks } from './ShopLinks';
export { PromotionsSection } from './PromotionsSection';
export { PriceAlerts } from './PriceAlerts';
export { PriceHistory } from './PriceHistory';

// Types
export type {
  MaterialType,
  TrendType,
  ReferencePrice,
  Shop,
  Promotion,
  PriceAlert,
  PriceHistoryPoint,
  MaterialPriceHistory,
} from './types';
