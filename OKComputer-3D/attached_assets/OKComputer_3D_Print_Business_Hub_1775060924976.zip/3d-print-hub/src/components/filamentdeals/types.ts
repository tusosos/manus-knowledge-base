// Types for Filament Deals Module

export type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'TPU' | 'PA' | 'PC';
export type TrendType = 'up' | 'down' | 'stable';

export interface ReferencePrice {
  material: MaterialType;
  pricePerKg: number;
  lastUpdated: string;
  trend: TrendType;
  trendValue: number;
}

export interface Shop {
  id: string;
  name: string;
  url: string;
  logo?: string;
  country: 'poland' | 'china';
}

export interface Promotion {
  id: string;
  shopName: string;
  shopUrl: string;
  material: MaterialType;
  color?: string;
  promotionalPrice: number;
  regularPrice: number;
  savings: number;
  savingsPercent: number;
  endDate: string;
  link: string;
  isHot?: boolean;
}

export interface PriceAlert {
  id: string;
  material: MaterialType;
  condition: 'below' | 'above';
  targetPrice: number;
  isActive: boolean;
  createdAt: string;
}

export interface PriceHistoryPoint {
  date: string;
  price: number;
}

export interface MaterialPriceHistory {
  material: MaterialType;
  data: PriceHistoryPoint[];
  bestBuyTime: string;
  lowestPrice: number;
  averagePrice: number;
}
