import React, { useState, useCallback } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ShoppingCart, 
  Tag, 
  Bell, 
  TrendingUp, 
  Store,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { ReferencePricesTable } from './ReferencePricesTable';
import { ShopLinks } from './ShopLinks';
import { PromotionsSection } from './PromotionsSection';
import { PriceAlerts } from './PriceAlerts';
import { PriceHistory } from './PriceHistory';
import type { 
  ReferencePrice, 
  Shop, 
  Promotion, 
  PriceAlert, 
  MaterialPriceHistory 
} from './types';

// Mock data - Reference Prices
const mockReferencePrices: ReferencePrice[] = [
  { material: 'PLA', pricePerKg: 65.50, lastUpdated: '2024-01-15', trend: 'down', trendValue: 3.2 },
  { material: 'PETG', pricePerKg: 72.00, lastUpdated: '2024-01-15', trend: 'stable', trendValue: 0.5 },
  { material: 'ABS', pricePerKg: 68.90, lastUpdated: '2024-01-15', trend: 'up', trendValue: 2.1 },
  { material: 'TPU', pricePerKg: 95.00, lastUpdated: '2024-01-15', trend: 'down', trendValue: 5.5 },
  { material: 'PA', pricePerKg: 120.00, lastUpdated: '2024-01-15', trend: 'stable', trendValue: 0.0 },
  { material: 'PC', pricePerKg: 145.00, lastUpdated: '2024-01-15', trend: 'up', trendValue: 4.2 },
];

// Mock data - Polish Shops
const mockPolishShops: Shop[] = [
  { id: '1', name: 'Allegro', url: 'https://allegro.pl/listing?string=filament+3d', country: 'poland' },
  { id: '2', name: '3DJake', url: 'https://www.3djake.pl', country: 'poland' },
  { id: '3', name: 'Botland', url: 'https://botland.com.pl', country: 'poland' },
  { id: '4', name: 'Rosa3D', url: 'https://rosa3d.pl', country: 'poland' },
  { id: '5', name: 'Fiberlogy', url: 'https://fiberlogy.com/pl', country: 'poland' },
  { id: '6', name: 'Devil Design', url: 'https://devildesign.pl', country: 'poland' },
];

// Mock data - Chinese Shops
const mockChineseShops: Shop[] = [
  { id: '7', name: 'AliExpress', url: 'https://pl.aliexpress.com/wholesale?SearchText=filament+3d', country: 'china' },
  { id: '8', name: 'Banggood', url: 'https://www.banggood.com/search/filament-3d.html', country: 'china' },
  { id: '9', name: 'Temu', url: 'https://www.temu.com/search_result.html?search_key=filament+3d', country: 'china' },
  { id: '10', name: 'Shein', url: 'https://www.shein.com/search?key=filament+3d', country: 'china' },
];

// Mock data - Promotions
const mockPromotions: Promotion[] = [
  {
    id: '1',
    shopName: 'Allegro',
    shopUrl: 'https://allegro.pl',
    material: 'PLA',
    color: 'Czarny',
    promotionalPrice: 52.99,
    regularPrice: 79.99,
    savings: 27.00,
    savingsPercent: 33.8,
    endDate: '2024-01-20',
    link: 'https://allegro.pl/oferta/filament-pla',
    isHot: true,
  },
  {
    id: '2',
    shopName: 'Fiberlogy',
    shopUrl: 'https://fiberlogy.com',
    material: 'PETG',
    color: 'Przezroczysty',
    promotionalPrice: 64.50,
    regularPrice: 89.00,
    savings: 24.50,
    savingsPercent: 27.5,
    endDate: '2024-01-25',
    link: 'https://fiberlogy.com/pl/produkt/petg',
    isHot: false,
  },
  {
    id: '3',
    shopName: 'Botland',
    shopUrl: 'https://botland.com.pl',
    material: 'ABS',
    color: 'Biały',
    promotionalPrice: 58.00,
    regularPrice: 75.00,
    savings: 17.00,
    savingsPercent: 22.7,
    endDate: '2024-01-18',
    link: 'https://botland.com.pl/filament-abs',
    isHot: true,
  },
  {
    id: '4',
    shopName: '3DJake',
    shopUrl: 'https://www.3djake.pl',
    material: 'TPU',
    color: 'Czerwony',
    promotionalPrice: 79.99,
    regularPrice: 110.00,
    savings: 30.01,
    savingsPercent: 27.3,
    endDate: '2024-01-30',
    link: 'https://www.3djake.pl/filament-tpu',
    isHot: true,
  },
  {
    id: '5',
    shopName: 'Rosa3D',
    shopUrl: 'https://rosa3d.pl',
    material: 'PLA',
    color: 'Szary',
    promotionalPrice: 59.90,
    regularPrice: 69.90,
    savings: 10.00,
    savingsPercent: 14.3,
    endDate: '2024-01-22',
    link: 'https://rosa3d.pl/filament-pla',
    isHot: false,
  },
  {
    id: '6',
    shopName: 'Devil Design',
    shopUrl: 'https://devildesign.pl',
    material: 'PETG',
    color: 'Niebieski',
    promotionalPrice: 61.00,
    regularPrice: 72.00,
    savings: 11.00,
    savingsPercent: 15.3,
    endDate: '2024-01-28',
    link: 'https://devildesign.pl/filament-petg',
    isHot: false,
  },
];

// Mock data - Price History
const generatePriceHistory = (basePrice: number, volatility: number): { date: string; price: number }[] => {
  const data: { date: string; price: number }[] = [];
  const today = new Date();
  
  for (let i = 365; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const randomChange = (Math.random() - 0.5) * volatility;
    const seasonalFactor = Math.sin((date.getMonth() / 12) * Math.PI * 2) * 5;
    const price = Math.max(basePrice + randomChange + seasonalFactor, basePrice * 0.7);
    
    data.push({
      date: date.toISOString().split('T')[0],
      price: Number(price.toFixed(2)),
    });
  }
  
  return data;
};

const mockPriceHistory: Record<string, MaterialPriceHistory> = {
  PLA: {
    material: 'PLA',
    data: generatePriceHistory(65, 8),
    bestBuyTime: 'w styczniu i lutym (po świętach)',
    lowestPrice: 52.99,
    averagePrice: 65.50,
  },
  PETG: {
    material: 'PETG',
    data: generatePriceHistory(72, 6),
    bestBuyTime: 'pod koniec kwartału (marzec, czerwiec, wrzesień)',
    lowestPrice: 61.00,
    averagePrice: 72.00,
  },
  ABS: {
    material: 'ABS',
    data: generatePriceHistory(68, 7),
    bestBuyTime: 'w okresie letnim (czerwiec-sierpień)',
    lowestPrice: 55.00,
    averagePrice: 68.90,
  },
  TPU: {
    material: 'TPU',
    data: generatePriceHistory(95, 12),
    bestBuyTime: 'podczas wyprzedaży sezonowych (Black Friday)',
    lowestPrice: 76.00,
    averagePrice: 95.00,
  },
  PA: {
    material: 'PA',
    data: generatePriceHistory(120, 10),
    bestBuyTime: 'na początku roku (styczeń-luty)',
    lowestPrice: 98.00,
    averagePrice: 120.00,
  },
  PC: {
    material: 'PC',
    data: generatePriceHistory(145, 15),
    bestBuyTime: 'podczas promocji specjalnych (listopad)',
    lowestPrice: 118.00,
    averagePrice: 145.00,
  },
};

// Mock data - Initial Alerts
const mockInitialAlerts: PriceAlert[] = [
  {
    id: '1',
    material: 'PLA',
    condition: 'below',
    targetPrice: 60.00,
    isActive: true,
    createdAt: '2024-01-10',
  },
  {
    id: '2',
    material: 'PETG',
    condition: 'below',
    targetPrice: 65.00,
    isActive: true,
    createdAt: '2024-01-12',
  },
];

export const FilamentDeals: React.FC = () => {
  const [alerts, setAlerts] = useState<PriceAlert[]>(mockInitialAlerts);

  const handleAddAlert = useCallback((alert: Omit<PriceAlert, 'id' | 'createdAt'>) => {
    const newAlert: PriceAlert = {
      ...alert,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setAlerts(prev => [...prev, newAlert]);
  }, []);

  const handleDeleteAlert = useCallback((id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  }, []);

  const handleToggleAlert = useCallback((id: string) => {
    setAlerts(prev => prev.map(a => 
      a.id === id ? { ...a, isActive: !a.isActive } : a
    ));
  }, []);

  const activePromotionsCount = mockPromotions.length;
  const activeAlertsCount = alerts.filter(a => a.isActive).length;

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                  <ShoppingCart className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-zinc-100">
                    Okazje na Filamenty
                  </h1>
                  <p className="text-sm text-zinc-500">
                    3D Print Business Hub
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/30">
                <Sparkles className="h-3.5 w-3.5 mr-1.5" />
                {activePromotionsCount} okazji
              </Badge>
              <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30">
                <Bell className="h-3.5 w-3.5 mr-1.5" />
                {activeAlertsCount} alertów
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="prices" className="space-y-6">
          <TabsList className="bg-zinc-900 border border-zinc-800 p-1 w-full justify-start overflow-x-auto">
            <TabsTrigger 
              value="prices" 
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Ceny
            </TabsTrigger>
            <TabsTrigger 
              value="promotions"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100"
            >
              <Tag className="h-4 w-4 mr-2" />
              Promocje
              {activePromotionsCount > 0 && (
                <span className="ml-2 px-1.5 py-0.5 text-xs bg-amber-500 text-black rounded-full font-medium">
                  {activePromotionsCount}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger 
              value="shops"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100"
            >
              <Store className="h-4 w-4 mr-2" />
              Sklepy
            </TabsTrigger>
            <TabsTrigger 
              value="history"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Historia
            </TabsTrigger>
            <TabsTrigger 
              value="alerts"
              className="data-[state=active]:bg-zinc-800 data-[state=active]:text-zinc-100"
            >
              <Bell className="h-4 w-4 mr-2" />
              Alerty
              {activeAlertsCount > 0 && (
                <span className="ml-2 px-1.5 py-0.5 text-xs bg-green-500 text-black rounded-full font-medium">
                  {activeAlertsCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Prices Tab */}
          <TabsContent value="prices" className="space-y-6">
            <ReferencePricesTable prices={mockReferencePrices} />
            
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <p className="text-sm text-zinc-500 mb-1">Najtańszy materiał</p>
                <p className="text-lg font-semibold text-green-400">PLA - 52.99 zł/kg</p>
                <p className="text-xs text-zinc-600 mt-1">w promocji na Allegro</p>
              </div>
              <div className="p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <p className="text-sm text-zinc-500 mb-1">Największa obniżka</p>
                <p className="text-lg font-semibold text-amber-400">-33.8%</p>
                <p className="text-xs text-zinc-600 mt-1">PLA Czarny na Allegro</p>
              </div>
              <div className="p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <p className="text-sm text-zinc-500 mb-1">Oszczędność miesięczna</p>
                <p className="text-lg font-semibold text-zinc-100">~89 zł</p>
                <p className="text-xs text-zinc-600 mt-1">przy zakupie 2kg filamentu</p>
              </div>
            </div>
          </TabsContent>

          {/* Promotions Tab */}
          <TabsContent value="promotions">
            <PromotionsSection promotions={mockPromotions} />
          </TabsContent>

          {/* Shops Tab */}
          <TabsContent value="shops">
            <ShopLinks 
              polishShops={mockPolishShops} 
              chineseShops={mockChineseShops} 
            />
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <PriceHistory priceHistory={mockPriceHistory} />
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts">
            <PriceAlerts 
              alerts={alerts}
              onAddAlert={handleAddAlert}
              onDeleteAlert={handleDeleteAlert}
              onToggleAlert={handleToggleAlert}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <div className="border-t border-zinc-800 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-zinc-500">
            <p>
              Dane aktualizowane codziennie. Ceny mogą ulec zmianie.
            </p>
            <div className="flex items-center gap-4">
              <a 
                href="#" 
                className="flex items-center gap-1 hover:text-zinc-300 transition-colors"
              >
                <ExternalLink className="h-4 w-4" />
                Zgłoś okazję
              </a>
              <a 
                href="#" 
                className="flex items-center gap-1 hover:text-zinc-300 transition-colors"
              >
                <ExternalLink className="h-4 w-4" />
                API dla deweloperów
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilamentDeals;
