import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  Target,
  Info,
  Clock,
  ArrowRight
} from 'lucide-react';
import type { MaterialType, MaterialPriceHistory } from './types';

interface PriceHistoryProps {
  priceHistory: Record<MaterialType, MaterialPriceHistory>;
}

const materials: MaterialType[] = ['PLA', 'PETG', 'ABS', 'TPU', 'PA', 'PC'];

const materialColors: Record<MaterialType, { stroke: string; fill: string }> = {
  PLA: { stroke: '#22c55e', fill: 'rgba(34, 197, 94, 0.1)' },
  PETG: { stroke: '#3b82f6', fill: 'rgba(59, 130, 246, 0.1)' },
  ABS: { stroke: '#ef4444', fill: 'rgba(239, 68, 68, 0.1)' },
  TPU: { stroke: '#a855f7', fill: 'rgba(168, 85, 247, 0.1)' },
  PA: { stroke: '#f59e0b', fill: 'rgba(245, 158, 11, 0.1)' },
  PC: { stroke: '#06b6d4', fill: 'rgba(6, 182, 212, 0.1)' },
};

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-zinc-900 border border-zinc-700 rounded-lg p-3 shadow-xl">
        <p className="text-zinc-400 text-sm mb-1">{label}</p>
        <p className="text-zinc-100 font-semibold text-lg">
          {payload[0].value.toFixed(2)} zł/kg
        </p>
      </div>
    );
  }
  return null;
};

export const PriceHistory: React.FC<PriceHistoryProps> = ({ priceHistory }) => {
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialType>('PLA');
  const [timeRange, setTimeRange] = useState<'30d' | '90d' | '1y'>('90d');

  const currentData = priceHistory[selectedMaterial];
  const colors = materialColors[selectedMaterial];

  // Filter data based on time range
  const filteredData = React.useMemo(() => {
    const days = timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
    return currentData.data.slice(-days);
  }, [currentData, timeRange]);

  // Calculate stats
  const currentPrice = filteredData[filteredData.length - 1]?.price || 0;
  const lowestPrice = Math.min(...filteredData.map(d => d.price));
  const highestPrice = Math.max(...filteredData.map(d => d.price));
  const averagePrice = filteredData.reduce((sum, d) => sum + d.price, 0) / filteredData.length;

  // Calculate trend
  const firstPrice = filteredData[0]?.price || 0;
  const priceChange = currentPrice - firstPrice;
  const priceChangePercent = firstPrice > 0 ? (priceChange / firstPrice) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Header with controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-semibold text-zinc-100 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-amber-500" />
            Historia Cen
          </h3>
          <p className="text-sm text-zinc-500 mt-1">
            Analiza zmian cen w czasie - znajdź najlepszy moment na zakup
          </p>
        </div>
        <div className="flex gap-3">
          <Select value={timeRange} onValueChange={(v) => setTimeRange(v as '30d' | '90d' | '1y')}>
            <SelectTrigger className="w-28 bg-zinc-900 border-zinc-700">
              <Calendar className="h-4 w-4 mr-2 text-zinc-500" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-700">
              <SelectItem value="30d">30 dni</SelectItem>
              <SelectItem value="90d">90 dni</SelectItem>
              <SelectItem value="1y">1 rok</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedMaterial} onValueChange={(v) => setSelectedMaterial(v as MaterialType)}>
            <SelectTrigger className="w-28 bg-zinc-900 border-zinc-700">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-zinc-700">
              {materials.map((m) => (
                <SelectItem key={m} value={m}>
                  <span className="font-semibold">{m}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-4">
            <p className="text-xs text-zinc-500 mb-1">Aktualna cena</p>
            <p className="text-xl font-bold text-zinc-100">{currentPrice.toFixed(2)} zł</p>
            <div className={`flex items-center gap-1 mt-1 text-xs ${priceChange >= 0 ? 'text-red-400' : 'text-green-400'}`}>
              {priceChange >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              <span>{priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(1)}%</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-4">
            <p className="text-xs text-zinc-500 mb-1">Najniższa cena</p>
            <p className="text-xl font-bold text-green-400">{lowestPrice.toFixed(2)} zł</p>
            <p className="text-xs text-zinc-500 mt-1">w tym okresie</p>
          </CardContent>
        </Card>
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-4">
            <p className="text-xs text-zinc-500 mb-1">Najwyższa cena</p>
            <p className="text-xl font-bold text-red-400">{highestPrice.toFixed(2)} zł</p>
            <p className="text-xs text-zinc-500 mt-1">w tym okresie</p>
          </CardContent>
        </Card>
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-4">
            <p className="text-xs text-zinc-500 mb-1">Średnia cena</p>
            <p className="text-xl font-bold text-amber-400">{averagePrice.toFixed(2)} zł</p>
            <p className="text-xs text-zinc-500 mt-1">w tym okresie</p>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <Card className="bg-zinc-950/50 border-zinc-800">
        <CardContent className="p-6">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={filteredData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id={`gradient-${selectedMaterial}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors.stroke} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={colors.stroke} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#52525b"
                  tick={{ fill: '#71717a', fontSize: 12 }}
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return `${date.getDate()}/${date.getMonth() + 1}`;
                  }}
                  minTickGap={30}
                />
                <YAxis 
                  stroke="#52525b"
                  tick={{ fill: '#71717a', fontSize: 12 }}
                  tickFormatter={(value) => `${value} zł`}
                  domain={['dataMin - 5', 'dataMax + 5']}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine 
                  y={averagePrice} 
                  stroke="#f59e0b" 
                  strokeDasharray="5 5"
                  strokeOpacity={0.5}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke="none"
                  fill={`url(#gradient-${selectedMaterial})`}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke={colors.stroke}
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 6, fill: colors.stroke, stroke: '#18181b', strokeWidth: 2 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-center gap-6 mt-4 text-xs text-zinc-500">
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5" style={{ backgroundColor: colors.stroke }} />
              <span>Cena</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 border-t border-dashed border-amber-500" />
              <span>Średnia</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Best Buy Time */}
      <Card className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/30">
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
              <Target className="h-6 w-6 text-green-400" />
            </div>
            <div className="flex-1">
              <h4 className="text-lg font-semibold text-zinc-100 mb-1">
                Najlepszy czas na zakup {selectedMaterial}
              </h4>
              <p className="text-sm text-zinc-400 mb-3">
                Na podstawie analizy historycznej, najlepsze ceny dla {selectedMaterial} 
                występują zazwyczaj <span className="text-green-400 font-medium">{currentData.bestBuyTime}</span>.
              </p>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-green-400" />
                  <span className="text-zinc-300">
                    Rekordowo niska: <span className="font-semibold text-green-400">{currentData.lowestPrice.toFixed(2)} zł</span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-4 w-4 text-amber-400" />
                  <span className="text-zinc-300">
                    Średnia: <span className="font-semibold text-amber-400">{currentData.averagePrice.toFixed(2)} zł</span>
                  </span>
                </div>
              </div>
            </div>
            <Button variant="outline" className="border-green-500/50 text-green-400 hover:bg-green-500/10">
              Ustaw alert
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Info */}
      <div className="flex items-start gap-3 p-4 bg-zinc-900/50 rounded-lg border border-zinc-800">
        <Info className="h-5 w-5 text-zinc-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-zinc-500">
          <p className="font-medium text-zinc-400 mb-1">O historii cen</p>
          <p>Dane są aktualizowane codziennie na podstawie cen z polskich i zagranicznych sklepów. 
          Wykres pokazuje średnie ceny rynkowe dla danego materiału.</p>
        </div>
      </div>
    </div>
  );
};

export default PriceHistory;
