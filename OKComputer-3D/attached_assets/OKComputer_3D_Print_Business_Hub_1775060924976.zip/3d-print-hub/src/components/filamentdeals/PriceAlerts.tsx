import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Bell, 
  Plus, 
  Trash2, 
  TrendingDown, 
  TrendingUp, 
  Check,
  AlertCircle,
  Mail
} from 'lucide-react';
import type { PriceAlert, MaterialType } from './types';

interface PriceAlertsProps {
  alerts: PriceAlert[];
  onAddAlert: (alert: Omit<PriceAlert, 'id' | 'createdAt'>) => void;
  onDeleteAlert: (id: string) => void;
  onToggleAlert: (id: string) => void;
}

const materials: MaterialType[] = ['PLA', 'PETG', 'ABS', 'TPU', 'PA', 'PC'];

const materialColors: Record<MaterialType, string> = {
  PLA: 'text-green-400',
  PETG: 'text-blue-400',
  ABS: 'text-red-400',
  TPU: 'text-purple-400',
  PA: 'text-amber-400',
  PC: 'text-cyan-400',
};

export const PriceAlerts: React.FC<PriceAlertsProps> = ({ 
  alerts, 
  onAddAlert, 
  onDeleteAlert,
  onToggleAlert 
}) => {
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialType>('PLA');
  const [condition, setCondition] = useState<'below' | 'above'>('below');
  const [targetPrice, setTargetPrice] = useState<string>('');
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (targetPrice && parseFloat(targetPrice) > 0) {
      onAddAlert({
        material: selectedMaterial,
        condition,
        targetPrice: parseFloat(targetPrice),
        isActive: true,
      });
      setTargetPrice('');
      setShowForm(false);
    }
  };

  const activeAlerts = alerts.filter(a => a.isActive);
  const inactiveAlerts = alerts.filter(a => !a.isActive);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-zinc-100 flex items-center gap-2">
            <Bell className="h-5 w-5 text-amber-500" />
            Alerty Cenowe
          </h3>
          <p className="text-sm text-zinc-500 mt-1">
            Otrzymuj powiadomienia gdy ceny spadną poniżej ustalonego poziomu
          </p>
        </div>
        <Button 
          onClick={() => setShowForm(!showForm)}
          className="bg-amber-500 hover:bg-amber-600 text-black"
          size="sm"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nowy alert
        </Button>
      </div>

      {/* Add Alert Form */}
      {showForm && (
        <Card className="bg-zinc-950/50 border-zinc-800 border-l-4 border-l-amber-500">
          <CardContent className="p-5">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Material Select */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Materiał</label>
                  <Select 
                    value={selectedMaterial} 
                    onValueChange={(v) => setSelectedMaterial(v as MaterialType)}
                  >
                    <SelectTrigger className="bg-zinc-900 border-zinc-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700">
                      {materials.map((m) => (
                        <SelectItem key={m} value={m}>
                          <span className={materialColors[m]}>{m}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Condition Select */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Warunek</label>
                  <Select 
                    value={condition} 
                    onValueChange={(v) => setCondition(v as 'below' | 'above')}
                  >
                    <SelectTrigger className="bg-zinc-900 border-zinc-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700">
                      <SelectItem value="below">
                        <span className="flex items-center gap-2">
                          <TrendingDown className="h-4 w-4 text-green-400" />
                          Spadnie poniżej
                        </span>
                      </SelectItem>
                      <SelectItem value="above">
                        <span className="flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-red-400" />
                          Wzroście powyżej
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Price Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Cena docelowa (zł/kg)</label>
                  <div className="relative">
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="np. 60"
                      value={targetPrice}
                      onChange={(e) => setTargetPrice(e.target.value)}
                      className="bg-zinc-900 border-zinc-700 pr-10"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 text-sm">
                      zł
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowForm(false)}
                  className="border-zinc-700 text-zinc-400 hover:text-zinc-200"
                >
                  Anuluj
                </Button>
                <Button 
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-black"
                >
                  <Check className="h-4 w-4 mr-2" />
                  Ustaw alert
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <h4 className="text-sm font-medium text-zinc-300">
              Aktywne alerty ({activeAlerts.length})
            </h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {activeAlerts.map((alert) => (
              <Card key={alert.id} className="bg-zinc-900/50 border-zinc-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`
                        w-10 h-10 rounded-lg flex items-center justify-center
                        ${alert.condition === 'below' ? 'bg-green-500/10' : 'bg-red-500/10'}
                      `}>
                        {alert.condition === 'below' ? (
                          <TrendingDown className="h-5 w-5 text-green-400" />
                        ) : (
                          <TrendingUp className="h-5 w-5 text-red-400" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold ${materialColors[alert.material]}`}>
                            {alert.material}
                          </span>
                          <Badge variant="outline" className="text-xs bg-green-500/10 text-green-400 border-green-500/30">
                            Aktywny
                          </Badge>
                        </div>
                        <p className="text-sm text-zinc-400">
                          {alert.condition === 'below' ? 'Poniżej' : 'Powyżej'}{' '}
                          <span className="font-semibold text-zinc-200">
                            {alert.targetPrice.toFixed(2)} zł/kg
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onToggleAlert(alert.id)}
                        className="text-zinc-500 hover:text-zinc-300"
                      >
                        <Bell className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-zinc-500 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Inactive Alerts */}
      {inactiveAlerts.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-zinc-600" />
            <h4 className="text-sm font-medium text-zinc-500">
              Nieaktywne alerty ({inactiveAlerts.length})
            </h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {inactiveAlerts.map((alert) => (
              <Card key={alert.id} className="bg-zinc-950/30 border-zinc-800/50 opacity-60">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center">
                        <Bell className="h-5 w-5 text-zinc-600" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold ${materialColors[alert.material]}`}>
                            {alert.material}
                          </span>
                          <Badge variant="outline" className="text-xs bg-zinc-800 text-zinc-500 border-zinc-700">
                            Wstrzymany
                          </Badge>
                        </div>
                        <p className="text-sm text-zinc-500">
                          {alert.condition === 'below' ? 'Poniżej' : 'Powyżej'}{' '}
                          <span className="font-semibold text-zinc-400">
                            {alert.targetPrice.toFixed(2)} zł/kg
                          </span>
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onToggleAlert(alert.id)}
                        className="text-zinc-500 hover:text-green-400"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-zinc-500 hover:text-red-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {alerts.length === 0 && (
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-8 text-center">
            <Mail className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-zinc-400 mb-2">
              Brak ustawionych alertów
            </h4>
            <p className="text-sm text-zinc-500 mb-4">
              Dodaj alert, aby otrzymywać powiadomienia o okazjach cenowych
            </p>
            <Button 
              onClick={() => setShowForm(true)}
              variant="outline"
              className="border-zinc-700 text-zinc-400"
            >
              <Plus className="h-4 w-4 mr-2" />
              Dodaj pierwszy alert
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Notification info */}
      <div className="flex items-start gap-3 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
        <AlertCircle className="h-5 w-5 text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-blue-300">
          <p className="font-medium mb-1">Powiadomienia</p>
          <p>Alerty będą wysyłane na Twój email oraz wyświetlane w panelu powiadomień aplikacji.</p>
        </div>
      </div>
    </div>
  );
};

export default PriceAlerts;
