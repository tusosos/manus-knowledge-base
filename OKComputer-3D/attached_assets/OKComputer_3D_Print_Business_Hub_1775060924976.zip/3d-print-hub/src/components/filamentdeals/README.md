# Filament Deals Module - 3D Print Business Hub

Moduł do śledzenia cen filamentów 3D, promocji i alertów cenowych.

## Funkcjonalności

### 1. Tabela Cen Referencyjnych (`ReferencePricesTable`)
- Wyświetla aktualne ceny dla materiałów: PLA, PETG, ABS, TPU, PA, PC
- Pokazuje trendy cenowe (rosnący/spadający/stabilny)
- Data ostatniej aktualizacji

### 2. Linki do Sklepów (`ShopLinks`)
- Polskie sklepy: Allegro, 3DJake, Botland, Rosa3D, Fiberlogy, Devil Design
- Chińskie platformy: AliExpress, Banggood, Temu, Shein

### 3. Sekcja Promocji (`PromotionsSection`)
- Aktualne okazje z podziałem na "Gorące" i standardowe
- Szczegóły: sklep, materiał, cena, oszczędność, data końca
- Bezpośrednie linki do ofert

### 4. Alerty Cenowe (`PriceAlerts`)
- Ustawianie alertów: "Kup gdy [materiał] [poniżej/powyżej] [cena]"
- Lista aktywnych i nieaktywnych alertów
- Zarządzanie alertami (włącz/wyłącz/usuń)

### 5. Historia Cen (`PriceHistory`)
- Wykres zmian cen (30/90/365 dni)
- Statystyki: min, max, średnia
- Rekomendacja najlepszego czasu na zakup

## Użycie

```tsx
import { FilamentDeals } from '@/components/filamentdeals';

function App() {
  return <FilamentDeals />;
}
```

## Komponenty indywidualne

```tsx
import { 
  ReferencePricesTable, 
  ShopLinks, 
  PromotionsSection,
  PriceAlerts,
  PriceHistory 
} from '@/components/filamentdeals';

// Użycie pojedynczych komponentów
<ReferencePricesTable prices={referencePrices} />
<ShopLinks polishShops={polishShops} chineseShops={chineseShops} />
<PromotionsSection promotions={promotions} />
<PriceAlerts 
  alerts={alerts} 
  onAddAlert={handleAddAlert}
  onDeleteAlert={handleDeleteAlert}
  onToggleAlert={handleToggleAlert}
/>
<PriceHistory priceHistory={priceHistory} />
```

## Typy

```tsx
import type { 
  ReferencePrice, 
  Shop, 
  Promotion, 
  PriceAlert,
  MaterialPriceHistory 
} from '@/components/filamentdeals';
```

## Zależności

- shadcn/ui: Table, Card, Badge, Button, Input, Tabs, Select
- Recharts: LineChart, Area, Line, XAxis, YAxis, Tooltip
- Lucide React: ikony

## Styl

- Dark theme (domyślny)
- Industrial aesthetic (czarny, szary, amber akcenty)
- Responsive design
- Mobile-first approach
