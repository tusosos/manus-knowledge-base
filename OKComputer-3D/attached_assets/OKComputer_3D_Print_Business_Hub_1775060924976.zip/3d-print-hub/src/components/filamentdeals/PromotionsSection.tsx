import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ExternalLink, 
  Flame, 
  Clock, 
  TrendingDown, 
  ShoppingBag,
  Percent,
  AlertCircle
} from 'lucide-react';
import type { Promotion, MaterialType } from './types';

interface PromotionsSectionProps {
  promotions: Promotion[];
}

const materialColors: Record<MaterialType, string> = {
  PLA: 'bg-green-500/20 text-green-400 border-green-500/30',
  PETG: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  ABS: 'bg-red-500/20 text-red-400 border-red-500/30',
  TPU: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  PA: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  PC: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
};

const PromotionCard: React.FC<{ promotion: Promotion }> = ({ promotion }) => {
  const daysLeft = Math.ceil(
    (new Date(promotion.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
  );
  
  const isEndingSoon = daysLeft <= 3;
  const isHot = promotion.isHot || promotion.savingsPercent > 30;

  return (
    <Card className="bg-zinc-950/50 border-zinc-800 hover:border-zinc-700 transition-all duration-300 group overflow-hidden">
      {/* Hot deal indicator */}
      {isHot && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500" />
      )}
      
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge 
                variant="outline" 
                className={`font-semibold text-xs ${materialColors[promotion.material]}`}
              >
                {promotion.material}
              </Badge>
              {promotion.color && (
                <span className="text-xs text-zinc-500">{promotion.color}</span>
              )}
            </div>
            <h4 className="font-semibold text-zinc-100 group-hover:text-amber-400 transition-colors">
              {promotion.shopName}
            </h4>
          </div>
          {isHot && (
            <div className="flex items-center gap-1 text-orange-400">
              <Flame className="h-4 w-4" />
              <span className="text-xs font-medium">HOT</span>
            </div>
          )}
        </div>

        {/* Price section */}
        <div className="space-y-2 mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-zinc-100">
              {promotion.promotionalPrice.toFixed(2)}
            </span>
            <span className="text-sm text-zinc-500">zł/kg</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-zinc-500 line-through">
              {promotion.regularPrice.toFixed(2)} zł
            </span>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
              <TrendingDown className="h-3 w-3 mr-1" />
              -{promotion.savingsPercent.toFixed(0)}%
            </Badge>
          </div>
          <div className="text-sm text-green-400 font-medium">
            Oszczędzasz {promotion.savings.toFixed(2)} zł
          </div>
        </div>

        {/* Time remaining */}
        <div className={`
          flex items-center gap-2 text-xs mb-4 p-2 rounded-lg
          ${isEndingSoon ? 'bg-red-500/10 text-red-400' : 'bg-zinc-900 text-zinc-500'}
        `}>
          <Clock className="h-3.5 w-3.5" />
          <span>
            {isEndingSoon 
              ? `Kończy się za ${daysLeft} dni!` 
              : `Do końca: ${daysLeft} dni`
            }
          </span>
        </div>

        {/* CTA Button */}
        <a 
          href={promotion.link} 
          target="_blank" 
          rel="noopener noreferrer"
          className="block"
        >
          <Button 
            className="w-full bg-amber-500 hover:bg-amber-600 text-black font-semibold"
            size="sm"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Zobacz ofertę
          </Button>
        </a>
      </CardContent>
    </Card>
  );
};

export const PromotionsSection: React.FC<PromotionsSectionProps> = ({ promotions }) => {
  const hotDeals = promotions.filter(p => p.isHot || p.savingsPercent > 30);
  const regularDeals = promotions.filter(p => !p.isHot && p.savingsPercent <= 30);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-zinc-100 flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-amber-500" />
            Aktualne Promocje
          </h3>
          <p className="text-sm text-zinc-500 mt-1">
            Znalezione okazje na filamenty - aktualizowane codziennie
          </p>
        </div>
        <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/30">
          <Percent className="h-3.5 w-3.5 mr-1" />
          {promotions.length} ofert
        </Badge>
      </div>

      {/* Hot Deals Section */}
      {hotDeals.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-orange-500" />
            <h4 className="text-sm font-medium text-orange-400">Gorące Okazje</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {hotDeals.map((promo) => (
              <PromotionCard key={promo.id} promotion={promo} />
            ))}
          </div>
        </div>
      )}

      {/* Regular Deals Section */}
      {regularDeals.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Percent className="h-4 w-4 text-zinc-500" />
            <h4 className="text-sm font-medium text-zinc-400">Pozostałe Oferty</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {regularDeals.map((promo) => (
              <PromotionCard key={promo.id} promotion={promo} />
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {promotions.length === 0 && (
        <Card className="bg-zinc-950/50 border-zinc-800">
          <CardContent className="p-8 text-center">
            <AlertCircle className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-zinc-400 mb-2">
              Brak aktywnych promocji
            </h4>
            <p className="text-sm text-zinc-500">
              Sprawdź ponownie później - nowe oferty pojawiają się regularnie
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PromotionsSection;
