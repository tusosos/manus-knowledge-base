'use client';

import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, DollarSign, Package, Percent, ShoppingCart } from 'lucide-react';
import { kpiData } from './data';

interface KPICardProps {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
  prefix?: string;
  suffix?: string;
}

function KPICard({ title, value, change, icon, prefix = '', suffix = '' }: KPICardProps) {
  const isPositive = change >= 0;

  return (
    <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-sm hover:border-amber-500/30 transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-slate-400 text-sm font-medium mb-1">{title}</p>
            <p className="text-2xl font-bold text-slate-100">
              {prefix}{value}{suffix}
            </p>
            <div className="flex items-center gap-1 mt-2">
              {isPositive ? (
                <TrendingUp className="w-4 h-4 text-emerald-500" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-500" />
              )}
              <span className={`text-sm font-medium ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                {isPositive ? '+' : ''}{change}%
              </span>
              <span className="text-slate-500 text-sm">vs poprzedni okres</span>
            </div>
          </div>
          <div className="p-3 bg-amber-500/10 rounded-xl">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function KPICards() {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pl-PL', {
      style: 'currency',
      currency: 'PLN',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <KPICard
        title="Całkowity Przychód"
        value={formatCurrency(kpiData.totalRevenue).replace('zł', '').trim()}
        change={kpiData.revenueChange}
        icon={<DollarSign className="w-6 h-6 text-amber-500" />}
        suffix=" zł"
      />
      <KPICard
        title="Całkowity Zysk"
        value={formatCurrency(kpiData.totalProfit).replace('zł', '').trim()}
        change={kpiData.profitChange}
        icon={<TrendingUp className="w-6 h-6 text-emerald-500" />}
        suffix=" zł"
      />
      <KPICard
        title="Średnia Marża"
        value={kpiData.avgMargin.toString()}
        change={kpiData.marginChange}
        icon={<Percent className="w-6 h-6 text-blue-500" />}
        suffix="%"
      />
      <KPICard
        title="Liczba Zamówień"
        value={kpiData.totalOrders.toLocaleString('pl-PL')}
        change={kpiData.ordersChange}
        icon={<ShoppingCart className="w-6 h-6 text-purple-500" />}
      />
    </div>
  );
}
