'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import { channelData } from './data';
import { useState } from 'react';
import { PieChart as PieChartIcon, BarChart3, ShoppingBag } from 'lucide-react';

export function ChannelComparison() {
  const [viewMode, setViewMode] = useState<'pie' | 'bar'>('pie');

  const totalOrders = channelData.reduce((acc, item) => acc + item.orders, 0);

  return (
    <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-100 text-lg font-semibold flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-500" />
            Porównanie Kanałów
          </CardTitle>
          <div className="flex gap-1 bg-slate-800/50 rounded-lg p-1">
            <button
              onClick={() => setViewMode('pie')}
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'pie'
                  ? 'bg-amber-500/20 text-amber-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <PieChartIcon className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('bar')}
              className={`p-1.5 rounded-md transition-colors ${
                viewMode === 'bar'
                  ? 'bg-amber-500/20 text-amber-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Wykres */}
        <div className="h-[220px]">
          <ResponsiveContainer width="100%" height="100%">
            {viewMode === 'pie' ? (
              <PieChart>
                <Pie
                  data={channelData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {channelData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                  }}
                  formatter={(value: number, name: string) => [`${value}%`, name]}
                />
              </PieChart>
            ) : (
              <BarChart data={channelData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis
                  dataKey="name"
                  stroke="#64748b"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#64748b"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                  }}
                  formatter={(value: number) => [`${value}%`, 'Udział']}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={50}>
                  {channelData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Legenda z detalami */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          {channelData.map((channel) => (
            <div
              key={channel.name}
              className="flex items-center gap-2 p-2 bg-slate-800/30 rounded-lg"
            >
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: channel.color }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-slate-200 text-sm font-medium truncate">{channel.name}</p>
                <div className="flex items-center gap-2">
                  <span className="text-amber-400 text-xs font-bold">{channel.value}%</span>
                  <span className="text-slate-500 text-xs">
                    {channel.orders} zam.
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Podsumowanie */}
        <div className="mt-4 pt-4 border-t border-slate-700/30">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-sm">Łącznie zamówień</span>
            <span className="text-slate-100 text-lg font-bold">{totalOrders.toLocaleString('pl-PL')}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
