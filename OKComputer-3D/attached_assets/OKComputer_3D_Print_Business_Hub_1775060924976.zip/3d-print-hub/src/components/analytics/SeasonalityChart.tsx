'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Line,
  ComposedChart,
} from 'recharts';
import { seasonalityData } from './data';
import { Calendar, TrendingUp, Gift, Heart, GraduationCap } from 'lucide-react';

const eventIcons: Record<string, React.ReactNode> = {
  'Walentynki': <Heart className="w-4 h-4 text-pink-500" />,
  'Wielkanoc': <Gift className="w-4 h-4 text-purple-500" />,
  'Dzień Matki': <Heart className="w-4 h-4 text-rose-500" />,
  'Dzień Ojca': <Gift className="w-4 h-4 text-blue-500" />,
  'Koniec roku szkolnego': <GraduationCap className="w-4 h-4 text-emerald-500" />,
  'Wakacje': <Calendar className="w-4 h-4 text-yellow-500" />,
  'Back-to-School': <GraduationCap className="w-4 h-4 text-indigo-500" />,
  'Początek roku szkolnego': <GraduationCap className="w-4 h-4 text-cyan-500" />,
  'Halloween': <Gift className="w-4 h-4 text-orange-500" />,
  'Black Friday': <TrendingUp className="w-4 h-4 text-red-500" />,
  'Mikołajki': <Gift className="w-4 h-4 text-green-500" />,
  'Boże Narodzenie': <Gift className="w-4 h-4 text-red-600" />,
  'Wyprzedaż': <TrendingUp className="w-4 h-4 text-amber-500" />,
};

export function SeasonalityChart() {
  const getHeatColor = (value: number) => {
    if (value >= 180) return 'bg-emerald-500';
    if (value >= 140) return 'bg-emerald-400';
    if (value >= 110) return 'bg-emerald-300';
    if (value >= 90) return 'bg-yellow-400';
    if (value >= 70) return 'bg-orange-400';
    return 'bg-red-400';
  };

  const getHeatOpacity = (value: number) => {
    if (value >= 180) return 'opacity-100';
    if (value >= 140) return 'opacity-90';
    if (value >= 110) return 'opacity-80';
    if (value >= 90) return 'opacity-70';
    if (value >= 70) return 'opacity-60';
    return 'opacity-50';
  };

  return (
    <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-slate-100 text-lg font-semibold flex items-center gap-2">
          <Calendar className="w-5 h-5 text-emerald-500" />
          Sezonowość Sprzedaży
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Heatmap */}
        <div className="mb-6">
          <p className="text-slate-400 text-xs mb-3">Heatmapa intensywności sprzedaży</p>
          <div className="grid grid-cols-6 sm:grid-cols-12 gap-1">
            {seasonalityData.map((item, index) => (
              <div
                key={item.month}
                className="flex flex-col items-center"
              >
                <div
                  className={`w-full aspect-square rounded-lg ${getHeatColor(item.sales)} ${getHeatOpacity(
                    item.sales
                  )} flex items-center justify-center cursor-pointer hover:scale-110 transition-transform`}
                  title={`${item.month}: ${item.sales}% sprzedaży`}
                >
                  <span className="text-xs font-bold text-slate-900">{item.sales}</span>
                </div>
                <span className="text-xs text-slate-500 mt-1">{item.month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between mt-3 text-xs text-slate-500">
            <span>Niska sprzedaż</span>
            <div className="flex gap-1">
              <div className="w-4 h-4 bg-red-400 rounded"></div>
              <div className="w-4 h-4 bg-orange-400 rounded"></div>
              <div className="w-4 h-4 bg-yellow-400 rounded"></div>
              <div className="w-4 h-4 bg-emerald-300 rounded"></div>
              <div className="w-4 h-4 bg-emerald-400 rounded"></div>
              <div className="w-4 h-4 bg-emerald-500 rounded"></div>
            </div>
            <span>Wysoka sprzedaż</span>
          </div>
        </div>

        {/* Wydarzenia sezonowe */}
        <div className="mb-6">
          <p className="text-slate-400 text-xs mb-3">Kluczowe wydarzenia</p>
          <div className="flex flex-wrap gap-2">
            {seasonalityData
              .filter((item) => item.events.length > 0)
              .map((item) =>
                item.events.map((event) => (
                  <div
                    key={`${item.month}-${event}`}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/50 rounded-full border border-slate-700/50"
                  >
                    {eventIcons[event] || <Calendar className="w-4 h-4 text-slate-400" />}
                    <span className="text-xs text-slate-300">{event}</span>
                    <span className="text-xs text-slate-500">({item.month})</span>
                  </div>
                ))
              )}
          </div>
        </div>

        {/* Prognoza */}
        <div className="pt-4 border-t border-slate-700/30">
          <p className="text-slate-400 text-xs mb-3">Sprzedaż rzeczywista vs Prognoza</p>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={seasonalityData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                <XAxis
                  dataKey="month"
                  stroke="#64748b"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="#64748b"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                  }}
                />
                <Bar
                  dataKey="sales"
                  name="Sprzedaż"
                  fill="#f59e0b"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={20}
                />
                <Line
                  type="monotone"
                  dataKey="forecast"
                  name="Prognoza"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
