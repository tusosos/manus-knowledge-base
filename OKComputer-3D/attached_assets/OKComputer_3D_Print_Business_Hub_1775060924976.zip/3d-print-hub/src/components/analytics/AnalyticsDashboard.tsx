'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { KPICards } from './KPICards';
import { RevenueChart } from './RevenueChart';
import { CostRevenueChart } from './CostRevenueChart';
import { MarginChart } from './MarginChart';
import { TrendChart } from './TrendChart';
import { TopProducts } from './TopProducts';
import { SeasonalityChart } from './SeasonalityChart';
import { ChannelComparison } from './ChannelComparison';
import { AnalyticsFilters } from './AnalyticsFilters';
import { DateRange, ChannelFilter } from './data';
import {
  BarChart3,
  TrendingUp,
  Package,
  Calendar,
  ShoppingBag,
  LayoutDashboard,
} from 'lucide-react';

export function AnalyticsDashboard() {
  const [dateRange, setDateRange] = useState<DateRange>('year');
  const [channel, setChannel] = useState<ChannelFilter>('all');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800/50 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-500/10 rounded-xl">
                <LayoutDashboard className="w-6 h-6 text-amber-500" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-100">
                  Analityka Sprzedaży
                </h1>
                <p className="text-sm text-slate-400">
                  3D Print Business Hub - Dashboard
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">
                Ostatnia aktualizacja: {new Date().toLocaleDateString('pl-PL')}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Filtry */}
        <AnalyticsFilters
          dateRange={dateRange}
          channel={channel}
          onDateRangeChange={setDateRange}
          onChannelChange={setChannel}
        />

        {/* KPI Cards */}
        <div className="mt-6">
          <KPICards />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="mt-6">
          <TabsList className="bg-slate-900/80 border border-slate-700/50 p-1 flex flex-wrap gap-1">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-500 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden sm:inline">Przegląd</span>
            </TabsTrigger>
            <TabsTrigger
              value="revenue"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-500 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Przychody</span>
            </TabsTrigger>
            <TabsTrigger
              value="products"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-500 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Package className="w-4 h-4" />
              <span className="hidden sm:inline">Produkty</span>
            </TabsTrigger>
            <TabsTrigger
              value="seasonality"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-500 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">Sezonowość</span>
            </TabsTrigger>
            <TabsTrigger
              value="channels"
              className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-500 text-slate-400 hover:text-slate-200 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Kanały</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RevenueChart />
              <TrendChart />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <TopProducts />
              </div>
              <ChannelComparison />
            </div>
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RevenueChart />
              <CostRevenueChart />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <MarginChart />
              <TrendChart />
            </div>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="mt-6">
            <div className="max-w-4xl mx-auto">
              <TopProducts />
            </div>
          </TabsContent>

          {/* Seasonality Tab */}
          <TabsContent value="seasonality" className="mt-6">
            <div className="max-w-4xl mx-auto">
              <SeasonalityChart />
            </div>
          </TabsContent>

          {/* Channels Tab */}
          <TabsContent value="channels" className="mt-6">
            <div className="max-w-2xl mx-auto">
              <ChannelComparison />
            </div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-slate-800/50">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-500">
            <p>3D Print Business Hub © 2024</p>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                System aktywny
              </span>
              <span>Wersja 1.0.0</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
