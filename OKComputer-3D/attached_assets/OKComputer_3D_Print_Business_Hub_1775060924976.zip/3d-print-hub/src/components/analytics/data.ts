// Dane mockowe dla analityki 3D Print Business Hub

export interface RevenueData {
  month: string;
  revenue: number;
  costs: number;
  margin: number;
}

export interface ProductData {
  id: string;
  name: string;
  quantity: number;
  revenue: number;
  margin: number;
  marginPercent: number;
}

export interface SeasonalityData {
  month: string;
  sales: number;
  events: string[];
  forecast: number;
}

export interface ChannelData {
  name: string;
  value: number;
  color: string;
  orders: number;
}

export const revenueData: RevenueData[] = [
  { month: 'Sty', revenue: 12500, costs: 7500, margin: 40 },
  { month: 'Lut', revenue: 14200, costs: 8200, margin: 42.3 },
  { month: 'Mar', revenue: 16800, costs: 9500, margin: 43.5 },
  { month: 'Kwi', revenue: 15400, costs: 8800, margin: 42.9 },
  { month: 'Maj', revenue: 18900, costs: 10200, margin: 46 },
  { month: 'Cze', revenue: 22100, costs: 11800, margin: 46.6 },
  { month: 'Lip', revenue: 19800, costs: 10800, margin: 45.5 },
  { month: 'Sie', revenue: 24500, costs: 13200, margin: 46.1 },
  { month: 'Wrz', revenue: 28900, costs: 15200, margin: 47.4 },
  { month: 'Paź', revenue: 31200, costs: 16500, margin: 47.1 },
  { month: 'Lis', revenue: 35800, costs: 18900, margin: 47.2 },
  { month: 'Gru', revenue: 42500, costs: 22100, margin: 48 },
];

export const topProducts: ProductData[] = [
  { id: '1', name: 'Wsporniki półek (komplet)', quantity: 847, revenue: 42350, margin: 28950, marginPercent: 68.4 },
  { id: '2', name: 'Organizer na biurko', quantity: 623, revenue: 31150, margin: 20550, marginPercent: 66 },
  { id: '3', name: 'Uchwyty na słuchawki', quantity: 589, revenue: 17670, margin: 12350, marginPercent: 69.9 },
  { id: '4', name: 'Stojak na telefon', quantity: 534, revenue: 16020, margin: 11200, marginPercent: 69.9 },
  { id: '5', name: 'Klipsy do kabli (20szt)', quantity: 498, revenue: 9960, margin: 6970, marginPercent: 70 },
];

export const seasonalityData: SeasonalityData[] = [
  { month: 'Sty', sales: 65, events: ['Wyprzedaż'], forecast: 68 },
  { month: 'Lut', sales: 72, events: ['Walentynki'], forecast: 75 },
  { month: 'Mar', sales: 85, events: [], forecast: 82 },
  { month: 'Kwi', sales: 78, events: ['Wielkanoc'], forecast: 80 },
  { month: 'Maj', sales: 95, events: ['Dzień Matki'], forecast: 92 },
  { month: 'Cze', sales: 110, events: ['Dzień Ojca', 'Koniec roku szkolnego'], forecast: 105 },
  { month: 'Lip', sales: 98, events: ['Wakacje'], forecast: 95 },
  { month: 'Sie', sales: 120, events: ['Back-to-School'], forecast: 115 },
  { month: 'Wrz', sales: 145, events: ['Początek roku szkolnego'], forecast: 138 },
  { month: 'Paź', sales: 155, events: ['Halloween'], forecast: 150 },
  { month: 'Lis', sales: 178, events: ['Black Friday'], forecast: 172 },
  { month: 'Gru', sales: 210, events: ['Boże Narodzenie', 'Mikołajki'], forecast: 195 },
];

export const channelData: ChannelData[] = [
  { name: 'Allegro', value: 45, color: '#f59e0b', orders: 1247 },
  { name: 'Etsy', value: 28, color: '#10b981', orders: 756 },
  { name: 'OLX', value: 15, color: '#3b82f6', orders: 423 },
  { name: 'Inne', value: 12, color: '#8b5cf6', orders: 312 },
];

export const trendData = [
  { month: 'Sty', sales: 12500, target: 12000 },
  { month: 'Lut', sales: 14200, target: 13000 },
  { month: 'Mar', sales: 16800, target: 14500 },
  { month: 'Kwi', sales: 15400, target: 15000 },
  { month: 'Maj', sales: 18900, target: 16500 },
  { month: 'Cze', sales: 22100, target: 18000 },
  { month: 'Lip', sales: 19800, target: 19000 },
  { month: 'Sie', sales: 24500, target: 20000 },
  { month: 'Wrz', sales: 28900, target: 22000 },
  { month: 'Paź', sales: 31200, target: 24000 },
  { month: 'Lis', sales: 35800, target: 26000 },
  { month: 'Gru', sales: 42500, target: 30000 },
];

export const kpiData = {
  totalRevenue: 282600,
  totalProfit: 132450,
  avgMargin: 45.8,
  totalOrders: 2738,
  revenueChange: 23.5,
  profitChange: 28.2,
  marginChange: 2.1,
  ordersChange: 18.7,
};

export type DateRange = 'month' | 'quarter' | 'year';
export type ChannelFilter = 'all' | 'allegro' | 'etsy' | 'olx';
