// Moduł Analityki Sprzedaży - 3D Print Business Hub

export { AnalyticsDashboard } from './AnalyticsDashboard';
export { KPICards } from './KPICards';
export { RevenueChart } from './RevenueChart';
export { CostRevenueChart } from './CostRevenueChart';
export { MarginChart } from './MarginChart';
export { TrendChart } from './TrendChart';
export { TopProducts } from './TopProducts';
export { SeasonalityChart } from './SeasonalityChart';
export { ChannelComparison } from './ChannelComparison';
export { AnalyticsFilters } from './AnalyticsFilters';

// Dane i typy
export {
  revenueData,
  topProducts,
  seasonalityData,
  channelData,
  trendData,
  kpiData,
} from './data';

export type {
  RevenueData,
  ProductData,
  SeasonalityData,
  ChannelData,
  DateRange,
  ChannelFilter,
} from './data';
