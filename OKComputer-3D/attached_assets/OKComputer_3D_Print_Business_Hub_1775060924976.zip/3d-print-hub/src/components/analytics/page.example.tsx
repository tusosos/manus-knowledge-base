// Przykład użycia AnalyticsDashboard w aplikacji Next.js
// Umieść ten plik w app/analytics/page.tsx

import { AnalyticsDashboard } from '@/components/analytics';

export default function AnalyticsPage() {
  return <AnalyticsDashboard />;
}
