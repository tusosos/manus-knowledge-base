'use client';

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar, Filter, BarChart3 } from 'lucide-react';
import { DateRange, ChannelFilter } from './data';

interface AnalyticsFiltersProps {
  dateRange: DateRange;
  channel: ChannelFilter;
  onDateRangeChange: (value: DateRange) => void;
  onChannelChange: (value: ChannelFilter) => void;
}

export function AnalyticsFilters({
  dateRange,
  channel,
  onDateRangeChange,
  onChannelChange,
}: AnalyticsFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-3 p-4 bg-slate-900/80 border border-slate-700/50 rounded-xl backdrop-blur-sm">
      <div className="flex items-center gap-2 text-slate-400">
        <Filter className="w-4 h-4" />
        <span className="text-sm font-medium">Filtry:</span>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 flex-1">
        {/* Filtr zakresu dat */}
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-slate-500" />
          <Select value={dateRange} onValueChange={(v) => onDateRangeChange(v as DateRange)}>
            <SelectTrigger className="w-[160px] bg-slate-800/50 border-slate-700 text-slate-200 focus:ring-amber-500/20">
              <SelectValue placeholder="Wybierz okres" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              <SelectItem value="month" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Ostatni miesiąc
              </SelectItem>
              <SelectItem value="quarter" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Ostatnie 3 miesiące
              </SelectItem>
              <SelectItem value="year" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Ostatni rok
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Filtr kanału */}
        <div className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-slate-500" />
          <Select value={channel} onValueChange={(v) => onChannelChange(v as ChannelFilter)}>
            <SelectTrigger className="w-[160px] bg-slate-800/50 border-slate-700 text-slate-200 focus:ring-amber-500/20">
              <SelectValue placeholder="Wybierz kanał" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              <SelectItem value="all" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Wszystkie kanały
              </SelectItem>
              <SelectItem value="allegro" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Allegro
              </SelectItem>
              <SelectItem value="etsy" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                Etsy
              </SelectItem>
              <SelectItem value="olx" className="text-slate-200 focus:bg-slate-700 focus:text-slate-100">
                OLX
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Aktywne filtry */}
      <div className="flex items-center gap-2">
        {(dateRange !== 'year' || channel !== 'all') && (
          <span className="text-xs text-amber-500 font-medium">
            Aktywne filtry
          </span>
        )}
      </div>
    </div>
  );
}
