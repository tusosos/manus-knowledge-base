'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { topProducts } from './data';
import { TrendingUp, Package } from 'lucide-react';

export function TopProducts() {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pl-PL', {
      style: 'currency',
      currency: 'PLN',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const maxRevenue = Math.max(...topProducts.map((p) => p.revenue));

  return (
    <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-slate-100 text-lg font-semibold flex items-center gap-2">
          <Package className="w-5 h-5 text-amber-500" />
          Top 5 Produktów
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Tabela produktów */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-3 px-2 text-slate-400 text-sm font-medium">Produkt</th>
                <th className="text-center py-3 px-2 text-slate-400 text-sm font-medium">Ilość</th>
                <th className="text-right py-3 px-2 text-slate-400 text-sm font-medium">Przychód</th>
                <th className="text-right py-3 px-2 text-slate-400 text-sm font-medium">Marża</th>
              </tr>
            </thead>
            <tbody>
              {topProducts.map((product, index) => (
                <tr
                  key={product.id}
                  className="border-b border-slate-700/30 hover:bg-slate-800/50 transition-colors"
                >
                  <td className="py-3 px-2">
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          index === 0
                            ? 'bg-amber-500/20 text-amber-500'
                            : index === 1
                            ? 'bg-slate-500/20 text-slate-400'
                            : index === 2
                            ? 'bg-orange-500/20 text-orange-500'
                            : 'bg-slate-700/30 text-slate-500'
                        }`}
                      >
                        {index + 1}
                      </span>
                      <span className="text-slate-200 text-sm font-medium">{product.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className="text-slate-300 text-sm">{product.quantity}</span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    <span className="text-emerald-400 text-sm font-medium">
                      {formatCurrency(product.revenue)}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <span className="text-amber-400 text-sm font-medium">
                        {product.marginPercent}%
                      </span>
                      <TrendingUp className="w-4 h-4 text-emerald-500" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mini wykres słupkowy */}
        <div className="mt-6 pt-4 border-t border-slate-700/30">
          <p className="text-slate-400 text-xs mb-3">Porównanie przychodów</p>
          <div className="h-[100px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={topProducts}
                layout="vertical"
                margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
              >
                <XAxis type="number" hide domain={[0, maxRevenue]} />
                <YAxis type="category" dataKey="name" hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                  }}
                  formatter={(value: number) => [formatCurrency(value), 'Przychód']}
                  labelFormatter={(label) => label}
                />
                <Bar dataKey="revenue" radius={[0, 4, 4, 0]} maxBarSize={20}>
                  {topProducts.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        index === 0
                          ? '#f59e0b'
                          : index === 1
                          ? '#d97706'
                          : index === 2
                          ? '#b45309'
                          : '#78350f'
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
