"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Check,
  Printer,
  Home,
  ShoppingCart,
  Sliders,
  FlaskConical,
  FileText,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Award,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface ChecklistItem {
  id: string;
  text: string;
  description?: string;
  checked: boolean;
}

interface ChecklistSection {
  id: string;
  title: string;
  icon: React.ReactNode;
  color: string;
  items: ChecklistItem[];
}

const initialChecklist: ChecklistSection[] = [
  {
    id: "printer",
    title: "Wybór i zakup drukarki",
    icon: <Printer className="w-5 h-5" />,
    color: "text-amber-500",
    items: [
      { id: "p1", text: "Zdefiniuj budżet na drukarkę (5000-20000 PLN)", description: "Dla biznesu zalecamy minimum 8000 PLN", checked: false },
      { id: "p2", text: "Porównaj modele: Bambu Lab H2D, P1S, X1 Carbon", description: "H2D - najnowsza, P1S - najlepsza cena/wydajność, X1 - premium", checked: false },
      { id: "p3", text: "Sprawdź dostępność w Polsce i gwarancję", description: "Autoryzowani dystrybutorzy: 3D Phoenix, 3D Kreator", checked: false },
      { id: "p4", text: "Zamów drukarkę z zestawem startowym filamentów", description: "Zestaw startowy zazwyczaj zawiera 4-5 szpuli", checked: false },
      { id: "p5", text: "Przygotuj miejsce na dostawę (duże pudło)", description: "Wymiary opakowania H2D: 60x50x50cm, waga ~20kg", checked: false },
    ],
  },
  {
    id: "workspace",
    title: "Przygotowanie stanowiska",
    icon: <Home className="w-5 h-5" />,
    color: "text-blue-500",
    items: [
      { id: "w1", text: "Zapewnij stabilną, wypoziomowaną powierzchnię", description: "Stół warsztatowy lub dedykowany stelaż, max przechył 2°", checked: false },
      { id: "w2", text: "Zainstaluj wentylację lub pracuj w przewiewnym pomieszczeniu", description: "Szczególnie ważne dla ABS/ASA - toksyczne opary", checked: false },
      { id: "w3", text: "Utrzymuj temperaturę 18-25°C w pomieszczeniu", description: "Wysokie temperatury mogą powodować problemy z chłodzeniem", checked: false },
      { id: "w4", text: "Zapewnij odpowiednią wilgotność (40-60%)", description: "Za niska wilgotność = elektrostatyka, za wysoka = wilgotny filament", checked: false },
      { id: "w5", text: "Przygotuj miejsce na przechowywanie filamentów", description: "Szafki z uszczelkami, pojemniki z silikagem", checked: false },
      { id: "w6", text: "Zorganizuj oświetlenie stanowiska", description: "Lampy LED 4000-6000K do kontroli jakości wydruków", checked: false },
    ],
  },
  {
    id: "materials",
    title: "Zakup materiałów",
    icon: <ShoppingCart className="w-5 h-5" />,
    color: "text-purple-500",
    items: [
      { id: "m1", text: "Kup filament PLA (5-10 szpuli)", description: "Startowy zestaw: biały, czarny, szary, dowolny kolor", checked: false },
      { id: "m2", text: "Kup filament PETG (3-5 szpuli)", description: "Do funkcjonalnych części: naturalny, czarny, biały", checked: false },
      { id: "m3", text: "Kup filament ABS/ASA (2-3 szpuli)", description: "Tylko jeśli masz zamkniętą komorę i wentylację", checked: false },
      { id: "m4", text: "Zamów zapasowe dysze (0.4mm, 0.6mm)", description: "Hardened steel dla ściernych materiałów", checked: false },
      { id: "m5", text: "Kup klej do stołu (opcjonalnie)", description: "Glue stick, Magigoo, lub 3DLac dla problematycznych materiałów", checked: false },
      { id: "m6", text: "Przygotuj narzędzia post-processingu", description: "Szpatułki, obcinaczki, papier ścierny 200-800", checked: false },
    ],
  },
  {
    id: "calibration",
    title: "Kalibracja drukarki",
    icon: <Sliders className="w-5 h-5" />,
    color: "text-cyan-500",
    items: [
      { id: "c1", text: "Wykonaj pierwsze uruchomienie i setup", description: "Postępuj zgodnie z instrukcją na ekranie drukarki", checked: false },
      { id: "c2", text: "Zaktualizuj firmware do najnowszej wersji", description: "Bambu Studio > Device > Update Firmware", checked: false },
      { id: "c3", text: "Wykonaj auto-leveling stołu", description: "Bambu Studio > Calibration > Bed Leveling", checked: false },
      { id: "c4", text: "Skalibruj flow rate dla PLA", description: "Wydrukuj test flow i dostosuj w ustawieniach filamentu", checked: false },
      { id: "c5", text: "Skalibruj Pressure Advance (K-factor)", description: "Bambu Studio > Calibration > Pressure Advance", checked: false },
      { id: "c6", text: "Przeprowadź kalibrację temperatury", description: "Temperature tower dla każdego nowego filamentu", checked: false },
      { id: "c7", text: "Zapisz profile filamentów w Bambu Studio", description: "Utwórz osobne profile dla każdego producenta/koloru", checked: false },
    ],
  },
  {
    id: "testing",
    title: "Testowe wydruki",
    icon: <FlaskConical className="w-5 h-5" />,
    color: "text-green-500",
    items: [
      { id: "t1", text: "Wydrukuj 3DBenchy (test ogólny)", description: "Klasyczny test druku 3D - sprawdza wiele aspektów", checked: false },
      { id: "t2", text: "Wydrukuj test tolerancji", description: "Sprawdź dokładność wymiarową drukarki", checked: false },
      { id: "t3", text: "Wydrukuj test wytrzymałościowy", description: "Sprawdź jakość warstw i przyczepność", checked: false },
      { id: "t4", text: "Przetestuj różne prędkości druku", description: "Znajdź optymalną prędkość dla jakości vs czas", checked: false },
      { id: "t5", text: "Przetestuj różne ustawienia wykończenia", description: "Ironing, supporty, orientacja na stole", checked: false },
      { id: "t6", text: "Udokumentuj wyniki testów", description: "Zdjęcia, notatki, ustawienia - przydatne przy problemach", checked: false },
    ],
  },
  {
    id: "legal",
    title: "Formalności prawne",
    icon: <FileText className="w-5 h-5" />,
    color: "text-red-500",
    items: [
      { id: "l1", text: "Wybierz formę prawną (JDG vs Sp. z o.o.)", description: "JDG - prostsza, Sp. z o.o. - bezpieczniejsza", checked: false },
      { id: "l2", text: "Zarejestruj działalność w CEIDG/KRS", description: "Online przez biznes.gov.pl lub u notariusza", checked: false },
      { id: "l3", text: "Wybierz formę opodatkowania", description: "Skala, liniowy 19%, ryczałt - zależy od przychodów", checked: false },
      { id: "l4", text: "Zarejestruj się w VAT (opcjonalnie)", description: "Obowiązkowy powyżej 200k PLN, poniżej - zwolnienie", checked: false },
      { id: "l5", text: "Zgłoś się do ZUS", description: "Mały ZUS plus dla nowych firm - preferencyjne składki", checked: false },
      { id: "l6", text: "Wykup ubezpieczenie OC działalności", description: "Chroni przed roszczeniami klientów", checked: false },
      { id: "l7", text: "Przygotuj regulamin sklepu", description: "Wymagany dla sprzedaży online - prawa konsumenta", checked: false },
    ],
  },
  {
    id: "business",
    title: "Start biznesu",
    icon: <TrendingUp className="w-5 h-5" />,
    color: "text-emerald-500",
    items: [
      { id: "b1", text: "Stwórz portfolio wydruków", description: "Zdjęcia, opisy, ceny - minimum 10 produktów", checked: false },
      { id: "b2", text: "Załóż konto na platformach sprzedaży", description: "Allegro, Etsy, OLX, własna strona", checked: false },
      { id: "b3", text: "Ustal cennik usług", description: "Koszt filamentu + czas druku + marża + VAT", checked: false },
      { id: "b4", text: "Przygotuj proces wycen", description: "Slicer + kalkulator + narzut", checked: false },
      { id: "b5", text: "Znajdź pierwszych klientów", description: "Rodzina, znajomi, lokalne grupy FB", checked: false },
      { id: "b6", text: "Zbierz pierwsze opinie", description: "Proś zadowolonych klientów o recenzje", checked: false },
      { id: "b7", text: "Zoptymalizuj proces produkcji", description: "Batch printing, automatyzacja, szablony", checked: false },
    ],
  },
];

export function StartupChecklist() {
  const [checklist, setChecklist] = useState<ChecklistSection[]>(initialChecklist);
  const [expandedSections, setExpandedSections] = useState<string[]>(["printer"]);
  const [showCelebration, setShowCelebration] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("3dhub-startup-checklist");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setChecklist(parsed);
      } catch (e) {
        console.error("Failed to parse saved checklist");
      }
    }
  }, []);

  // Save to localStorage on change
  useEffect(() => {
    localStorage.setItem("3dhub-startup-checklist", JSON.stringify(checklist));
  }, [checklist]);

  const toggleItem = (sectionId: string, itemId: string) => {
    setChecklist((prev) =>
      prev.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              items: section.items.map((item) =>
                item.id === itemId ? { ...item, checked: !item.checked } : item
              ),
            }
          : section
      )
    );
  };

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) =>
      prev.includes(sectionId)
        ? prev.filter((id) => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const resetAll = () => {
    if (confirm("Czy na pewno chcesz zresetować całą checklistę?")) {
      setChecklist(initialChecklist);
      setShowCelebration(false);
    }
  };

  const checkAllInSection = (sectionId: string, checked: boolean) => {
    setChecklist((prev) =>
      prev.map((section) =>
        section.id === sectionId
          ? {
              ...section,
              items: section.items.map((item) => ({ ...item, checked })),
            }
          : section
      )
    );
  };

  const stats = {
    total: checklist.reduce((acc, section) => acc + section.items.length, 0),
    checked: checklist.reduce(
      (acc, section) => acc + section.items.filter((i) => i.checked).length,
      0
    ),
    bySection: checklist.map((section) => ({
      id: section.id,
      title: section.title,
      total: section.items.length,
      checked: section.items.filter((i) => i.checked).length,
    })),
  };

  const progress = Math.round((stats.checked / stats.total) * 100);

  // Show celebration when all items are checked
  useEffect(() => {
    if (progress === 100 && stats.total > 0) {
      setShowCelebration(true);
    }
  }, [progress, stats.total]);

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl text-white flex items-center gap-2">
                <Award className="w-6 h-6 text-amber-500" />
                Postęp Startu Biznesu
              </CardTitle>
              <CardDescription className="text-zinc-400 mt-1">
                {stats.checked} z {stats.total} zadań ukończonych
              </CardDescription>
            </div>
            <div className="text-right">
              <span className="text-3xl font-bold text-amber-500">{progress}%</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Progress
            value={progress}
            className="h-3 bg-zinc-800"
          />
          
          {/* Section Progress */}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {stats.bySection.map((section) => (
              <div
                key={section.id}
                className="bg-zinc-800/50 rounded-lg p-2 text-center cursor-pointer hover:bg-zinc-800 transition-colors"
                onClick={() => toggleSection(section.id)}
              >
                <p className="text-xs text-zinc-500 truncate">{section.title.split(" ")[0]}</p>
                <p className={`text-sm font-semibold ${
                  section.checked === section.total ? "text-emerald-500" : "text-zinc-300"
                }`}>
                  {section.checked}/{section.total}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-4 flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={resetAll}
              className="text-zinc-400 hover:text-white border-zinc-700"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Resetuj
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Celebration */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-gradient-to-r from-amber-600 to-orange-600 rounded-xl p-6 text-center"
          >
            <Award className="w-12 h-12 text-white mx-auto mb-3" />
            <h3 className="text-xl font-bold text-white">Gratulacje!</h3>
            <p className="text-white/90 mt-1">
              Ukończyłeś wszystkie zadania z checklisty startowej. 
              Twój biznes druku 3D jest gotowy do startu!
            </p>
            <Button
              variant="secondary"
              className="mt-4"
              onClick={() => setShowCelebration(false)}
            >
              Zamknij
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Checklist Sections */}
      <Accordion type="multiple" value={expandedSections} onValueChange={setExpandedSections}>
        {checklist.map((section, sectionIndex) => {
          const sectionStats = {
            total: section.items.length,
            checked: section.items.filter((i) => i.checked).length,
          };
          const isComplete = sectionStats.checked === sectionStats.total;

          return (
            <AccordionItem
              key={section.id}
              value={section.id}
              className="border-zinc-800 mb-3"
            >
              <AccordionTrigger className="hover:no-underline py-4 px-4 bg-zinc-900/50 rounded-lg hover:bg-zinc-900 transition-colors">
                <div className="flex items-center gap-4 flex-1 text-left">
                  <div className={`${section.color}`}>{section.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-zinc-100">{section.title}</span>
                      {isComplete && (
                        <Badge className="bg-emerald-600 text-white text-xs">
                          <Check className="w-3 h-3 mr-1" />
                          Gotowe
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-zinc-500 mt-0.5">
                      {sectionStats.checked} z {sectionStats.total} zadań
                    </p>
                  </div>
                  <div className="hidden sm:block w-24">
                    <Progress
                      value={(sectionStats.checked / sectionStats.total) * 100}
                      className="h-2 bg-zinc-800"
                    />
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4">
                <div className="space-y-2">
                  {/* Section Actions */}
                  <div className="flex gap-2 mb-4 px-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => checkAllInSection(section.id, true)}
                      className="text-xs text-zinc-400 hover:text-emerald-400"
                    >
                      Zaznacz wszystkie
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => checkAllInSection(section.id, false)}
                      className="text-xs text-zinc-400 hover:text-zinc-300"
                    >
                      Odznacz wszystkie
                    </Button>
                  </div>

                  {/* Items */}
                  {section.items.map((item, itemIndex) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: itemIndex * 0.05 }}
                      className={`flex items-start gap-3 p-3 rounded-lg transition-all cursor-pointer ${
                        item.checked
                          ? "bg-emerald-950/30 border border-emerald-900/50"
                          : "bg-zinc-800/50 border border-zinc-800 hover:bg-zinc-800"
                      }`}
                      onClick={() => toggleItem(section.id, item.id)}
                    >
                      <Checkbox
                        checked={item.checked}
                        onCheckedChange={() => toggleItem(section.id, item.id)}
                        className={`mt-0.5 ${
                          item.checked
                            ? "border-emerald-500 bg-emerald-500 data-[state=checked]:bg-emerald-500"
                            : "border-zinc-600"
                        }`}
                      />
                      <div className="flex-1">
                        <p
                          className={`text-sm font-medium transition-all ${
                            item.checked
                              ? "text-emerald-400 line-through"
                              : "text-zinc-200"
                          }`}
                        >
                          {item.text}
                        </p>
                        {item.description && (
                          <p
                            className={`text-xs mt-1 transition-all ${
                              item.checked ? "text-emerald-600/70" : "text-zinc-500"
                            }`}
                          >
                            {item.description}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}
