"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle,
  XCircle,
  Thermometer,
  Wind,
  Layers,
  Zap,
  Droplets,
  Settings,
  ExternalLink,
  Play,
  BookOpen,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Wrench,
  Cpu,
  Box,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Problem {
  id: string;
  title: string;
  category: "first-layer" | "extrusion" | "mechanical" | "filament" | "quality" | "software";
  severity: "low" | "medium" | "high" | "critical";
  description: string;
  causes: string[];
  solutions: string[];
  prevention: string[];
  wikiLink?: string;
  videoLink?: string;
  relatedSettings?: string[];
}

const problems: Problem[] = [
  {
    id: "warping",
    title: "Warping - Odchodzenie od stołu",
    category: "first-layer",
    severity: "high",
    description: "Rogi wydruku odchodzą od stołu, powodując deformację i potencjalne zerwanie wydruku.",
    causes: [
      "Za niska temperatura stołu",
      "Brak adhesives na stole",
      "Zbyt duży kontakt z powietrzem (przewiew)",
      "Zbyt mała powierzchnia przylegania",
      "Nieodpowiedni materiał (ABS bez komory)",
    ],
    solutions: [
      "Zwiększ temperaturę stołu (+10-20°C)",
      "Użyj brim (5-10 linii) lub raft",
      "Nałóż klej na stół (glue stick, Magigoo)",
      "Wyłącz wentylatory w pierwszych warstwach",
      "Upewnij się, że komora jest zamknięta (ABS/ASA)",
    ],
    prevention: [
      "Zawsze używaj brim dla dużych płaskich elementów",
      "Utrzymuj stałą temperaturę w pomieszczeniu",
      "Czyść stół przed każdym drukiem",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/warping",
    videoLink: "https://www.youtube.com/watch?v=example",
    relatedSettings: ["Bed Temperature", "Brim", "Initial Layer Speed"],
  },
  {
    id: "stringing",
    title: "Stringing - Nici/Żylki",
    category: "extrusion",
    severity: "medium",
    description: "Cienkie nici filamentu łączące różne części wydruku, szczególnie widoczne przy ruchach podróżnych.",
    causes: [
      "Za wysoka temperatura druku",
      "Za mały retraction",
      "Za szybkie ruchy podróżne",
      "Wilgotny filament",
      "Nieodpowiedni materiał (PETG)",
    ],
    solutions: [
      "Zmniejsz temperaturę o 5-10°C",
      "Zwiększ retraction (PLA: 0.8mm, PETG: 1.2mm)",
      "Zmniejsz prędkość podróżną do 150mm/s",
      "Włącz 'Combing' w slicerze",
      "Wysusz filament (4h/50°C)",
    ],
    prevention: [
      "Kalibruj retraction dla każdego filamentu",
      "Przechowuj filament w suchym miejscu",
      "Używaj odpowiednich profili materiałów",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/stringing",
    relatedSettings: ["Retraction Distance", "Retraction Speed", "Temperature", "Travel Speed"],
  },
  {
    id: "layer-shift",
    title: "Layer Shifting - Przesunięcie warstw",
    category: "mechanical",
    severity: "critical",
    description: "Warstwy wydruku są przesunięte względem siebie, tworząc 'schodki' lub całkowicie zniekształcając wydruk.",
    causes: [
      "Luźne pasy napędowe",
      "Zbyt wysokie przyspieszenia",
      "Przeszkody w ruchu głowicy",
      "Przegrzane sterowniki silników",
      "Uszkodzone łożyska liniowe",
    ],
    solutions: [
      "Sprawdź i napnij pasy (dźwięk jak gitara)",
      "Zmniejsz przyspieszenia do 5000mm/s²",
      "Sprawdź czy nic nie blokuje ruchu głowicy",
      "Wyczyść szyny liniowe i nałóż smar",
      "Sprawdź temperaturę sterowników",
    ],
    prevention: [
      "Regularnie sprawdzaj naprężenie pasów",
      "Czyść i smaruj szyny co 50h druku",
      "Nie przekraczaj zalecanych przyspieszeń",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/layer-shifting",
    relatedSettings: ["Acceleration", "Jerk", "Print Speed"],
  },
  {
    id: "underextrusion",
    title: "Underextrusion - Niedodruk",
    category: "extrusion",
    severity: "high",
    description: "Brakujący filament w wydruku, widoczne luki, cienkie ściany lub słaba przyczepność warstw.",
    causes: [
      "Zatkana dysza (clog)",
      "Za mały flow rate",
      "Ślizgająca się szpula (tangling)",
      "Za wysoka prędkość druku",
      "Zużyta dysza",
    ],
    solutions: [
      "Wyczyść dyszę (cold pull / atomic pull)",
      "Skalibruj flow rate (+5-10%)",
      "Sprawdź czy filament swobodnie odwija się z szpuli",
      "Zmniejsz prędkość druku o 20%",
      "Wymień dyszę (po 500-1000h)",
    ],
    prevention: [
      "Regularnie czyść dyszę",
      "Używaj jakościowych filamentów",
      "Nie przekraczaj zalecanych prędkości",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/under-extrusion",
    relatedSettings: ["Flow Rate", "Print Speed", "Temperature"],
  },
  {
    id: "overextrusion",
    title: "Overextrusion - Nadmiar filamentu",
    category: "extrusion",
    severity: "medium",
    description: "Za dużo filamentu w wydruku, widoczne grube warstwy, 'zgrubienia' na powierzchni.",
    causes: [
      "Za wysoki flow rate",
      "Nieprawidłowe e-steps",
      "Za niska prędkość druku",
      "Nieprawidłowa szerokość linii",
    ],
    solutions: [
      "Zmniejsz flow rate o 5-10%",
      "Skalibruj e-steps ekstrudera",
      "Zwiększ prędkość druku",
      "Dostosuj szerokość linii do dyszy",
    ],
    prevention: [
      "Kalibruj flow rate dla każdego filamentu",
      "Regularnie sprawdzaj kalibrację e-steps",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/over-extrusion",
    relatedSettings: ["Flow Rate", "Line Width", "E-steps"],
  },
  {
    id: "popping",
    title: "Popping Sounds - Pękanie filamentu",
    category: "filament",
    severity: "medium",
    description: "Słyszalne pękanie/pukanie podczas druku, widoczne bąbelki w wydruku, słaba jakość powierzchni.",
    causes: [
      "Wilgotny filament",
      "Zanieczyszczony filament",
      "Za wysoka temperatura druku",
    ],
    solutions: [
      "Wysusz filament w suszarce (4-8h/50°C)",
      "Przechowuj filament w szczelnym pojemniku z silikagem",
      "Sprawdź czy filament nie jest zanieczyszczony",
    ],
    prevention: [
      "Zawsze susz filamenty hygroskopijne (PA, PETG, TPU)",
      "Przechowuj filamenty w suchym miejscu",
      "Używaj pojemników z wilgoci pochłaniaczami",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/popping-sound",
    relatedSettings: ["Temperature", "Dry Filament"],
  },
  {
    id: "first-layer",
    title: "First Layer Issues - Problemy z pierwszą warstwą",
    category: "first-layer",
    severity: "high",
    description: "Pierwsza warstwa nie przylega do stołu, jest zbyt cienia/gruba lub ma nierówną powierzchnię.",
    causes: [
      "Nieprawidłowe poziomowanie stołu",
      "Zły Z-offset",
      "Brudny stół",
      "Nieodpowiednia temperatura stołu",
      "Za szybka pierwsza warstwa",
    ],
    solutions: [
      "Wykonaj auto-leveling stołu",
      "Dostosuj Z-offset (płaska linia, nie za płaska)",
      "Wyczyść stół alkoholem izopropylowym",
      "Zwiększ temperaturę stołu o 5-10°C",
      "Zmniejsz prędkość pierwszej warstwy do 20mm/s",
    ],
    prevention: [
      "Regularnie sprawdzaj poziomowanie",
      "Czyść stół przed każdym drukiem",
      "Używaj odpowiednich adhesives",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/first-layer",
    relatedSettings: ["Z-Offset", "Bed Temperature", "First Layer Speed", "First Layer Flow"],
  },
  {
    id: "poor-adhesion",
    title: "Poor Layer Adhesion - Słaba przyczepność warstw",
    category: "quality",
    severity: "high",
    description: "Warstwy rozwarstwiają się, wydruk jest słaby i łamliwy wzdłuż warstw.",
    causes: [
      "Za niska temperatura druku",
      "Za duże chłodzenie",
      "Nieodpowiednia szerokość warstwy",
      "Zanieczyszczony filament",
    ],
    solutions: [
      "Zwiększ temperaturę o 10°C",
      "Zmniejsz lub wyłącz chłodzenie",
      "Zwiększ szerokość warstwy do 120% wysokości",
      "Użyj świeżego filamentu",
    ],
    prevention: [
      "Używaj odpowiednich temperatur dla materiału",
      "Kontroluj chłodzenie (szczególnie ABS/ASA)",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/layer-adhesion",
    relatedSettings: ["Temperature", "Cooling", "Layer Height", "Line Width"],
  },
  {
    id: "z-seam",
    title: "Z-Seam - Widoczny szew Z",
    category: "quality",
    severity: "low",
    description: "Widoczna linia na wydruku w miejscu zmiany warstwy (Z-seam).",
    causes: [
      "Nieoptymalne ustawienie Z-seam",
      "Za duże ruchy podróżne",
      "Nieprawidłowe retraction",
    ],
    solutions: [
      "Ustaw Z-seam na 'Sharpest Corner'",
      "Włącz 'Coasting' w slicerze",
      "Zwiększ retraction",
      "Użyj 'Wipe' przed ruchem podróżnym",
    ],
    prevention: [
      "Projektuj modele z zaokrąglonymi krawędziami",
      "Optymalizuj ustawienia retraction",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/z-seam",
    relatedSettings: ["Z-Seam Alignment", "Coasting", "Wipe"],
  },
  {
    id: "clog",
    title: "Nozzle Clog - Zatkana dysza",
    category: "mechanical",
    severity: "critical",
    description: "Filament nie wypływa z dyszy lub wypływa nieregularnie.",
    causes: [
      "Zanieczyszczony filament",
      "Spalone resztki w dyszy",
      "Za niska temperatura dla materiału",
      "Zużyta dysza",
    ],
    solutions: [
      "Wykonaj cold pull (atomic pull)",
      "Podgrzej dyszę do 250°C i wyczyść drucikiem",
      "Wymień dyszę",
      "Użyj acupuncture needle do czyszczenia",
    ],
    prevention: [
      "Regularnie czyść dyszę",
      "Używaj jakościowych filamentów",
      "Nie zmieniaj filamentu na zimno",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/nozzle-clog",
    relatedSettings: ["Temperature", "Filament Quality"],
  },
  {
    id: "spaghetti",
    title: "Spaghetti - Splatany wydruk",
    category: "first-layer",
    severity: "critical",
    description: "Wydruk zamienia się w splątaną masę filamentu, zazwyczaj po zerwaniu z stołu.",
    causes: [
      "Wydruk oderwał się od stołu",
      "Zbyt wysoka pierwsza warstwa",
      "Brak adhesives",
      "Zderzenie głowicy z wydrukiem",
    ],
    solutions: [
      "Zatrzymaj druk natychmiast",
      "Wyczyśc stół i zacznij od nowa",
      "Użyj brim lub raft",
      "Sprawdź Z-offset",
      "Włącz 'Filament Runout Sensor'",
    ],
    prevention: [
      "Monitoruj pierwsze warstwy",
      "Używaj kamery do zdalnego monitoringu",
      "Ustaw detekcję kolizji w firmware",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/spaghetti",
    relatedSettings: ["First Layer Adhesion", "Z-Offset", "Collision Detection"],
  },
  {
    id: "elephants-foot",
    title: "Elephant's Foot - Słońska stopa",
    category: "quality",
    severity: "low",
    description: "Pierwsze warstwy są szersze niż reszta wydruku, tworząc 'stopę' na dole.",
    causes: [
      "Za niska pierwsza warstwa (zbyt mocne ściśnięcie)",
      "Za wysoka temperatura stołu",
      "Za duży flow pierwszej warstwy",
    ],
    solutions: [
      "Zwiększ Z-offset o 0.05-0.1mm",
      "Zmniejsz temperaturę stołu o 5-10°C",
      "Zmniejsz flow pierwszej warstwy do 90%",
      "Użyj 'Initial Layer Horizontal Expansion'",
    ],
    prevention: [
      "Dostosuj Z-offset przed długimi wydrukami",
      "Używaj odpowiedniej temperatury stołu",
    ],
    wikiLink: "https://wiki.bambulab.com/en/troubleshooting/elephants-foot",
    relatedSettings: ["Z-Offset", "Bed Temperature", "Initial Layer Flow"],
  },
];

const categories = {
  "first-layer": { label: "Pierwsza warstwa", icon: <Layers className="w-4 h-4" />, color: "bg-blue-500" },
  "extrusion": { label: "Ekstruzja", icon: <Droplets className="w-4 h-4" />, color: "bg-purple-500" },
  "mechanical": { label: "Mechanika", icon: <Settings className="w-4 h-4" />, color: "bg-amber-500" },
  "filament": { label: "Filament", icon: <Box className="w-4 h-4" />, color: "bg-emerald-500" },
  "quality": { label: "Jakość", icon: <CheckCircle className="w-4 h-4" />, color: "bg-cyan-500" },
  "software": { label: "Oprogramowanie", icon: <Cpu className="w-4 h-4" />, color: "bg-rose-500" },
};

const severityColors = {
  low: "bg-blue-500",
  medium: "bg-amber-500",
  high: "bg-orange-500",
  critical: "bg-red-500",
};

const severityLabels = {
  low: "Niski",
  medium: "Średni",
  high: "Wysoki",
  critical: "Krytyczny",
};

export function TroubleshootingH2D() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedSeverity, setSelectedSeverity] = useState<string>("all");

  const filteredProblems = problems.filter((problem) => {
    const matchesSearch =
      problem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      problem.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || problem.category === selectedCategory;
    const matchesSeverity = selectedSeverity === "all" || problem.severity === selectedSeverity;
    return matchesSearch && matchesCategory && matchesSeverity;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                placeholder="Szukaj problemu..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-800 border-zinc-700 text-zinc-100"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-zinc-800 border border-zinc-700 text-zinc-300 rounded-lg px-3 py-2 text-sm"
              >
                <option value="all">Wszystkie kategorie</option>
                {Object.entries(categories).map(([key, cat]) => (
                  <option key={key} value={key}>
                    {cat.label}
                  </option>
                ))}
              </select>
              <select
                value={selectedSeverity}
                onChange={(e) => setSelectedSeverity(e.target.value)}
                className="bg-zinc-800 border border-zinc-700 text-zinc-300 rounded-lg px-3 py-2 text-sm"
              >
                <option value="all">Wszystkie poziomy</option>
                {Object.entries(severityLabels).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Category Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {Object.entries(categories).map(([key, cat]) => {
          const count = problems.filter((p) => p.category === key).length;
          return (
            <button
              key={key}
              onClick={() => setSelectedCategory(selectedCategory === key ? "all" : key)}
              className={`p-3 rounded-lg border transition-all text-left ${
                selectedCategory === key
                  ? `${cat.color} border-transparent text-white`
                  : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700"
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                {cat.icon}
                <span className="font-medium text-sm">{cat.label}</span>
              </div>
              <span className={`text-xs ${selectedCategory === key ? "text-white/70" : "text-zinc-500"}`}>
                {count} problemów
              </span>
            </button>
          );
        })}
      </div>

      {/* Problems List */}
      <Accordion type="multiple" className="space-y-3">
        {filteredProblems.map((problem, index) => (
          <AccordionItem
            key={problem.id}
            value={problem.id}
            className="border-zinc-800 bg-zinc-900 rounded-lg overflow-hidden"
          >
            <AccordionTrigger className="hover:no-underline px-4 py-4 hover:bg-zinc-800/50 transition-colors">
              <div className="flex items-center gap-4 flex-1 text-left">
                <Badge className={`${severityColors[problem.severity]} text-white shrink-0`}>
                  {severityLabels[problem.severity]}
                </Badge>
                <div className={`${categories[problem.category].color} p-2 rounded-lg shrink-0`}>
                  {categories[problem.category].icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-zinc-100">{problem.title}</p>
                  <p className="text-sm text-zinc-500 truncate">{problem.description}</p>
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="grid lg:grid-cols-2 gap-6 pt-4">
                {/* Causes */}
                <div>
                  <h4 className="font-semibold text-amber-400 flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-4 h-4" />
                    Przyczyny
                  </h4>
                  <ul className="space-y-2">
                    {problem.causes.map((cause, i) => (
                      <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                        <span className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 shrink-0" />
                        {cause}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Solutions */}
                <div>
                  <h4 className="font-semibold text-emerald-400 flex items-center gap-2 mb-3">
                    <CheckCircle className="w-4 h-4" />
                    Rozwiązania
                  </h4>
                  <ul className="space-y-2">
                    {problem.solutions.map((solution, i) => (
                      <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 shrink-0" />
                        {solution}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Prevention */}
                <div className="lg:col-span-2">
                  <h4 className="font-semibold text-blue-400 flex items-center gap-2 mb-3">
                    <Wrench className="w-4 h-4" />
                    Zapobieganie
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {problem.prevention.map((prev, i) => (
                      <Badge key={i} variant="secondary" className="bg-blue-950/50 text-blue-300 border border-blue-900">
                        {prev}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Related Settings */}
                {problem.relatedSettings && (
                  <div>
                    <h4 className="font-semibold text-purple-400 flex items-center gap-2 mb-3">
                      <Settings className="w-4 h-4" />
                      Powiązane ustawienia
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {problem.relatedSettings.map((setting, i) => (
                        <Badge key={i} variant="outline" className="border-purple-800 text-purple-400">
                          {setting}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Links */}
                <div className="flex gap-3">
                  {problem.wikiLink && (
                    <a
                      href={problem.wikiLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
                    >
                      <BookOpen className="w-4 h-4" />
                      Wiki Bambu Lab
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                  {problem.videoLink && (
                    <a
                      href={problem.videoLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm text-rose-400 hover:text-rose-300 transition-colors"
                    >
                      <Play className="w-4 h-4" />
                      Film instruktażowy
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      {filteredProblems.length === 0 && (
        <div className="text-center py-12">
          <Search className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
          <p className="text-zinc-400">Nie znaleziono problemów pasujących do kryteriów</p>
          <Button
            variant="outline"
            className="mt-4 border-zinc-700 text-zinc-400"
            onClick={() => {
              setSearchQuery("");
              setSelectedCategory("all");
              setSelectedSeverity("all");
            }}
          >
            Wyczyść filtry
          </Button>
        </div>
      )}

      {/* Quick Tips Card */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-lg text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            Szybkie Wskazówki Bambu Lab H2D
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-zinc-800/50 rounded-lg p-4">
              <Thermometer className="w-5 h-5 text-amber-500 mb-2" />
              <p className="font-medium text-zinc-200 text-sm">Temperatura</p>
              <p className="text-xs text-zinc-500">PLA: 200-220°C, PETG: 230-250°C, ABS: 240-260°C</p>
            </div>
            <div className="bg-zinc-800/50 rounded-lg p-4">
              <Wind className="w-5 h-5 text-blue-500 mb-2" />
              <p className="font-medium text-zinc-200 text-sm">Chłodzenie</p>
              <p className="text-xs text-zinc-500">PLA: 100%, PETG: 30%, ABS: 0-20%</p>
            </div>
            <div className="bg-zinc-800/50 rounded-lg p-4">
              <Layers className="w-5 h-5 text-emerald-500 mb-2" />
              <p className="font-medium text-zinc-200 text-sm">Pierwsza warstwa</p>
              <p className="text-xs text-zinc-500">Prędkość: 20mm/s, Flow: 100%, Temp stołu: 60-110°C</p>
            </div>
            <div className="bg-zinc-800/50 rounded-lg p-4">
              <Droplets className="w-5 h-5 text-purple-500 mb-2" />
              <p className="font-medium text-zinc-200 text-sm">Retraction</p>
              <p className="text-xs text-zinc-500">PLA: 0.8mm, PETG: 1.2mm, Prędkość: 40mm/s</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
