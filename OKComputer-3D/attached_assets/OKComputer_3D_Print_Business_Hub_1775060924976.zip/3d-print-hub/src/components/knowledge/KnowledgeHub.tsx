"use client";

import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  BookOpen,
  CheckSquare,
  Briefcase,
  Layers,
  Wrench,
  Settings,
  ChevronRight,
  Filter,
  X,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { StartupChecklist } from "./StartupChecklist";
import { BusinessAdvice } from "./BusinessAdvice";
import { MaterialProfiles } from "./MaterialProfiles";
import { TroubleshootingH2D } from "./TroubleshootingH2D";
import { PrintSettings } from "./PrintSettings";

export type KnowledgeCategory =
  | "all"
  | "startup"
  | "business"
  | "materials"
  | "troubleshooting"
  | "settings";

interface SearchResult {
  id: string;
  title: string;
  content: string;
  category: KnowledgeCategory;
  section: string;
}

const categoryLabels: Record<KnowledgeCategory, string> = {
  all: "Wszystkie",
  startup: "Checklist Startowy",
  business: "Porady Biznesowe",
  materials: "Materiały",
  troubleshooting: "Troubleshooting",
  settings: "Ustawienia",
};

const categoryIcons: Record<KnowledgeCategory, React.ReactNode> = {
  all: <BookOpen className="w-4 h-4" />,
  startup: <CheckSquare className="w-4 h-4" />,
  business: <Briefcase className="w-4 h-4" />,
  materials: <Layers className="w-4 h-4" />,
  troubleshooting: <Wrench className="w-4 h-4" />,
  settings: <Settings className="w-4 h-4" />,
};

const categoryColors: Record<KnowledgeCategory, string> = {
  all: "bg-zinc-700",
  startup: "bg-emerald-600",
  business: "bg-blue-600",
  materials: "bg-purple-600",
  troubleshooting: "bg-amber-600",
  settings: "bg-cyan-600",
};

// Searchable content database
const searchableContent: SearchResult[] = [
  // Startup
  { id: "s1", title: "Wybór drukarki 3D", content: "Zalecamy Bambu Lab H2D, P1S lub X1 Carbon dla biznesu", category: "startup", section: "Sprzęt" },
  { id: "s2", title: "Przygotowanie stanowiska", content: "Wentylacja, stabilna powierzchnia, odpowiednia wilgotność", category: "startup", section: "Stanowisko" },
  { id: "s3", title: "Zakup filamentów", content: "PLA, PETG, ABS - startowy zestaw materiałów", category: "startup", section: "Materiały" },
  { id: "s4", title: "Kalibracja drukarki", content: "Flow rate, pressure advance, temperature tower", category: "startup", section: "Kalibracja" },
  { id: "s5", title: "Testowe wydruki", content: "Benchy, tolerance test, strength test", category: "startup", section: "Testy" },
  { id: "s6", title: "Rejestracja działalności", content: "JDG lub Sp. z o.o. - wybór formy prawnej", category: "startup", section: "Formalności" },
  
  // Business
  { id: "b1", title: "Jednoosobowa działalność gospodarcza", content: "Prosta forma, niskie koszty, pełna odpowiedzialność", category: "business", section: "Rejestracja" },
  { id: "b2", title: "Spółka z o.o.", content: "Ograniczona odpowiedzialność, wyższe koszty, prestiż", category: "business", section: "Rejestracja" },
  { id: "b3", title: "VAT - podatek od towarów i usług", content: "Rejestracja VAT, stawki 23%, 8%, 5%, zwolnienie", category: "business", section: "Podatki" },
  { id: "b4", title: "PIT - podatek dochodowy", content: "Skala podatkowa, liniowy 19%, ryczałt", category: "business", section: "Podatki" },
  { id: "b5", title: "ZUS - składki ubezpieczeniowe", content: "Mały ZUS, duży ZUS, preferencyjne składki", category: "business", section: "ZUS" },
  { id: "b6", title: "Ubezpieczenie firmy", content: "OC, AC, ubezpieczenie mienia, cyberochrona", category: "business", section: "Ubezpieczenia" },
  { id: "b7", title: "Wysyłka produktów", content: "InPost, DPD, DHL - porównanie cen", category: "business", section: "Logistyka" },
  { id: "b8", title: "Polityka zwrotów", content: "14 dni na zwrot, wady ukryte, rękojmia", category: "business", section: "Logistyka" },
  
  // Materials
  { id: "m1", title: "PLA - kiedy używać", content: "Prototypy, dekoracje, niski koszt, łatwy w druku", category: "materials", section: "PLA" },
  { id: "m2", title: "PETG - kiedy używać", content: "Funkcjonalne części, odporność chemiczna, przeźroczystość", category: "materials", section: "PETG" },
  { id: "m3", title: "ABS - kiedy używać", content: "Wysoka temperatura pracy, wytrzymałość, lakierowanie", category: "materials", section: "ABS" },
  { id: "m4", title: "TPU - kiedy używać", content: "Elastyczne części, uszczelki, oponki, amortyzacja", category: "materials", section: "TPU" },
  { id: "m5", title: "PA (Nylon) - kiedy używać", content: "Wysoka wytrzymałość mechaniczna, odporność na zużycie", category: "materials", section: "PA" },
  { id: "m6", title: "PC (Poliwęglan) - kiedy używać", content: "Najwyższa wytrzymałość termiczna, przezroczystość", category: "materials", section: "PC" },
  
  // Troubleshooting
  { id: "t1", title: "Warping - odchodzenie od stołu", content: "Brim, raft, temperatura stołu, adhesives", category: "troubleshooting", section: "Problemy ze stołem" },
  { id: "t2", title: "Stringing - nici/żylki", content: "Retraction, temperatura, prędkość podróży", category: "troubleshooting", section: "Ekstruzja" },
  { id: "t3", title: "Layer shifting - przesunięcie warstw", content: "Napięcie pasów, prędkość, mechanika", category: "troubleshooting", section: "Mechanika" },
  { id: "t4", title: "Underextrusion - niedodruk", content: "Clog, tension, temperature, flow rate", category: "troubleshooting", section: "Ekstruzja" },
  { id: "t5", title: "Overextrusion - nadmiar filamentu", content: "Flow rate, e-steps, kalibracja", category: "troubleshooting", section: "Ekstruzja" },
  { id: "t6", title: "Popping sounds - pękanie filamentu", content: "Wilgotność filamentu, suszenie, przechowywanie", category: "troubleshooting", section: "Filament" },
  { id: "t7", title: "First layer issues - problemy z pierwszą warstwą", content: "Leveling, Z-offset, flow, speed", category: "troubleshooting", section: "Pierwsza warstwa" },
  
  // Settings
  { id: "p1", title: "PLA - ustawienia domyślne", content: "Temp: 200-220°C, stół: 60°C, prędkość: 150mm/s", category: "settings", section: "PLA" },
  { id: "p2", title: "PETG - ustawienia domyślne", content: "Temp: 230-250°C, stół: 80°C, prędkość: 100mm/s", category: "settings", section: "PETG" },
  { id: "p3", title: "ABS - ustawienia domyślne", content: "Temp: 240-260°C, stół: 100°C, komora: 50°C", category: "settings", section: "ABS" },
  { id: "p4", title: "TPU - ustawienia domyślne", content: "Temp: 220-240°C, stół: 60°C, prędkość: 30mm/s", category: "settings", section: "TPU" },
  { id: "p5", title: "Wypełnienie - infill", content: "15-20% standard, 50% mocne, 100% solid", category: "settings", section: "Ogólne" },
  { id: "p6", title: "Ściany - walls", content: "2-3 ściany standard, 4-5 wytrzymałe", category: "settings", section: "Ogólne" },
  { id: "p7", title: "Retraction - wycofanie", content: "PLA: 0.8mm, PETG: 1.2mm, ABS: 0.8mm", category: "settings", section: "Ogólne" },
];

export function KnowledgeHub() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<KnowledgeCategory>("all");
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    
    const query = searchQuery.toLowerCase();
    return searchableContent.filter(
      (item) =>
        (activeCategory === "all" || item.category === activeCategory) &&
        (item.title.toLowerCase().includes(query) ||
          item.content.toLowerCase().includes(query))
    );
  }, [searchQuery, activeCategory]);

  const clearSearch = () => {
    setSearchQuery("");
    setActiveCategory("all");
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-white flex items-center gap-3">
                <BookOpen className="w-7 h-7 text-amber-500" />
                Centrum Wiedzy
              </h1>
              <p className="text-zinc-400 text-sm mt-1">
                Kompletny poradnik dla biznesu druku 3D
              </p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full sm:w-96">
              <div
                className={`relative transition-all duration-300 ${
                  isSearchFocused ? "scale-105" : ""
                }`}
              >
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <Input
                  placeholder="Szukaj w bazie wiedzy..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setIsSearchFocused(false)}
                  className="pl-10 pr-10 bg-zinc-800 border-zinc-700 text-zinc-100 placeholder:text-zinc-500 focus:border-amber-500 focus:ring-amber-500/20"
                />
                {searchQuery && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Search Results Dropdown */}
              <AnimatePresence>
                {searchQuery && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-zinc-800 border border-zinc-700 rounded-lg shadow-xl z-50 overflow-hidden"
                  >
                    <div className="p-3 border-b border-zinc-700 flex items-center gap-2">
                      <Filter className="w-4 h-4 text-zinc-500" />
                      <span className="text-xs text-zinc-400">Filtruj:</span>
                      <div className="flex gap-1 flex-wrap">
                        {(Object.keys(categoryLabels) as KnowledgeCategory[]).map(
                          (cat) => (
                            <button
                              key={cat}
                              onClick={() => setActiveCategory(cat)}
                              className={`px-2 py-0.5 text-xs rounded-full transition-colors ${
                                activeCategory === cat
                                  ? categoryColors[cat]
                                  : "bg-zinc-700 hover:bg-zinc-600"
                              }`}
                            >
                              {categoryLabels[cat]}
                            </button>
                          )
                        )}
                      </div>
                    </div>
                    <ScrollArea className="max-h-80">
                      {filteredResults.length > 0 ? (
                        <div className="p-2">
                          {filteredResults.map((result) => (
                            <motion.div
                              key={result.id}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="p-3 hover:bg-zinc-700/50 rounded-lg cursor-pointer group transition-colors"
                            >
                              <div className="flex items-start gap-3">
                                <Badge
                                  variant="secondary"
                                  className={`${categoryColors[result.category]} text-white text-xs shrink-0`}
                                >
                                  {categoryIcons[result.category]}
                                </Badge>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium text-zinc-100 group-hover:text-amber-400 transition-colors">
                                    {result.title}
                                  </p>
                                  <p className="text-xs text-zinc-400 mt-0.5 line-clamp-2">
                                    {result.content}
                                  </p>
                                  <p className="text-xs text-zinc-500 mt-1">
                                    Sekcja: {result.section}
                                  </p>
                                </div>
                                <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 transition-colors shrink-0" />
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-8 text-center">
                          <Search className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                          <p className="text-zinc-400 text-sm">
                            Nie znaleziono wyników
                          </p>
                          <p className="text-zinc-500 text-xs mt-1">
                            Spróbuj innych słów kluczowych
                          </p>
                        </div>
                      )}
                    </ScrollArea>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="startup" className="space-y-6">
          <TabsList className="bg-zinc-900 border border-zinc-800 p-1 flex flex-wrap h-auto gap-1">
            <TabsTrigger
              value="startup"
              className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <CheckSquare className="w-4 h-4" />
              <span className="hidden sm:inline">Checklist Startowy</span>
              <span className="sm:hidden">Start</span>
            </TabsTrigger>
            <TabsTrigger
              value="business"
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <Briefcase className="w-4 h-4" />
              <span className="hidden sm:inline">Porady Biznesowe</span>
              <span className="sm:hidden">Biznes</span>
            </TabsTrigger>
            <TabsTrigger
              value="materials"
              className="data-[state=active]:bg-purple-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <Layers className="w-4 h-4" />
              <span className="hidden sm:inline">Materiały</span>
              <span className="sm:hidden">Materiały</span>
            </TabsTrigger>
            <TabsTrigger
              value="troubleshooting"
              className="data-[state=active]:bg-amber-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <Wrench className="w-4 h-4" />
              <span className="hidden sm:inline">Troubleshooting</span>
              <span className="sm:hidden">Problemy</span>
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="data-[state=active]:bg-cyan-600 data-[state=active]:text-white flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Ustawienia</span>
              <span className="sm:hidden">Ustawienia</span>
            </TabsTrigger>
          </TabsList>

          <AnimatePresence mode="wait">
            <TabsContent value="startup" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <StartupChecklist />
              </motion.div>
            </TabsContent>

            <TabsContent value="business" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <BusinessAdvice />
              </motion.div>
            </TabsContent>

            <TabsContent value="materials" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <MaterialProfiles />
              </motion.div>
            </TabsContent>

            <TabsContent value="troubleshooting" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <TroubleshootingH2D />
              </motion.div>
            </TabsContent>

            <TabsContent value="settings" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <PrintSettings />
              </motion.div>
            </TabsContent>
          </AnimatePresence>
        </Tabs>
      </main>
    </div>
  );
}
