"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Thermometer,
  Wind,
  Layers,
  Zap,
  Clock,
  Box,
  Settings,
  Copy,
  Check,
  Download,
  Upload,
  Info,
  Beaker,
  Maximize2,
  Minimize2,
  RotateCcw,
  Save,
  FileJson,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface PrintProfile {
  id: string;
  name: string;
  material: string;
  color: string;
  gradient: string;
  icon: React.ReactNode;
  description: string;
  settings: {
    temperature: {
      nozzle: number;
      bed: number;
      chamber?: number;
    };
    speed: {
      print: number;
      firstLayer: number;
      travel: number;
      wall: number;
      infill: number;
    };
    cooling: {
      fanSpeed: number;
      firstLayerFan: number;
      threshold: number;
    };
    retraction: {
      distance: number;
      speed: number;
      extraRestart: number;
    };
    quality: {
      layerHeight: number;
      wallThickness: number;
      topBottomThickness: number;
      infillDensity: number;
      infillPattern: string;
    };
    support: {
      enabled: boolean;
      overhangAngle: number;
      density: number;
      pattern: string;
    };
    adhesion: {
      type: "none" | "brim" | "raft" | "skirt";
      brimWidth?: number;
      raftLayers?: number;
    };
  };
  notes: string[];
}

const defaultProfiles: PrintProfile[] = [
  {
    id: "pla-standard",
    name: "PLA Standard",
    material: "PLA",
    color: "text-emerald-500",
    gradient: "from-emerald-600 to-green-500",
    icon: <Beaker className="w-5 h-5" />,
    description: "Optymalne ustawienia dla większości filamentów PLA. Zbalansowana prędkość i jakość.",
    settings: {
      temperature: { nozzle: 210, bed: 60 },
      speed: { print: 150, firstLayer: 20, travel: 200, wall: 100, infill: 150 },
      cooling: { fanSpeed: 100, firstLayerFan: 0, threshold: 3 },
      retraction: { distance: 0.8, speed: 40, extraRestart: 0 },
      quality: { layerHeight: 0.2, wallThickness: 1.2, topBottomThickness: 0.8, infillDensity: 20, infillPattern: "grid" },
      support: { enabled: false, overhangAngle: 50, density: 20, pattern: "zigzag" },
      adhesion: { type: "skirt" },
    },
    notes: [
      "Dla lepszego połysku: zmniejsz prędkość do 50mm/s",
      "Dla szybkich prototypów: zwiększ do 200mm/s",
      "Susz filament jeśli słyszysz pękanie",
    ],
  },
  {
    id: "pla-quality",
    name: "PLA Wysoka Jakość",
    material: "PLA",
    color: "text-emerald-400",
    gradient: "from-emerald-500 to-teal-400",
    icon: <Beaker className="w-5 h-5" />,
    description: "Maksymalna jakość dla prezentacji i produktów finalnych. Wolniejszy ale precyzyjny.",
    settings: {
      temperature: { nozzle: 200, bed: 60 },
      speed: { print: 50, firstLayer: 15, travel: 150, wall: 30, infill: 50 },
      cooling: { fanSpeed: 100, firstLayerFan: 0, threshold: 2 },
      retraction: { distance: 0.8, speed: 40, extraRestart: 0 },
      quality: { layerHeight: 0.12, wallThickness: 1.2, topBottomThickness: 1.0, infillDensity: 25, infillPattern: "gyroid" },
      support: { enabled: false, overhangAngle: 45, density: 25, pattern: "zigzag" },
      adhesion: { type: "brim", brimWidth: 8 },
    },
    notes: [
      "Ironing dla górnych powierzchni",
      "Gyroid infill dla lepszej wytrzymałości",
      "Cienkie warstwy = lepsza jakość",
    ],
  },
  {
    id: "petg-standard",
    name: "PETG Standard",
    material: "PETG",
    color: "text-blue-500",
    gradient: "from-blue-600 to-cyan-500",
    icon: <Layers className="w-5 h-5" />,
    description: "Zbalansowane ustawienia dla PETG. Uwaga na stringing - zwiększ retraction.",
    settings: {
      temperature: { nozzle: 240, bed: 80 },
      speed: { print: 100, firstLayer: 20, travel: 150, wall: 80, infill: 100 },
      cooling: { fanSpeed: 30, firstLayerFan: 0, threshold: 3 },
      retraction: { distance: 1.2, speed: 35, extraRestart: 0.1 },
      quality: { layerHeight: 0.2, wallThickness: 1.2, topBottomThickness: 0.8, infillDensity: 20, infillPattern: "grid" },
      support: { enabled: false, overhangAngle: 50, density: 20, pattern: "zigzag" },
      adhesion: { type: "brim", brimWidth: 10 },
    },
    notes: [
      "Zwiększ Z-offset o 0.05mm (nie ściskaj za mocno)",
      "Mniejsze chłodzenie = lepsza przyczepność warstw",
      "Używaj kleju do stołu dla pewności",
    ],
  },
  {
    id: "petg-clear",
    name: "PETG Przezroczysty",
    material: "PETG",
    color: "text-cyan-400",
    gradient: "from-cyan-500 to-blue-400",
    icon: <Layers className="w-5 h-5" />,
    description: "Specjalne ustawienia dla przezroczystego PETG. Maksymalna przezroczystość.",
    settings: {
      temperature: { nozzle: 250, bed: 80 },
      speed: { print: 40, firstLayer: 15, travel: 100, wall: 30, infill: 40 },
      cooling: { fanSpeed: 0, firstLayerFan: 0, threshold: 999 },
      retraction: { distance: 1.5, speed: 30, extraRestart: 0.2 },
      quality: { layerHeight: 0.28, wallThickness: 1.5, topBottomThickness: 1.0, infillDensity: 0, infillPattern: "grid" },
      support: { enabled: false, overhangAngle: 45, density: 15, pattern: "zigzag" },
      adhesion: { type: "brim", brimWidth: 12 },
    },
    notes: [
      "Grube warstwy = lepsza przezroczystość",
      "Wyłącz chłodzenie całkowicie",
      "Drukuj powoli dla klarowności",
    ],
  },
  {
    id: "abs-standard",
    name: "ABS Standard",
    material: "ABS",
    color: "text-amber-500",
    gradient: "from-amber-600 to-orange-500",
    icon: <Box className="w-5 h-5" />,
    description: "Standardowe ustawienia dla ABS. Wymaga zamkniętej komory i wentylacji.",
    settings: {
      temperature: { nozzle: 250, bed: 100, chamber: 50 },
      speed: { print: 80, firstLayer: 20, travel: 150, wall: 60, infill: 80 },
      cooling: { fanSpeed: 10, firstLayerFan: 0, threshold: 5 },
      retraction: { distance: 0.8, speed: 40, extraRestart: 0 },
      quality: { layerHeight: 0.2, wallThickness: 1.2, topBottomThickness: 0.8, infillDensity: 20, infillPattern: "grid" },
      support: { enabled: false, overhangAngle: 50, density: 20, pattern: "zigzag" },
      adhesion: { type: "brim", brimWidth: 12 },
    },
    notes: [
      "Komora zamknięta OBOWIĄZKOWA (min 45°C)",
      "Wentylacja pomieszczenia - konieczna (toksyczne opary)",
      "Używaj brim dla dużych elementów",
    ],
  },
  {
    id: "tpu-standard",
    name: "TPU Standard",
    material: "TPU",
    color: "text-purple-500",
    gradient: "from-purple-600 to-pink-500",
    icon: <Maximize2 className="w-5 h-5" />,
    description: "Ustawienia dla elastycznego TPU. Wymaga direct drive i wolnego druku.",
    settings: {
      temperature: { nozzle: 230, bed: 60 },
      speed: { print: 30, firstLayer: 15, travel: 80, wall: 20, infill: 30 },
      cooling: { fanSpeed: 60, firstLayerFan: 0, threshold: 3 },
      retraction: { distance: 2.0, speed: 25, extraRestart: 0.2 },
      quality: { layerHeight: 0.2, wallThickness: 1.2, topBottomThickness: 0.8, infillDensity: 25, infillPattern: "gyroid" },
      support: { enabled: false, overhangAngle: 55, density: 15, pattern: "zigzag" },
      adhesion: { type: "brim", brimWidth: 8 },
    },
    notes: [
      "Wymaga direct drive (nie bowden!)",
      "Drukuj bardzo wolno",
      "Zwiększ flow rate o 10-15%",
      "Unikaj sharp corners",
    ],
  },
];

interface CustomProfile {
  name: string;
  settings: PrintProfile["settings"];
}

export function PrintSettings() {
  const [selectedProfile, setSelectedProfile] = useState<string>("pla-standard");
  const [copied, setCopied] = useState(false);
  const [customProfiles, setCustomProfiles] = useState<CustomProfile[]>([]);
  const [showCustomEditor, setShowCustomEditor] = useState(false);

  const profile = defaultProfiles.find((p) => p.id === selectedProfile);

  const copySettings = () => {
    if (profile) {
      navigator.clipboard.writeText(JSON.stringify(profile.settings, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const exportProfile = () => {
    if (profile) {
      const dataStr = JSON.stringify(profile, null, 2);
      const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
      const exportFileDefaultName = `${profile.id}.json`;
      const linkElement = document.createElement("a");
      linkElement.setAttribute("href", dataUri);
      linkElement.setAttribute("download", exportFileDefaultName);
      linkElement.click();
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-6">
      {/* Profile Selector */}
      <Card className="bg-zinc-900 border-zinc-800">
        <CardHeader>
          <CardTitle className="text-lg text-white">Wybierz Profil Druku</CardTitle>
          <CardDescription className="text-zinc-400">
            Gotowe ustawienia zoptymalizowane dla Bambu Lab H2D
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {defaultProfiles.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedProfile(p.id)}
                className={`p-4 rounded-lg border text-left transition-all ${
                  selectedProfile === p.id
                    ? `bg-gradient-to-r ${p.gradient} border-transparent text-white shadow-lg`
                    : "bg-zinc-800 border-zinc-700 text-zinc-300 hover:border-zinc-600"
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  {p.icon}
                  <span className="font-semibold">{p.name}</span>
                </div>
                <p className={`text-xs ${selectedProfile === p.id ? "text-white/70" : "text-zinc-500"}`}>
                  {p.description.slice(0, 60)}...
                </p>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Profile Details */}
      <motion.div
        key={profile.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`${profile.color}`}>{profile.icon}</div>
            <div>
              <h2 className="text-xl font-bold text-white">{profile.name}</h2>
              <p className="text-sm text-zinc-400">{profile.description}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="sm" onClick={copySettings} className="border-zinc-700">
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Kopiuj ustawienia</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="sm" onClick={exportProfile} className="border-zinc-700">
                    <Download className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Eksportuj profil</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

        {/* Settings Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Temperature */}
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-amber-500" />
                Temperatury
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Dysza</p>
                  <p className="text-xl font-bold text-amber-400">{profile.settings.temperature.nozzle}°C</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Stół</p>
                  <p className="text-xl font-bold text-blue-400">{profile.settings.temperature.bed}°C</p>
                </div>
                {profile.settings.temperature.chamber && (
                  <div className="bg-zinc-800/50 rounded-lg p-3 col-span-2">
                    <p className="text-xs text-zinc-500">Komora</p>
                    <p className="text-xl font-bold text-purple-400">{profile.settings.temperature.chamber}°C</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Speed */}
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-500" />
                Prędkości
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Druk</p>
                  <p className="text-lg font-bold text-cyan-400">{profile.settings.speed.print} mm/s</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Pierwsza warstwa</p>
                  <p className="text-lg font-bold text-emerald-400">{profile.settings.speed.firstLayer} mm/s</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Podróż</p>
                  <p className="text-lg font-bold text-zinc-300">{profile.settings.speed.travel} mm/s</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Ściany</p>
                  <p className="text-lg font-bold text-zinc-300">{profile.settings.speed.wall} mm/s</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Cooling */}
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <Wind className="w-4 h-4 text-blue-500" />
                Chłodzenie
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Prędkość wentylatora</span>
                  <span className="font-bold text-blue-400">{profile.settings.cooling.fanSpeed}%</span>
                </div>
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Pierwsza warstwa</span>
                  <span className="font-bold text-zinc-300">{profile.settings.cooling.firstLayerFan}%</span>
                </div>
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Próg włączenia</span>
                  <span className="font-bold text-zinc-300">Warstwa {profile.settings.cooling.threshold}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Retraction */}
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-purple-500" />
                Retraction
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Dystans</p>
                  <p className="text-lg font-bold text-purple-400">{profile.settings.retraction.distance} mm</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Prędkość</p>
                  <p className="text-lg font-bold text-zinc-300">{profile.settings.retraction.speed} mm/s</p>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3 col-span-2">
                  <p className="text-xs text-zinc-500">Extra restart</p>
                  <p className="text-lg font-bold text-zinc-300">{profile.settings.retraction.extraRestart} mm</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quality Settings */}
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-500" />
              Jakość
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="bg-zinc-800/50 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-500">Wysokość warstwy</p>
                <p className="text-xl font-bold text-emerald-400">{profile.settings.quality.layerHeight} mm</p>
              </div>
              <div className="bg-zinc-800/50 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-500">Grubość ścian</p>
                <p className="text-xl font-bold text-zinc-300">{profile.settings.quality.wallThickness} mm</p>
              </div>
              <div className="bg-zinc-800/50 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-500">Góra/dół</p>
                <p className="text-xl font-bold text-zinc-300">{profile.settings.quality.topBottomThickness} mm</p>
              </div>
              <div className="bg-zinc-800/50 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-500">Wypełnienie</p>
                <p className="text-xl font-bold text-zinc-300">{profile.settings.quality.infillDensity}%</p>
              </div>
              <div className="bg-zinc-800/50 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-500">Wzór wypełnienia</p>
                <p className="text-lg font-bold text-zinc-300 capitalize">{profile.settings.quality.infillPattern}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support & Adhesion */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <Box className="w-4 h-4 text-amber-500" />
                Supporty
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Włączone</span>
                  <Badge className={profile.settings.support.enabled ? "bg-emerald-600" : "bg-zinc-600"}>
                    {profile.settings.support.enabled ? "Tak" : "Nie"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Kąt przewieszenia</span>
                  <span className="font-bold text-zinc-300">{profile.settings.support.overhangAngle}°</span>
                </div>
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Gęstość</span>
                  <span className="font-bold text-zinc-300">{profile.settings.support.density}%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-base text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-rose-500" />
                Przyczepność
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                  <span className="text-sm text-zinc-400">Typ</span>
                  <Badge variant="outline" className="border-zinc-700 text-zinc-300 capitalize">
                    {profile.settings.adhesion.type}
                  </Badge>
                </div>
                {profile.settings.adhesion.brimWidth && (
                  <div className="flex items-center justify-between bg-zinc-800/50 rounded-lg p-3">
                    <span className="text-sm text-zinc-400">Szerokość brim</span>
                    <span className="font-bold text-zinc-300">{profile.settings.adhesion.brimWidth} mm</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notes */}
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-base text-white flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-500" />
              Wskazówki
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {profile.notes.map((note, i) => (
                <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 shrink-0" />
                  {note}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
