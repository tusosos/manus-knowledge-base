"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Building2,
  Calculator,
  Shield,
  Truck,
  RotateCcw,
  FileText,
  AlertTriangle,
  CheckCircle,
  Info,
  ExternalLink,
  ChevronRight,
  Percent,
  User,
  Package,
  Scale,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface BusinessTopic {
  id: string;
  title: string;
  icon: React.ReactNode;
  color: string;
  content: React.ReactNode;
}

const businessTopics: BusinessTopic[] = [
  {
    id: "registration",
    title: "Rejestracja Firmy",
    icon: <Building2 className="w-5 h-5" />,
    color: "bg-blue-600",
    content: null, // Will be rendered separately
  },
  {
    id: "taxes",
    title: "Podatki",
    icon: <Calculator className="w-5 h-5" />,
    color: "bg-emerald-600",
    content: null,
  },
  {
    id: "zus",
    title: "ZUS",
    icon: <Shield className="w-5 h-5" />,
    color: "bg-purple-600",
    content: null,
  },
  {
    id: "insurance",
    title: "Ubezpieczenie",
    icon: <FileText className="w-5 h-5" />,
    color: "bg-amber-600",
    content: null,
  },
  {
    id: "shipping",
    title: "Wysyłka",
    icon: <Truck className="w-5 h-5" />,
    color: "bg-cyan-600",
    content: null,
  },
  {
    id: "returns",
    title: "Zwroty",
    icon: <RotateCcw className="w-5 h-5" />,
    color: "bg-rose-600",
    content: null,
  },
];

const jdvdComparison = [
  {
    aspect: "Koszt założenia",
    jdg: "Darmowa rejestracja online",
    spzoo: "Ok. 2500-5000 PLN (notariusz + sąd)",
  },
  {
    aspect: "Czas rejestracji",
    jdg: "1-3 dni robocze",
    spzoo: "2-4 tygodnie",
  },
  {
    aspect: "Odpowiedzialność",
    jdg: "Pełna odpowiedzialność majątkowa",
    spzoo: "Odpowiedzialność do wysokości kapitału",
  },
  {
    aspect: "Złożoność księgowa",
    jdg: "Prosta (PKPiR lub ryczałt)",
    spzoo: "Pełna księgowość",
  },
  {
    aspect: "Koszty prowadzenia",
    jdg: "Niskie (księgowość od 100 PLN)",
    spzoo: "Wyższe (księgowość od 500 PLN)",
  },
  {
    aspect: "Prestiż",
    jdg: "Standardowa",
    spzoo: "Wyższa wiarygodność",
  },
  {
    aspect: "Podział zysków",
    jdg: "Całość dla właściciela",
    spzoo: "Dywidendy dla wspólników",
  },
];

const taxForms = [
  {
    name: "Skala podatkowa",
    description: "Progresywna stawka 12% / 32%",
    pros: ["Kwota wolna od podatku (30k PLN)", "Ulgi podatkowe (np. IP Box)", "Dobra przy niższych dochodach"],
    cons: ["Wysoka stawka przy wyższych dochodach", "Skomplikowane rozliczenia"],
    bestFor: "Dochody do 120k PLN rocznie",
    color: "blue",
  },
  {
    name: "Podatek liniowy",
    description: "Stała stawka 19%",
    pros: ["Stała stawka niezależnie od dochodu", "Prostsze rozliczenia", "Korzystny przy wysokich dochodach"],
    cons: ["Brak kwoty wolnej", "Brak ulg podatkowych", "Nieopłacalny przy niskich dochodach"],
    bestFor: "Dochody powyżej 200k PLN rocznie",
    color: "emerald",
  },
  {
    name: "Ryczałt ewidencjonowany",
    description: "Stała stawka od przychodu (3%-17%)",
    pros: ["Najprostsze rozliczenia", "Brak kosztów uzyskania przychodu do udokumentowania", "Niskie stawki dla niektórych branż"],
    cons: ["Podatek od przychodu, nie dochodu", "Limit przychodów (2M EUR)", "Brak współmałżonka w rozliczeniu"],
    bestFor: "Wysokie marże, niskie koszty",
    color: "amber",
  },
];

const zusTypes = [
  {
    name: "Mały ZUS Plus",
    description: "Dla nowych firm przez pierwsze 24 miesiące",
    base: "30% minimalnego wynagrodzenia",
    amount: "~350 PLN/miesiąc",
    conditions: ["Pierwsza firma lub po 5 latach przerwy", "Przychody poniżej 120k PLN/rok"],
    color: "emerald",
  },
  {
    name: "Preferencyjny ZUS",
    description: "Dla małych firm (24-36 miesiąc)",
    base: "30% minimalnego wynagrodzenia",
    amount: "~450 PLN/miesiąc",
    conditions: ["Po okresie Małego ZUS", "Przychody poniżej 120k PLN/rok"],
    color: "blue",
  },
  {
    name: "Duży ZUS",
    description: "Standardowa stawka dla firm",
    base: "60% prognozowanego wynagrodzenia",
    amount: "~1600 PLN/miesiąc",
    conditions: ["Po 36 miesiącach działalności", "Lub przychody powyżej 120k PLN/rok"],
    color: "rose",
  },
];

const shippingCarriers = [
  {
    name: "InPost",
    paczkomat: "12-15 PLN",
    kurier: "15-18 PLN",
    features: ["Największa sieć paczkomatów", "Aplikacja mobilna", "Integracja z platformami"],
    bestFor: "Małe i średnie paczki",
  },
  {
    name: "DPD",
    paczkomat: "-",
    kurier: "16-20 PLN",
    features: ["Szybka dostawa", "Dobry tracking", "Ubezpieczenie do 5000 PLN"],
    bestFor: "Wartościowe przesyłki",
  },
  {
    name: "DHL",
    paczkomat: "-",
    kurier: "18-25 PLN",
    features: ["Międzynarodowe przesyłki", "Profesjonalna obsługa", "Dostawa w soboty"],
    bestFor: "Przesyłki zagraniczne",
  },
  {
    name: "Orlen Paczka",
    paczkomat: "10-13 PLN",
    kurier: "14-17 PLN",
    features: ["Najniższe ceny", "Odbiór na stacjach", "Rosnąca sieć"],
    bestFor: "Budżetowe przesyłki",
  },
];

export function BusinessAdvice() {
  const [activeTab, setActiveTab] = useState("registration");

  return (
    <div className="space-y-6">
      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {businessTopics.map((topic) => (
          <motion.button
            key={topic.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setActiveTab(topic.id)}
            className={`p-4 rounded-xl border transition-all text-left ${
              activeTab === topic.id
                ? `${topic.color} border-transparent text-white`
                : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
            }`}
          >
            <div className="mb-2">{topic.icon}</div>
            <p className="text-sm font-medium">{topic.title}</p>
          </motion.button>
        ))}
      </div>

      {/* Content Area */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {/* Registration Content */}
          {activeTab === "registration" && (
            <div className="space-y-6">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <Scale className="w-6 h-6 text-blue-500" />
                    JDG vs Sp. z o.o. - Porównanie
                  </CardTitle>
                  <CardDescription className="text-zinc-400">
                    Wybierz odpowiednią formę prawną dla swojego biznesu
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-zinc-800">
                          <TableHead className="text-zinc-400">Aspekt</TableHead>
                          <TableHead className="text-blue-400">Jednoosobowa Działalność</TableHead>
                          <TableHead className="text-purple-400">Spółka z o.o.</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {jdvdComparison.map((row, idx) => (
                          <TableRow key={idx} className="border-zinc-800">
                            <TableCell className="font-medium text-zinc-300">{row.aspect}</TableCell>
                            <TableCell className="text-zinc-400">{row.jdg}</TableCell>
                            <TableCell className="text-zinc-400">{row.spzoo}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="mt-6 grid md:grid-cols-2 gap-4">
                    <div className="bg-blue-950/30 border border-blue-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-400 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        Kiedy wybrać JDG?
                      </h4>
                      <ul className="mt-2 space-y-1 text-sm text-zinc-400">
                        <li>• Startujesz z małym kapitałem</li>
                        <li>• Chcesz szybko zacząć działać</li>
                        <li>• Oczekujesz umiarkowanych przychodów</li>
                        <li>• Samodzielnie prowadzisz biznes</li>
                      </ul>
                    </div>
                    <div className="bg-purple-950/30 border border-purple-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-purple-400 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        Kiedy wybrać Sp. z o.o.?
                      </h4>
                      <ul className="mt-2 space-y-1 text-sm text-zinc-400">
                        <li>• Planujesz duże inwestycje</li>
                        <li>• Chcesz ograniczyć ryzyko</li>
                        <li>• Masz wspólników biznesowych</li>
                        <li>• Dążysz do dużej skali</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Jak zarejestrować JDG?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { step: 1, title: "Przygotuj dane", desc: "PESEL, adres, NIP (jeśli masz), kod PKD (28.99.Z - Produkcja pozostałych wyrobów)" },
                      { step: 2, title: "Wejdź na biznes.gov.pl", desc: "Wypełnij formularz CEIDG-1 online" },
                      { step: 3, title: "Wybierz formę opodatkowania", desc: "Skala, liniowy lub ryczałt" },
                      { step: 4, title: "Zgłoś się do ZUS", desc: "Automatycznie w formularzu lub osobno" },
                      { step: 5, title: "Odbierz potwierdzenie", desc: "Na email otrzymasz wpis do CEIDG" },
                    ].map((item) => (
                      <div key={item.step} className="flex gap-4 p-3 bg-zinc-800/50 rounded-lg">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold shrink-0">
                          {item.step}
                        </div>
                        <div>
                          <p className="font-medium text-zinc-200">{item.title}</p>
                          <p className="text-sm text-zinc-500">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Taxes Content */}
          {activeTab === "taxes" && (
            <div className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-4">
                {taxForms.map((tax) => (
                  <Card key={tax.name} className="bg-zinc-900 border-zinc-800">
                    <CardHeader className="pb-3">
                      <Badge className={`bg-${tax.color}-600 text-white w-fit mb-2`}>
                        {tax.name}
                      </Badge>
                      <CardDescription className="text-zinc-400">
                        {tax.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-xs font-medium text-emerald-500 mb-1">Zalety:</p>
                        <ul className="space-y-1">
                          {tax.pros.map((pro, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <CheckCircle className="w-3 h-3 text-emerald-500 mt-0.5 shrink-0" />
                              {pro}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-rose-500 mb-1">Wady:</p>
                        <ul className="space-y-1">
                          {tax.cons.map((con, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <AlertTriangle className="w-3 h-3 text-rose-500 mt-0.5 shrink-0" />
                              {con}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="pt-3 border-t border-zinc-800">
                        <p className="text-xs text-zinc-500">
                          <span className="text-amber-500">Najlepszy dla:</span> {tax.bestFor}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg text-white flex items-center gap-2">
                    <Percent className="w-5 h-5 text-emerald-500" />
                    VAT - Podatek od Towarów i Usług
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-zinc-800/50 rounded-lg p-4">
                      <h4 className="font-semibold text-zinc-200 mb-2">Zwolnienie z VAT</h4>
                      <ul className="space-y-1 text-sm text-zinc-400">
                        <li>• Przychody poniżej 200k PLN/rok</li>
                        <li>• Brak konieczności składania deklaracji VAT</li>
                        <li>• Niższe ceny dla klientów indywidualnych</li>
                        <li>• Nie można odliczać VAT od zakupów</li>
                      </ul>
                    </div>
                    <div className="bg-zinc-800/50 rounded-lg p-4">
                      <h4 className="font-semibold text-zinc-200 mb-2">VAT czynny</h4>
                      <ul className="space-y-1 text-sm text-zinc-400">
                        <li>• Obowiązkowy powyżej 200k PLN</li>
                        <li>• Stawka 23% (domyślna), 8%, 5%</li>
                        <li>• Możliwość odliczenia VAT od zakupów</li>
                        <li>• Wymagane faktury VAT</li>
                      </ul>
                    </div>
                  </div>
                  <div className="bg-amber-950/30 border border-amber-900/50 rounded-lg p-4 flex gap-3">
                    <Info className="w-5 h-5 text-amber-500 shrink-0" />
                    <p className="text-sm text-zinc-400">
                      <span className="text-amber-400 font-medium">Wskazówka:</span> Dla druku 3D 
                      stawka VAT to 23%. Jeśli sprzedajesz głównie do firm (B2B), rejestracja VAT 
                      jest korzystna - klienci odliczą VAT, a Ty odliczysz VAT od zakupu filamentów i drukarek.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* ZUS Content */}
          {activeTab === "zus" && (
            <div className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-4">
                {zusTypes.map((zus) => (
                  <Card key={zus.name} className="bg-zinc-900 border-zinc-800">
                    <CardHeader>
                      <Badge className={`${zus.color === "emerald" ? "bg-emerald-600" : zus.color === "blue" ? "bg-blue-600" : "bg-rose-600"} text-white w-fit`}>
                        {zus.name}
                      </Badge>
                      <CardDescription className="text-zinc-400">
                        {zus.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center py-4 bg-zinc-800/50 rounded-lg">
                        <p className="text-3xl font-bold text-white">{zus.amount}</p>
                        <p className="text-xs text-zinc-500 mt-1">{zus.base}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-zinc-400 mb-2">Warunki:</p>
                        <ul className="space-y-1">
                          {zus.conditions.map((cond, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <CheckCircle className="w-3 h-3 text-emerald-500 mt-0.5 shrink-0" />
                              {cond}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Co zawiera składka ZUS?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { name: "Ubezpieczenie emerytalne", percent: "19.52%", desc: "Przyszła emerytura" },
                      { name: "Ubezpieczenie rentowe", percent: "8.00%", desc: "Zabezpieczenie na wypadek choroby" },
                      { name: "Ubezpieczenie chorobowe", percent: "2.45%", desc: "Zasiłek chorobowy" },
                      { name: "Ubezpieczenie zdrowotne", percent: "9.00%", desc: "Opieka medyczna" },
                    ].map((item) => (
                      <div key={item.name} className="bg-zinc-800/50 rounded-lg p-4">
                        <p className="font-medium text-zinc-200">{item.name}</p>
                        <p className="text-2xl font-bold text-amber-500">{item.percent}</p>
                        <p className="text-xs text-zinc-500">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Insurance Content */}
          {activeTab === "insurance" && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="text-lg text-white flex items-center gap-2">
                      <Shield className="w-5 h-5 text-amber-500" />
                      OC Działalności Gospodarczej
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-zinc-400 text-sm">
                      Ochrona przed roszczeniami osób trzecich w przypadku szkód 
                      wyrządzonych w związku z prowadzeniem działalności.
                    </p>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-zinc-300">Co chroni:</p>
                      <ul className="space-y-1 text-sm text-zinc-400">
                        <li>• Wady produktów wyrządzające szkody</li>
                        <li>• Błędy w wycenach lub doradztwie</li>
                        <li>• Szkody na mieniu klientów</li>
                        <li>• Koszty obrony w procesie sądowym</li>
                      </ul>
                    </div>
                    <div className="bg-amber-950/30 border border-amber-900/50 rounded-lg p-3">
                      <p className="text-sm text-amber-400 font-medium">Koszt: 200-800 PLN/rok</p>
                      <p className="text-xs text-zinc-500">Zależnie od limitu i zakresu</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="text-lg text-white flex items-center gap-2">
                      <Package className="w-5 h-5 text-blue-500" />
                      Ubezpieczenie Mienia
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-zinc-400 text-sm">
                      Ochrona drukarek 3D, komputerów, filamentów i innego 
                      sprzętu używanego w działalności.
                    </p>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-zinc-300">Co chroni:</p>
                      <ul className="space-y-1 text-sm text-zinc-400">
                        <li>• Kradzież z włamaniem</li>
                        <li>• Pożar, zalanie, uszkodzenia</li>
                        <li>• Przepięcia i awarie elektryczne</li>
                        <li>• Uszkodzenie podczas transportu</li>
                      </ul>
                    </div>
                    <div className="bg-blue-950/30 border border-blue-900/50 rounded-lg p-3">
                      <p className="text-sm text-blue-400 font-medium">Koszt: 0.5-2% wartości/rok</p>
                      <p className="text-xs text-zinc-500">Dla sprzętu wartego 50k PLN: ~500 PLN</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Rekomendowane pakiety ubezpieczeniowe</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-zinc-800">
                          <TableHead className="text-zinc-400">Pakiet</TableHead>
                          <TableHead className="text-zinc-400">Zakres</TableHead>
                          <TableHead className="text-zinc-400">Limit</TableHead>
                          <TableHead className="text-zinc-400">Cena/rok</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow className="border-zinc-800">
                          <TableCell className="font-medium text-zinc-200">Podstawowy</TableCell>
                          <TableCell className="text-zinc-400">OC + mienie</TableCell>
                          <TableCell className="text-zinc-400">100k PLN / 30k PLN</TableCell>
                          <TableCell className="text-emerald-400">~400 PLN</TableCell>
                        </TableRow>
                        <TableRow className="border-zinc-800">
                          <TableCell className="font-medium text-zinc-200">Rozszerzony</TableCell>
                          <TableCell className="text-zinc-400">OC + mienie + cyber</TableCell>
                          <TableCell className="text-zinc-400">250k PLN / 50k PLN</TableCell>
                          <TableCell className="text-emerald-400">~700 PLN</TableCell>
                        </TableRow>
                        <TableRow className="border-zinc-800">
                          <TableCell className="font-medium text-zinc-200">Premium</TableCell>
                          <TableCell className="text-zinc-400">Pełna ochrona</TableCell>
                          <TableCell className="text-zinc-400">500k PLN / 100k PLN</TableCell>
                          <TableCell className="text-emerald-400">~1200 PLN</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Shipping Content */}
          {activeTab === "shipping" && (
            <div className="space-y-6">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <Truck className="w-6 h-6 text-cyan-500" />
                    Porównanie Przewoźników
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-zinc-800">
                          <TableHead className="text-zinc-400">Przewoźnik</TableHead>
                          <TableHead className="text-zinc-400">Paczkomat</TableHead>
                          <TableHead className="text-zinc-400">Kurier</TableHead>
                          <TableHead className="text-zinc-400">Najlepszy dla</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {shippingCarriers.map((carrier) => (
                          <TableRow key={carrier.name} className="border-zinc-800">
                            <TableCell className="font-medium text-zinc-200">{carrier.name}</TableCell>
                            <TableCell className="text-zinc-400">{carrier.paczkomat}</TableCell>
                            <TableCell className="text-zinc-400">{carrier.kurier}</TableCell>
                            <TableCell className="text-zinc-400">{carrier.bestFor}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-4">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="text-lg text-white">Pakowanie Produktów 3D</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { title: "Małe elementy (<10cm)", desc: "Koperta bąbelkowa + kartonik - koszt ~2 PLN" },
                      { title: "Średnie elementy (10-30cm)", desc: "Karton 20x15x10cm + wypełniacz - koszt ~4 PLN" },
                      { title: "Duże elementy (>30cm)", desc: "Karton 40x30x20cm + folia bąbelkowa - koszt ~8 PLN" },
                      { title: "Delikatne elementy", desc: "Dodatkowa pianka ochronna - koszt +3 PLN" },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-3 p-3 bg-zinc-800/50 rounded-lg">
                        <Package className="w-5 h-5 text-cyan-500 shrink-0" />
                        <div>
                          <p className="font-medium text-zinc-200 text-sm">{item.title}</p>
                          <p className="text-xs text-zinc-500">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="text-lg text-white">Wskazówki Logistyczne</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { title: "Zawsze ubezpieczaj przesyłki", desc: "Dla wartościowych zamówień (>200 PLN) wykup ubezpieczenie" },
                      { title: "Śledzenie przesyłek", desc: "Udostępniaj klientom numery trackingowe" },
                      { title: "Czas realizacji", desc: "Standard: 24-48h od zamówienia. Komunikuj opóźnienia" },
                      { title: "Darmowa dostawa", desc: "Ofertuj od kwoty X (np. 200 PLN) - zwiększa wartość koszyka" },
                    ].map((item, i) => (
                      <div key={i} className="flex gap-3 p-3 bg-zinc-800/50 rounded-lg">
                        <Info className="w-5 h-5 text-amber-500 shrink-0" />
                        <div>
                          <p className="font-medium text-zinc-200 text-sm">{item.title}</p>
                          <p className="text-xs text-zinc-500">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Returns Content */}
          {activeTab === "returns" && (
            <div className="space-y-6">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <RotateCcw className="w-6 h-6 text-rose-500" />
                    Polityka Zwrotów - Co Musisz Wiedzieć
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-rose-950/30 border border-rose-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-rose-400 flex items-center gap-2 mb-3">
                        <User className="w-4 h-4" />
                        Zwrot przez Konsumenta (14 dni)
                      </h4>
                      <ul className="space-y-2 text-sm text-zinc-400">
                        <li>• Prawo do zwrotu bez podania przyczyny</li>
                        <li>• 14 dni od otrzymania produktu</li>
                        <li>• Produkt nie może być używany/uszkodzony</li>
                        <li>• Koszt zwrotu ponosi klient (chyba że oferujesz darmowy)</li>
                        <li>• Zwrot pieniędzy w ciągu 14 dni</li>
                      </ul>
                    </div>
                    <div className="bg-amber-950/30 border border-amber-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-amber-400 flex items-center gap-2 mb-3">
                        <AlertTriangle className="w-4 h-4" />
                        Rękojmia - Wady Ukryte (2 lata)
                      </h4>
                      <ul className="space-y-2 text-sm text-zinc-400">
                        <li>• Odpowiedzialność za wady istniejące przy sprzedaży</li>
                        <li>• Termin: 2 lata od zakupu</li>
                        <li>• Klient może żądać naprawy, wymiany lub zwrotu</li>
                        <li>• Koszty ponosi sprzedawca</li>
                        <li>• Nie dotyczy uszkodzeń mechanicznych</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-zinc-800/50 rounded-lg p-4">
                    <h4 className="font-semibold text-zinc-200 mb-3">Wzór Polityki Zwrotów</h4>
                    <div className="bg-zinc-950 rounded-lg p-4 font-mono text-xs text-zinc-400 space-y-2">
                      <p className="text-zinc-500">// Dodaj do regulaminu sklepu:</p>
                      <p>1. Masz prawo odstąpić od umowy w ciągu 14 dni bez podania przyczyny.</p>
                      <p>2. Termin odstąpienia wygasa po 14 dniach od otrzymania towaru.</p>
                      <p>3. Towar musi być zwrócony w stanie niezmienionym (chyba że wada).</p>
                      <p>4. Zwrot pieniędzy w ciągu 14 dni od otrzymania zwrotu.</p>
                      <p>5. Koszt zwrotu ponosi kupujący (chyba że wada).</p>
                      <p>6. Nie przyjmujemy zwrotów produktów spersonalizowanych.</p>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-3 gap-4">
                    <div className="bg-emerald-950/30 border border-emerald-900/50 rounded-lg p-4 text-center">
                      <p className="text-3xl font-bold text-emerald-500">14 dni</p>
                      <p className="text-sm text-zinc-400">Na zwrot bez przyczyny</p>
                    </div>
                    <div className="bg-amber-950/30 border border-amber-900/50 rounded-lg p-4 text-center">
                      <p className="text-3xl font-bold text-amber-500">2 lata</p>
                      <p className="text-sm text-zinc-400">Rękojmia za wady</p>
                    </div>
                    <div className="bg-blue-950/30 border border-blue-900/50 rounded-lg p-4 text-center">
                      <p className="text-3xl font-bold text-blue-500">14 dni</p>
                      <p className="text-sm text-zinc-400">Na zwrot pieniędzy</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// Helper component for AnimatePresence
function AnimatePresence({ children, mode }: { children: React.ReactNode; mode?: "wait" | "sync" | "popLayout" }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      {children}
    </motion.div>
  );
}
