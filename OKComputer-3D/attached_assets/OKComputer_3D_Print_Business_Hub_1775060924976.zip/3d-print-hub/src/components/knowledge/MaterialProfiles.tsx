"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Thermometer,
  Droplets,
  Shield,
  Zap,
  DollarSign,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Info,
  Beaker,
  Layers,
  Wind,
  Box,
  Scale,
  Maximize2,
  Minimize2,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";

interface MaterialProfile {
  id: string;
  name: string;
  fullName: string;
  color: string;
  gradient: string;
  icon: React.ReactNode;
  description: string;
  properties: {
    strength: number;
    flexibility: number;
    heatResistance: number;
    printability: number;
    durability: number;
    cost: number;
  };
  specs: {
    printTemp: string;
    bedTemp: string;
    chamberTemp: string;
    speed: string;
    cooling: string;
  };
  whenToUse: string[];
  whenNotToUse: string[];
  pros: string[];
  cons: string[];
  brands: string[];
  priceRange: string;
  applications: string[];
  tips: string[];
}

const materials: MaterialProfile[] = [
  {
    id: "pla",
    name: "PLA",
    fullName: "Polylactic Acid (Kwas polimlekowy)",
    color: "text-emerald-500",
    gradient: "from-emerald-600 to-green-500",
    icon: <Beaker className="w-6 h-6" />,
    description: "Najpopularniejszy materiał do druku 3D. Biodegradowalny, łatwy w druku, idealny dla początkujących.",
    properties: {
      strength: 60,
      flexibility: 20,
      heatResistance: 30,
      printability: 95,
      durability: 50,
      cost: 20,
    },
    specs: {
      printTemp: "190-220°C",
      bedTemp: "50-60°C",
      chamberTemp: "Nie wymagana",
      speed: "50-150 mm/s",
      cooling: "100% (wymagane)",
    },
    whenToUse: [
      "Prototypy i modele wizualne",
      "Dekoracje i figurki",
      "Elementy nie wymagające wytrzymałości",
      "Pierwsze kroki w druku 3D",
      "Duże wydruki (mały skręt)",
    ],
    whenNotToUse: [
      "Elementy narażone na wysokie temperatury (>60°C)",
      "Części mechaniczne pod obciążeniem",
      "Elementy na zewnątrz (UV degradacja)",
      "Uszczelki i elementy elastyczne",
    ],
    pros: [
      "Bardzo łatwy w druku",
      "Minimalny warp",
      "Brak zapachu",
      "Biodegradowalny",
      "Szeroka dostępność kolorów",
      "Niski koszt",
    ],
    cons: [
      "Niska odporność termiczna",
      "Kruchy przy uderzeniach",
      "Niska odporność na UV",
      "Hydrofilny (chłonie wilgoć)",
    ],
    brands: ["Bambu Lab", "Prusament", "Fiberlogy", "Devil Design", "Hatchbox"],
    priceRange: "60-100 PLN/kg",
    applications: ["Figurki", "Prototypy", "Pudełka", "Wsporniki", "Dekoracje"],
    tips: [
      "Susz filament przed użyciem (4h/50°C)",
      "Używaj chłodzenia 100% po 3. warstwie",
      "Dla lepszego połysku: temp 210°C, speed 40mm/s",
    ],
  },
  {
    id: "petg",
    name: "PETG",
    fullName: "Polyethylene Terephthalate Glycol",
    color: "text-blue-500",
    gradient: "from-blue-600 to-cyan-500",
    icon: <Layers className="w-6 h-6" />,
    description: "Połączenie łatwości druku PLA z wytrzymałością ABS. Najlepszy wybór dla funkcjonalnych części.",
    properties: {
      strength: 75,
      flexibility: 40,
      heatResistance: 60,
      printability: 80,
      durability: 80,
      cost: 35,
    },
    specs: {
      printTemp: "230-250°C",
      bedTemp: "70-80°C",
      chamberTemp: "Opcjonalna",
      speed: "40-100 mm/s",
      cooling: "30-50% (ograniczone)",
    },
    whenToUse: [
      "Funkcjonalne części mechaniczne",
      "Pojemniki na żywność (bezpieczny)",
      "Elementy na zewnątrz (odporny na UV)",
      "Przezroczyste wydruki",
      "Części wymagające wytrzymałości",
    ],
    whenNotToUse: [
      "Elementy elastyczne (za sztywny)",
      "Wysokie temperatury (>75°C)",
      "Szybkie prototypowanie (wolniejszy druk)",
    ],
    pros: [
      "Wysoka wytrzymałość mechaniczna",
      "Odporny na chemikalia",
      "Bezpieczny kontakt z żywnością",
      "Odporny na UV i wilgoć",
      "Przezroczyste warianty",
      "Łatwy w druku jak PLA",
    ],
    cons: [
      "Stringing (nici/żylki)",
      "Tendencja do zbierania wilgoci",
      "Wymaga kalibracji retraction",
      "Słabsza przyczepność do stołu",
    ],
    brands: ["Prusament", "Fiberlogy", "Devil Design", "Hatchbox", "3D Jake"],
    priceRange: "80-120 PLN/kg",
    applications: ["Pojemniki", "Części mechaniczne", "Obudowy", "Elementy zewnętrzne", "Przezroczyste części"],
    tips: [
      "Zwiększ retraction do 1.2mm",
      "Zmniejsz chłodzenie do 30%",
      "Używaj kleju do stołu (opcjonalnie)",
    ],
  },
  {
    id: "abs",
    name: "ABS",
    fullName: "Acrylonitrile Butadiene Styrene",
    color: "text-amber-500",
    gradient: "from-amber-600 to-orange-500",
    icon: <Box className="w-6 h-6" />,
    description: "Klasyczny materiał przemysłowy. Wymaga zamkniętej komory, ale oferuje najlepsze właściwości mechaniczne.",
    properties: {
      strength: 85,
      flexibility: 50,
      heatResistance: 85,
      printability: 50,
      durability: 90,
      cost: 40,
    },
    specs: {
      printTemp: "240-260°C",
      bedTemp: "90-110°C",
      chamberTemp: "40-60°C (wymagana)",
      speed: "40-80 mm/s",
      cooling: "0-20% (minimalne)",
    },
    whenToUse: [
      "Części narażone na wysokie temperatury",
      "Elementy do lakierowania",
      "Części mechaniczne pod obciążeniem",
      "Prototypy przemysłowe",
      "Elementy wymagające obróbki",
    ],
    whenNotToUse: [
      "Bez zamkniętej komory",
      "W słabo wentylowanym pomieszczeniu (toksyczne opary)",
      "Szybkie prototypowanie",
      "Kontakt z żywnością",
    ],
    pros: [
      "Wysoka wytrzymałość termiczna",
      "Świetna wytrzymałość udarowa",
      "Możliwość lakierowania",
      "Odporny na chemikalia",
      "Można obrabiać (wiercić, szlifować)",
    ],
    cons: [
      "Wymaga zamkniętej komory",
      "Silny warp i shrinkage",
      "Toksyczne opary (wymagana wentylacja)",
      "Trudny w druku dla początkujących",
      "Niebezpieczny kontakt z żywnością",
    ],
    brands: ["Prusament", "Fiberlogy", "3D Jake", "Hatchbox", "eSun"],
    priceRange: "80-130 PLN/kg",
    applications: ["Części samochodowe", "Obudowy elektroniki", "Zabawki", "Prototypy", "Elementy lakierowane"],
    tips: [
      "Używaj brim lub raft",
      "Zamknięta komora obowiązkowa",
      "Wentylacja pomieszczenia - konieczna",
      "Temp. stołu minimum 100°C",
    ],
  },
  {
    id: "tpu",
    name: "TPU",
    fullName: "Thermoplastic Polyurethane",
    color: "text-purple-500",
    gradient: "from-purple-600 to-pink-500",
    icon: <Maximize2 className="w-6 h-6" />,
    description: "Elastyczny materiał gumopodobny. Idealny do uszczelek, opon, amortyzatorów i elementów elastycznych.",
    properties: {
      strength: 70,
      flexibility: 95,
      heatResistance: 50,
      printability: 60,
      durability: 85,
      cost: 60,
    },
    specs: {
      printTemp: "220-240°C",
      bedTemp: "50-60°C",
      chamberTemp: "Nie wymagana",
      speed: "20-40 mm/s (wolno!)",
      cooling: "50-80%",
    },
    whenToUse: [
      "Uszczelki i oringi",
      "Opony do modeli RC",
      "Amortyzatory i tłumiki drgań",
      "Etui ochronne (np. telefon)",
      "Elementy elastyczne",
      "Paski i opaski",
    ],
    whenNotToUse: [
      "Sztywne części konstrukcyjne",
      "Wysokie temperatury (>60°C)",
      "Szybkie drukowanie",
      "Precyzyjne elementy (trudność w druku)",
    ],
    pros: [
      "Bardzo elastyczny",
      "Wysoka odporność na ścieranie",
      "Odporny na oleje i tłuszcze",
      "Świetna przyczepność warstw",
      "Trwały",
    ],
    cons: [
      "Bardzo wolny druk",
      "Trudny w drukowaniu (stringing)",
      "Wymaga bezpośredniego feedu (bez bowdena)",
      "Wysoki koszt",
      "Trudność w post-processingu",
    ],
    brands: ["Prusament", "Fiberlogy", "NinjaTek", "SainSmart", "eSun"],
    priceRange: "120-200 PLN/kg",
    applications: ["Uszczelki", "Opony RC", "Etui", "Paski", "Amortyzatory", "Maski"],
    tips: [
      "Drukuj bardzo wolno (20-30mm/s)",
      "Używaj direct drive (bez bowdena)",
      "Zwiększ flow rate o 10-15%",
      "Unikaj sharp corners (zaokrąglaj)",
    ],
  },
  {
    id: "pa",
    name: "PA (Nylon)",
    fullName: "Polyamide (Poliamid)",
    color: "text-rose-500",
    gradient: "from-rose-600 to-red-500",
    icon: <Scale className="w-6 h-6" />,
    description: "Inżynierski materiał o najwyższej wytrzymałości mechanicznej i odporności na zużycie.",
    properties: {
      strength: 95,
      flexibility: 60,
      heatResistance: 90,
      printability: 40,
      durability: 95,
      cost: 80,
    },
    specs: {
      printTemp: "250-280°C",
      bedTemp: "80-100°C",
      chamberTemp: "40-50°C (zalecana)",
      speed: "30-60 mm/s",
      cooling: "0-30% (minimalne)",
    },
    whenToUse: [
      "Części mechaniczne o wysokim obciążeniu",
      "Łożyska i prowadnice",
      "Koła zębate",
      "Elementy narażone na ścieranie",
      "Prototypy przemysłowe",
      "Zastępstwo metalu",
    ],
    whenNotToUse: [
      "Bez suszenia filamentu",
      "Bez doświadczenia w druku 3D",
      "Małe budżety",
      "Szybkie prototypowanie",
    ],
    pros: [
      "Najwyższa wytrzymałość mechaniczna",
      "Świetna odporność na zużycie",
      "Samosmarujący",
      "Odporny na chemikalia",
      "Wysoka odporność termiczna",
    ],
    cons: [
      "Bardzo higroskopijny (suszenie wymagane!)",
      "Wysoka temperatura druku",
      "Wymaga zamkniętej komory",
      "Wysoki koszt",
      "Trudny w druku",
    ],
    brands: ["Prusament", "Fiberlogy", "Polymaker", "3DXTech", "eSun"],
    priceRange: "150-250 PLN/kg",
    applications: ["Koła zębate", "Łożyska", "Prowadnice", "Części maszyn", "Zamienniki metalu"],
    tips: [
      "Susz filament 8-12h w 80°C przed drukiem",
      "Przechowuj w szczelnym pojemniku z silikagem",
      "Używaj dyszy hardened steel",
      "Zamknięta komora zalecana",
    ],
  },
  {
    id: "pc",
    name: "PC",
    fullName: "Polycarbonate (Poliwęglan)",
    color: "text-cyan-500",
    gradient: "from-cyan-600 to-teal-500",
    icon: <Shield className="w-6 h-6" />,
    description: "Materiał o najwyższej odporności termicznej i przezroczystości. Wymaga zaawansowanego sprzętu.",
    properties: {
      strength: 90,
      flexibility: 40,
      heatResistance: 100,
      printability: 30,
      durability: 90,
      cost: 90,
    },
    specs: {
      printTemp: "260-300°C",
      bedTemp: "100-120°C",
      chamberTemp: "50-70°C (wymagana)",
      speed: "30-50 mm/s",
      cooling: "0-20% (minimalne)",
    },
    whenToUse: [
      "Najwyższe temperatury pracy (>100°C)",
      "Przezroczyste elementy techniczne",
      "Części o wysokiej wytrzymałości",
      "Zastępstwo szkła",
      "Elementy bezpieczeństwa",
    ],
    whenNotToUse: [
      "Bez drukarki z wysoką temperaturą głowicy",
      "Bez zamkniętej komory",
      "Dla początkujących",
      "Małe budżety",
    ],
    pros: [
      "Najwyższa odporność termiczna",
      "Przezroczystość",
      "Bardzo wysoka wytrzymałość",
      "Odporny na uderzenia",
      "Odporny na promieniowanie UV",
    ],
    cons: [
      "Bardzo wysoka temperatura druku",
      "Wymaga zamkniętej komory (70°C+)",
      "Silny warp",
      "Wymaga heated chamber",
      "Wysoki koszt",
      "Trudny w druku",
    ],
    brands: ["Polymaker", "3DXTech", "eSun", "Prusament", "MatterHackers"],
    priceRange: "180-300 PLN/kg",
    applications: ["Szyby", "Osłony", "Elementy oświetlenia", "Części techniczne", "Zamienniki szkła"],
    tips: [
      "Wymaga drukarki z temp. głowicy >280°C",
      "Komora musi być podgrzewana do 50-70°C",
      "Używaj kleju do stołu (koniecznie)",
      "Drukuj bardzo wolno",
    ],
  },
];

const comparisonData = [
  { property: "Wytrzymałość", pla: 60, petg: 75, abs: 85, tpu: 70, pa: 95, pc: 90 },
  { property: "Elastyczność", pla: 20, petg: 40, abs: 50, tpu: 95, pa: 60, pc: 40 },
  { property: "Odporność termiczna", pla: 30, petg: 60, abs: 85, tpu: 50, pa: 90, pc: 100 },
  { property: "Łatwość druku", pla: 95, petg: 80, abs: 50, tpu: 60, pa: 40, pc: 30 },
  { property: "Trwałość", pla: 50, petg: 80, abs: 90, tpu: 85, pa: 95, pc: 90 },
  { property: "Koszt (niższy=lepiej)", pla: 20, petg: 35, abs: 40, tpu: 60, pa: 80, pc: 90 },
];

export function MaterialProfiles() {
  const [selectedMaterial, setSelectedMaterial] = useState<string>("pla");
  const [viewMode, setViewMode] = useState<"cards" | "table">("cards");

  const material = materials.find((m) => m.id === selectedMaterial);

  return (
    <div className="space-y-6">
      {/* Material Selector */}
      <div className="flex flex-wrap gap-2">
        {materials.map((m) => (
          <button
            key={m.id}
            onClick={() => setSelectedMaterial(m.id)}
            className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center gap-2 ${
              selectedMaterial === m.id
                ? `bg-gradient-to-r ${m.gradient} text-white shadow-lg`
                : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-zinc-200"
            }`}
          >
            {m.icon}
            {m.name}
          </button>
        ))}
      </div>

      {/* View Mode Toggle */}
      <div className="flex gap-2">
        <button
          onClick={() => setViewMode("cards")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === "cards"
              ? "bg-zinc-700 text-white"
              : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
          }`}
        >
          Szczegóły materiału
        </button>
        <button
          onClick={() => setViewMode("table")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === "table"
              ? "bg-zinc-700 text-white"
              : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
          }`}
        >
          Tabela porównawcza
        </button>
      </div>

      {/* Content */}
      {viewMode === "cards" && material && (
        <motion.div
          key={material.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="space-y-6"
        >
          {/* Header Card */}
          <Card className={`bg-zinc-900 border-zinc-800 overflow-hidden`}>
            <div className={`h-2 bg-gradient-to-r ${material.gradient}`} />
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`${material.color}`}>{material.icon}</div>
                    <CardTitle className="text-2xl text-white">{material.name}</CardTitle>
                  </div>
                  <CardDescription className="text-zinc-400">
                    {material.fullName}
                  </CardDescription>
                </div>
                <Badge className={`${material.color.replace("text-", "bg-")} text-white`}>
                  {material.priceRange}
                </Badge>
              </div>
              <p className="text-zinc-300 mt-4">{material.description}</p>
            </CardHeader>
          </Card>

          {/* Properties Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {Object.entries(material.properties).map(([key, value]) => {
              const labels: Record<string, string> = {
                strength: "Wytrzymałość",
                flexibility: "Elastyczność",
                heatResistance: "Odporność termiczna",
                printability: "Łatwość druku",
                durability: "Trwałość",
                cost: "Koszt",
              };
              const colors: Record<string, string> = {
                strength: "bg-blue-500",
                flexibility: "bg-purple-500",
                heatResistance: "bg-amber-500",
                printability: "bg-emerald-500",
                durability: "bg-cyan-500",
                cost: "bg-rose-500",
              };
              return (
                <div key={key} className="bg-zinc-900 border border-zinc-800 rounded-lg p-4">
                  <p className="text-xs text-zinc-500 mb-2">{labels[key]}</p>
                  <div className="flex items-end gap-2">
                    <span className="text-2xl font-bold text-white">{value}</span>
                    <span className="text-xs text-zinc-500 mb-1">/100</span>
                  </div>
                  <Progress value={value} className={`h-2 mt-2 ${colors[key]}`} />
                </div>
              );
            })}
          </div>

          {/* Specs & Usage */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Technical Specs */}
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <Thermometer className="w-5 h-5 text-amber-500" />
                  Parametry Druku
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-800/50 rounded-lg p-3">
                    <p className="text-xs text-zinc-500">Temperatura dyszy</p>
                    <p className="font-semibold text-zinc-200">{material.specs.printTemp}</p>
                  </div>
                  <div className="bg-zinc-800/50 rounded-lg p-3">
                    <p className="text-xs text-zinc-500">Temperatura stołu</p>
                    <p className="font-semibold text-zinc-200">{material.specs.bedTemp}</p>
                  </div>
                  <div className="bg-zinc-800/50 rounded-lg p-3">
                    <p className="text-xs text-zinc-500">Komora</p>
                    <p className="font-semibold text-zinc-200">{material.specs.chamberTemp}</p>
                  </div>
                  <div className="bg-zinc-800/50 rounded-lg p-3">
                    <p className="text-xs text-zinc-500">Prędkość</p>
                    <p className="font-semibold text-zinc-200">{material.specs.speed}</p>
                  </div>
                </div>
                <div className="bg-zinc-800/50 rounded-lg p-3">
                  <p className="text-xs text-zinc-500">Chłodzenie</p>
                  <p className="font-semibold text-zinc-200">{material.specs.cooling}</p>
                </div>
              </CardContent>
            </Card>

            {/* When to Use */}
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                  Kiedy Używać
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-emerald-400 mb-2">Idealny dla:</p>
                  <ul className="space-y-1">
                    {material.whenToUse.map((item, i) => (
                      <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="text-sm font-medium text-rose-400 mb-2">Unikaj gdy:</p>
                  <ul className="space-y-1">
                    {material.whenNotToUse.map((item, i) => (
                      <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                        <XCircle className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Pros & Cons */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                  Zalety
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {material.pros.map((pro, i) => (
                    <li key={i} className="text-sm text-zinc-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-2 shrink-0" />
                      {pro}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                  Wady
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {material.cons.map((con, i) => (
                    <li key={i} className="text-sm text-zinc-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 shrink-0" />
                      {con}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Applications & Tips */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <Box className="w-5 h-5 text-blue-500" />
                  Zastosowania
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {material.applications.map((app, i) => (
                    <Badge key={i} variant="secondary" className="bg-zinc-800 text-zinc-300">
                      {app}
                    </Badge>
                  ))}
                </div>
                <div className="mt-4">
                  <p className="text-sm font-medium text-zinc-400 mb-2">Polecane marki:</p>
                  <div className="flex flex-wrap gap-2">
                    {material.brands.map((brand, i) => (
                      <Badge key={i} variant="outline" className="border-zinc-700 text-zinc-400">
                        {brand}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-lg text-white flex items-center gap-2">
                  <Info className="w-5 h-5 text-amber-500" />
                  Wskazówki Druku
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {material.tips.map((tip, i) => (
                    <li key={i} className="text-sm text-zinc-300 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      )}

      {/* Comparison Table */}
      {viewMode === "table" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle className="text-xl text-white">Tabela Porównawcza Materiałów</CardTitle>
              <CardDescription className="text-zinc-400">
                Skala 0-100, gdzie 100 to najlepsza wartość
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800">
                      <TableHead className="text-zinc-400">Właściwość</TableHead>
                      <TableHead className="text-emerald-400">PLA</TableHead>
                      <TableHead className="text-blue-400">PETG</TableHead>
                      <TableHead className="text-amber-400">ABS</TableHead>
                      <TableHead className="text-purple-400">TPU</TableHead>
                      <TableHead className="text-rose-400">PA</TableHead>
                      <TableHead className="text-cyan-400">PC</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {comparisonData.map((row, idx) => (
                      <TableRow key={idx} className="border-zinc-800">
                        <TableCell className="font-medium text-zinc-300">{row.property}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.pla} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.pla}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.petg} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.petg}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.abs} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.abs}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.tpu} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.tpu}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.pa} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.pa}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={row.pc} className="w-16 h-2" />
                            <span className="text-sm text-zinc-400">{row.pc}</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Quick Reference */}
              <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="bg-emerald-950/30 border border-emerald-900/50 rounded-lg p-4">
                  <p className="font-semibold text-emerald-400 mb-2">Dla początkujących</p>
                  <p className="text-sm text-zinc-400">PLA - najłatwiejszy w druku, idealny do nauki</p>
                </div>
                <div className="bg-blue-950/30 border border-blue-900/50 rounded-lg p-4">
                  <p className="font-semibold text-blue-400 mb-2">Uniwersalny wybór</p>
                  <p className="text-sm text-zinc-400">PETG - połączenie łatwości i wytrzymałości</p>
                </div>
                <div className="bg-amber-950/30 border border-amber-900/50 rounded-lg p-4">
                  <p className="font-semibold text-amber-400 mb-2">Wysokie temperatury</p>
                  <p className="text-sm text-zinc-400">ABS/ASA - wymaga zamkniętej komory</p>
                </div>
                <div className="bg-purple-950/30 border border-purple-900/50 rounded-lg p-4">
                  <p className="font-semibold text-purple-400 mb-2">Elastyczność</p>
                  <p className="text-sm text-zinc-400">TPU - uszczelki, opony, amortyzatory</p>
                </div>
                <div className="bg-rose-950/30 border border-rose-900/50 rounded-lg p-4">
                  <p className="font-semibold text-rose-400 mb-2">Maksymalna wytrzymałość</p>
                  <p className="text-sm text-zinc-400">PA (Nylon) - zastępstwo metalu</p>
                </div>
                <div className="bg-cyan-950/30 border border-cyan-900/50 rounded-lg p-4">
                  <p className="font-semibold text-cyan-400 mb-2">Przezroczystość</p>
                  <p className="text-sm text-zinc-400">PC - najwyższa odporność termiczna</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
